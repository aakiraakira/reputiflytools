document.addEventListener('DOMContentLoaded', () => {

	/* ─── Tab switching ─── */
	const tabs = document.querySelectorAll('.rspd-tab');
	tabs.forEach((tab) => {
		tab.addEventListener('click', () => {
			const target = tab.getAttribute('data-tab');
			tabs.forEach((t) => t.classList.remove('active'));
			tab.classList.add('active');
			document.querySelectorAll('.rspd-tab-content').forEach((c) => { c.style.display = 'none'; });
			const panel = document.getElementById('rspd-tab-' + target);
			if (panel) panel.style.display = '';
		});
	});
	const requestedTab = new URLSearchParams(window.location.search).get('tab');
	if (requestedTab) {
		const requestedButton = Array.from(tabs).find((tab) => tab.getAttribute('data-tab') === requestedTab);
		if (requestedButton) requestedButton.click();
	}

	/* ─── Paste tab: Page mode radio buttons ─── */
	const layoutPageCheckboxes = document.querySelectorAll('input[name="layout_injections[page_ids][]"]');
	const layoutSelectionCount = document.querySelector('[data-layout-selection-count]');
	const layoutSelectionChips = document.querySelector('[data-layout-selection-chips]');
	const layoutSelectAllBtn = document.querySelector('[data-layout-select-all]');
	const layoutClearAllBtn = document.querySelector('[data-layout-clear-all]');
	const layoutPageCards = document.querySelectorAll('.rspd-layout-page-card');

	function updateLayoutSelectionSummary() {
		if (!layoutPageCheckboxes.length || !layoutSelectionCount || !layoutSelectionChips) return;

		const selected = [];

		Array.from(layoutPageCheckboxes).forEach((input) => {
			const card = input.closest('.rspd-layout-page-card');
			const title = card ? card.querySelector('strong') : null;
			const status = card ? card.querySelector('.rspd-layout-page-status') : null;

			if (card) {
				card.classList.toggle('is-selected', input.checked);
			}

			if (status) {
				status.textContent = input.checked ? 'Applied' : 'Not Applied';
			}

			if (input.checked && title) {
				selected.push(title.textContent.trim());
			}
		});

		layoutSelectionCount.textContent = `${selected.length} page${selected.length === 1 ? '' : 's'} selected`;
		layoutSelectionChips.innerHTML = selected.length
			? selected.map((title) => `<span class="rspd-layout-selection-chip">${title}</span>`).join('')
			: '<span class="rspd-layout-selection-empty">No pages selected yet.</span>';
	}

	layoutPageCheckboxes.forEach((input) => {
		input.addEventListener('change', updateLayoutSelectionSummary);
	});
	updateLayoutSelectionSummary();

	layoutPageCards.forEach((card) => {
		const inner = card.querySelector('.rspd-layout-page-card-inner');
		const input = card.querySelector('.rspd-layout-page-checkbox');
		if (!inner || !input) return;

		inner.addEventListener('click', (event) => {
			if (event.target.closest('input, button, a')) return;
			event.preventDefault();
			input.checked = !input.checked;
			input.dispatchEvent(new Event('change', { bubbles: true }));
		});
	});

	if (layoutSelectAllBtn) {
		layoutSelectAllBtn.addEventListener('click', () => {
			layoutPageCheckboxes.forEach((input) => {
				input.checked = true;
				input.dispatchEvent(new Event('change', { bubbles: true }));
			});
		});
	}

	if (layoutClearAllBtn) {
		layoutClearAllBtn.addEventListener('click', () => {
			layoutPageCheckboxes.forEach((input) => {
				input.checked = false;
				input.dispatchEvent(new Event('change', { bubbles: true }));
			});
		});
	}

	const toolsPageCheckboxes = document.querySelectorAll('input[name="replace_tools[page_ids][]"]');
	const toolsSelectionCount = document.querySelector('[data-tools-selection-count]');
	const toolsSelectionChips = document.querySelector('[data-tools-selection-chips]');
	const toolsSelectAllBtn = document.querySelector('[data-tools-select-all]');
	const toolsClearAllBtn = document.querySelector('[data-tools-clear-all]');

	function updateToolsSelectionSummary() {
		if (!toolsPageCheckboxes.length || !toolsSelectionCount || !toolsSelectionChips) return;

		const selected = Array.from(toolsPageCheckboxes)
			.filter((input) => input.checked)
			.map((input) => {
				const card = input.closest('.rspd-layout-page-card');
				const title = card ? card.querySelector('strong') : null;
				const status = card ? card.querySelector('.rspd-layout-page-status') : null;
				if (status) status.textContent = input.checked ? 'Selected' : 'Not Selected';
				return title ? title.textContent.trim() : '';
			})
			.filter(Boolean);

		toolsSelectionCount.textContent = `${selected.length} page${selected.length === 1 ? '' : 's'} selected`;
		toolsSelectionChips.innerHTML = selected.length
			? selected.map((title) => `<span class="rspd-layout-selection-chip">${title}</span>`).join('')
			: '<span class="rspd-layout-selection-empty">No pages selected yet.</span>';
	}

	toolsPageCheckboxes.forEach((input) => {
		input.addEventListener('change', updateToolsSelectionSummary);
	});

	if (toolsSelectAllBtn) {
		toolsSelectAllBtn.addEventListener('click', () => {
			toolsPageCheckboxes.forEach((input) => {
				input.checked = true;
				input.dispatchEvent(new Event('change', { bubbles: true }));
			});
		});
	}

	if (toolsClearAllBtn) {
		toolsClearAllBtn.addEventListener('click', () => {
			toolsPageCheckboxes.forEach((input) => {
				input.checked = false;
				input.dispatchEvent(new Event('change', { bubbles: true }));
			});
		});
	}

	updateToolsSelectionSummary();

	const labsCards = document.querySelectorAll('[data-labs-card]');
	const labsSelectionCount = document.querySelector('[data-labs-selection-count]');
	const labsSelectionChips = document.querySelector('[data-labs-selection-chips]');
	const labsSelectAllBtn = document.querySelector('[data-labs-select-all]');
	const labsClearAllBtn = document.querySelector('[data-labs-clear-all]');
	const labsPreflightSummary = document.querySelector('[data-labs-preflight-summary]');

	function updateLabsTargetFields(card) {
		if (!card) return;
		const selectedTarget = card.querySelector('.rspd-labs-target-radio:checked');
		const selectedMode = selectedTarget ? selectedTarget.value : 'create_new';
		const createFields = card.querySelector('[data-labs-target-create]');
		const existingFields = card.querySelector('[data-labs-target-existing]');
		const inPlaceFields = card.querySelector('[data-labs-target-in-place]');

		if (createFields) createFields.style.display = selectedMode === 'create_new' ? '' : 'none';
		if (existingFields) existingFields.style.display = selectedMode === 'existing' ? '' : 'none';
		if (inPlaceFields) inPlaceFields.style.display = selectedMode === 'in_place' ? '' : 'none';
	}

	function updateLabsSelectionSummary() {
		if (!labsCards.length || !labsSelectionCount || !labsSelectionChips) return;

		const selectedTitles = [];
		const modeCounts = {
			create_new: 0,
			existing: 0,
			in_place: 0,
		};

		labsCards.forEach((card) => {
			const checkbox = card.querySelector('.rspd-labs-source-checkbox');
			const title = card.getAttribute('data-source-title') || '';
			const checkedRadio = card.querySelector('.rspd-labs-target-radio:checked');
			const selectedMode = checkedRadio ? checkedRadio.value : 'create_new';

			card.classList.toggle('is-selected', !!(checkbox && checkbox.checked));

			if (checkbox && checkbox.checked) {
				selectedTitles.push(title);
				if (Object.prototype.hasOwnProperty.call(modeCounts, selectedMode)) {
					modeCounts[selectedMode] += 1;
				}
			}
		});

		labsSelectionCount.textContent = `${selectedTitles.length} page${selectedTitles.length === 1 ? '' : 's'} selected`;
		labsSelectionChips.innerHTML = selectedTitles.length
			? selectedTitles.map((title) => `<span class="rspd-layout-selection-chip">${escHtml(title)}</span>`).join('')
			: '<span class="rspd-layout-selection-empty">No Elementor pages selected yet.</span>';

		if (labsPreflightSummary) {
			if (!selectedTitles.length) {
				labsPreflightSummary.textContent = 'Select the Elementor pages you want to convert. Internal links between selected source pages will be rewritten to the final Archimedes targets when matches are found.';
			} else {
				const parts = [];
				if (modeCounts.create_new) parts.push(`${modeCounts.create_new} create new`);
				if (modeCounts.existing) parts.push(`${modeCounts.existing} deploy to existing`);
				if (modeCounts.in_place) parts.push(`${modeCounts.in_place} convert in place`);
				labsPreflightSummary.textContent = `${selectedTitles.length} Elementor page${selectedTitles.length === 1 ? '' : 's'} ready. Modes: ${parts.join(', ')}. Internal links between selected source pages will be rewritten to the new Archimedes targets when matches are found.`;
			}
		}
	}

	labsCards.forEach((card) => {
		const checkbox = card.querySelector('.rspd-labs-source-checkbox');
		const radios = card.querySelectorAll('.rspd-labs-target-radio');
		const titleInput = card.querySelector('.rspd-labs-target-title');
		const slugInput = card.querySelector('.rspd-labs-target-slug');

		updateLabsTargetFields(card);

		if (checkbox) {
			checkbox.addEventListener('change', updateLabsSelectionSummary);
		}

		radios.forEach((radio) => {
			radio.addEventListener('change', () => {
				updateLabsTargetFields(card);
				updateLabsSelectionSummary();
			});
		});

		if (titleInput && slugInput) {
			slugInput.dataset.userEdited = 'false';
			slugInput.addEventListener('input', () => {
				slugInput.dataset.userEdited = 'true';
			});
			titleInput.addEventListener('input', () => {
				if (slugInput.dataset.userEdited === 'true') return;
				slugInput.value = slugify(titleInput.value || '');
			});
		}

		card.addEventListener('click', (event) => {
			if (event.target.closest('input, select, textarea, button, a, label')) return;
			if (!checkbox) return;
			checkbox.checked = !checkbox.checked;
			checkbox.dispatchEvent(new Event('change', { bubbles: true }));
		});
	});

	if (labsSelectAllBtn) {
		labsSelectAllBtn.addEventListener('click', () => {
			labsCards.forEach((card) => {
				const checkbox = card.querySelector('.rspd-labs-source-checkbox');
				if (!checkbox) return;
				checkbox.checked = true;
				checkbox.dispatchEvent(new Event('change', { bubbles: true }));
			});
		});
	}

	if (labsClearAllBtn) {
		labsClearAllBtn.addEventListener('click', () => {
			labsCards.forEach((card) => {
				const checkbox = card.querySelector('.rspd-labs-source-checkbox');
				if (!checkbox) return;
				checkbox.checked = false;
				checkbox.dispatchEvent(new Event('change', { bubbles: true }));
			});
		});
	}

	updateLabsSelectionSummary();

	const radioExisting = document.getElementById('rspd-mode-existing');
	const radioNew = document.getElementById('rspd-mode-new');
	const pageSelect = document.getElementById('rspd-page-select');
	const newTitle = document.getElementById('rspd-new-title');

	function syncPageMode() {
		if (!radioExisting || !radioNew) return;
		const isNew = radioNew.checked;
		if (pageSelect) pageSelect.disabled = isNew;
		if (newTitle) newTitle.disabled = !isNew;
	}
	if (radioExisting) radioExisting.addEventListener('change', syncPageMode);
	if (radioNew) radioNew.addEventListener('change', syncPageMode);
	syncPageMode();

	/* ─── Upload tab: ZIP scan + multi-deploy ─── */
	const dropZone = document.getElementById('rspd-drop-zone');
	const fileInput = document.getElementById('rspd-file-input');
	const folderInput = document.getElementById('rspd-folder-input');
	const browseFilesBtn = document.getElementById('rspd-upload-browse-btn');
	const browseFolderBtn = document.getElementById('rspd-upload-browse-folder-btn');
	const scanStatus = document.getElementById('rspd-scan-status');
	const uploadStep = document.getElementById('rspd-upload-step');
	const multiDeploy = document.getElementById('rspd-multi-deploy');
	const fileList = document.getElementById('rspd-file-list');
	const deployAllBtn = document.getElementById('rspd-deploy-all-btn');
	const resetBtn = document.getElementById('rspd-upload-reset');
	const deployProgress = document.getElementById('rspd-deploy-progress');
	const uploadModePages = document.getElementById('rspd-upload-mode-pages');
	const uploadModeSoftware = document.getElementById('rspd-upload-mode-software');
	const softwareOptions = document.getElementById('rspd-software-options');
	const softwareSlugInput = document.getElementById('rspd-software-slug');
	const softwareEntrySelect = document.getElementById('rspd-software-entry');
	const softwareValidation = document.getElementById('rspd-software-validation');

	let scanTempKey = '';
	let scanImageCount = 0;
	let scanImageSize = 0;
	let scanGdAvailable = false;

	if (!window.rspdData) return; // No AJAX data, bail.
	const existingPages = Array.isArray(rspdData.pages) ? rspdData.pages : [];
	const existingSoftwareApps = Array.isArray(rspdData.softwareApps) ? rspdData.softwareApps : [];

	/* ─── Helpers ─── */

	function buildPageOptions(selectedId) {
		let html = '<option value="">— Select a page —</option>';
		existingPages.forEach((p) => {
			const sel = p.id == selectedId ? ' selected' : '';
			html += '<option value="' + p.id + '"' + sel + '>' + escHtml(p.title) + '</option>';
		});
		return html;
	}

	function escHtml(str) {
		const d = document.createElement('div');
		d.textContent = str;
		return d.innerHTML;
	}

	function filenameToTitle(filename) {
		let name = filename.replace(/^.*[\\/]/, '').replace(/\.(html?|htm)$/i, '');
		name = name.replace(/[-_]+/g, ' ');
		return name.replace(/\b\w/g, (c) => c.toUpperCase());
	}

	function normalizeText(value) {
		return String(value || '').trim().toLowerCase();
	}

	function slugify(value) {
		return normalizeText(value)
			.replace(/&/g, ' and ')
			.replace(/[^a-z0-9]+/g, '-')
			.replace(/^-+|-+$/g, '');
	}

	function deriveSlugFromFile(file, fallbackTitle) {
		let htmlFile = String(file || '').replace(/\\/g, '/').replace(/\.(html?|htm)$/i, '').replace(/^\/+|\/+$/g, '');
		if (!htmlFile) return slugify(fallbackTitle || 'index');

		let segments = htmlFile.split('/').filter(Boolean);
		if (!segments.length) return slugify(fallbackTitle || 'index');

		const lastSegment = segments[segments.length - 1];
		if (String(lastSegment).toLowerCase() === 'index') {
			segments.pop();
		}

		if (!segments.length) return slugify(fallbackTitle || 'index');
		return slugify(segments.join('-'));
	}

	function findExistingPageBySlug(slug) {
		return existingPages.find((page) => normalizeText(page.slug) === normalizeText(slug)) || null;
	}

	function findExistingPageByTitle(title) {
		return existingPages.find((page) => normalizeText(page.title) === normalizeText(title)) || null;
	}

	function findExistingSoftwareAppBySlug(slug) {
		return existingSoftwareApps.find((app) => normalizeText(app.slug) === normalizeText(slug)) || null;
	}

	function getUploadDeploymentType() {
		return uploadModeSoftware && uploadModeSoftware.checked ? 'software_app' : 'website_pages';
	}

	function populateSoftwareEntryOptions(files) {
		if (!softwareEntrySelect) return;
		const currentValue = String(softwareEntrySelect.value || '').trim();
		const html = [];
		(files || []).forEach((file) => {
			html.push('<option value="' + escHtml(file) + '">' + escHtml(file) + '</option>');
		});
		softwareEntrySelect.innerHTML = html.join('');
		const preferred = (files || []).find((file) => String(file).toLowerCase() === 'index.html')
			|| (files || []).find((file) => /(^|\/)index\.html$/i.test(String(file)))
			|| (files || [])[0]
			|| '';
		const hasCurrentValue = currentValue && (files || []).some((file) => String(file) === currentValue);
		softwareEntrySelect.value = hasCurrentValue ? currentValue : preferred;
	}

	function setSoftwareValidation() {
		if (!softwareValidation) return { ok: true, replaceExisting: false };
		if (getUploadDeploymentType() !== 'software_app') {
			softwareValidation.innerHTML = '';
			softwareValidation.style.display = 'none';
			return { ok: true, replaceExisting: false };
		}

		const rawSlug = softwareSlugInput ? softwareSlugInput.value : '';
		const slug = slugify(rawSlug);
		const entryFile = softwareEntrySelect ? String(softwareEntrySelect.value || '').trim() : '';
		const errors = [];
		const warnings = [];
		const info = [];
		let replaceExisting = false;

		if (!slug) {
			errors.push('Add a parent folder slug before deploying the software app.');
		} else {
			info.push('App will go live at /' + slug + '/');
			const pageConflict = findExistingPageBySlug(slug);
			const softwareConflict = findExistingSoftwareAppBySlug(slug);

			if (pageConflict) {
				errors.push('That folder conflicts with the existing page "' + pageConflict.title + '".');
			} else if (softwareConflict) {
				replaceExisting = true;
				warnings.push('An app already exists at /' + slug + '/. Deploying again will replace it.');
			}
		}

		if (!entryFile) {
			errors.push('Choose the HTML entry file for the software app.');
		} else {
			info.push('Root request will open ' + entryFile);
		}

		const lines = [];
		info.forEach((message) => {
			lines.push('<div class="rspd-file-validation-item rspd-file-validation-item--info">' + escHtml(message) + '</div>');
		});
		errors.forEach((message) => {
			lines.push('<div class="rspd-file-validation-item rspd-file-validation-item--error">' + escHtml(message) + '</div>');
		});
		warnings.forEach((message) => {
			lines.push('<div class="rspd-file-validation-item rspd-file-validation-item--warning">' + escHtml(message) + '</div>');
		});

		softwareValidation.innerHTML = lines.join('');
		softwareValidation.style.display = lines.length ? '' : 'none';

		return {
			ok: errors.length === 0,
			replaceExisting: replaceExisting
		};
	}

	function syncUploadDeploymentType() {
		const isSoftware = getUploadDeploymentType() === 'software_app';
		if (softwareOptions) softwareOptions.style.display = isSoftware && scanTempKey ? '' : 'none';
		if (fileList) fileList.style.display = isSoftware ? 'none' : '';
		if (deployAllBtn) deployAllBtn.textContent = isSoftware ? 'Deploy Software App' : 'Deploy Selected';

		const deployOptions = multiDeploy ? multiDeploy.querySelector('.rspd-deploy-options') : null;
		if (deployOptions) deployOptions.style.display = isSoftware ? 'none' : '';

		if (isSoftware) {
			setSoftwareValidation();
		}
	}

	function setCardValidation(card) {
		const validation = card.querySelector('.rspd-file-validation');
		if (!validation) return { ok: true, warnings: [] };

		const modeRadio = card.querySelector('.rspd-fmode-radio:checked');
		const mode = modeRadio ? modeRadio.value : 'new';
		const file = card.getAttribute('data-file') || '';
		const titleInput = card.querySelector('.rspd-file-new-title');
		const selectInput = card.querySelector('.rspd-file-page-select');
		const title = titleInput ? titleInput.value.trim() : '';
		const pageId = selectInput ? String(selectInput.value || '') : '';
		const errors = [];
		const warnings = [];
		let info = '';

		card.classList.remove('has-error', 'has-warning');

		if (card.getAttribute('data-enabled') !== '1') {
			validation.innerHTML = '';
			validation.style.display = 'none';
			return { ok: true, warnings: [] };
		}

		if (mode === 'new') {
			if (!title) {
				errors.push('Add a page title before deploying this file.');
			} else {
				const slug = deriveSlugFromFile(file, title);
				info = 'Will create /' + slug + '/';
				const slugConflict = findExistingPageBySlug(slug);
				const titleConflict = findExistingPageByTitle(title);

				if (slugConflict) {
					errors.push('Slug /' + slug + '/ already exists on "' + slugConflict.title + '". Use "Assign to existing page" or change the title.');
				} else if (titleConflict) {
					warnings.push('A page titled "' + titleConflict.title + '" already exists. Double-check that you want a new page.');
				}
			}
		} else if (!pageId) {
			errors.push('Choose the existing page that this file should deploy onto.');
		} else {
			const selectedPage = existingPages.find((page) => String(page.id) === pageId);
			if (selectedPage) {
				info = 'Will deploy onto ' + selectedPage.title;
			}
		}

		const lines = [];
		if (info) {
			lines.push('<div class="rspd-file-validation-item rspd-file-validation-item--info">' + escHtml(info) + '</div>');
		}
		errors.forEach((message) => {
			lines.push('<div class="rspd-file-validation-item rspd-file-validation-item--error">' + escHtml(message) + '</div>');
		});
		warnings.forEach((message) => {
			lines.push('<div class="rspd-file-validation-item rspd-file-validation-item--warning">' + escHtml(message) + '</div>');
		});

		validation.innerHTML = lines.join('');
		validation.style.display = lines.length ? '' : 'none';

		if (errors.length) {
			card.classList.add('has-error');
		} else if (warnings.length) {
			card.classList.add('has-warning');
		}

		return {
			ok: errors.length === 0,
			warnings: warnings
		};
	}

	function formatBytes(bytes) {
		if (bytes === 0) return '0 B';
		if (bytes < 1024) return bytes + ' B';
		if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
		return (bytes / 1048576).toFixed(1) + ' MB';
	}

	function openFilePicker() {
		if (!fileInput) return;
		fileInput.value = '';
		fileInput.click();
	}

	function openFolderPicker() {
		if (!folderInput) return;
		folderInput.value = '';
		folderInput.click();
	}

	if (uploadModePages) uploadModePages.addEventListener('change', syncUploadDeploymentType);
	if (uploadModeSoftware) uploadModeSoftware.addEventListener('change', syncUploadDeploymentType);
	if (softwareSlugInput) {
		softwareSlugInput.addEventListener('input', () => {
			const cleaned = slugify(softwareSlugInput.value);
			if (softwareSlugInput.value !== cleaned) {
				softwareSlugInput.value = cleaned;
			}
			setSoftwareValidation();
		});
	}
	if (softwareEntrySelect) softwareEntrySelect.addEventListener('change', setSoftwareValidation);
	syncUploadDeploymentType();

	/* ─── Scan summary + deploy options (injected by JS after scan) ─── */

	function renderScanSummary(fileCount) {
		// Remove any existing summary/options.
		const existing = multiDeploy.querySelector('.rspd-scan-summary');
		if (existing) existing.remove();
		const existingOpts = multiDeploy.querySelector('.rspd-deploy-options');
		if (existingOpts) existingOpts.remove();

		// Summary bar.
		const summary = document.createElement('div');
		summary.className = 'rspd-scan-summary';
		let text = fileCount + ' HTML page' + (fileCount !== 1 ? 's' : '');
		if (scanImageCount > 0) {
			text += ' &nbsp;&bull;&nbsp; ' + scanImageCount + ' image' + (scanImageCount !== 1 ? 's' : '') + ' (' + formatBytes(scanImageSize) + ')';
		}
		summary.innerHTML = text;
		multiDeploy.insertBefore(summary, fileList);

		// Deploy options panel (WebP toggle).
		if (scanImageCount > 0 && scanGdAvailable) {
			const opts = document.createElement('div');
			opts.className = 'rspd-deploy-options';
			opts.innerHTML =
				'<label class="rspd-webp-toggle">' +
					'<input type="checkbox" id="rspd-webp-convert" checked>' +
					'<span class="rspd-toggle-track"><span class="rspd-toggle-thumb"></span></span>' +
					'<span class="rspd-toggle-label">' +
						'Convert images to WebP' +
						'<span class="rspd-toggle-desc">Reduces image file sizes for faster page loads</span>' +
					'</span>' +
				'</label>';
			multiDeploy.insertBefore(opts, fileList.nextSibling);
		}
	}

	/* ─── File list rendering ─── */

	function renderFileList(files) {
		fileList.innerHTML = '';
		files.forEach((file, idx) => {
			const suggestedTitle = filenameToTitle(file);
			const card = document.createElement('div');
			card.className = 'rspd-file-card';
			card.setAttribute('data-file', file);
			card.setAttribute('data-enabled', '1');
			card.innerHTML =
				'<div class="rspd-file-card-head">' +
					'<div class="rspd-file-name-label">' + escHtml(file) + '</div>' +
					'<button type="button" class="rspd-file-toggle rspd-btn-sm" title="Skip this file">Skip</button>' +
				'</div>' +
				'<div class="rspd-file-card-body">' +
					'<div class="rspd-file-mode">' +
						'<label><input type="radio" name="fmode_' + idx + '" value="new" checked class="rspd-radio rspd-fmode-radio"> Create new page</label>' +
						'<input type="text" class="rspd-input rspd-file-new-title" value="' + escHtml(suggestedTitle) + '" placeholder="Page title...">' +
					'</div>' +
					'<div class="rspd-file-mode">' +
						'<label><input type="radio" name="fmode_' + idx + '" value="existing" class="rspd-radio rspd-fmode-radio"> Assign to existing page</label>' +
						'<select class="rspd-select rspd-file-page-select" disabled>' + buildPageOptions('') + '</select>' +
					'</div>' +
					'<div class="rspd-file-validation" style="display:none;"></div>' +
				'</div>';
			fileList.appendChild(card);

			// Toggle skip.
			const toggleBtn = card.querySelector('.rspd-file-toggle');
			const body = card.querySelector('.rspd-file-card-body');
			toggleBtn.addEventListener('click', () => {
				const enabled = card.getAttribute('data-enabled') === '1';
				card.setAttribute('data-enabled', enabled ? '0' : '1');
				toggleBtn.textContent = enabled ? 'Include' : 'Skip';
				card.classList.toggle('is-skipped', enabled);
				body.style.display = enabled ? 'none' : '';
			});

			// Radio toggle.
			const radios = card.querySelectorAll('.rspd-fmode-radio');
			const titleInput = card.querySelector('.rspd-file-new-title');
			const selectInput = card.querySelector('.rspd-file-page-select');
			radios.forEach((r) => {
				r.addEventListener('change', () => {
					const isNew = r.value === 'new' && r.checked;
					titleInput.disabled = !isNew;
					selectInput.disabled = isNew;
					setCardValidation(card);
				});
			});
			if (titleInput) titleInput.addEventListener('input', () => setCardValidation(card));
			if (selectInput) selectInput.addEventListener('change', () => setCardValidation(card));
			setCardValidation(card);
		});
	}

	/* ─── File upload handler ─── */

	function handleFileUpload(file) {
		if (!file) return;
		uploadStep.querySelector('.rspd-upload-zone').style.display = 'none';
		scanStatus.style.display = '';
		scanStatus.innerHTML = '<p style="color:var(--rspd-text-muted);">Scanning <strong>' + escHtml(file.name) + '</strong>...</p>';

		const fd = new FormData();
		fd.append('action', 'rspd_scan_zip');
		fd.append('nonce', rspdData.scanNonce);
		fd.append('zip_file', file);

		fetch(rspdData.ajaxUrl, { method: 'POST', body: fd })
			.then((r) => r.json())
			.then((res) => {
				if (res.success) {
					scanTempKey = res.data.temp_key;
					scanImageCount = res.data.image_count || 0;
					scanImageSize = res.data.total_image_size || 0;
					scanGdAvailable = !!res.data.gd_available;
					renderFileList(res.data.files);
					populateSoftwareEntryOptions(res.data.files);
					renderScanSummary(res.data.files.length);
					uploadStep.style.display = 'none';
					multiDeploy.style.display = '';
					syncUploadDeploymentType();
				} else {
					scanStatus.innerHTML = '<p style="color:var(--rspd-red);">' + escHtml(res.data || 'Scan failed.') + '</p>';
					uploadStep.querySelector('.rspd-upload-zone').style.display = '';
				}
			})
			.catch(() => {
				scanStatus.innerHTML = '<p style="color:var(--rspd-red);">Upload failed. Please try again.</p>';
				uploadStep.querySelector('.rspd-upload-zone').style.display = '';
			});
	}

	if (fileInput) {
		fileInput.addEventListener('change', () => {
			if (fileInput.files.length) handleFileUpload(fileInput.files[0]);
		});
	}

	if (folderInput) {
		folderInput.addEventListener('change', () => {
			const files = Array.from(folderInput.files || []);
			if (!files.length) return;
			const fileEntries = files.map((file) => ({
				file: file,
				path: String(file.webkitRelativePath || file.name || '').replace(/\\/g, '/').replace(/^\/+/, '')
			})).filter((entry) => entry.path);
			if (fileEntries.length) handleFolderUpload(fileEntries);
		});
	}

	/* ─── Folder drop support ─── */

	function readAllEntries(dirReader) {
		return new Promise((resolve) => {
			const all = [];
			(function read() {
				dirReader.readEntries((entries) => {
					if (!entries.length) return resolve(all);
					all.push(...entries);
					read();
				});
			})();
		});
	}

	function traverseEntry(entry, path) {
		return new Promise((resolve) => {
			if (entry.isFile) {
				entry.file((f) => resolve([{ file: f, path: path + f.name }]));
			} else if (entry.isDirectory) {
				readAllEntries(entry.createReader()).then((entries) => {
					Promise.all(entries.map((e) => traverseEntry(e, path + entry.name + '/'))).then((arrs) => {
						resolve(arrs.flat());
					});
				});
			} else {
				resolve([]);
			}
		});
	}

	function handleFolderUpload(fileEntries) {
		uploadStep.querySelector('.rspd-upload-zone').style.display = 'none';
		scanStatus.style.display = '';
		scanStatus.innerHTML = '<p style="color:var(--rspd-text-muted);">Scanning folder (' + fileEntries.length + ' files)...</p>';

		const fd = new FormData();
		fd.append('action', 'rspd_scan_folder');
		fd.append('nonce', rspdData.folderNonce);
		fileEntries.forEach((entry, i) => {
			fd.append('files[' + i + ']', entry.file, entry.file.name);
			fd.append('paths[' + i + ']', entry.path);
		});

		fetch(rspdData.ajaxUrl, { method: 'POST', body: fd })
			.then((r) => r.json())
			.then((res) => {
				if (res.success) {
					scanTempKey = res.data.temp_key;
					scanImageCount = res.data.image_count || 0;
					scanImageSize = res.data.total_image_size || 0;
					scanGdAvailable = !!res.data.gd_available;
					renderFileList(res.data.files);
					populateSoftwareEntryOptions(res.data.files);
					renderScanSummary(res.data.files.length);
					uploadStep.style.display = 'none';
					multiDeploy.style.display = '';
					syncUploadDeploymentType();
				} else {
					scanStatus.innerHTML = '<p style="color:var(--rspd-red);">' + escHtml(res.data || 'Scan failed.') + '</p>';
					uploadStep.querySelector('.rspd-upload-zone').style.display = '';
				}
			})
			.catch(() => {
				scanStatus.innerHTML = '<p style="color:var(--rspd-red);">Upload failed. Please try again.</p>';
				uploadStep.querySelector('.rspd-upload-zone').style.display = '';
			});
	}

	if (dropZone) {
		dropZone.addEventListener('click', (e) => {
			if (e.target === browseFolderBtn || e.target === browseFilesBtn) return;
			openFilePicker();
		});
		dropZone.addEventListener('keydown', (e) => {
			if (e.key === 'Enter' || e.key === ' ') {
				e.preventDefault();
				openFilePicker();
			}
		});
		dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('dragover'); });
		dropZone.addEventListener('dragleave', () => { dropZone.classList.remove('dragover'); });
		dropZone.addEventListener('drop', (e) => {
			e.preventDefault();
			dropZone.classList.remove('dragover');

			// Check if a folder was dropped using webkitGetAsEntry.
			const items = e.dataTransfer.items;
			if (items && items.length) {
				const firstEntry = items[0].webkitGetAsEntry && items[0].webkitGetAsEntry();
				if (firstEntry && firstEntry.isDirectory) {
					// Folder drop — traverse recursively.
					traverseEntry(firstEntry, '').then((fileEntries) => {
						if (fileEntries.length) handleFolderUpload(fileEntries);
					});
					return;
				}
			}

			// Regular file drop.
			if (e.dataTransfer.files.length) handleFileUpload(e.dataTransfer.files[0]);
		});
	}

	if (browseFilesBtn) {
		browseFilesBtn.addEventListener('click', (e) => {
			e.preventDefault();
			e.stopPropagation();
			openFilePicker();
		});
	}

	if (browseFolderBtn) {
		browseFolderBtn.addEventListener('click', (e) => {
			e.preventDefault();
			e.stopPropagation();
			openFolderPicker();
		});
	}

	// Reset button.
	if (resetBtn) {
		resetBtn.addEventListener('click', () => {
			multiDeploy.style.display = 'none';
			uploadStep.style.display = '';
			uploadStep.querySelector('.rspd-upload-zone').style.display = '';
			scanStatus.style.display = 'none';
			fileList.innerHTML = '';
			deployProgress.style.display = 'none';
			deployProgress.innerHTML = '';
			if (fileInput) fileInput.value = '';
			if (folderInput) folderInput.value = '';
			if (softwareSlugInput) softwareSlugInput.value = '';
			if (softwareEntrySelect) softwareEntrySelect.innerHTML = '';
			if (softwareValidation) {
				softwareValidation.innerHTML = '';
				softwareValidation.style.display = 'none';
			}
			scanTempKey = '';
			scanImageCount = 0;
			scanImageSize = 0;
			// Remove dynamic elements.
			const s = multiDeploy.querySelector('.rspd-scan-summary');
			if (s) s.remove();
			const o = multiDeploy.querySelector('.rspd-deploy-options');
			if (o) o.remove();
			syncUploadDeploymentType();
		});
	}

	/* ─── Deploy all selected ─── */

	if (deployAllBtn) {
		deployAllBtn.addEventListener('click', () => {
			const cards = fileList.querySelectorAll('.rspd-file-card');
			const items = [];
			let hasBlockingErrors = false;
			let firstInvalidCard = null;
			const deploymentType = getUploadDeploymentType();

			if (deploymentType === 'software_app') {
				const validation = setSoftwareValidation();
				if (!validation.ok) {
					deployProgress.style.display = '';
					deployProgress.innerHTML = '<p style="color:var(--rspd-red);">Fix the highlighted software app issues before deploying.</p>';
					return;
				}

				const softwareSlug = slugify(softwareSlugInput ? softwareSlugInput.value : '');
				const softwareEntryFile = softwareEntrySelect ? String(softwareEntrySelect.value || '').trim() : '';

				deployAllBtn.disabled = true;
				deployAllBtn.textContent = 'Deploying...';
				deployProgress.style.display = '';
				deployProgress.innerHTML = '<p style="color:var(--rspd-text-muted);">Deploying software app to /' + escHtml(softwareSlug) + '/...</p>';

				const fd = new FormData();
				fd.append('action', 'rspd_deploy_multi');
				fd.append('nonce', rspdData.deployNonce);
				fd.append('temp_key', scanTempKey);
				fd.append('deployment_type', 'software_app');
				fd.append('software_slug', softwareSlug);
				fd.append('software_entry_file', softwareEntryFile);

				fetch(rspdData.ajaxUrl, { method: 'POST', body: fd })
					.then((r) => r.json())
					.then((res) => {
						if (res.success && res.data && res.data.type === 'software_app' && res.data.result) {
							const result = res.data.result;
							let html = '<h3 style="margin-bottom:12px;">Software App Deployed</h3>';
							html += '<div class="rspd-result-ok"><strong>Mount</strong> &rarr; <a href="' + escHtml(result.url) + '" target="_blank">' + escHtml(result.url) + '</a></div>';
							html += '<div class="rspd-result-ok"><strong>Entry</strong> &rarr; ' + escHtml(result.entry_file) + '</div>';
							html += '<div class="rspd-file-validation-item rspd-file-validation-item--info">This is a mounted software app, so it will appear in the plugin dashboard under Software Apps, not in WordPress Pages.</div>';
							if (Array.isArray(result.routes) && result.routes.length) {
								html += '<div style="margin-top:12px;"><strong>Live routes</strong></div>';
								result.routes.forEach((route) => {
									html += '<div class="rspd-result-ok"><strong>' + escHtml(route.file) + '</strong> &rarr; <a href="' + escHtml(route.url) + '" target="_blank">' + escHtml(route.url) + '</a></div>';
								});
							}
							if (result.replaced) {
								html += '<div class="rspd-file-validation-item rspd-file-validation-item--warning">Replaced the previous software app mounted at /' + escHtml(result.slug) + '/.</div>';
							}
							html += '<div style="margin-top:16px;"><a href="' + escHtml(result.url) + '" target="_blank" class="rspd-btn-deploy" style="text-decoration:none !important;display:inline-block;">Open Software App</a></div>';
							deployProgress.innerHTML = html;
							if (softwareOptions) softwareOptions.style.display = 'none';
							fileList.style.display = 'none';
							deployAllBtn.style.display = 'none';
							if (resetBtn) resetBtn.style.display = 'none';
							const opts = multiDeploy.querySelector('.rspd-deploy-options');
							if (opts) opts.style.display = 'none';
							const summ = multiDeploy.querySelector('.rspd-scan-summary');
							if (summ) summ.style.display = 'none';
						} else {
							deployProgress.innerHTML = '<p style="color:var(--rspd-red);">' + escHtml((res && res.data) || 'Deploy failed.') + '</p>';
							deployAllBtn.disabled = false;
							deployAllBtn.textContent = 'Deploy Software App';
						}
					})
					.catch(() => {
						deployProgress.innerHTML = '<p style="color:var(--rspd-red);">Deploy request failed. Please try again.</p>';
						deployAllBtn.disabled = false;
						deployAllBtn.textContent = 'Deploy Software App';
					});
				return;
			}

			cards.forEach((card) => {
				if (card.getAttribute('data-enabled') !== '1') return;

				const validation = setCardValidation(card);
				if (!validation.ok) {
					hasBlockingErrors = true;
					if (!firstInvalidCard) firstInvalidCard = card;
				}

				const file = card.getAttribute('data-file');
				const modeRadio = card.querySelector('.rspd-fmode-radio:checked');
				const mode = modeRadio ? modeRadio.value : 'new';
				const newTitle = card.querySelector('.rspd-file-new-title').value.trim();
				const pageId = card.querySelector('.rspd-file-page-select').value;

				items.push({
					file: file,
					mode: mode,
					page_id: mode === 'existing' ? pageId : '',
					new_title: mode === 'new' ? (newTitle || filenameToTitle(file)) : '',
				});
			});

			if (hasBlockingErrors) {
				deployProgress.style.display = '';
				deployProgress.innerHTML = '<p style="color:var(--rspd-red);">Fix the highlighted page conflicts before deploying.</p>';
				if (firstInvalidCard && firstInvalidCard.scrollIntoView) {
					firstInvalidCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
				}
				return;
			}

			if (!items.length) {
				alert('No files selected for deployment.');
				return;
			}

			// Check WebP toggle.
			const webpCheckbox = document.getElementById('rspd-webp-convert');
			const convertWebp = webpCheckbox && webpCheckbox.checked ? '1' : '0';

			deployAllBtn.disabled = true;
			deployAllBtn.textContent = 'Deploying...';
			deployProgress.style.display = '';
			let progressMsg = 'Deploying ' + items.length + ' page(s)';
			if (convertWebp === '1') progressMsg += ' with WebP conversion';
			progressMsg += '...';
			deployProgress.innerHTML = '<p style="color:var(--rspd-text-muted);">' + progressMsg + '</p>';

			const fd = new FormData();
			fd.append('action', 'rspd_deploy_multi');
			fd.append('nonce', rspdData.deployNonce);
			fd.append('temp_key', scanTempKey);
			fd.append('convert_webp', convertWebp);
			items.forEach((item, i) => {
				fd.append('items[' + i + '][file]', item.file);
				fd.append('items[' + i + '][mode]', item.mode);
				fd.append('items[' + i + '][page_id]', item.page_id);
				fd.append('items[' + i + '][new_title]', item.new_title);
			});

			fetch(rspdData.ajaxUrl, { method: 'POST', body: fd })
				.then((r) => r.json())
				.then((res) => {
					if (res.success && res.data.results) {
						let html = '<h3 style="margin-bottom:12px;">Deploy Results</h3>';

						// WebP summary banner.
						if (res.data.webp_summary && res.data.webp_summary.converted > 0) {
							html += '<div class="rspd-webp-summary">' +
								res.data.webp_summary.converted + ' image' + (res.data.webp_summary.converted !== 1 ? 's' : '') +
								' converted to WebP &mdash; saved ' + formatBytes(res.data.webp_summary.saved_bytes) +
							'</div>';
						}

						res.data.results.forEach((r) => {
							if (r.ok) {
								html += '<div class="rspd-result-ok">' +
									'<strong>' + escHtml(r.file) + '</strong> &rarr; ' +
									'<a href="' + escHtml(r.permalink) + '" target="_blank">' + escHtml(r.title) + '</a>' +
								'</div>';
							} else {
								html += '<div class="rspd-result-fail">' +
									'<strong>' + escHtml(r.file) + '</strong>: ' + escHtml(r.message) +
								'</div>';
							}
						});
						html += '<div style="margin-top:16px;"><a href="' + window.location.href.split('?')[0] + '?page=rspd" class="rspd-btn-deploy" style="text-decoration:none !important;display:inline-block;">Done — View Deployments</a></div>';
						deployProgress.innerHTML = html;
						fileList.style.display = 'none';
						deployAllBtn.style.display = 'none';
						if (resetBtn) resetBtn.style.display = 'none';
						const opts = multiDeploy.querySelector('.rspd-deploy-options');
						if (opts) opts.style.display = 'none';
						const summ = multiDeploy.querySelector('.rspd-scan-summary');
						if (summ) summ.style.display = 'none';
					} else {
						deployProgress.innerHTML = '<p style="color:var(--rspd-red);">' + escHtml(res.data || 'Deploy failed.') + '</p>';
						deployAllBtn.disabled = false;
						deployAllBtn.textContent = getUploadDeploymentType() === 'software_app' ? 'Deploy Software App' : 'Deploy Selected';
					}
				})
				.catch(() => {
					deployProgress.innerHTML = '<p style="color:var(--rspd-red);">Deploy request failed. Please try again.</p>';
					deployAllBtn.disabled = false;
					deployAllBtn.textContent = getUploadDeploymentType() === 'software_app' ? 'Deploy Software App' : 'Deploy Selected';
				});
		});
	}

	/* ─── Merge Sections tab ─── */
	const mergeSections = [];
	const sectionsList = document.getElementById('rspd-sections-list');
	const addSectionBtn = document.getElementById('rspd-add-section');
	const mergeDeployBtn = document.getElementById('rspd-merge-deploy-btn');
	const mergeStatus = document.getElementById('rspd-merge-status');
	const mergeRadioExisting = document.getElementById('rspd-merge-mode-existing');
	const mergeRadioNew = document.getElementById('rspd-merge-mode-new');
	const mergePageSelect = document.getElementById('rspd-merge-page-select');
	const mergeNewTitle = document.getElementById('rspd-merge-new-title');

	function syncMergePageMode() {
		if (!mergeRadioExisting || !mergeRadioNew) return;
		const isNew = mergeRadioNew.checked;
		if (mergePageSelect) mergePageSelect.disabled = isNew;
		if (mergeNewTitle) mergeNewTitle.disabled = !isNew;
	}
	if (mergeRadioExisting) mergeRadioExisting.addEventListener('change', syncMergePageMode);
	if (mergeRadioNew) mergeRadioNew.addEventListener('change', syncMergePageMode);
	syncMergePageMode();

	function renderMergeSections() {
		if (!sectionsList) return;
		if (mergeSections.length === 0) {
			sectionsList.innerHTML = '<p class="rspd-text-muted" style="text-align:center;padding:24px 0;">No sections yet. Click "+ Add Section" to start.</p>';
			return;
		}
		let html = '';
		mergeSections.forEach(function(sec, i) {
			html += '<div class="rspd-merge-section-card" data-index="' + i + '">'
				+ '<div class="rspd-merge-section-head">'
				+ '<span class="rspd-section-number">' + (i + 1) + '</span>'
				+ '<input type="text" class="rspd-merge-title-input rspd-merge-title" value="' + (sec.title || '').replace(/"/g, '&quot;') + '" placeholder="Label (optional)">'
				+ '<div class="rspd-merge-section-actions">'
				+ (i > 0 ? '<button type="button" class="rspd-btn-sm rspd-merge-move-up" title="Move up">&uarr;</button>' : '')
				+ (i < mergeSections.length - 1 ? '<button type="button" class="rspd-btn-sm rspd-merge-move-down" title="Move down">&darr;</button>' : '')
				+ '<button type="button" class="rspd-btn-sm rspd-merge-remove" title="Remove">&times;</button>'
				+ '</div>'
				+ '</div>'
				+ '<textarea class="rspd-code rspd-merge-code" placeholder="Paste HTML for this section...">' + (sec.code || '').replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</textarea>'
				+ '</div>';
		});
		sectionsList.innerHTML = html;
	}

	if (sectionsList) {
		sectionsList.addEventListener('input', function(e) {
			var card = e.target.closest('.rspd-merge-section-card');
			if (!card) return;
			var idx = parseInt(card.getAttribute('data-index'), 10);
			if (e.target.classList.contains('rspd-merge-title')) {
				mergeSections[idx].title = e.target.value;
			} else if (e.target.classList.contains('rspd-merge-code')) {
				mergeSections[idx].code = e.target.value;
			}
		});
		sectionsList.addEventListener('click', function(e) {
			var card = e.target.closest('.rspd-merge-section-card');
			if (!card) return;
			var idx = parseInt(card.getAttribute('data-index'), 10);
			if (e.target.classList.contains('rspd-merge-remove')) {
				mergeSections.splice(idx, 1);
				renderMergeSections();
			} else if (e.target.classList.contains('rspd-merge-move-up') && idx > 0) {
				var tmp = mergeSections[idx];
				mergeSections[idx] = mergeSections[idx - 1];
				mergeSections[idx - 1] = tmp;
				renderMergeSections();
			} else if (e.target.classList.contains('rspd-merge-move-down') && idx < mergeSections.length - 1) {
				var tmp2 = mergeSections[idx];
				mergeSections[idx] = mergeSections[idx + 1];
				mergeSections[idx + 1] = tmp2;
				renderMergeSections();
			}
		});
	}

	if (addSectionBtn) {
		addSectionBtn.addEventListener('click', function() {
			mergeSections.push({ title: '', code: '' });
			renderMergeSections();
			// Focus the new section's title input.
			var cards = sectionsList.querySelectorAll('.rspd-merge-section-card');
			var last = cards[cards.length - 1];
			if (last) {
				var titleInput = last.querySelector('.rspd-merge-title');
				if (titleInput) titleInput.focus();
			}
		});
	}

	// Edit mode: populate sections from saved data.
	if (typeof rspdData !== 'undefined' && rspdData.editSourceType === 'merge' && rspdData.editSections && rspdData.editSections.length) {
		rspdData.editSections.forEach(function(sec) {
			mergeSections.push({ title: sec.title || '', code: sec.code || '' });
		});
		renderMergeSections();
		// Auto-activate the merge tab.
		tabs.forEach(function(t) {
			if (t.getAttribute('data-tab') === 'merge') t.click();
		});
		// Pre-select the page in the merge dropdown.
		if (mergePageSelect && rspdData.editPageId) {
			mergePageSelect.value = rspdData.editPageId;
		}
	} else {
		renderMergeSections();
	}

	// Deploy merged page.
	if (mergeDeployBtn) {
		mergeDeployBtn.addEventListener('click', function() {
			// Validate.
			var hasCode = mergeSections.some(function(s) { return s.code && s.code.trim() !== ''; });
			if (!hasCode) {
				if (mergeStatus) {
					mergeStatus.style.display = '';
					mergeStatus.innerHTML = '<p style="color:var(--rspd-red);">Add at least one section with HTML code.</p>';
				}
				return;
			}

			var pageMode = 'existing';
			var selectedPageId = '';
			var newPageTitle = '';

			if (mergeRadioNew && mergeRadioNew.checked) {
				pageMode = 'new';
				newPageTitle = mergeNewTitle ? mergeNewTitle.value.trim() : '';
				if (!newPageTitle) {
					if (mergeStatus) {
						mergeStatus.style.display = '';
						mergeStatus.innerHTML = '<p style="color:var(--rspd-red);">Enter a title for the new page.</p>';
					}
					return;
				}
			} else {
				// Check for edit mode (page already selected via hidden field or locked badge).
				if (typeof rspdData !== 'undefined' && rspdData.editSourceType === 'merge' && rspdData.editPageId) {
					selectedPageId = rspdData.editPageId;
				} else {
					selectedPageId = mergePageSelect ? mergePageSelect.value : '';
				}
				if (!selectedPageId) {
					if (mergeStatus) {
						mergeStatus.style.display = '';
						mergeStatus.innerHTML = '<p style="color:var(--rspd-red);">Select a target page.</p>';
					}
					return;
				}
			}

			mergeDeployBtn.disabled = true;
			mergeDeployBtn.textContent = 'Deploying...';
			if (mergeStatus) {
				mergeStatus.style.display = '';
				mergeStatus.innerHTML = '<p class="rspd-text-muted">Merging sections and deploying...</p>';
			}

			var fd = new FormData();
			fd.append('action', 'rspd_deploy_merge');
			fd.append('nonce', rspdData.mergeNonce);
			fd.append('page_mode', pageMode);
			fd.append('page_id', selectedPageId);
			fd.append('new_title', newPageTitle);
			mergeSections.forEach(function(sec, i) {
				fd.append('sections[' + i + '][title]', sec.title || '');
				fd.append('sections[' + i + '][code]', sec.code || '');
			});

			fetch(rspdData.ajaxUrl, { method: 'POST', body: fd })
				.then(function(r) { return r.json(); })
				.then(function(res) {
					if (res.success) {
						if (mergeStatus) {
							mergeStatus.innerHTML = '<p style="color:var(--rspd-green);">Deployed! <a href="' + res.data.permalink + '" target="_blank">' + res.data.title + '</a></p>';
						}
						setTimeout(function() { window.location.href = window.location.pathname + '?page=rspd'; }, 1500);
					} else {
						if (mergeStatus) {
							mergeStatus.innerHTML = '<p style="color:var(--rspd-red);">' + (res.data || 'Deployment failed.') + '</p>';
						}
						mergeDeployBtn.disabled = false;
						mergeDeployBtn.textContent = 'Deploy Merged Page';
					}
				})
				.catch(function() {
					if (mergeStatus) {
						mergeStatus.innerHTML = '<p style="color:var(--rspd-red);">Request failed. Please try again.</p>';
					}
					mergeDeployBtn.disabled = false;
					mergeDeployBtn.textContent = 'Deploy Merged Page';
				});
		});
	}

	/* ─── Copy buttons ─── */
	document.querySelectorAll('.rspd-copy-button').forEach((button) => {
		button.addEventListener('click', async () => {
			const value = button.getAttribute('data-copy') || '';
			if (!value || !navigator.clipboard) return;
			try {
				await navigator.clipboard.writeText(value);
				const original = button.textContent;
				button.textContent = 'Copied';
				setTimeout(() => { button.textContent = original; }, 1200);
			} catch (err) { /* silent */ }
		});
	});

	/* ═══════════════════════════════════════════════════════════
	   Per-Page Settings Overrides
	   ═══════════════════════════════════════════════════════════ */

	function renderOverrideRow(key, label, type, globalValue, overrideValue, isOverridden) {
		const displayGlobal = type === 'boolean' ? (globalValue ? 'On' : 'Off') : escHtml(String(globalValue || '\u2014'));
		const overriddenClass = isOverridden ? ' is-overridden' : '';

		let controlHtml = '';
		if (type === 'boolean') {
			const checked = isOverridden ? (overrideValue ? ' checked' : '') : (globalValue ? ' checked' : '');
			controlHtml =
				'<label class="rspd-override-switch">' +
					'<input type="checkbox" class="rspd-override-value" data-key="' + key + '"' + checked + '>' +
					'<span class="rspd-toggle-track"><span class="rspd-toggle-thumb"></span></span>' +
				'</label>';
		} else if (type === 'select' && key === 'render_mode') {
			const val = isOverridden ? overrideValue : globalValue;
			controlHtml =
				'<select class="rspd-select rspd-override-value" data-key="' + key + '">' +
					'<option value="isolated"' + (val === 'isolated' ? ' selected' : '') + '>Isolated</option>' +
					'<option value="compatibility"' + (val === 'compatibility' ? ' selected' : '') + '>Compatibility</option>' +
				'</select>';
		} else {
			const val = isOverridden ? (overrideValue || '') : (globalValue || '');
			controlHtml = '<input type="text" class="rspd-input rspd-override-value" data-key="' + key + '" value="' + escHtml(val) + '">';
		}

		const statusHtml = isOverridden
			? '<span class="rspd-custom-badge">Custom override</span>'
			: '<span class="rspd-inherit-badge">Using global: ' + displayGlobal + '</span>';

		return '<div class="rspd-override-row' + overriddenClass + '" data-key="' + key + '">' +
			'<div class="rspd-override-toggle">' +
				'<label class="rspd-override-switch">' +
					'<input type="checkbox" class="rspd-override-enable" data-key="' + key + '"' + (isOverridden ? ' checked' : '') + '>' +
					'<span class="rspd-toggle-track"><span class="rspd-toggle-thumb"></span></span>' +
				'</label>' +
			'</div>' +
			'<div class="rspd-override-content">' +
				'<div class="rspd-override-label">' + escHtml(label) + '</div>' +
				'<div class="rspd-override-status">' + statusHtml + '</div>' +
				'<div class="rspd-override-control" style="' + (isOverridden ? '' : 'display:none;') + '">' +
					controlHtml +
				'</div>' +
			'</div>' +
		'</div>';
	}

	function renderPageSettingsPanel(pageId, data) {
		const overrides = data.overrides || {};
		const globals   = data.globals || {};
		const perf      = globals.performance || {};
		const perfOv    = overrides.performance || {};
		const compatOv  = overrides.compatibility || {};

		const rawHtml = [
			{ key: 'raw_html', label: 'Force Display As-Is (Raw HTML)', type: 'boolean',
			  global: (globals.defaults || {}).raw_html || 0, override: overrides.raw_html },
		];

		const renderBehavior = [
			{ key: 'render_mode', label: 'Render Mode', type: 'select',
			  global: (globals.defaults || {}).render_mode || 'isolated', override: overrides.render_mode },
			{ key: 'preserve_imported_head', label: 'Preserve Imported Head Tags', type: 'boolean',
			  global: (globals.defaults || {}).preserve_imported_head, override: overrides.preserve_imported_head },
			{ key: 'prefer_plugin_metadata', label: 'Prefer Plugin Metadata', type: 'boolean',
			  global: (globals.defaults || {}).prefer_plugin_metadata, override: overrides.prefer_plugin_metadata },
		];

		const compatibility = [
			{ key: 'compatibility_wp_head', label: 'Include wp_head()', type: 'boolean',
			  global: (globals.defaults || {}).compatibility_wp_head, override: compatOv.wp_head },
			{ key: 'compatibility_wp_footer', label: 'Include wp_footer()', type: 'boolean',
			  global: (globals.defaults || {}).compatibility_wp_footer, override: compatOv.wp_footer },
		];

		const performanceToggles = [
			{ key: 'performance_enable_html_cache', label: 'Cache Rendered HTML', skey: 'enable_html_cache' },
			{ key: 'performance_minify_html', label: 'Minify HTML Output', skey: 'minify_html' },
			{ key: 'performance_lazy_load_images', label: 'Lazy-load Images', skey: 'lazy_load_images' },
			{ key: 'performance_disable_emoji', label: 'Disable Emoji Scripts', skey: 'disable_emoji' },
			{ key: 'performance_disable_wp_embed', label: 'Disable wp-embed', skey: 'disable_wp_embed' },
			{ key: 'performance_asset_fingerprinting', label: 'Fingerprint Assets', skey: 'asset_fingerprinting' },
			{ key: 'performance_defer_scripts', label: 'Defer External Scripts', skey: 'defer_scripts' },
		];

		let html = '<div class="rspd-page-settings-header">' +
			'<h3>Page Settings</h3>' +
			'<p class="rspd-text-muted">Toggle the left switch to override a global default for this page only.</p>' +
		'</div>';

		html += '<div class="rspd-override-section"><h4 class="rspd-override-section-title">Display Mode</h4>' +
			'<p class="rspd-text-muted" style="margin-bottom:8px;font-size:12px;">Enable Raw HTML to skip all processing and serve your page exactly as uploaded — preserves animations, scripts, and complex layouts.</p>';
		rawHtml.forEach(function(item) {
			const isOv = item.override !== undefined;
			html += renderOverrideRow(item.key, item.label, item.type, item.global, item.override, isOv);
		});
		html += '</div>';

		html += '<div class="rspd-override-section"><h4 class="rspd-override-section-title">Render Behavior</h4>';
		renderBehavior.forEach(function(item) {
			const isOv = item.override !== undefined;
			html += renderOverrideRow(item.key, item.label, item.type, item.global, item.override, isOv);
		});
		html += '</div>';

		html += '<div class="rspd-override-section"><h4 class="rspd-override-section-title">Compatibility</h4>';
		compatibility.forEach(function(item) {
			const isOv = item.override !== undefined;
			html += renderOverrideRow(item.key, item.label, item.type, item.global, item.override, isOv);
		});
		html += '</div>';

		html += '<div class="rspd-override-section"><h4 class="rspd-override-section-title">Performance</h4>';
		performanceToggles.forEach(function(item) {
			const isOv = perfOv[item.skey] !== undefined;
			html += renderOverrideRow(item.key, item.label, 'boolean', perf[item.skey], perfOv[item.skey], isOv);
		});
		html += '</div>';

		html += '<div class="rspd-page-settings-actions">' +
			'<button type="button" class="rspd-btn-deploy rspd-save-overrides" data-page-id="' + pageId + '">Save Page Settings</button>' +
			'<button type="button" class="rspd-btn-secondary rspd-reset-overrides" data-page-id="' + pageId + '">Reset to Global</button>' +
			'<button type="button" class="rspd-btn-secondary rspd-close-settings" data-page-id="' + pageId + '">Cancel</button>' +
		'</div>';

		return html;
	}

	// Toggle override enable/disable.
	document.addEventListener('change', function(e) {
		if (!e.target.classList.contains('rspd-override-enable')) return;

		const row = e.target.closest('.rspd-override-row');
		if (!row) return;

		const control = row.querySelector('.rspd-override-control');
		const status  = row.querySelector('.rspd-override-status');
		const isEnabled = e.target.checked;

		if (control) control.style.display = isEnabled ? '' : 'none';
		row.classList.toggle('is-overridden', isEnabled);

		if (isEnabled) {
			status.innerHTML = '<span class="rspd-custom-badge">Custom override</span>';
		} else {
			status.innerHTML = '<span class="rspd-inherit-badge">Using global default</span>';
		}
	});

	// Settings button click — toggle panel.
	document.addEventListener('click', function(e) {
		const btn = e.target.closest('.rspd-btn-settings-toggle');
		if (!btn) return;

		const pageId = btn.getAttribute('data-page-id');
		const card   = btn.closest('.rspd-deploy-card');
		const panel  = card ? card.querySelector('.rspd-page-settings-panel') : null;

		if (!panel) return;

		if (panel.style.display !== 'none') {
			panel.style.display = 'none';
			return;
		}

		panel.style.display = '';
		panel.innerHTML = '<div class="rspd-page-settings-loading">Loading settings...</div>';

		const fd = new FormData();
		fd.append('action', 'rspd_get_page_overrides');
		fd.append('nonce', rspdData.overridesNonce);
		fd.append('page_id', pageId);

		fetch(rspdData.ajaxUrl, { method: 'POST', body: fd })
			.then(function(r) { return r.json(); })
			.then(function(res) {
				if (res.success) {
					panel.innerHTML = renderPageSettingsPanel(pageId, res.data);
				} else {
					panel.innerHTML = '<p style="color:var(--rspd-red);">' + escHtml(res.data || 'Failed to load settings.') + '</p>';
				}
			})
			.catch(function() {
				panel.innerHTML = '<p style="color:var(--rspd-red);">Failed to load settings.</p>';
			});
	});

	// Save overrides.
	document.addEventListener('click', function(e) {
		const btn = e.target.closest('.rspd-save-overrides');
		if (!btn) return;

		const pageId = btn.getAttribute('data-page-id');
		const panel  = btn.closest('.rspd-page-settings-panel');
		if (!panel) return;

		btn.disabled = true;
		btn.textContent = 'Saving...';

		const fd = new FormData();
		fd.append('action', 'rspd_save_page_overrides');
		fd.append('nonce', rspdData.overridesNonce);
		fd.append('page_id', pageId);

		panel.querySelectorAll('.rspd-override-row').forEach(function(row) {
			const enableCb = row.querySelector('.rspd-override-enable');
			const valueEl  = row.querySelector('.rspd-override-value');
			const key      = enableCb.getAttribute('data-key');
			const enabled  = enableCb.checked ? '1' : '0';

			fd.append('overrides[' + key + '][enabled]', enabled);

			if (valueEl) {
				const val = valueEl.type === 'checkbox' ? (valueEl.checked ? '1' : '0') : valueEl.value;
				fd.append('overrides[' + key + '][value]', val);
			}
		});

		fetch(rspdData.ajaxUrl, { method: 'POST', body: fd })
			.then(function(r) { return r.json(); })
			.then(function(res) {
				if (res.success) {
					btn.textContent = 'Saved!';
					setTimeout(function() { window.location.reload(); }, 600);
				} else {
					btn.textContent = 'Save Page Settings';
					btn.disabled = false;
					alert(res.data || 'Save failed.');
				}
			})
			.catch(function() {
				btn.textContent = 'Save Page Settings';
				btn.disabled = false;
				alert('Save request failed.');
			});
	});

	// Reset to global.
	document.addEventListener('click', function(e) {
		const btn = e.target.closest('.rspd-reset-overrides');
		if (!btn) return;

		if (!confirm('Reset all settings for this page to use global defaults?')) return;

		const panel = btn.closest('.rspd-page-settings-panel');
		if (panel) {
			panel.querySelectorAll('.rspd-override-enable').forEach(function(cb) {
				cb.checked = false;
				cb.dispatchEvent(new Event('change', { bubbles: true }));
			});
			// Auto-save the cleared overrides.
			const saveBtn = panel.querySelector('.rspd-save-overrides');
			if (saveBtn) saveBtn.click();
		}
	});

	// Close settings panel.
	document.addEventListener('click', function(e) {
		const btn = e.target.closest('.rspd-close-settings');
		if (!btn) return;

		const panel = btn.closest('.rspd-page-settings-panel');
		if (panel) panel.style.display = 'none';
	});

	/* ═══════════════════════════════════════════════
	   A/B VARIANT SETTINGS — Per-Variant Overrides
	   ═══════════════════════════════════════════════ */

	function renderVariantSettingsPanel(pageId, data) {
		var variants = data.variants || {};
		var globals  = data.globals || {};
		var variantKeys = Object.keys(variants);

		if (variantKeys.length === 0) {
			return '<p style="color:var(--rspd-red);">No variants found.</p>';
		}

		// Build tab bar.
		var html = '<div class="rspd-variant-tabs-wrapper">';
		html += '<div class="rspd-variant-tab-bar">';
		variantKeys.forEach(function(vkey, idx) {
			var v = variants[vkey];
			var activeClass = idx === 0 ? ' active' : '';
			var pillClass = vkey === 'control' ? 'control' : 'variant';
			html += '<button type="button" class="rspd-variant-tab' + activeClass + '" data-variant-key="' + escHtml(vkey) + '">' +
				'<span class="rspd-ab-variant-pill ' + pillClass + '" style="margin:0;">' + escHtml(v.label) + ' (' + v.weight + '%)</span>' +
			'</button>';
		});
		html += '</div>';

		// Build tab content for each variant.
		variantKeys.forEach(function(vkey, idx) {
			var v = variants[vkey];
			var overrides = v.overrides || {};
			var displayStyle = idx === 0 ? '' : 'display:none;';

			html += '<div class="rspd-variant-tab-content" data-variant-key="' + escHtml(vkey) + '" style="' + displayStyle + '">';
			html += renderVariantOverridesContent(pageId, vkey, overrides, globals);
			html += '</div>';
		});

		html += '</div>';
		return html;
	}

	function renderVariantOverridesContent(pageId, variantKey, overrides, globals) {
		var perf      = globals.performance || {};
		var perfOv    = overrides.performance || {};
		var compatOv  = overrides.compatibility || {};

		var rawHtml = [
			{ key: 'raw_html', label: 'Force Display As-Is (Raw HTML)', type: 'boolean',
			  global: (globals.defaults || {}).raw_html || 0, override: overrides.raw_html },
		];

		var renderBehavior = [
			{ key: 'render_mode', label: 'Render Mode', type: 'select',
			  global: (globals.defaults || {}).render_mode || 'isolated', override: overrides.render_mode },
			{ key: 'preserve_imported_head', label: 'Preserve Imported Head Tags', type: 'boolean',
			  global: (globals.defaults || {}).preserve_imported_head, override: overrides.preserve_imported_head },
			{ key: 'prefer_plugin_metadata', label: 'Prefer Plugin Metadata', type: 'boolean',
			  global: (globals.defaults || {}).prefer_plugin_metadata, override: overrides.prefer_plugin_metadata },
		];

		var compatibility = [
			{ key: 'compatibility_wp_head', label: 'Include wp_head()', type: 'boolean',
			  global: (globals.defaults || {}).compatibility_wp_head, override: compatOv.wp_head },
			{ key: 'compatibility_wp_footer', label: 'Include wp_footer()', type: 'boolean',
			  global: (globals.defaults || {}).compatibility_wp_footer, override: compatOv.wp_footer },
		];

		var performanceToggles = [
			{ key: 'performance_enable_html_cache', label: 'Cache Rendered HTML', skey: 'enable_html_cache' },
			{ key: 'performance_minify_html', label: 'Minify HTML Output', skey: 'minify_html' },
			{ key: 'performance_lazy_load_images', label: 'Lazy-load Images', skey: 'lazy_load_images' },
			{ key: 'performance_disable_emoji', label: 'Disable Emoji Scripts', skey: 'disable_emoji' },
			{ key: 'performance_disable_wp_embed', label: 'Disable wp-embed', skey: 'disable_wp_embed' },
			{ key: 'performance_asset_fingerprinting', label: 'Fingerprint Assets', skey: 'asset_fingerprinting' },
			{ key: 'performance_defer_scripts', label: 'Defer External Scripts', skey: 'defer_scripts' },
		];

		var html = '<div class="rspd-page-settings-header">' +
			'<h3>Variant Settings</h3>' +
			'<p class="rspd-text-muted">Toggle the left switch to override a setting for this variant only.</p>' +
		'</div>';

		html += '<div class="rspd-override-section"><h4 class="rspd-override-section-title">Display Mode</h4>' +
			'<p class="rspd-text-muted" style="margin-bottom:8px;font-size:12px;">Enable Raw HTML to skip all processing and serve this variant exactly as uploaded.</p>';
		rawHtml.forEach(function(item) {
			var isOv = item.override !== undefined;
			html += renderOverrideRow(item.key, item.label, item.type, item.global, item.override, isOv);
		});
		html += '</div>';

		html += '<div class="rspd-override-section"><h4 class="rspd-override-section-title">Render Behavior</h4>';
		renderBehavior.forEach(function(item) {
			var isOv = item.override !== undefined;
			html += renderOverrideRow(item.key, item.label, item.type, item.global, item.override, isOv);
		});
		html += '</div>';

		html += '<div class="rspd-override-section"><h4 class="rspd-override-section-title">Compatibility</h4>';
		compatibility.forEach(function(item) {
			var isOv = item.override !== undefined;
			html += renderOverrideRow(item.key, item.label, item.type, item.global, item.override, isOv);
		});
		html += '</div>';

		html += '<div class="rspd-override-section"><h4 class="rspd-override-section-title">Performance</h4>';
		performanceToggles.forEach(function(item) {
			var isOv = perfOv[item.skey] !== undefined;
			html += renderOverrideRow(item.key, item.label, 'boolean', perf[item.skey], perfOv[item.skey], isOv);
		});
		html += '</div>';

		html += '<div class="rspd-page-settings-actions">' +
			'<button type="button" class="rspd-btn-deploy rspd-save-variant-overrides" data-page-id="' + pageId + '" data-variant-key="' + escHtml(variantKey) + '">Save Variant Settings</button>' +
			'<button type="button" class="rspd-btn-secondary rspd-reset-variant-overrides" data-page-id="' + pageId + '" data-variant-key="' + escHtml(variantKey) + '">Reset to Global</button>' +
			'<button type="button" class="rspd-btn-secondary rspd-close-variant-settings" data-page-id="' + pageId + '">Cancel</button>' +
		'</div>';

		return html;
	}

	// Variant Settings button click — toggle panel.
	document.addEventListener('click', function(e) {
		var btn = e.target.closest('.rspd-btn-variant-settings-toggle');
		if (!btn) return;

		var pageId = btn.getAttribute('data-page-id');
		var card   = btn.closest('.rspd-deploy-card');
		var panel  = card ? card.querySelector('.rspd-variant-settings-panel') : null;

		if (!panel) return;

		if (panel.style.display !== 'none') {
			panel.style.display = 'none';
			return;
		}

		panel.style.display = '';
		panel.innerHTML = '<div class="rspd-page-settings-loading">Loading variant settings...</div>';

		var fd = new FormData();
		fd.append('action', 'rspd_get_variant_overrides');
		fd.append('nonce', rspdData.overridesNonce);
		fd.append('page_id', pageId);

		fetch(rspdData.ajaxUrl, { method: 'POST', body: fd })
			.then(function(r) { return r.json(); })
			.then(function(res) {
				if (res.success) {
					panel.innerHTML = renderVariantSettingsPanel(pageId, res.data);
				} else {
					panel.innerHTML = '<p style="color:var(--rspd-red);">' + escHtml(res.data || 'Failed to load variant settings.') + '</p>';
				}
			})
			.catch(function() {
				panel.innerHTML = '<p style="color:var(--rspd-red);">Failed to load variant settings.</p>';
			});
	});

	// Variant tab switching.
	document.addEventListener('click', function(e) {
		var tab = e.target.closest('.rspd-variant-tab');
		if (!tab) return;

		var wrapper    = tab.closest('.rspd-variant-tabs-wrapper');
		var variantKey = tab.getAttribute('data-variant-key');
		if (!wrapper || !variantKey) return;

		// Deactivate all tabs.
		wrapper.querySelectorAll('.rspd-variant-tab').forEach(function(t) {
			t.classList.remove('active');
		});
		tab.classList.add('active');

		// Show matching content, hide others.
		wrapper.querySelectorAll('.rspd-variant-tab-content').forEach(function(content) {
			if (content.getAttribute('data-variant-key') === variantKey) {
				content.style.display = '';
			} else {
				content.style.display = 'none';
			}
		});
	});

	// Save variant overrides.
	document.addEventListener('click', function(e) {
		var btn = e.target.closest('.rspd-save-variant-overrides');
		if (!btn) return;

		var pageId     = btn.getAttribute('data-page-id');
		var variantKey = btn.getAttribute('data-variant-key');
		var tabContent = btn.closest('.rspd-variant-tab-content');
		if (!tabContent) return;

		btn.disabled = true;
		btn.textContent = 'Saving...';

		var fd = new FormData();
		fd.append('action', 'rspd_save_variant_overrides');
		fd.append('nonce', rspdData.overridesNonce);
		fd.append('page_id', pageId);
		fd.append('variant_key', variantKey);

		tabContent.querySelectorAll('.rspd-override-row').forEach(function(row) {
			var enableCb = row.querySelector('.rspd-override-enable');
			var valueEl  = row.querySelector('.rspd-override-value');
			var key      = enableCb.getAttribute('data-key');
			var enabled  = enableCb.checked ? '1' : '0';

			fd.append('overrides[' + key + '][enabled]', enabled);

			if (valueEl) {
				var val = valueEl.type === 'checkbox' ? (valueEl.checked ? '1' : '0') : valueEl.value;
				fd.append('overrides[' + key + '][value]', val);
			}
		});

		fetch(rspdData.ajaxUrl, { method: 'POST', body: fd })
			.then(function(r) { return r.json(); })
			.then(function(res) {
				if (res.success) {
					btn.textContent = 'Saved!';
					setTimeout(function() {
						btn.textContent = 'Save Variant Settings';
						btn.disabled = false;
					}, 1500);
				} else {
					btn.textContent = 'Save Variant Settings';
					btn.disabled = false;
					alert(res.data || 'Save failed.');
				}
			})
			.catch(function() {
				btn.textContent = 'Save Variant Settings';
				btn.disabled = false;
				alert('Save request failed.');
			});
	});

	// Reset variant overrides.
	document.addEventListener('click', function(e) {
		var btn = e.target.closest('.rspd-reset-variant-overrides');
		if (!btn) return;

		if (!confirm('Reset all settings for this variant to use global defaults?')) return;

		var tabContent = btn.closest('.rspd-variant-tab-content');
		if (tabContent) {
			tabContent.querySelectorAll('.rspd-override-enable').forEach(function(cb) {
				cb.checked = false;
				cb.dispatchEvent(new Event('change', { bubbles: true }));
			});
			var saveBtn = tabContent.querySelector('.rspd-save-variant-overrides');
			if (saveBtn) saveBtn.click();
		}
	});

	// Close variant settings panel.
	document.addEventListener('click', function(e) {
		var btn = e.target.closest('.rspd-close-variant-settings');
		if (!btn) return;

		var panel = btn.closest('.rspd-variant-settings-panel');
		if (panel) panel.style.display = 'none';
	});

	/* ═══════════════════════════════════════════════
	   SEO INTELLIGENCE — Schema Editor
	   ═══════════════════════════════════════════════ */

	const SCHEMA_TYPES = {
		custom_json: { label: 'Pro Mode (Raw JSON-LD)', color: 'purple', fields: [] },
		none: { label: 'None', color: 'muted', fields: [] },
		local_business: {
			label: 'Local Business', color: 'pink',
			fields: [
				{ key: 'business_type', label: 'Business Type', type: 'select',
					options: ['LocalBusiness','Restaurant','MedicalBusiness','LegalService',
						'HomeAndConstructionBusiness','AutomotiveBusiness','FinancialService',
						'FoodEstablishment','Hotel','Store','RealEstateAgent','DentalClinic',
						'Optician','Plumber','HairSalon','SpaOrBeautyParlor'] },
				{ key: 'name',           label: 'Business Name',  type: 'text',     placeholder: "Joe's Plumbing",    full: false },
				{ key: 'telephone',      label: 'Phone Number',   type: 'text',     placeholder: '+1-555-555-5555',   full: false },
				{ key: 'email',          label: 'Email',          type: 'text',     placeholder: 'hello@business.com',full: false },
				{ key: 'street_address', label: 'Street Address', type: 'text',     placeholder: '123 Main St',       full: false },
				{ key: 'city',           label: 'City',           type: 'text',     placeholder: 'Austin',            full: false },
				{ key: 'state',          label: 'State / Region', type: 'text',     placeholder: 'TX',                full: false },
				{ key: 'postal_code',    label: 'Postal Code',    type: 'text',     placeholder: '78701',             full: false },
				{ key: 'country',        label: 'Country',        type: 'text',     placeholder: 'US',                full: false },
				{ key: 'hours',          label: 'Opening Hours',  type: 'text',     placeholder: 'Mo-Fr 09:00-17:00', full: false },
				{ key: 'price_range',    label: 'Price Range',    type: 'text',     placeholder: '$$',                full: false },
			]
		},
		webpage: {
			label: 'Web Page', color: 'blue',
			fields: [
				{ key: 'name',        label: 'Page Name',   type: 'text',     placeholder: 'Auto-filled from page title', full: false },
				{ key: 'description', label: 'Description', type: 'textarea', placeholder: 'Brief description...',        full: true  },
			]
		},
		article: {
			label: 'Article', color: 'purple',
			fields: [
				{ key: 'name',           label: 'Headline',        type: 'text',     placeholder: 'Article headline',   full: false },
				{ key: 'description',    label: 'Description',     type: 'textarea', placeholder: 'Brief summary...',   full: true  },
				{ key: 'author_name',    label: 'Author Name',     type: 'text',     placeholder: 'Jane Doe',           full: false },
				{ key: 'publisher_name', label: 'Publisher Name',  type: 'text',     placeholder: 'Reputifly',          full: false },
				{ key: 'publisher_logo', label: 'Publisher Logo URL',type:'text',    placeholder: 'https://...',        full: false },
				{ key: 'date_published', label: 'Date Published',  type: 'text',     placeholder: '2026-01-15',         full: false },
			]
		},
		faq: {
			label: 'FAQ Page', color: 'orange',
			fields: [] // Handled separately via dynamic FAQ rows
		},
		product: {
			label: 'Product', color: 'green',
			fields: [
				{ key: 'name',        label: 'Product Name', type: 'text',     placeholder: 'My Product',   full: false },
				{ key: 'description', label: 'Description',  type: 'textarea', placeholder: 'Product description...', full: true },
				{ key: 'brand_name',  label: 'Brand Name',   type: 'text',     placeholder: 'Acme Corp',    full: false },
				{ key: 'price',       label: 'Price',        type: 'text',     placeholder: '29.99',        full: false },
				{ key: 'currency',    label: 'Currency',     type: 'text',     placeholder: 'USD',          full: false },
			]
		},
		service: {
			label: 'Service', color: 'green',
			fields: [
				{ key: 'name',          label: 'Service Name',        type: 'text',     placeholder: 'Web Design',     full: false },
				{ key: 'description',   label: 'Description',         type: 'textarea', placeholder: 'What you offer...',full: true },
				{ key: 'provider_name', label: 'Provider / Business', type: 'text',     placeholder: 'Your Agency',    full: false },
				{ key: 'area_served',   label: 'Area Served',         type: 'text',     placeholder: 'Austin, TX',     full: false },
			]
		},
	};

	function buildSchemaTypeSelect(currentType) {
		let html = '<select class="rspd-schema-type-select" id="rspd-schema-type-select">';
		Object.entries(SCHEMA_TYPES).forEach(([key, def]) => {
			html += `<option value="${key}"${key === currentType ? ' selected' : ''}>${escHtml(def.label)}</option>`;
		});
		html += '</select>';
		return html;
	}

	function buildFieldsHtml(type, data) {
		const def = SCHEMA_TYPES[type];
		if (!def || !def.fields.length) return '';
		let html = '<div class="rspd-schema-fields-grid">';
		def.fields.forEach(f => {
			const val = data[f.key] || '';
			const fullClass = f.full ? ' rspd-schema-field-full' : '';
			html += `<div class="${fullClass}"><label class="rspd-schema-field-label">${escHtml(f.label)}</label>`;
			if (f.type === 'textarea') {
				html += `<textarea class="rspd-schema-input rspd-schema-textarea" data-key="${f.key}" placeholder="${escHtml(f.placeholder||'')}">${escHtml(val)}</textarea>`;
			} else if (f.type === 'select') {
				html += `<select class="rspd-schema-input rspd-schema-type-select" data-key="${f.key}">`;
				f.options.forEach(opt => {
					html += `<option value="${escHtml(opt)}"${opt === val ? ' selected' : ''}>${escHtml(opt)}</option>`;
				});
				html += '</select>';
			} else {
				html += `<input type="text" class="rspd-schema-input" data-key="${f.key}" value="${escHtml(val)}" placeholder="${escHtml(f.placeholder||'')}">`;
			}
			html += '</div>';
		});
		html += '</div>';
		return html;
	}

	function buildCustomJsonHtml(jsonLd) {
		// Pretty-print stored JSON for editing.
		let displayValue = '';
		if (jsonLd) {
			try {
				const parsed = JSON.parse(jsonLd);
				displayValue = JSON.stringify(parsed, null, 2);
			} catch (e) {
				displayValue = jsonLd;
			}
		} else {
			// Helpful starter template.
			displayValue = JSON.stringify({
				"@context": "https://schema.org",
				"@type": "LocalBusiness",
				"name": "Your Business Name",
				"url": ""
			}, null, 2);
		}
		let html = '<div style="margin-bottom:8px;">';
		html += '<label class="rspd-schema-field-label">JSON-LD</label>';
		html += '<p style="font-size:12px;color:var(--rspd-text-muted);margin-bottom:8px;">Paste valid JSON-LD. Google will read this directly from your page. <code style="color:var(--rspd-pink);">@context</code> is auto-added if missing.</p>';
		html += '<textarea class="rspd-code" id="rspd-custom-json-input" rows="14" style="min-height:200px;" placeholder=\'{"@context":"https://schema.org","@type":"LocalBusiness","name":"..."}\'>' + escHtml(displayValue) + '</textarea>';
		html += '<div id="rspd-json-validation" style="margin-top:6px;font-size:12px;font-weight:600;"></div>';
		html += '</div>';
		return html;
	}

	function buildFaqHtml(faqs) {
		if (!faqs || !faqs.length) faqs = [{ question: '', answer: '' }];
		let html = '<div class="rspd-faq-rows" id="rspd-faq-rows">';
		faqs.forEach((faq, i) => {
			html += `<div class="rspd-faq-row" data-faq-index="${i}">
				<div>
					<label class="rspd-schema-field-label">Question</label>
					<input type="text" class="rspd-schema-input rspd-faq-question" value="${escHtml(faq.question||'')}" placeholder="e.g. What are your hours?">
				</div>
				<div>
					<label class="rspd-schema-field-label">Answer</label>
					<input type="text" class="rspd-schema-input rspd-faq-answer" value="${escHtml(faq.answer||'')}" placeholder="We're open Mon-Fri 9am-5pm">
				</div>
				<button type="button" class="rspd-faq-remove" title="Remove">×</button>
			</div>`;
		});
		html += '</div>';
		html += '<button type="button" class="rspd-btn-add-faq" id="rspd-add-faq">+ Add Question</button>';
		return html;
	}

	function renderSchemaEditor(container, pageId, currentData) {
		const type = (currentData && currentData.type) ? currentData.type : 'none';

		let html = `<div class="rspd-schema-editor-header">
			<span class="rspd-schema-editor-title">Structured Data (JSON-LD)</span>
			${buildSchemaTypeSelect(type)}
		</div>`;

		html += `<div id="rspd-schema-fields-wrap">`;
		if (type === 'custom_json') {
			html += buildCustomJsonHtml(currentData ? currentData.json_ld || '' : '');
		} else if (type === 'faq') {
			html += buildFaqHtml(currentData && currentData.faqs ? currentData.faqs : []);
		} else {
			html += buildFieldsHtml(type, currentData || {});
		}
		html += `</div>`;

		html += `<div class="rspd-schema-editor-actions">
			<button type="button" class="rspd-btn-deploy" style="font-size:13px;padding:10px 24px;" id="rspd-schema-save-btn" data-page-id="${pageId}">Save Schema</button>
			<button type="button" class="rspd-btn-secondary" style="font-size:13px;" id="rspd-schema-cancel-btn">Cancel</button>
			<span class="rspd-schema-save-msg" id="rspd-schema-save-msg">✓ Saved</span>
		</div>`;

		container.innerHTML = html;
		container.style.display = '';

		// Type change handler.
		const typeSelect = container.querySelector('#rspd-schema-type-select');
		if (typeSelect) {
			typeSelect.addEventListener('change', () => {
				const newType = typeSelect.value;
				const wrap = container.querySelector('#rspd-schema-fields-wrap');
				if (!wrap) return;
				if (newType === 'custom_json') {
					wrap.innerHTML = buildCustomJsonHtml('');
				} else if (newType === 'faq') {
					wrap.innerHTML = buildFaqHtml([]);
					bindFaqButtons(wrap);
				} else {
					wrap.innerHTML = buildFieldsHtml(newType, {});
				}
			});
		}

		// Bind FAQ add/remove buttons.
		const fieldsWrap = container.querySelector('#rspd-schema-fields-wrap');
		if (fieldsWrap) bindFaqButtons(fieldsWrap);

		// Live JSON validation for Pro Mode.
		const jsonInput = container.querySelector('#rspd-custom-json-input');
		const jsonValidation = container.querySelector('#rspd-json-validation');
		if (jsonInput && jsonValidation) {
			jsonInput.addEventListener('input', () => {
				const raw = jsonInput.value.trim();
				if (!raw) {
					jsonValidation.textContent = '';
					return;
				}
				try {
					JSON.parse(raw);
					jsonValidation.style.color = 'var(--rspd-green)';
					jsonValidation.textContent = 'Valid JSON';
				} catch (e) {
					jsonValidation.style.color = 'var(--rspd-red)';
					jsonValidation.textContent = 'Invalid JSON: ' + e.message;
				}
			});
		}

		// Save handler.
		const saveBtn = container.querySelector('#rspd-schema-save-btn');
		if (saveBtn) {
			saveBtn.addEventListener('click', () => saveSchema(container, pageId));
		}

		// Cancel handler.
		const cancelBtn = container.querySelector('#rspd-schema-cancel-btn');
		if (cancelBtn) {
			cancelBtn.addEventListener('click', () => {
				container.innerHTML = '';
				container.style.display = 'none';
			});
		}
	}

	function bindFaqButtons(wrap) {
		// Event delegation — handles both existing and dynamically added buttons.
		wrap.addEventListener('click', (e) => {
			if (e.target.closest('.rspd-faq-remove')) {
				const row = e.target.closest('.rspd-faq-row');
				if (row) row.remove();
				return;
			}
			if (e.target.closest('#rspd-add-faq')) {
				const rows = wrap.querySelector('#rspd-faq-rows');
				if (!rows) return;
				const i = rows.querySelectorAll('.rspd-faq-row').length;
				const row = document.createElement('div');
				row.className = 'rspd-faq-row';
				row.dataset.faqIndex = i;
				row.innerHTML = `
					<div>
						<label class="rspd-schema-field-label">Question</label>
						<input type="text" class="rspd-schema-input rspd-faq-question" placeholder="Your question here">
					</div>
					<div>
						<label class="rspd-schema-field-label">Answer</label>
						<input type="text" class="rspd-schema-input rspd-faq-answer" placeholder="Your answer here">
					</div>
					<button type="button" class="rspd-faq-remove" title="Remove">×</button>`;
				rows.appendChild(row);
			}
		});
	}

	function collectSchemaData(container) {
		const typeSelect = container.querySelector('#rspd-schema-type-select');
		const type = typeSelect ? typeSelect.value : 'none';
		const schema = { type };

		if (type === 'custom_json') {
			const jsonInput = container.querySelector('#rspd-custom-json-input');
			if (jsonInput) {
				const raw = jsonInput.value.trim();
				if (raw) {
					// Validate JSON before sending.
					try {
						JSON.parse(raw);
					} catch (e) {
						throw new Error('Invalid JSON: ' + e.message);
					}
					schema.json_ld = raw;
				}
			}
		} else if (type === 'faq') {
			const faqs = [];
			container.querySelectorAll('.rspd-faq-row').forEach(row => {
				const q = row.querySelector('.rspd-faq-question');
				const a = row.querySelector('.rspd-faq-answer');
				if (q && a && q.value.trim()) {
					faqs.push({ question: q.value.trim(), answer: a.value.trim() });
				}
			});
			schema.faqs = faqs;
		} else {
			container.querySelectorAll('.rspd-schema-input[data-key]').forEach(input => {
				const key = input.dataset.key;
				if (key && input.value.trim()) {
					schema[key] = input.value.trim();
				}
			});
		}
		return schema;
	}

	function saveSchema(container, pageId) {
		const saveBtn = container.querySelector('#rspd-schema-save-btn');
		const saveMsg = container.querySelector('#rspd-schema-save-msg');

		let schema;
		try {
			schema = collectSchemaData(container);
		} catch (e) {
			// Show validation error inline.
			const validationEl = container.querySelector('#rspd-json-validation');
			if (validationEl) {
				validationEl.style.color = 'var(--rspd-red)';
				validationEl.textContent = e.message;
			} else {
				alert(e.message);
			}
			return;
		}

		if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Saving…'; }

		const body = new FormData();
		body.append('action', 'rspd_save_schema');
		body.append('nonce', rspdData.schemaNonce);
		body.append('page_id', pageId);

		// Flatten schema into FormData (handle faqs array).
		Object.entries(schema).forEach(([k, v]) => {
			if (k === 'faqs' && Array.isArray(v)) {
				v.forEach((faq, i) => {
					body.append(`schema[faqs][${i}][question]`, faq.question || '');
					body.append(`schema[faqs][${i}][answer]`,   faq.answer   || '');
				});
			} else {
				body.append(`schema[${k}]`, v);
			}
		});

		fetch(rspdData.ajaxUrl, { method: 'POST', body })
			.then(r => r.json())
			.then(res => {
				if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save Schema'; }
				if (!res.success) {
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Save failed.'));
					return;
				}
				// Update the badge + score ring on the card.
				if (res.data) {
					updateCardUI(pageId, res.data);
				}
				// Show saved msg.
				if (saveMsg) {
					saveMsg.classList.add('visible');
					setTimeout(() => saveMsg.classList.remove('visible'), 2500);
				}
				// Update in-memory seoData.
				if (rspdData.seoData && rspdData.seoData[pageId]) {
					rspdData.seoData[pageId].schema = schema;
				}
			})
			.catch(() => {
				if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save Schema'; }
				alert('Network error. Please try again.');
			});
	}

	function updateCardUI(pageId, data) {
		const card = document.getElementById('seo-card-' + pageId);
		if (!card) return;

		// Update score ring.
		if (data.score !== undefined) {
			const scoreNum = card.querySelector('.rspd-score-num');
			const ring     = card.querySelector('circle:last-child');
			const score    = data.score;
			const color    = score >= 80 ? '#34D399' : (score >= 50 ? '#FF8A00' : '#E6397F');
			if (scoreNum) { scoreNum.textContent = score; scoreNum.style.color = color; }
			if (ring) {
				const circ   = 2 * Math.PI * 28;
				const offset = circ * (1 - score / 100);
				ring.setAttribute('stroke', color);
				ring.setAttribute('stroke-dashoffset', offset.toFixed(2));
			}
		}

		// Update schema badge.
		const badge = card.querySelector('.rspd-schema-badge');
		if (badge && data.type) {
			const typeMap = {
				none: ['No Schema','muted'], custom_json: ['Custom JSON-LD','purple'],
				local_business: ['Local Business','pink'], webpage: ['Web Page','blue'],
				article: ['Article','purple'], faq: ['FAQ Page','orange'],
				product: ['Product','green'], service: ['Service','green'],
			};
			const [label, color] = typeMap[data.type] || ['No Schema','muted'];
			badge.textContent = label;
			badge.className = 'rspd-schema-badge rspd-schema-badge--' + color;
		}

		// Update breakdown dots.
		if (data.breakdown && Array.isArray(data.breakdown)) {
			const dots = card.querySelectorAll('.rspd-breakdown-dot');
			data.breakdown.forEach((check, i) => {
				if (dots[i]) {
					dots[i].className = 'rspd-breakdown-dot ' + (check.passed ? 'pass' : 'fail');
				}
			});
		}
	}

	// Open/close schema editor on button click.
	document.addEventListener('click', function(e) {
		const btn = e.target.closest('.rspd-btn-schema-edit');
		if (!btn) return;

		const pageId    = btn.dataset.pageId;
		const card      = document.getElementById('seo-card-' + pageId);
		const container = document.getElementById('schema-editor-' + pageId);
		if (!card || !container) return;

		// Toggle.
		if (container.style.display !== 'none' && container.innerHTML.trim() !== '') {
			container.innerHTML = '';
			container.style.display = 'none';
			return;
		}

		// Close social editor if open on same card.
		const socialEditor = document.getElementById('social-editor-' + pageId);
		if (socialEditor) { socialEditor.innerHTML = ''; socialEditor.style.display = 'none'; }

		// Get current schema from in-memory seoData.
		const currentSchema = (rspdData.seoData && rspdData.seoData[pageId])
			? rspdData.seoData[pageId].schema : {};

		renderSchemaEditor(container, pageId, currentSchema);

		// Scroll into view.
		setTimeout(() => container.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 50);
	});

	/* ═══════════════════════════════════════════════
	   SEO INTELLIGENCE — Social / OG Editor
	   ═══════════════════════════════════════════════ */

	const SOCIAL_FIELDS = [
		{ key: 'og_title',       label: 'OG Title',       type: 'text',     placeholder: 'Auto-fills from page title if empty', full: false },
		{ key: 'og_description', label: 'OG Description', type: 'textarea', placeholder: 'Brief description for social shares...', full: true },
		{ key: 'og_image',       label: 'OG Image URL',   type: 'text',     placeholder: 'https://example.com/image.jpg', full: true },
		{ key: 'og_type',        label: 'OG Type',        type: 'select',   options: ['website','article','product','profile'], full: false },
		{ key: 'og_site_name',   label: 'Site Name',      type: 'text',     placeholder: 'Your Brand Name', full: false },
		{ key: 'twitter_card',   label: 'Twitter Card',   type: 'select',   options: ['summary_large_image','summary'], full: false },
	];

	function buildSocialFieldsHtml(data) {
		let html = '<div class="rspd-schema-fields-grid">';
		SOCIAL_FIELDS.forEach(f => {
			const val = data[f.key] || '';
			const fullClass = f.full ? ' rspd-schema-field-full' : '';
			html += `<div class="${fullClass}"><label class="rspd-schema-field-label">${escHtml(f.label)}</label>`;
			if (f.type === 'textarea') {
				html += `<textarea class="rspd-schema-input rspd-schema-textarea rspd-social-input" data-key="${f.key}" placeholder="${escHtml(f.placeholder||'')}">${escHtml(val)}</textarea>`;
			} else if (f.type === 'select') {
				html += `<select class="rspd-schema-input rspd-schema-type-select rspd-social-input" data-key="${f.key}">`;
				f.options.forEach(opt => {
					html += `<option value="${escHtml(opt)}"${opt === val ? ' selected' : ''}>${escHtml(opt)}</option>`;
				});
				html += '</select>';
			} else {
				html += `<input type="text" class="rspd-schema-input rspd-social-input" data-key="${f.key}" value="${escHtml(val)}" placeholder="${escHtml(f.placeholder||'')}">`;
			}
			html += '</div>';
		});
		html += '</div>';
		return html;
	}

	function renderSocialEditor(container, pageId, currentData) {
		let html = `<div class="rspd-schema-editor-header">
			<span class="rspd-schema-editor-title">Open Graph &amp; Twitter Cards</span>
			<span class="rspd-social-hint">Powers LinkedIn, Facebook, Twitter link previews</span>
		</div>`;

		html += buildSocialFieldsHtml(currentData || {});

		// OG Preview card
		const title = (currentData && currentData.og_title) || (rspdData.seoData && rspdData.seoData[pageId] ? rspdData.seoData[pageId].title : 'Page Title');
		const desc  = (currentData && currentData.og_description) || '';
		const img   = (currentData && currentData.og_image) || '';
		const site  = (currentData && currentData.og_site_name) || '';

		html += `<div class="rspd-og-preview" id="rspd-og-preview-${pageId}">
			<div class="rspd-og-preview-label">Social Share Preview</div>
			<div class="rspd-og-preview-card">
				<div class="rspd-og-preview-img" id="rspd-og-img-${pageId}" style="${img ? 'background-image:url(' + escHtml(img) + ')' : ''}">
					${img ? '' : '<span class="rspd-og-preview-no-img">No image set</span>'}
				</div>
				<div class="rspd-og-preview-body">
					<div class="rspd-og-preview-site" id="rspd-og-site-${pageId}">${escHtml(site || 'yoursite.com')}</div>
					<div class="rspd-og-preview-title" id="rspd-og-title-${pageId}">${escHtml(title)}</div>
					<div class="rspd-og-preview-desc" id="rspd-og-desc-${pageId}">${escHtml(desc || 'Add a description to see it here...')}</div>
				</div>
			</div>
		</div>`;

		html += `<div class="rspd-schema-editor-actions">
			<button type="button" class="rspd-btn-deploy" style="font-size:13px;padding:10px 24px;" id="rspd-social-save-btn" data-page-id="${pageId}">Save Social Tags</button>
			<button type="button" class="rspd-btn-secondary" style="font-size:13px;" id="rspd-social-cancel-btn">Cancel</button>
			<span class="rspd-schema-save-msg" id="rspd-social-save-msg">✓ Saved</span>
		</div>`;

		container.innerHTML = html;
		container.style.display = '';

		// Live preview updates.
		container.querySelectorAll('.rspd-social-input').forEach(input => {
			const updatePreview = () => {
				const key = input.dataset.key;
				const val = input.value.trim();
				const imgEl   = document.getElementById('rspd-og-img-' + pageId);
				const titleEl = document.getElementById('rspd-og-title-' + pageId);
				const descEl  = document.getElementById('rspd-og-desc-' + pageId);
				const siteEl  = document.getElementById('rspd-og-site-' + pageId);
				if (key === 'og_image' && imgEl) {
					imgEl.style.backgroundImage = val ? 'url(' + val + ')' : '';
					imgEl.innerHTML = val ? '' : '<span class="rspd-og-preview-no-img">No image set</span>';
				}
				if (key === 'og_title' && titleEl) titleEl.textContent = val || 'Page Title';
				if (key === 'og_description' && descEl) descEl.textContent = val || 'Add a description to see it here...';
				if (key === 'og_site_name' && siteEl) siteEl.textContent = val || 'yoursite.com';
			};
			input.addEventListener('input', updatePreview);
		});

		// Save handler.
		const saveBtn = container.querySelector('#rspd-social-save-btn');
		if (saveBtn) {
			saveBtn.addEventListener('click', () => saveSocial(container, pageId));
		}

		// Cancel handler.
		const cancelBtn = container.querySelector('#rspd-social-cancel-btn');
		if (cancelBtn) {
			cancelBtn.addEventListener('click', () => {
				container.innerHTML = '';
				container.style.display = 'none';
			});
		}
	}

	function collectSocialData(container) {
		const social = {};
		container.querySelectorAll('.rspd-social-input[data-key]').forEach(input => {
			const key = input.dataset.key;
			const val = input.value.trim();
			if (key && val) social[key] = val;
		});
		return social;
	}

	function saveSocial(container, pageId) {
		const saveBtn = container.querySelector('#rspd-social-save-btn');
		const saveMsg = container.querySelector('#rspd-social-save-msg');
		const social  = collectSocialData(container);

		if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Saving…'; }

		const body = new FormData();
		body.append('action', 'rspd_save_social');
		body.append('nonce', rspdData.socialNonce);
		body.append('page_id', pageId);

		Object.entries(social).forEach(([k, v]) => {
			body.append(`social[${k}]`, v);
		});

		fetch(rspdData.ajaxUrl, { method: 'POST', body })
			.then(r => r.json())
			.then(res => {
				if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save Social Tags'; }
				if (!res.success) {
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Save failed.'));
					return;
				}
				if (res.data) {
					updateCardUI(pageId, res.data);
					// Update OG badge.
					const card = document.getElementById('seo-card-' + pageId);
					if (card) {
						const ogBadge = card.querySelector('.rspd-og-badge');
						if (ogBadge) {
							ogBadge.textContent = res.data.has_og ? 'OG Ready' : 'No OG';
							ogBadge.className = 'rspd-schema-badge rspd-og-badge rspd-schema-badge--' + (res.data.has_og ? 'blue' : 'muted');
						}
					}
				}
				if (saveMsg) {
					saveMsg.classList.add('visible');
					setTimeout(() => saveMsg.classList.remove('visible'), 2500);
				}
				// Update in-memory seoData.
				if (rspdData.seoData && rspdData.seoData[pageId]) {
					rspdData.seoData[pageId].social = social;
				}
			})
			.catch(() => {
				if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save Social Tags'; }
				alert('Network error. Please try again.');
			});
	}

	// Open/close social editor on button click.
	document.addEventListener('click', function(e) {
		const btn = e.target.closest('.rspd-btn-social-edit');
		if (!btn) return;

		const pageId    = btn.dataset.pageId;
		const card      = document.getElementById('seo-card-' + pageId);
		const container = document.getElementById('social-editor-' + pageId);
		if (!card || !container) return;

		// Toggle.
		if (container.style.display !== 'none' && container.innerHTML.trim() !== '') {
			container.innerHTML = '';
			container.style.display = 'none';
			return;
		}

		// Close schema editor if open on same card.
		const schemaEditor = document.getElementById('schema-editor-' + pageId);
		if (schemaEditor) { schemaEditor.innerHTML = ''; schemaEditor.style.display = 'none'; }

		const currentSocial = (rspdData.seoData && rspdData.seoData[pageId])
			? rspdData.seoData[pageId].social : {};

		renderSocialEditor(container, pageId, currentSocial);

		setTimeout(() => container.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 50);
	});

	/* ═══════════════════════════════════════════════
	   A/B Testing Page
	   ═══════════════════════════════════════════════ */

	const abPage = document.getElementById('rspd-ab-page');
	if (abPage) {

		// ─── Create Test: Page selector shows control preview + variant section ───

		const abPageSelect    = document.getElementById('rspd-ab-page-select');
		const abControlPreview = document.getElementById('rspd-ab-control-preview');
		const abControlTitle  = document.getElementById('rspd-ab-control-title');
		const abControlUrl    = document.getElementById('rspd-ab-control-url');
		const abVariantSection = document.getElementById('rspd-ab-variant-section');
		const abCreateSplit   = document.getElementById('rspd-ab-create-split');
		const abDeploySection = document.getElementById('rspd-ab-deploy-section');
		const abWeightControl = document.getElementById('rspd-ab-weight-control');
		const abWeightVariant = document.getElementById('rspd-ab-weight-variant');
		const abDeployBtn     = document.getElementById('rspd-ab-deploy-btn');
		const abVariantHtml   = document.getElementById('rspd-ab-variant-html');

		if (abPageSelect) {
			abPageSelect.addEventListener('change', function() {
				const opt = this.options[this.selectedIndex];
				const pageId = this.value;

				if (!pageId) {
					// No selection — hide everything.
					if (abControlPreview) abControlPreview.style.display = 'none';
					if (abVariantSection) abVariantSection.style.display = 'none';
					if (abCreateSplit) abCreateSplit.style.display = 'none';
					if (abDeploySection) abDeploySection.style.display = 'none';
					return;
				}

				// Show control card.
				if (abControlTitle) abControlTitle.textContent = opt.dataset.title || '';
				if (abControlUrl) abControlUrl.textContent = opt.dataset.url || '';
				if (abControlPreview) abControlPreview.style.display = '';

				// Show variant HTML textarea.
				if (abVariantSection) abVariantSection.style.display = '';

				// Show split inputs.
				if (abCreateSplit) abCreateSplit.style.display = '';

				// Show deploy button.
				if (abDeploySection) abDeploySection.style.display = '';
			});
		}

		// ─── Weight auto-complement ───

		if (abWeightControl && abWeightVariant) {
			abWeightControl.addEventListener('input', function() {
				const val = parseInt(this.value, 10);
				if (!isNaN(val) && val >= 1 && val <= 99) {
					abWeightVariant.value = 100 - val;
				}
			});
			abWeightVariant.addEventListener('input', function() {
				const val = parseInt(this.value, 10);
				if (!isNaN(val) && val >= 1 && val <= 99) {
					abWeightControl.value = 100 - val;
				}
			});
		}

		// ─── Deploy & Start Test ───

		if (abDeployBtn) {
			abDeployBtn.addEventListener('click', function() {
				const pageId = abPageSelect ? abPageSelect.value : '';
				const html   = abVariantHtml ? abVariantHtml.value.trim() : '';
				const wc     = abWeightControl ? parseInt(abWeightControl.value, 10) : 50;
				const wv     = abWeightVariant ? parseInt(abWeightVariant.value, 10) : 50;

				if (!pageId) {
					alert('Please select a page first.');
					return;
				}
				if (!html) {
					alert('Please paste variant HTML.');
					return;
				}
				if (isNaN(wc) || isNaN(wv) || wc + wv !== 100 || wc < 1 || wv < 1) {
					alert('Traffic weights must be between 1-99 and sum to 100.');
					return;
				}

				abDeployBtn.disabled = true;
				abDeployBtn.textContent = 'Deploying…';

				const body = new FormData();
				body.append('action', 'rspd_ab_create');
				body.append('nonce', rspdData.abNonce);
				body.append('page_id', pageId);
				body.append('variant_html', html);
				body.append('weight_control', wc);
				body.append('weight_variant', wv);

				fetch(rspdData.ajaxUrl, { method: 'POST', body: body })
					.then(function(r) { return r.json(); })
					.then(function(res) {
						if (!res.success) {
							alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Create failed.'));
							abDeployBtn.disabled = false;
							abDeployBtn.textContent = 'Deploy & Start Test';
							return;
						}
						// Reload the page to show the new active test.
						window.location.reload();
					})
					.catch(function() {
						alert('Network error. Please try again.');
						abDeployBtn.disabled = false;
						abDeployBtn.textContent = 'Deploy & Start Test';
					});
			});
		}

		// ─── Active Test Management: Toggle, Update Split, End Test ───
		// Uses event delegation on the #rspd-ab-page container.

		abPage.addEventListener('click', function(e) {

			// ── Toggle (Pause / Resume) ──
			const toggleBtn = e.target.closest('.rspd-ab-toggle-btn');
			if (toggleBtn) {
				const card      = toggleBtn.closest('.rspd-ab-test-card');
				const pageId    = card ? card.dataset.pageId : '';
				const isEnabled = toggleBtn.dataset.enabled === '1';

				if (!pageId) return;

				toggleBtn.disabled = true;
				toggleBtn.textContent = isEnabled ? 'Pausing…' : 'Resuming…';

				const body = new FormData();
				body.append('action', 'rspd_ab_toggle');
				body.append('nonce', rspdData.abNonce);
				body.append('page_id', pageId);

				fetch(rspdData.ajaxUrl, { method: 'POST', body: body })
					.then(function(r) { return r.json(); })
					.then(function(res) {
						if (!res.success) {
							alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Toggle failed.'));
							toggleBtn.disabled = false;
							toggleBtn.textContent = isEnabled ? 'Pause Test' : 'Resume Test';
							return;
						}
						// Update button state.
						const nowEnabled = res.data && res.data.enabled;
						toggleBtn.dataset.enabled = nowEnabled ? '1' : '0';
						toggleBtn.textContent = nowEnabled ? 'Pause Test' : 'Resume Test';
						toggleBtn.disabled = false;

						// Update status indicator.
						const statusEl = card.querySelector('.rspd-ab-status');
						if (statusEl) {
							statusEl.className = 'rspd-ab-status rspd-ab-status--' + (nowEnabled ? 'running' : 'paused');
							statusEl.textContent = nowEnabled ? 'Running' : 'Paused';
						}

						// Update card border.
						if (nowEnabled) {
							card.classList.remove('rspd-ab-test-card--paused');
						} else {
							card.classList.add('rspd-ab-test-card--paused');
						}
					})
					.catch(function() {
						alert('Network error. Please try again.');
						toggleBtn.disabled = false;
						toggleBtn.textContent = isEnabled ? 'Pause Test' : 'Resume Test';
					});
				return;
			}

			// ── Update Split ──
			const splitBtn = e.target.closest('.rspd-ab-update-split-btn');
			if (splitBtn) {
				const card   = splitBtn.closest('.rspd-ab-test-card');
				const pageId = card ? card.dataset.pageId : '';

				if (!pageId) return;

				// Collect weights from all inputs in this card.
				const weightInputs = card.querySelectorAll('.rspd-ab-weight-input');
				const weights = {};
				let total = 0;
				weightInputs.forEach(function(input) {
					const variant = input.dataset.variant;
					const val     = parseInt(input.value, 10);
					if (variant && !isNaN(val)) {
						weights[variant] = val;
						total += val;
					}
				});

				if (total !== 100) {
					alert('Weights must sum to 100. Current total: ' + total);
					return;
				}

				splitBtn.disabled = true;
				splitBtn.textContent = 'Updating…';

				const body = new FormData();
				body.append('action', 'rspd_ab_update_split');
				body.append('nonce', rspdData.abNonce);
				body.append('page_id', pageId);
				Object.keys(weights).forEach(function(key) {
					body.append('weights[' + key + ']', weights[key]);
				});

				fetch(rspdData.ajaxUrl, { method: 'POST', body: body })
					.then(function(r) { return r.json(); })
					.then(function(res) {
						splitBtn.disabled = false;
						splitBtn.textContent = 'Update Split';

						if (!res.success) {
							alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Update failed.'));
							return;
						}

						// Update variant pill weights shown on the card.
						const pills = card.querySelectorAll('.rspd-ab-variant-pill');
						pills.forEach(function(pill) {
							const weightSpan = pill.querySelector('.rspd-ab-variant-weight');
							if (weightSpan) {
								const label = pill.querySelector('.rspd-ab-variant-label');
								if (label) {
									// Try to match by variant key from input data.
									for (const [k, v] of Object.entries(weights)) {
										const labelText = label.textContent.trim().toLowerCase();
										if ((k === 'control' && labelText.includes('control')) ||
											(k !== 'control' && !labelText.includes('control'))) {
											weightSpan.textContent = v + '%';
											break;
										}
									}
								}
							}
						});

						// Brief success flash.
						splitBtn.textContent = 'Updated!';
						setTimeout(function() {
							splitBtn.textContent = 'Update Split';
						}, 1500);
					})
					.catch(function() {
						splitBtn.disabled = false;
						splitBtn.textContent = 'Update Split';
						alert('Network error. Please try again.');
					});
				return;
			}

			// ── End Test & Pick Winner ──
			const endBtn = e.target.closest('.rspd-ab-end-btn');
			if (endBtn) {
				const card      = endBtn.closest('.rspd-ab-test-card');
				const pageId    = card ? card.dataset.pageId : '';
				const selectEl  = card ? card.querySelector('.rspd-ab-winner-select') : null;
				const winner    = selectEl ? selectEl.value : '';
				const winnerLabel = selectEl ? selectEl.options[selectEl.selectedIndex].text : winner;

				if (!pageId || !winner) return;

				const confirmed = confirm(
					'End this A/B test and make "' + winnerLabel + '" the permanent version?\n\n' +
					'The losing variant will be deleted. This cannot be undone.'
				);
				if (!confirmed) return;

				endBtn.disabled = true;
				endBtn.textContent = 'Ending…';

				const body = new FormData();
				body.append('action', 'rspd_ab_end');
				body.append('nonce', rspdData.abNonce);
				body.append('page_id', pageId);
				body.append('winner', winner);

				fetch(rspdData.ajaxUrl, { method: 'POST', body: body })
					.then(function(r) { return r.json(); })
					.then(function(res) {
						if (!res.success) {
							alert('Error: ' + (res.data && res.data.message ? res.data.message : 'End test failed.'));
							endBtn.disabled = false;
							endBtn.textContent = 'End Test & Pick Winner';
							return;
						}
						// Reload to reflect the change.
						window.location.reload();
					})
					.catch(function() {
						alert('Network error. Please try again.');
						endBtn.disabled = false;
						endBtn.textContent = 'End Test & Pick Winner';
					});
				return;
			}
		});
	}

});
