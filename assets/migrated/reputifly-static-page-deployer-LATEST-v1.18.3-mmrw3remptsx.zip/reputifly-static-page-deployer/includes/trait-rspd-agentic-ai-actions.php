<?php
/**
 * Agentic AI mutating action callbacks.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait RSPD_Agentic_AI_Actions_Trait {

	public function rest_post_license_recheck( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'license_recheck' ),
			true,
			function () {
				$this->license->maybe_refresh_status( true, 'agent_api' );
				return array(
					'license' => $this->license->get_status_context(),
					'message' => 'License recheck completed.',
				);
			},
			array( 'allow_when_locked' => true )
		);
	}

	public function rest_post_create_key( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'agent_access_manage' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$payload      = $this->get_request_payload( $request );
				$label        = ! empty( $payload['label'] ) ? sanitize_text_field( $payload['label'] ) : 'Agent Key';
				$capabilities = ! empty( $payload['capabilities'] ) && is_array( $payload['capabilities'] ) ? $payload['capabilities'] : $this->auth->get_default_capabilities();
				$created      = $this->auth->create_key( $label, $capabilities, false, 0 );

				return array(
					'key'     => $created['key'],
					'record'  => $created['record'],
					'message' => 'Agent key created.',
				);
			}
		);
	}

	public function rest_delete_key( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'agent_access_manage' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$key_id = sanitize_key( (string) $request['key_id'] );
				$key    = $this->auth->get_key( $key_id );

				if ( empty( $key ) ) {
					return new WP_Error( 'rspd_agent_key_missing', __( 'That agent key could not be found.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$this->auth->set_key_status( $key_id, 'revoked' );

				return array(
					'key_id'  => $key_id,
					'message' => 'Agent key revoked.',
				);
			}
		);
	}

	public function rest_post_upload( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'website_pages_deploy', 'software_apps_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$files = $request->get_file_params();
				$file  = array();

				if ( ! empty( $files['package'] ) ) {
					$file = $files['package'];
				} elseif ( ! empty( $files['deployment_package'] ) ) {
					$file = $files['deployment_package'];
				} elseif ( ! empty( $files ) ) {
					$file = reset( $files );
				}

				$session = $this->create_upload_session( is_array( $file ) ? $file : array() );
				if ( is_wp_error( $session ) ) {
					return $session;
				}

				return array(
					'upload_id'         => $session['upload_id'],
					'original_filename' => $session['original_filename'],
					'html_files'        => $session['html_files'],
					'entry_file'        => $session['entry_file'],
					'package_type'      => $session['package_type'],
					'suggestions'       => $session['suggestions'],
					'warnings'          => $session['warnings'],
					'expires_at'        => $session['expires_at'],
					'message'           => 'ZIP uploaded and scanned successfully.',
				);
			},
			array( 'match_any' => true )
		);
	}

	public function rest_delete_upload( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'website_pages_deploy', 'software_apps_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$upload_id = sanitize_key( (string) $request['upload_id'] );
				$session   = $this->storage->get_agent_upload_session( $upload_id );

				if ( empty( $session ) ) {
					return new WP_Error( 'rspd_agent_upload_missing', __( 'That upload session could not be found.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$this->storage->delete_agent_upload_session( $upload_id, true );

				return array(
					'upload_id' => $upload_id,
					'message'   => 'Upload session deleted.',
				);
			},
			array( 'match_any' => true )
		);
	}

	public function rest_post_update_page( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'website_pages_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$page    = get_post( $page_id );
				$payload = $this->get_request_payload( $request );

				if ( ! $page instanceof WP_Post || 'page' !== $page->post_type ) {
					return new WP_Error( 'rspd_agent_page_missing', __( 'That WordPress page could not be found.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$postarr = array(
					'ID' => $page_id,
				);

				if ( array_key_exists( 'title', $payload ) ) {
					$postarr['post_title'] = sanitize_text_field( (string) $payload['title'] );
				}

				if ( array_key_exists( 'slug', $payload ) ) {
					$raw_slug = trim( (string) $payload['slug'] );
					if ( '' === $raw_slug ) {
						return new WP_Error( 'rspd_agent_page_slug_missing', __( 'The page slug cannot be empty.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
					}
					$postarr['post_name'] = sanitize_title( $raw_slug );
				}

				if ( array_key_exists( 'status', $payload ) ) {
					$status = sanitize_key( (string) $payload['status'] );
					if ( ! in_array( $status, $this->get_agent_editable_page_statuses(), true ) ) {
						return new WP_Error( 'rspd_agent_page_status_invalid', __( 'That page status is not allowed through Agentic AI.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
					}
					$postarr['post_status'] = $status;
				}

				if ( 1 === count( $postarr ) ) {
					return new WP_Error( 'rspd_agent_page_update_empty', __( 'Provide a new title, slug, or status to update the page.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$update_result = wp_update_post( wp_slash( $postarr ), true, false );
				if ( is_wp_error( $update_result ) ) {
					return $update_result;
				}

				$config          = $this->storage->get_page_config( $page_id );
				$related_rebuilds = array();

				if ( ! empty( $config ) ) {
					$this->storage->update_page_config( $page_id, $config );

					if ( isset( $postarr['post_name'] ) || isset( $postarr['post_status'] ) ) {
						$rebuilt = $this->deployer->rebuild_page_deployment( $page_id );
						if ( is_wp_error( $rebuilt ) ) {
							return $rebuilt;
						}
						$related_rebuilds = $this->rebuild_related_package_pages( ! empty( $config['package_key'] ) ? $config['package_key'] : '', $page_id );
					} else {
						$this->bridge->purge_frontend_cache_for_page_public( $page_id );
					}
				}

				$page = get_post( $page_id );

				return array(
					'page'             => array(
						'id'        => $page_id,
						'title'     => $page ? $page->post_title : '',
						'slug'      => $page ? $page->post_name : '',
						'status'    => $page ? $page->post_status : '',
						'permalink' => $page ? get_permalink( $page ) : '',
					),
					'related_rebuilds' => $related_rebuilds,
					'message'          => 'Page updated successfully.',
				);
			}
		);
	}

	public function rest_post_duplicate_page( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'website_pages_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id      = absint( $request['page_id'] );
				$source_page  = get_post( $page_id );
				$payload      = $this->get_request_payload( $request );
				$config       = $this->storage->get_page_config( $page_id );
				$default_title = $source_page instanceof WP_Post ? sprintf( __( '%s Copy', 'reputifly-static-page-deployer' ), $source_page->post_title ) : __( 'Page Copy', 'reputifly-static-page-deployer' );
				$status       = ! empty( $payload['status'] ) ? sanitize_key( (string) $payload['status'] ) : 'draft';

				if ( ! $source_page instanceof WP_Post || 'page' !== $source_page->post_type || 'trash' === $source_page->post_status ) {
					return new WP_Error( 'rspd_agent_duplicate_source_missing', __( 'The source page could not be duplicated.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				if ( ! in_array( $status, $this->get_agent_editable_page_statuses(), true ) ) {
					return new WP_Error( 'rspd_agent_duplicate_status_invalid', __( 'That duplicate page status is not allowed.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$new_page_id = wp_insert_post(
					wp_slash(
						array(
							'post_type'      => 'page',
							'post_status'    => $status,
							'post_title'     => ! empty( $payload['title'] ) ? sanitize_text_field( (string) $payload['title'] ) : $default_title,
							'post_name'      => ! empty( $payload['slug'] ) ? sanitize_title( (string) $payload['slug'] ) : '',
							'post_content'   => $source_page->post_content,
							'post_excerpt'   => $source_page->post_excerpt,
							'post_parent'    => (int) $source_page->post_parent,
							'menu_order'     => (int) $source_page->menu_order,
							'comment_status' => $source_page->comment_status,
							'ping_status'    => $source_page->ping_status,
						)
					),
					true,
					false
				);

				if ( is_wp_error( $new_page_id ) ) {
					return $new_page_id;
				}

				$new_page_id = (int) $new_page_id;

				$page_template = get_post_meta( $page_id, '_wp_page_template', true );
				if ( '' !== (string) $page_template ) {
					update_post_meta( $new_page_id, '_wp_page_template', $page_template );
				}

				$thumbnail_id = (int) get_post_meta( $page_id, '_thumbnail_id', true );
				if ( $thumbnail_id ) {
					update_post_meta( $new_page_id, '_thumbnail_id', $thumbnail_id );
				}

				if ( ! empty( $config['deployment_rel_dir'] ) ) {
					$result = $this->deployer->deploy_local_static_package_to_page(
						$this->storage->get_deployment_path( $config['deployment_rel_dir'] ),
						$new_page_id,
						array(
							'entry_file'  => ! empty( $config['entry_file'] ) ? $config['entry_file'] : '',
							'source_type' => ! empty( $config['source_type'] ) ? $config['source_type'] : 'upload',
						)
					);

					if ( is_wp_error( $result ) ) {
						wp_delete_post( $new_page_id, true );
						return $result;
					}

					$new_config = $this->storage->get_page_config( $new_page_id );
					if ( ! empty( $new_config ) ) {
						$new_config['enabled']                = ! empty( $config['enabled'] ) ? 1 : 0;
						$new_config['render_mode']            = ! empty( $config['render_mode'] ) ? $config['render_mode'] : $new_config['render_mode'];
						$new_config['preserve_imported_head'] = ! empty( $config['preserve_imported_head'] ) ? 1 : 0;
						$new_config['prefer_plugin_metadata'] = ! empty( $config['prefer_plugin_metadata'] ) ? 1 : 0;
						$new_config['raw_html']               = ! empty( $config['raw_html'] ) ? 1 : 0;
						$new_config['compatibility']          = ! empty( $config['compatibility'] ) && is_array( $config['compatibility'] ) ? $config['compatibility'] : $new_config['compatibility'];
						$new_config['metadata']               = ! empty( $config['metadata'] ) && is_array( $config['metadata'] ) ? $config['metadata'] : $new_config['metadata'];
						$new_config['performance']            = ! empty( $config['performance'] ) && is_array( $config['performance'] ) ? $config['performance'] : $new_config['performance'];
						$new_config['page_overrides']         = ! empty( $config['page_overrides'] ) && is_array( $config['page_overrides'] ) ? $config['page_overrides'] : array();
						$new_config['package_key']            = 'pkgdup_' . substr( sha1( $page_id . '|' . $new_page_id . '|' . microtime( true ) ), 0, 20 );
						$new_config['updated_at']             = time();
						$new_config['cache_version']          = wp_generate_password( 12, false, false );
						$this->storage->update_page_config( $new_page_id, $new_config );

						$rebuilt = $this->deployer->rebuild_page_deployment( $new_page_id );
						if ( is_wp_error( $rebuilt ) ) {
							$this->deployer->delete_deployment( $new_page_id );
							wp_delete_post( $new_page_id, true );
							return $rebuilt;
						}
					}
				}

				return array(
					'page'                   => array(
						'id'        => $new_page_id,
						'title'     => get_the_title( $new_page_id ),
						'slug'      => get_post_field( 'post_name', $new_page_id ),
						'status'    => get_post_field( 'post_status', $new_page_id ),
						'permalink' => get_permalink( $new_page_id ),
					),
					'source_page_id'         => $page_id,
					'managed_deployment_cloned' => ! empty( $config['deployment_rel_dir'] ),
					'message'                => 'Page duplicated successfully.',
				);
			}
		);
	}

	public function rest_post_trash_page( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deploy_delete' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$page    = get_post( $page_id );
				$config  = $this->storage->get_page_config( $page_id );

				if ( ! $page instanceof WP_Post || 'page' !== $page->post_type ) {
					return new WP_Error( 'rspd_agent_page_missing', __( 'That WordPress page could not be found.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				if ( 'trash' === $page->post_status ) {
					return new WP_Error( 'rspd_agent_page_already_trashed', __( 'That page is already in the trash.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$result = wp_trash_post( $page_id );
				if ( false === $result ) {
					return new WP_Error( 'rspd_agent_trash_failed', __( 'The page could not be moved to the trash.', 'reputifly-static-page-deployer' ), array( 'status' => 500 ) );
				}

				if ( ! empty( $config ) ) {
					$this->storage->remove_page_map_entry( $page_id );
					$this->bridge->purge_frontend_cache_for_page_public( $page_id );
				}

				return array(
					'page_id'          => $page_id,
					'title'            => $page->post_title,
					'related_rebuilds' => $this->rebuild_related_package_pages( ! empty( $config['package_key'] ) ? $config['package_key'] : '', $page_id ),
					'message'          => 'Page moved to trash.',
				);
			}
		);
	}

	public function rest_post_restore_page( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deploy_delete' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$page    = get_post( $page_id );
				$config  = $this->storage->get_page_config( $page_id );

				if ( ! $page instanceof WP_Post || 'page' !== $page->post_type ) {
					return new WP_Error( 'rspd_agent_page_missing', __( 'That WordPress page could not be found.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				if ( 'trash' !== $page->post_status ) {
					return new WP_Error( 'rspd_agent_page_not_trashed', __( 'That page is not currently in the trash.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$result = wp_untrash_post( $page_id );
				if ( false === $result ) {
					return new WP_Error( 'rspd_agent_restore_failed', __( 'The page could not be restored.', 'reputifly-static-page-deployer' ), array( 'status' => 500 ) );
				}

				$related_rebuilds = array();

				if ( ! empty( $config ) ) {
					$this->storage->update_page_config( $page_id, $config );
					$rebuilt = $this->deployer->rebuild_page_deployment( $page_id );
					if ( is_wp_error( $rebuilt ) ) {
						return $rebuilt;
					}
					$related_rebuilds = $this->rebuild_related_package_pages( ! empty( $config['package_key'] ) ? $config['package_key'] : '', $page_id );
				}

				$page = get_post( $page_id );

				return array(
					'page'             => array(
						'id'        => $page_id,
						'title'     => $page ? $page->post_title : '',
						'slug'      => $page ? $page->post_name : '',
						'status'    => $page ? $page->post_status : '',
						'permalink' => $page ? get_permalink( $page ) : '',
					),
					'related_rebuilds' => $related_rebuilds,
					'message'          => 'Page restored successfully.',
				);
			}
		);
	}

	public function rest_delete_wordpress_page( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deploy_delete' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$page    = get_post( $page_id );
				$config  = $this->storage->get_page_config( $page_id );

				if ( ! $page instanceof WP_Post || 'page' !== $page->post_type ) {
					return new WP_Error( 'rspd_agent_page_missing', __( 'That WordPress page could not be found.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				if ( ! empty( $config ) ) {
					$this->deployer->delete_deployment( $page_id );
				}

				$deleted = wp_delete_post( $page_id, true );
				if ( ! $deleted ) {
					return new WP_Error( 'rspd_agent_delete_page_failed', __( 'The WordPress page could not be deleted.', 'reputifly-static-page-deployer' ), array( 'status' => 500 ) );
				}

				return array(
					'page_id'          => $page_id,
					'title'            => $page->post_title,
					'related_rebuilds' => $this->rebuild_related_package_pages( ! empty( $config['package_key'] ) ? $config['package_key'] : '', $page_id ),
					'message'          => 'WordPress page deleted permanently.',
				);
			}
		);
	}

	public function rest_post_deploy_website_pages( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'website_pages_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$payload  = $this->get_request_payload( $request );
				$upload   = $this->validate_upload_session( isset( $payload['upload_id'] ) ? $payload['upload_id'] : '' );
				$items    = ! empty( $payload['items'] ) && is_array( $payload['items'] ) ? array_values( $payload['items'] ) : array();
				$results  = array();
				$failures = array();
				$targets  = array();

				if ( is_wp_error( $upload ) ) {
					return $upload;
				}

				if ( empty( $items ) ) {
					return new WP_Error( 'rspd_agent_deploy_items_missing', __( 'Add at least one website deployment item.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				foreach ( $items as $index => $item ) {
					$item        = is_array( $item ) ? $item : array();
					$source_file = $this->security->normalize_relative_path( isset( $item['source_file'] ) ? $item['source_file'] : '' );
					$target_mode = sanitize_key( isset( $item['target_mode'] ) ? $item['target_mode'] : 'existing' );
					$created_new = false;
					$target_page = null;

					if ( '' === $source_file || ! in_array( $source_file, $upload['html_files'], true ) ) {
						$failures[] = array(
							'index'   => $index,
							'message' => 'The source file "' . $source_file . '" is not present in the uploaded package.',
						);
						continue;
					}

					if ( 'new' === $target_mode ) {
						$target_page = $this->create_page(
							isset( $item['title'] ) ? $item['title'] : ucwords( str_replace( '-', ' ', pathinfo( basename( $source_file ), PATHINFO_FILENAME ) ) ),
							isset( $item['slug'] ) ? $item['slug'] : $this->bridge->derive_slug_from_html_file_public( $source_file )
						);

						if ( is_wp_error( $target_page ) ) {
							$failures[] = array(
								'index'   => $index,
								'message' => $target_page->get_error_message(),
							);
							continue;
						}

						$created_new = true;
					} else {
						$page_id     = isset( $item['existing_page_id'] ) ? absint( $item['existing_page_id'] ) : 0;
						$target_page = $page_id ? get_post( $page_id ) : null;

						if ( ! $target_page instanceof WP_Post || 'page' !== $target_page->post_type ) {
							$failures[] = array(
								'index'   => $index,
								'message' => 'Select a valid existing WordPress page for "' . $source_file . '".',
							);
							continue;
						}
					}

					$page_id = (int) $target_page->ID;
					if ( in_array( $page_id, $targets, true ) ) {
						$failures[] = array(
							'index'   => $index,
							'message' => 'The page "' . $target_page->post_title . '" is targeted more than once in this batch.',
						);
						if ( $created_new ) {
							wp_delete_post( $page_id, true );
						}
						continue;
					}

					$targets[] = $page_id;
					$result    = $this->deployer->deploy_local_static_package_to_page(
						$upload['source_absolute_dir'],
						$page_id,
						array(
							'entry_file'  => $source_file,
							'source_type' => 'agent_upload',
						)
					);

					if ( is_wp_error( $result ) ) {
						if ( $created_new ) {
							wp_delete_post( $page_id, true );
						}
						$failures[] = array(
							'index'   => $index,
							'message' => $result->get_error_message(),
						);
						continue;
					}

					$pref = $this->apply_page_render_preferences( $page_id, $item );
					if ( is_wp_error( $pref ) ) {
						if ( $created_new ) {
							wp_delete_post( $page_id, true );
						}
						$failures[] = array(
							'index'   => $index,
							'message' => $pref->get_error_message(),
						);
						continue;
					}

					$results[] = array(
						'page_id'     => $page_id,
						'title'       => get_the_title( $page_id ),
						'permalink'   => get_permalink( $page_id ),
						'source_file' => $source_file,
						'target_mode' => $target_mode,
						'created_new' => $created_new,
						'warnings'    => ! empty( $result['warnings'] ) ? $result['warnings'] : array(),
					);
				}

				foreach ( $results as $result ) {
					$this->deployer->rebuild_page_deployment( $result['page_id'] );
				}

				if ( empty( $failures ) ) {
					$this->storage->delete_agent_upload_session( $upload['upload_id'], true );
				}

				return array(
					'results'   => $results,
					'failures'  => $failures,
					'upload_id' => $upload['upload_id'],
					'message'   => sprintf( 'Website deployment completed. %d page%s deployed.', count( $results ), 1 === count( $results ) ? '' : 's' ),
				);
			}
		);
	}

	public function rest_post_deploy_software_app( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'software_apps_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$payload = $this->get_request_payload( $request );
				$upload  = $this->validate_upload_session( isset( $payload['upload_id'] ) ? $payload['upload_id'] : '' );

				if ( is_wp_error( $upload ) ) {
					return $upload;
				}

				$result = $this->deployer->deploy_software_app_from_directory(
					$upload['source_absolute_dir'],
					isset( $payload['parent_slug'] ) ? $payload['parent_slug'] : '',
					isset( $payload['entry_file'] ) ? $payload['entry_file'] : $upload['entry_file'],
					isset( $payload['label'] ) ? $payload['label'] : ''
				);

				if ( is_wp_error( $result ) ) {
					return $result;
				}

				$this->storage->delete_agent_upload_session( $upload['upload_id'], true );

				return array(
					'software_app' => $result,
					'message'      => 'Software app deployed successfully.',
				);
			}
		);
	}

	public function rest_post_deploy_raw_page( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'website_pages_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$payload     = $this->get_request_payload( $request );
				$combined    = isset( $payload['combined_code'] ) ? (string) $payload['combined_code'] : ( isset( $payload['html'] ) ? (string) $payload['html'] : '' );
				$render      = $this->normalize_render_mode_input( isset( $payload['render_mode'] ) ? $payload['render_mode'] : 'display_as_is', isset( $payload['raw_html'] ) ? $payload['raw_html'] : null );
				$page_id     = isset( $payload['page_id'] ) ? absint( $payload['page_id'] ) : 0;
				$created_new = false;

				if ( '' === trim( $combined ) ) {
					return new WP_Error( 'rspd_agent_raw_page_missing_html', __( 'Raw page deployment requires HTML content.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				if ( ! $page_id ) {
					$page = $this->create_page(
						isset( $payload['title'] ) ? $payload['title'] : __( 'New Archimedes Page', 'reputifly-static-page-deployer' ),
						isset( $payload['slug'] ) ? $payload['slug'] : ''
					);
					if ( is_wp_error( $page ) ) {
						return $page;
					}
					$page_id     = (int) $page->ID;
					$created_new = true;
				}

				$result = $this->deployer->save_deployment(
					array(
						'page_id'                 => $page_id,
						'enabled'                 => 1,
						'import_method'           => 'paste',
						'preserve_existing_source'=> $page_id ? 1 : 0,
						'combined_code'           => $combined,
						'render_mode'             => $render['render_mode'],
						'raw_html'                => $render['raw_html'],
						'preserve_imported_head'  => array_key_exists( 'preserve_imported_head', $payload ) ? ( ! empty( $payload['preserve_imported_head'] ) ? 1 : 0 ) : 1,
						'prefer_plugin_metadata'  => ! empty( $payload['prefer_plugin_metadata'] ) ? 1 : 0,
						'compatibility_wp_head'   => ! empty( $payload['compatibility']['wp_head'] ) ? 1 : 0,
						'compatibility_wp_footer' => ! empty( $payload['compatibility']['wp_footer'] ) ? 1 : 0,
					)
				);

				if ( is_wp_error( $result ) ) {
					if ( $created_new ) {
						wp_delete_post( $page_id, true );
					}
					return $result;
				}

				return array(
					'page_id'     => $page_id,
					'title'       => get_the_title( $page_id ),
					'permalink'   => get_permalink( $page_id ),
					'created_new' => $created_new,
					'message'     => 'Raw page deployed successfully.',
				);
			}
		);
	}

	public function rest_post_rebuild_page( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deploy_rebuild' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$result  = $this->deployer->rebuild_page_deployment( $page_id );

				if ( is_wp_error( $result ) ) {
					return $result;
				}

				return array(
					'page_id'  => $page_id,
					'warnings' => ! empty( $result['warnings'] ) ? $result['warnings'] : array(),
					'message'  => 'Deployment rebuilt successfully.',
				);
			}
		);
	}

	public function rest_post_rebuild_all( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deploy_rebuild' ),
			true,
			function () {
				$results = $this->deployer->rebuild_all_deployments();
				$summary = array(
					'successful' => 0,
					'failed'     => 0,
				);

				foreach ( $results as $result ) {
					if ( is_wp_error( $result ) ) {
						$summary['failed']++;
					} else {
						$summary['successful']++;
					}
				}

				return array(
					'results' => $results,
					'summary' => $summary,
					'message' => sprintf( 'Rebuild completed. %d succeeded, %d failed.', $summary['successful'], $summary['failed'] ),
				);
			}
		);
	}

	public function rest_delete_page( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deploy_delete' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				if ( ! $page_id || empty( $this->storage->get_page_config( $page_id ) ) ) {
					return new WP_Error( 'rspd_agent_missing_deployment', __( 'No managed deployment exists for that page.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$title = get_the_title( $page_id );
				$this->deployer->delete_deployment( $page_id );

				return array(
					'page_id' => $page_id,
					'title'   => $title,
					'message' => 'Deployment deleted successfully.',
				);
			}
		);
	}

	public function rest_delete_software_app( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deploy_delete' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$slug   = trim( sanitize_title( (string) $request['slug'] ), '/' );
				$record = $this->storage->get_software_app( $slug );

				if ( empty( $record ) ) {
					return new WP_Error( 'rspd_agent_missing_software_app', __( 'No software app exists for that slug.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$this->deployer->delete_software_app( $slug );

				return array(
					'slug'    => $slug,
					'message' => 'Software app deleted successfully.',
				);
			}
		);
	}

	public function rest_post_patch_deployment_file( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'website_pages_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$config  = $this->storage->get_page_config( $page_id );
				$payload = $this->get_request_payload( $request );

				if ( empty( $config['deployment_rel_dir'] ) ) {
					return new WP_Error( 'rspd_agent_missing_deployment', __( 'No managed deployment exists for that page.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$relative_path = isset( $payload['path'] ) ? (string) $payload['path'] : '';
				$content       = array_key_exists( 'content', $payload ) ? (string) $payload['content'] : null;
				$allow_create  = ! empty( $payload['create_if_missing'] );
				$rebuild_after = ! array_key_exists( 'rebuild_after', $payload ) || ! empty( $payload['rebuild_after'] );

				if ( null === $content ) {
					return new WP_Error( 'rspd_agent_patch_content_missing', __( 'Patched file updates require a content string.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$absolute_root = $this->storage->get_deployment_path( $config['deployment_rel_dir'] );
				$file          = $this->write_agent_text_file( $absolute_root, $relative_path, $content, $allow_create );
				if ( is_wp_error( $file ) ) {
					return $file;
				}

				$config['updated_at'] = time();
				$config['cache_version'] = wp_generate_password( 12, false, false );
				if ( $allow_create || preg_match( '/\.html?$/i', $file['path'] ) ) {
					$config['html_files'] = $this->scan_html_files( $absolute_root );
				}
				$this->storage->update_page_config( $page_id, $config );

				if ( $rebuild_after ) {
					$rebuilt = $this->deployer->rebuild_page_deployment( $page_id );
					if ( is_wp_error( $rebuilt ) ) {
						return $rebuilt;
					}
				} else {
					$this->bridge->purge_frontend_cache_for_page_public( $page_id );
				}

				return array(
					'page_id'       => $page_id,
					'file'          => $this->build_file_payload( $absolute_root, $file['path'] ),
					'rebuilt'       => $rebuild_after,
					'public_url'    => trailingslashit( $this->storage->get_public_deployment_url( $page_id ) ) . ltrim( $file['path'], '/' ),
					'message'       => 'Deployment file patched successfully.',
				);
			}
		);
	}

	public function rest_post_update_software_app( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'software_apps_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$slug    = trim( sanitize_title( (string) $request['slug'] ), '/' );
				$record  = $this->storage->get_software_app( $slug );
				$payload = $this->get_request_payload( $request );
				$upload  = $this->validate_upload_session( isset( $payload['upload_id'] ) ? $payload['upload_id'] : '' );

				if ( empty( $record['relative_dir'] ) ) {
					return new WP_Error( 'rspd_agent_missing_software_app', __( 'No software app exists for that slug.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				if ( is_wp_error( $upload ) ) {
					return $upload;
				}

				$result = $this->deployer->deploy_software_app_from_directory(
					$upload['source_absolute_dir'],
					$slug,
					isset( $payload['entry_file'] ) ? $payload['entry_file'] : ( ! empty( $record['entry_file'] ) ? $record['entry_file'] : $upload['entry_file'] ),
					isset( $payload['label'] ) ? $payload['label'] : ( ! empty( $record['label'] ) ? $record['label'] : '' )
				);

				if ( is_wp_error( $result ) ) {
					return $result;
				}

				$this->storage->delete_agent_upload_session( $upload['upload_id'], true );

				return array(
					'software_app' => $result,
					'message'      => 'Software app updated successfully.',
				);
			}
		);
	}

	public function rest_post_rename_software_app( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'software_apps_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$slug      = trim( sanitize_title( (string) $request['slug'] ), '/' );
				$record    = $this->storage->get_software_app( $slug );
				$payload   = $this->get_request_payload( $request );
				$new_slug  = ! empty( $payload['new_slug'] ) ? trim( sanitize_title( (string) $payload['new_slug'] ), '/' ) : '';
				$label     = isset( $payload['label'] ) ? $payload['label'] : ( ! empty( $record['label'] ) ? $record['label'] : '' );
				$entry_file = isset( $payload['entry_file'] ) ? $payload['entry_file'] : ( ! empty( $record['entry_file'] ) ? $record['entry_file'] : '' );
				$replace_existing = ! empty( $payload['replace_existing'] );

				if ( empty( $record['relative_dir'] ) ) {
					return new WP_Error( 'rspd_agent_missing_software_app', __( 'No software app exists for that slug.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				if ( '' === $new_slug ) {
					return new WP_Error( 'rspd_agent_software_slug_missing', __( 'Provide a new software app slug.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				if ( $new_slug === $slug ) {
					return new WP_Error( 'rspd_agent_software_slug_same', __( 'The new software app slug matches the current slug.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$existing_target = $this->storage->get_software_app( $new_slug );
				if ( ! empty( $existing_target ) && ! $replace_existing ) {
					return new WP_Error( 'rspd_agent_software_slug_taken', __( 'That software app slug is already in use. Pass replace_existing to overwrite it.', 'reputifly-static-page-deployer' ), array( 'status' => 409 ) );
				}

				$result = $this->deployer->deploy_software_app_from_directory(
					$this->storage->get_deployment_path( $record['relative_dir'] ),
					$new_slug,
					$entry_file,
					$label
				);

				if ( is_wp_error( $result ) ) {
					return $result;
				}

				$this->storage->remove_software_app( $slug, true );

				return array(
					'old_slug'     => $slug,
					'software_app' => $result,
					'message'      => 'Software app renamed successfully.',
				);
			}
		);
	}

	public function rest_post_update_software_entry_file( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'software_apps_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$slug      = trim( sanitize_title( (string) $request['slug'] ), '/' );
				$record    = $this->storage->get_software_app( $slug );
				$payload   = $this->get_request_payload( $request );
				$entry_file = isset( $payload['entry_file'] ) ? (string) $payload['entry_file'] : '';

				if ( empty( $record['relative_dir'] ) ) {
					return new WP_Error( 'rspd_agent_missing_software_app', __( 'No software app exists for that slug.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				if ( '' === trim( $entry_file ) ) {
					return new WP_Error( 'rspd_agent_software_entry_missing', __( 'Provide an entry file for the software app.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$result = $this->deployer->deploy_software_app_from_directory(
					$this->storage->get_deployment_path( $record['relative_dir'] ),
					$slug,
					$entry_file,
					! empty( $record['label'] ) ? $record['label'] : ''
				);

				if ( is_wp_error( $result ) ) {
					return $result;
				}

				return array(
					'software_app' => $result,
					'message'      => 'Software app entry file updated successfully.',
				);
			}
		);
	}

	public function rest_post_patch_software_file( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'software_apps_deploy' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$slug     = trim( sanitize_title( (string) $request['slug'] ), '/' );
				$record   = $this->storage->get_software_app( $slug );
				$payload  = $this->get_request_payload( $request );
				$relative_path = isset( $payload['path'] ) ? (string) $payload['path'] : '';
				$content       = array_key_exists( 'content', $payload ) ? (string) $payload['content'] : null;
				$allow_create  = ! empty( $payload['create_if_missing'] );

				if ( empty( $record['relative_dir'] ) ) {
					return new WP_Error( 'rspd_agent_missing_software_app', __( 'No software app exists for that slug.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				if ( null === $content ) {
					return new WP_Error( 'rspd_agent_patch_content_missing', __( 'Patched file updates require a content string.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$absolute_root = $this->storage->get_deployment_path( $record['relative_dir'] );
				$file          = $this->write_agent_text_file( $absolute_root, $relative_path, $content, $allow_create );
				if ( is_wp_error( $file ) ) {
					return $file;
				}

				$record['html_files'] = $this->scan_html_files( $absolute_root );
				if ( empty( $record['entry_file'] ) || ! in_array( $record['entry_file'], $record['html_files'], true ) ) {
					$record['entry_file'] = $this->detect_entry_file( $record['html_files'], '' );
				}
				$record['updated_at'] = time();
				$this->storage->update_software_app( $slug, $record );

				return array(
					'software_app' => array(
						'slug'       => $slug,
						'label'      => ! empty( $record['label'] ) ? $record['label'] : ucfirst( str_replace( '-', ' ', $slug ) ),
						'url'        => $this->storage->get_software_mount_url( $slug ),
						'entry_file' => ! empty( $record['entry_file'] ) ? $record['entry_file'] : '',
						'html_files' => ! empty( $record['html_files'] ) ? array_values( $record['html_files'] ) : array(),
						'routes'     => $this->storage->get_software_app_routes( $slug, ! empty( $record['entry_file'] ) ? $record['entry_file'] : '', ! empty( $record['html_files'] ) ? $record['html_files'] : array() ),
					),
					'file'        => $this->build_file_payload( $absolute_root, $file['path'] ),
					'message'     => 'Software app file patched successfully.',
				);
			}
		);
	}

	public function rest_post_layout_injections( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'layout_injections_manage' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$payload         = $this->get_request_payload( $request );
				$settings        = $this->storage->get_settings();
				$existing_layout = ! empty( $settings['layout_injections'] ) && is_array( $settings['layout_injections'] ) ? $settings['layout_injections'] : array();
				$old_page_ids    = ! empty( $existing_layout['page_ids'] ) && is_array( $existing_layout['page_ids'] ) ? array_values( array_unique( array_map( 'absint', $existing_layout['page_ids'] ) ) ) : array();
				$raw_page_ids    = ! empty( $payload['page_ids'] ) && is_array( $payload['page_ids'] ) ? array_values( array_unique( array_map( 'absint', $payload['page_ids'] ) ) ) : array();
				$allowed_page_ids = array();

				foreach ( $this->storage->get_deployments() as $deployment ) {
					if ( ! empty( $deployment['page']->ID ) ) {
						$allowed_page_ids[] = (int) $deployment['page']->ID;
					}
				}

				$page_ids = array_values( array_intersect( $raw_page_ids, $allowed_page_ids ) );
				$settings['layout_injections'] = array(
					'header_html' => $this->bridge->sanitize_layout_markup_public( isset( $payload['header_html'] ) ? $payload['header_html'] : '' ),
					'body_html'   => $this->bridge->sanitize_layout_markup_public( isset( $payload['body_html'] ) ? $payload['body_html'] : '' ),
					'footer_html' => $this->bridge->sanitize_layout_markup_public( isset( $payload['footer_html'] ) ? $payload['footer_html'] : '' ),
					'page_ids'    => $page_ids,
				);
				$this->storage->update_settings( $settings );

				$refreshed = array();
				foreach ( array_values( array_unique( array_merge( $old_page_ids, $page_ids ) ) ) as $page_id ) {
					$config = $this->storage->get_page_config( $page_id );
					if ( empty( $config['deployment_rel_dir'] ) ) {
						continue;
					}
					$this->bridge->refresh_layout_target_page_public( $page_id, $config );
					$refreshed[] = $page_id;
				}

				return array(
					'layout_injections' => $this->build_layout_injections_payload(),
					'refreshed_pages'   => $refreshed,
					'message'           => empty( $page_ids ) ? 'Layout injections saved, but no pages are selected.' : 'Layout injections saved and refreshed immediately.',
				);
			}
		);
	}

	public function rest_post_page_overrides( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'page_overrides_manage' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$config  = $this->storage->get_page_config( $page_id );
				$payload = $this->get_request_payload( $request );

				if ( empty( $config ) ) {
					return new WP_Error( 'rspd_agent_missing_deployment', __( 'No deployment exists for that page.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$submitted                = ! empty( $payload['overrides'] ) && is_array( $payload['overrides'] ) ? $payload['overrides'] : $payload;
				$config['page_overrides'] = $this->sanitize_direct_overrides( $submitted );
				$this->storage->update_page_config( $page_id, $config );
				$result = $this->deployer->rebuild_page_deployment( $page_id );

				if ( is_wp_error( $result ) ) {
					return $result;
				}

				return array(
					'page_id'   => $page_id,
					'overrides' => $config['page_overrides'],
					'message'   => 'Page overrides saved and deployment rebuilt.',
				);
			}
		);
	}

	public function rest_post_replace_urls( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'replace_urls' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$payload      = $this->get_request_payload( $request );
				$original     = trim( isset( $payload['original_url'] ) ? (string) $payload['original_url'] : '' );
				$new          = trim( isset( $payload['new_url'] ) ? (string) $payload['new_url'] : '' );
				$selected_ids = ! empty( $payload['page_ids'] ) && is_array( $payload['page_ids'] ) ? array_values( array_unique( array_map( 'absint', $payload['page_ids'] ) ) ) : array();
				$allowed_ids  = array();

				foreach ( $this->storage->get_deployments() as $deployment ) {
					if ( ! empty( $deployment['page']->ID ) ) {
						$allowed_ids[] = (int) $deployment['page']->ID;
					}
				}

				$selected_ids = array_values( array_intersect( $selected_ids, $allowed_ids ) );

				if ( empty( $selected_ids ) ) {
					return new WP_Error( 'rspd_agent_replace_pages_missing', __( 'Select at least one deployed page before replacing URLs.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}
				if ( '' === $original || '' === $new ) {
					return new WP_Error( 'rspd_agent_replace_missing_values', __( 'Both original_url and new_url are required.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}
				if ( $original === $new ) {
					return new WP_Error( 'rspd_agent_replace_same_values', __( 'The original and new URLs are identical.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$backup  = $this->storage->create_backup_directory( 'agent-url-replace' );
				$summary = array(
					'pages_updated'     => 0,
					'files_changed'     => 0,
					'replacement_count' => 0,
					'backed_up_files'   => 0,
					'changed_pages'     => array(),
					'errors'            => array(),
				);

				foreach ( $selected_ids as $page_id ) {
					$config = $this->storage->get_page_config( $page_id );
					if ( empty( $config['deployment_rel_dir'] ) ) {
						continue;
					}

					$targets            = $this->bridge->get_replace_targets_for_page_public( $config );
					$page_changed       = false;
					$variant_keys_reset = array();

					foreach ( $targets as $target_key => $relative_dir ) {
						$result = $this->storage->replace_string_in_deployment( $relative_dir, $original, $new, $backup['absolute_dir'] );
						$summary['files_changed'] += (int) $result['files_changed'];
						$summary['replacement_count'] += (int) $result['replacement_count'];
						$summary['backed_up_files'] += (int) $result['backed_up_files'];

						if ( ! empty( $result['errors'] ) ) {
							$summary['errors'] = array_merge( $summary['errors'], $result['errors'] );
						}

						if ( ! empty( $result['files_changed'] ) ) {
							$page_changed = true;
							if ( 'main' === $target_key ) {
								$config['cache_version'] = wp_generate_password( 12, false, false );
							} elseif ( 0 === strpos( $target_key, 'variant:' ) ) {
								$variant_key = substr( $target_key, 8 );
								if ( ! empty( $config['ab_test']['variants'][ $variant_key ] ) ) {
									$config['ab_test']['variants'][ $variant_key ]['cache_version'] = wp_generate_password( 12, false, false );
									$variant_keys_reset[] = $variant_key;
								}
							}
						}
					}

					if ( ! $page_changed ) {
						continue;
					}

					$config['updated_at'] = time();
					$this->storage->update_page_config( $page_id, $config );
					delete_transient( 'rspd_render_' . $page_id );
					foreach ( array_unique( $variant_keys_reset ) as $variant_key ) {
						delete_transient( 'rspd_render_' . $page_id . '_' . sanitize_key( $variant_key ) );
					}
					$this->bridge->purge_frontend_cache_for_page_public( $page_id );
					$summary['pages_updated']++;
					$summary['changed_pages'][] = get_the_title( $page_id );
				}

				$summary['errors']             = array_values( array_unique( $summary['errors'] ) );
				$summary['backup_relative_dir'] = $backup['relative_dir'];

				return array(
					'summary' => $summary,
					'message' => $summary['files_changed'] > 0 ? sprintf( 'URL replacement completed. %d file%s changed.', $summary['files_changed'], 1 === (int) $summary['files_changed'] ? '' : 's' ) : 'No matching URLs were found in the selected deployments.',
				);
			}
		);
	}

	protected function get_agent_editable_page_statuses() {
		return array( 'publish', 'draft', 'pending', 'private', 'future' );
	}

	protected function rebuild_related_package_pages( $package_key, $exclude_page_id = 0 ) {
		$package_key = trim( (string) $package_key );
		$results     = array();

		if ( '' === $package_key ) {
			return $results;
		}

		foreach ( $this->storage->get_deployments() as $deployment ) {
			$page_id = ! empty( $deployment['page']->ID ) ? (int) $deployment['page']->ID : 0;
			$config  = ! empty( $deployment['config'] ) && is_array( $deployment['config'] ) ? $deployment['config'] : array();

			if ( ! $page_id || $page_id === absint( $exclude_page_id ) ) {
				continue;
			}

			if ( empty( $config['package_key'] ) || $package_key !== (string) $config['package_key'] ) {
				continue;
			}

			$page = get_post( $page_id );
			if ( ! $page instanceof WP_Post || 'page' !== $page->post_type || 'trash' === $page->post_status ) {
				continue;
			}

			$rebuilt = $this->deployer->rebuild_page_deployment( $page_id );
			$results[] = array(
				'page_id' => $page_id,
				'title'   => $page->post_title,
				'success' => ! is_wp_error( $rebuilt ),
				'message' => is_wp_error( $rebuilt ) ? $rebuilt->get_error_message() : 'Rebuilt',
			);
		}

		return $results;
	}

	protected function write_agent_text_file( $absolute_root, $relative_path, $content, $allow_create = false ) {
		$absolute_root = wp_normalize_path( (string) $absolute_root );
		$relative_path = $this->security->normalize_relative_path( $relative_path );

		if ( '' === $relative_path ) {
			return new WP_Error( 'rspd_agent_invalid_file_path', __( 'Provide a valid deployment-relative file path.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
		}

		$absolute_path = $this->security->safe_join( $absolute_root, $relative_path );
		if ( ! $absolute_path ) {
			return new WP_Error( 'rspd_agent_invalid_file_path', __( 'That file path is outside the managed deployment.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
		}

		$absolute_path = wp_normalize_path( $absolute_path );
		$exists        = file_exists( $absolute_path );

		if ( $exists && is_dir( $absolute_path ) ) {
			return new WP_Error( 'rspd_agent_invalid_file_target', __( 'Directories cannot be patched through this endpoint.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
		}

		if ( $exists ) {
			$file = $this->build_file_payload( $absolute_root, $relative_path );
			if ( is_wp_error( $file ) ) {
				return $file;
			}
			if ( empty( $file['is_text'] ) ) {
				return new WP_Error( 'rspd_agent_binary_patch_forbidden', __( 'Only text files can be patched through Agentic AI.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
			}
		} elseif ( ! $allow_create ) {
			return new WP_Error( 'rspd_agent_missing_file', __( 'That file does not exist. Pass create_if_missing to create it.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
		} elseif ( ! $this->is_text_file( $relative_path ) ) {
			return new WP_Error( 'rspd_agent_file_type_forbidden', __( 'Only text-based files can be created through this endpoint.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
		}

		if ( ! $this->storage->write_file( $absolute_path, (string) $content ) ) {
			return new WP_Error( 'rspd_agent_file_write_failed', __( 'The deployment file could not be saved.', 'reputifly-static-page-deployer' ), array( 'status' => 500 ) );
		}

		return array(
			'path'    => $relative_path,
			'created' => ! $exists,
		);
	}
}
