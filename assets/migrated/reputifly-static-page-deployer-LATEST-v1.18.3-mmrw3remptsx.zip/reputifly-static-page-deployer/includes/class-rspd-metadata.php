<?php
/**
 * Metadata parsing and head generation.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Metadata manager.
 */
class RSPD_Metadata {

	/**
	 * Security helper.
	 *
	 * @var RSPD_Security
	 */
	protected $security;

	/**
	 * Performance helper.
	 *
	 * @var RSPD_Performance
	 */
	protected $performance;

	/**
	 * Constructor.
	 *
	 * @param RSPD_Security    $security    Security helper.
	 * @param RSPD_Performance $performance Performance helper.
	 */
	public function __construct( RSPD_Security $security, RSPD_Performance $performance ) {
		$this->security    = $security;
		$this->performance = $performance;
	}

	/**
	 * Parse source HTML into a deployable render bundle shape.
	 *
	 * @param string $html                Raw source HTML.
	 * @param array  $context             Deployment context.
	 * @param array  $performance_options Page performance options.
	 * @return array|WP_Error
	 */
	public function parse_source( $html, array $context, array $performance_options = array() ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return new WP_Error( 'rspd_dom_missing', __( 'DOMDocument is required to parse imported HTML on this server.', 'reputifly-static-page-deployer' ) );
		}

		$is_full_document = $this->looks_like_document( $html );
		$wrapped_html     = $is_full_document ? (string) $html : $this->wrap_fragment( $html, $context );
		$doctype          = $this->extract_doctype( $wrapped_html );
		$document         = $this->load_document( $wrapped_html );

		if ( ! $document ) {
			return new WP_Error( 'rspd_invalid_html', __( 'The imported HTML could not be parsed.', 'reputifly-static-page-deployer' ) );
		}

		$html_node = $document->getElementsByTagName( 'html' )->item( 0 );
		$head_node = $document->getElementsByTagName( 'head' )->item( 0 );
		$body_node = $document->getElementsByTagName( 'body' )->item( 0 );

		if ( ! $html_node ) {
			return new WP_Error( 'rspd_missing_html', __( 'The imported document is missing an <html> element.', 'reputifly-static-page-deployer' ) );
		}

		if ( ! $head_node ) {
			$head_node = $document->createElement( 'head' );
			$html_node->insertBefore( $head_node, $html_node->firstChild );
		}

		if ( ! $body_node ) {
			$body_node = $document->createElement( 'body' );
			$html_node->appendChild( $body_node );
		}

		$asset_refs = array();
		$warnings   = array();

		$this->rewrite_document_references( $document, $context, $asset_refs, $warnings );
		$this->performance->apply_dom_optimizations( $document, $context, $performance_options, $asset_refs, $warnings );

		return array(
			'is_full_document' => $is_full_document,
			'doctype'          => $doctype ? $doctype : '<!doctype html>',
			'html_attrs'       => $this->serialize_attributes( $html_node ),
			'body_attrs'       => $this->serialize_attributes( $body_node ),
			'body_html'        => $this->get_inner_html( $body_node ),
			'imported_meta'    => $this->extract_imported_metadata( $head_node ),
			'extra_head_html'  => $this->extract_extra_head_html( $head_node ),
			'asset_refs'       => $asset_refs,
			'warnings'         => array_values( array_unique( $warnings ) ),
		);
	}

	/**
	 * Rewrite a raw document while preserving its original document shape.
	 *
	 * @param string $html     Raw source HTML.
	 * @param array  $context  Deployment context.
	 * @param array  $warnings Collected warnings.
	 * @return string|WP_Error
	 */
	public function rewrite_raw_document( $html, array $context, array &$warnings ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return new WP_Error( 'rspd_dom_missing', __( 'DOMDocument is required to parse imported HTML on this server.', 'reputifly-static-page-deployer' ) );
		}

		$is_full_document = $this->looks_like_document( $html );
		$wrapped_html     = $is_full_document ? (string) $html : $this->wrap_fragment( $html, $context );
		$doctype          = $this->extract_doctype( $wrapped_html );
		$document         = $this->load_document( $wrapped_html );

		if ( ! $document ) {
			return new WP_Error( 'rspd_invalid_html', __( 'The imported HTML could not be parsed.', 'reputifly-static-page-deployer' ) );
		}

		$html_node = $document->getElementsByTagName( 'html' )->item( 0 );
		$head_node = $document->getElementsByTagName( 'head' )->item( 0 );
		$body_node = $document->getElementsByTagName( 'body' )->item( 0 );

		if ( ! $html_node ) {
			return new WP_Error( 'rspd_missing_html', __( 'The imported document is missing an <html> element.', 'reputifly-static-page-deployer' ) );
		}

		if ( ! $head_node ) {
			$head_node = $document->createElement( 'head' );
			$html_node->insertBefore( $head_node, $html_node->firstChild );
		}

		if ( ! $body_node ) {
			$body_node = $document->createElement( 'body' );
			$html_node->appendChild( $body_node );
		}

		$asset_refs = array();
		$this->rewrite_document_references( $document, $context, $asset_refs, $warnings );

		return $doctype . "\n" . $document->saveHTML( $html_node );
	}

	/**
	 * Merge imported metadata, page-level metadata, and defaults.
	 *
	 * @param array   $parsed   Parsed source data.
	 * @param array   $config   Deployment config.
	 * @param WP_Post $page     Target page object.
	 * @param array   $settings Plugin settings.
	 * @return array
	 */
	public function build_final_metadata( array $parsed, array $config, WP_Post $page, array $settings ) {
		$preserve_imported = ! empty( $config['preserve_imported_head'] );
		$prefer_plugin     = ! empty( $config['prefer_plugin_metadata'] );
		$defaults          = isset( $settings['metadata'] ) && is_array( $settings['metadata'] ) ? $settings['metadata'] : array();
		$page_meta         = isset( $config['metadata'] ) && is_array( $config['metadata'] ) ? $config['metadata'] : array();
		$imported          = $preserve_imported && ! empty( $parsed['imported_meta'] ) && is_array( $parsed['imported_meta'] ) ? $parsed['imported_meta'] : array();
		$permalink         = get_permalink( $page );

		$stack_primary = $prefer_plugin ? array( $page_meta, $defaults, $imported ) : array( $page_meta, $imported, $defaults );
		$stack_social  = $prefer_plugin ? array( $page_meta, $defaults, $imported ) : array( $page_meta, $imported, $defaults );

		$metadata = array(
			'charset'             => $this->pick_first( $stack_primary, 'charset', get_bloginfo( 'charset' ) ),
			'viewport'            => $this->pick_first( $stack_primary, 'viewport', 'width=device-width, initial-scale=1' ),
			'title'               => $this->pick_first( $stack_primary, 'seo_title', '' ),
			'description'         => $this->pick_first( $stack_primary, 'meta_description', '' ),
			'canonical'           => $this->pick_first( $stack_primary, 'canonical_url', $permalink ),
			'robots'              => $this->pick_first( $stack_primary, 'robots', 'index,follow' ),
			'og_title'            => $this->pick_first( $stack_social, 'og_title', '' ),
			'og_description'      => $this->pick_first( $stack_social, 'og_description', '' ),
			'og_image'            => $this->pick_first( $stack_social, 'og_image', '' ),
			'twitter_card'        => $this->pick_first( $stack_social, 'twitter_card', 'summary_large_image' ),
			'twitter_title'       => $this->pick_first( $stack_social, 'twitter_title', '' ),
			'twitter_description' => $this->pick_first( $stack_social, 'twitter_description', '' ),
			'twitter_image'       => $this->pick_first( $stack_social, 'twitter_image', '' ),
			'json_ld'             => $this->build_json_ld_blocks( $page_meta, $imported ),
		);

		if ( '' === $metadata['title'] ) {
			$metadata['title'] = ! empty( $imported['title'] ) ? $imported['title'] : get_the_title( $page );
		}

		if ( '' === $metadata['description'] && ! empty( $defaults['description'] ) ) {
			$metadata['description'] = (string) $defaults['description'];
		}

		if ( '' === $metadata['og_title'] ) {
			$metadata['og_title'] = $metadata['title'];
		}

		if ( '' === $metadata['og_description'] ) {
			$metadata['og_description'] = $metadata['description'];
		}

		if ( '' === $metadata['twitter_title'] ) {
			$metadata['twitter_title'] = $metadata['og_title'];
		}

		if ( '' === $metadata['twitter_description'] ) {
			$metadata['twitter_description'] = $metadata['og_description'];
		}

		if ( '' === $metadata['twitter_image'] ) {
			$metadata['twitter_image'] = $metadata['og_image'];
		}

		return $metadata;
	}

	/**
	 * Build head markup from the resolved metadata and preserved head tags.
	 *
	 * @param array $metadata Final metadata payload.
	 * @param array $config   Deployment config.
	 * @param array $parsed   Parsed source data.
	 * @return string
	 */
	public function build_head_html( array $metadata, array $config, array $parsed ) {
		$tags = array();

		if ( ! empty( $metadata['charset'] ) ) {
			$tags[] = '<meta charset="' . esc_attr( $metadata['charset'] ) . '">';
		}

		if ( ! empty( $metadata['viewport'] ) ) {
			$tags[] = '<meta name="viewport" content="' . esc_attr( $metadata['viewport'] ) . '">';
		}

		$tags[] = '<title>' . esc_html( wp_strip_all_tags( $metadata['title'] ) ) . '</title>';

		if ( ! empty( $metadata['description'] ) ) {
			$tags[] = '<meta name="description" content="' . esc_attr( $metadata['description'] ) . '">';
		}

		if ( ! empty( $metadata['robots'] ) ) {
			$tags[] = '<meta name="robots" content="' . esc_attr( $metadata['robots'] ) . '">';
		}

		if ( ! empty( $metadata['canonical'] ) ) {
			$tags[] = '<link rel="canonical" href="' . esc_url( $metadata['canonical'] ) . '">';
		}

		if ( ! empty( $metadata['og_title'] ) ) {
			$tags[] = '<meta property="og:title" content="' . esc_attr( $metadata['og_title'] ) . '">';
		}

		if ( ! empty( $metadata['og_description'] ) ) {
			$tags[] = '<meta property="og:description" content="' . esc_attr( $metadata['og_description'] ) . '">';
		}

		if ( ! empty( $metadata['canonical'] ) ) {
			$tags[] = '<meta property="og:url" content="' . esc_url( $metadata['canonical'] ) . '">';
		}

		if ( ! empty( $metadata['og_image'] ) ) {
			$tags[] = '<meta property="og:image" content="' . esc_url( $metadata['og_image'] ) . '">';
		}

		if ( ! empty( $metadata['twitter_card'] ) ) {
			$tags[] = '<meta name="twitter:card" content="' . esc_attr( $metadata['twitter_card'] ) . '">';
		}

		if ( ! empty( $metadata['twitter_title'] ) ) {
			$tags[] = '<meta name="twitter:title" content="' . esc_attr( $metadata['twitter_title'] ) . '">';
		}

		if ( ! empty( $metadata['twitter_description'] ) ) {
			$tags[] = '<meta name="twitter:description" content="' . esc_attr( $metadata['twitter_description'] ) . '">';
		}

		if ( ! empty( $metadata['twitter_image'] ) ) {
			$tags[] = '<meta name="twitter:image" content="' . esc_url( $metadata['twitter_image'] ) . '">';
		}

		$performance = isset( $config['performance'] ) && is_array( $config['performance'] ) ? $config['performance'] : array();
		$resource    = $this->performance->build_resource_hint_tags( $performance );

		if ( $resource ) {
			$tags[] = $resource;
		}

		if ( ! empty( $config['preserve_imported_head'] ) && ! empty( $parsed['extra_head_html'] ) ) {
			$tags[] = $parsed['extra_head_html'];
		}

		foreach ( isset( $metadata['json_ld'] ) && is_array( $metadata['json_ld'] ) ? $metadata['json_ld'] : array() as $block ) {
			$tags[] = '<script type="application/ld+json">' . trim( $block ) . '</script>';
		}

		return trim( implode( "\n", array_filter( $tags ) ) );
	}

	/**
	 * Create a complete HTML string for preview or isolated output.
	 *
	 * @param array $bundle Render bundle.
	 * @return string
	 */
	public function compose_document( array $bundle ) {
		$doctype    = ! empty( $bundle['doctype'] ) ? $bundle['doctype'] : '<!doctype html>';
		$html_attrs = ! empty( $bundle['html_attrs'] ) ? ' ' . trim( $bundle['html_attrs'] ) : '';
		$body_attrs = ! empty( $bundle['body_attrs'] ) ? ' ' . trim( $bundle['body_attrs'] ) : '';

		return $doctype . "\n<html" . $html_attrs . ">\n<head>\n" . ( isset( $bundle['head_html'] ) ? $bundle['head_html'] : '' ) . "\n</head>\n<body" . $body_attrs . ">\n" . ( isset( $bundle['body_html'] ) ? $bundle['body_html'] : '' ) . "\n</body>\n</html>";
	}

	/**
	 * Detect a full HTML document.
	 *
	 * @param string $html Raw HTML.
	 * @return bool
	 */
	protected function looks_like_document( $html ) {
		return (bool) preg_match( '/<(?:!doctype|html|head|body)\b/i', (string) $html );
	}

	/**
	 * Wrap fragment markup in a valid shell.
	 *
	 * @param string $html    Fragment markup.
	 * @param array  $context Deployment context.
	 * @return string
	 */
	protected function wrap_fragment( $html, array $context ) {
		$charset  = ! empty( $context['default_charset'] ) ? $context['default_charset'] : get_bloginfo( 'charset' );
		$viewport = ! empty( $context['default_viewport'] ) ? $context['default_viewport'] : 'width=device-width, initial-scale=1';

		return '<!doctype html><html><head><meta charset="' . esc_attr( $charset ) . '"><meta name="viewport" content="' . esc_attr( $viewport ) . '"></head><body>' . $html . '</body></html>';
	}

	/**
	 * Extract the source document doctype.
	 *
	 * @param string $html Raw HTML.
	 * @return string
	 */
	protected function extract_doctype( $html ) {
		if ( preg_match( '/<!doctype[^>]*>/i', (string) $html, $matches ) ) {
			return $matches[0];
		}

		return '<!doctype html>';
	}

	/**
	 * Load HTML into DOMDocument.
	 *
	 * @param string $html HTML string.
	 * @return DOMDocument|null
	 */
	protected function load_document( $html ) {
		libxml_use_internal_errors( true );

		$document = new DOMDocument( '1.0', 'UTF-8' );
		$loaded   = $document->loadHTML(
			'<?xml encoding="utf-8" ?>' . (string) $html,
			LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_COMPACT
		);

		libxml_clear_errors();

		if ( ! $loaded ) {
			return null;
		}

		foreach ( iterator_to_array( $document->childNodes ) as $child ) {
			if ( XML_PI_NODE === $child->nodeType ) {
				$document->removeChild( $child );
				break;
			}
		}

		return $document;
	}

	/**
	 * Rewrite local asset references to deployment URLs.
	 *
	 * @param DOMDocument $document   Parsed document.
	 * @param array       $context    Deployment context.
	 * @param array       $asset_refs Collected asset references.
	 * @param array       $warnings   Collected warnings.
	 * @return void
	 */
	protected function rewrite_document_references( DOMDocument $document, array $context, array &$asset_refs, array &$warnings ) {
		$base_nodes = array();
		foreach ( $document->getElementsByTagName( 'base' ) as $base ) {
			$base_nodes[] = $base;
		}

		foreach ( $base_nodes as $base ) {
			$warnings[] = __( 'The imported document contained a <base> tag; it was removed so deployment URLs stay predictable on the final WordPress page URL.', 'reputifly-static-page-deployer' );
			$base->parentNode->removeChild( $base );
		}

		$targets = array(
			'link'   => array( 'href' ),
			'script' => array( 'src' ),
			'img'    => array( 'src', 'srcset' ),
			'source' => array( 'src', 'srcset' ),
			'video'  => array( 'src', 'poster' ),
			'audio'  => array( 'src' ),
			'track'  => array( 'src' ),
			'iframe' => array( 'src' ),
			'embed'  => array( 'src' ),
			'object' => array( 'data' ),
			'a'      => array( 'href' ),
		);

		foreach ( $targets as $tag => $attributes ) {
			foreach ( $document->getElementsByTagName( $tag ) as $node ) {
				foreach ( $attributes as $attribute ) {
					if ( ! $node->hasAttribute( $attribute ) ) {
						continue;
					}

					$node->setAttribute(
						$attribute,
						$this->rewrite_attribute( $tag, $attribute, $node->getAttribute( $attribute ), $context, $asset_refs, $warnings )
					);
				}

				if ( $node->hasAttribute( 'style' ) ) {
					$node->setAttribute( 'style', $this->rewrite_css_references( $node->getAttribute( 'style' ), $context, $asset_refs ) );
				}
			}
		}

		foreach ( $document->getElementsByTagName( 'script' ) as $script ) {
			if ( $script->hasAttribute( 'src' ) ) {
				continue;
			}

			$script->nodeValue = $this->rewrite_javascript_navigation_references( $script->textContent, $context, $warnings );
		}

		foreach ( $document->getElementsByTagName( 'style' ) as $style ) {
			$style->nodeValue = $this->rewrite_css_references( $style->textContent, $context, $asset_refs );
		}
	}

	/**
	 * Rewrite one attribute value.
	 *
	 * @param string $tag        Tag name.
	 * @param string $attribute  Attribute name.
	 * @param string $value      Original value.
	 * @param array  $context    Deployment context.
	 * @param array  $asset_refs Collected asset references.
	 * @param array  $warnings   Collected warnings.
	 * @return string
	 */
	protected function rewrite_attribute( $tag, $attribute, $value, array $context, array &$asset_refs, array &$warnings ) {
		if ( 'srcset' === $attribute ) {
			return $this->rewrite_srcset( $value, $context, $asset_refs );
		}

		if ( 'a' === $tag && 'href' === $attribute ) {
			$link_parts     = $this->security->split_reference( $value );
			$link_basename  = basename( rtrim( isset( $link_parts['path'] ) ? $link_parts['path'] : '', '/' ) );
			$link_extension = strtolower( pathinfo( $link_basename, PATHINFO_EXTENSION ) );
			$is_html_ref    = $this->security->is_html_reference( isset( $link_parts['path'] ) ? $link_parts['path'] : '' );
			$is_route_like  = '' === $link_extension || $is_html_ref;

			if ( $is_route_like ) {
				$target_url = $this->resolve_html_document_reference( $value, $context, $warnings );

				if ( $target_url ) {
					$asset_refs[] = array(
						'tag'       => $tag,
						'attribute' => $attribute,
						'original'  => $value,
						'resolved'  => isset( $link_parts['path'] ) ? $link_parts['path'] : '',
						'is_local'  => $this->security->is_local_reference( $value ),
						'is_html'   => true,
						'exists'    => true,
						'rewritten' => $target_url,
					);

					return $target_url;
				}
			}
		}

		if ( ! $this->security->is_local_reference( $value ) ) {
			return $value;
		}

		$parts    = $this->security->split_reference( $value );
		$resolved = $this->security->resolve_reference_path( $parts['path'], isset( $context['entry_dir'] ) ? $context['entry_dir'] : '' );

		if ( ! $resolved ) {
			return $value;
		}

		$absolute_path = trailingslashit( $context['deployment_path'] ) . $resolved;
		$exists        = file_exists( $absolute_path );
		$is_html_ref   = $this->security->is_html_reference( $parts['path'] );
		$record        = array(
			'tag'       => $tag,
			'attribute' => $attribute,
			'original'  => $value,
			'resolved'  => $resolved,
			'is_local'  => true,
			'is_html'   => $is_html_ref,
			'exists'    => $exists,
			'rewritten' => '',
		);

		$rewritten = trailingslashit( $context['deployment_url'] ) . ltrim( $resolved, '/' ) . $parts['suffix'];

		if ( ! empty( $context['fingerprint_assets'] ) && $exists && is_file( $absolute_path ) ) {
			$separator = false === strpos( $rewritten, '?' ) ? '?' : '&';
			$rewritten .= $separator . 'v=' . substr( md5_file( $absolute_path ), 0, 10 );
		}

		$record['rewritten'] = $rewritten;
		$asset_refs[]        = $record;

		return $rewritten;
	}

	/**
	 * Rewrite route-like HTML string literals inside JavaScript.
	 *
	 * @param string $javascript Script contents.
	 * @param array  $context    Deployment context.
	 * @param array  $warnings   Collected warnings.
	 * @return string
	 */
	public function rewrite_javascript_navigation_references( $javascript, array $context, array &$warnings ) {
		$javascript = (string) preg_replace_callback(
			'/(["\'])([^"\']+?\.(?:html?|htm)(?:[?#][^"\']*)?)\1/i',
			function ( $matches ) use ( $context, &$warnings ) {
				$reference = isset( $matches[2] ) ? $matches[2] : '';

				if ( ! $this->security->is_local_reference( $reference ) || ! $this->security->is_html_reference( $reference ) ) {
					return $matches[0];
				}

				$rewritten = $this->resolve_html_document_reference( $reference, $context, $warnings );

				if ( ! $rewritten || $rewritten === $reference ) {
					return $matches[0];
				}

				return $matches[1] . $rewritten . $matches[1];
			},
			(string) $javascript
		);

		return (string) preg_replace_callback(
			'/(["\'])((?:\.{1,2}\/|\/)[^"\']+|[^"\']+\/)\1/i',
			function ( $matches ) use ( $context, &$warnings ) {
				$reference = isset( $matches[2] ) ? $matches[2] : '';
				$path      = $this->security->split_reference( $reference );
				$basename  = basename( rtrim( isset( $path['path'] ) ? $path['path'] : '', '/' ) );

				if ( '' !== pathinfo( $basename, PATHINFO_EXTENSION ) ) {
					return $matches[0];
				}

				$rewritten = $this->resolve_html_document_reference( $reference, $context, $warnings );

				if ( ! $rewritten || $rewritten === $reference ) {
					return $matches[0];
				}

				return $matches[1] . $rewritten . $matches[1];
			},
			$javascript
		);
	}

	/**
	 * Rewrite srcset candidates.
	 *
	 * @param string $srcset     Source srcset.
	 * @param array  $context    Deployment context.
	 * @param array  $asset_refs Collected asset references.
	 * @return string
	 */
	protected function rewrite_srcset( $srcset, array $context, array &$asset_refs ) {
		$candidates = array_map( 'trim', explode( ',', (string) $srcset ) );
		$rewritten  = array();

		foreach ( $candidates as $candidate ) {
			if ( '' === $candidate ) {
				continue;
			}

			$parts       = preg_split( '/\s+/', $candidate, 2 );
			$url         = isset( $parts[0] ) ? $parts[0] : '';
			$descriptor  = isset( $parts[1] ) ? $parts[1] : '';
			$no_warnings = array();
			$new_url     = $this->rewrite_attribute( 'source', 'src', $url, $context, $asset_refs, $no_warnings );

			$rewritten[] = trim( $new_url . ' ' . $descriptor );
		}

		return implode( ', ', $rewritten );
	}

	/**
	 * Rewrite CSS url() and @import references.
	 *
	 * @param string $css        CSS text.
	 * @param array  $context    Deployment context.
	 * @param array  $asset_refs Collected asset references.
	 * @return string
	 */
	protected function rewrite_css_references( $css, array $context, array &$asset_refs ) {
		$css = preg_replace_callback(
			'/url\(\s*([\'"]?)([^)\'"]+)\1\s*\)/i',
			function ( $matches ) use ( $context, &$asset_refs ) {
				$quote = isset( $matches[1] ) ? $matches[1] : '';
				$url   = isset( $matches[2] ) ? trim( $matches[2] ) : '';

				if ( ! $this->security->is_local_reference( $url ) ) {
					return $matches[0];
				}

				$no_warnings = array();
				$rewritten   = $this->rewrite_attribute( 'style', 'url', $url, $context, $asset_refs, $no_warnings );

				return 'url(' . $quote . $rewritten . $quote . ')';
			},
			(string) $css
		);

		return (string) preg_replace_callback(
			'/@import\s+(?:url\()?\s*([\'"])([^\'"]+)\1\s*\)?/i',
			function ( $matches ) use ( $context, &$asset_refs ) {
				$url = isset( $matches[2] ) ? trim( $matches[2] ) : '';

				if ( ! $this->security->is_local_reference( $url ) ) {
					return $matches[0];
				}

				$no_warnings = array();
				$rewritten   = $this->rewrite_attribute( 'style', 'url', $url, $context, $asset_refs, $no_warnings );

				return '@import url("' . $rewritten . '")';
			},
			(string) $css
		);
	}

	/**
	 * Resolve a local HTML reference to either a mapped WordPress page or a deployment file URL.
	 *
	 * @param string $value    Original reference.
	 * @param array  $context  Deployment context.
	 * @param array  $warnings Collected warnings.
	 * @return string
	 */
	protected function resolve_html_document_reference( $value, array $context, array &$warnings ) {
		$parts           = $this->security->split_reference( $value );
		$deployment_root = ! empty( $context['deployment_url'] ) ? trailingslashit( (string) $context['deployment_url'] ) : '';
		$basename = basename( rtrim( isset( $parts['path'] ) ? $parts['path'] : '', '/' ) );

		if ( ! $this->security->is_local_reference( $value ) ) {
			if ( '' === $deployment_root || 0 !== strpos( (string) $parts['path'], $deployment_root ) ) {
				return '';
			}

			$resolved = ltrim( substr( (string) $parts['path'], strlen( $deployment_root ) ), '/' );
		} else {
			$resolved = $this->security->resolve_reference_path( $parts['path'], isset( $context['entry_dir'] ) ? $context['entry_dir'] : '' );
		}

		if ( '' !== pathinfo( $basename, PATHINFO_EXTENSION ) && ! $this->security->is_html_reference( $parts['path'] ) ) {
			return '';
		}

		if ( ! $resolved ) {
			return '';
		}

		$reference_aliases = $this->security->build_html_reference_aliases( $resolved );
		$current_aliases   = $this->security->build_html_reference_aliases( isset( $context['entry_file'] ) ? $context['entry_file'] : '' );

		if ( ! empty( array_intersect( $reference_aliases, $current_aliases ) ) ) {
			return (string) $context['page_permalink'] . $parts['suffix'];
		}

		$link_map = isset( $context['html_link_map'] ) ? $context['html_link_map'] : array();

		foreach ( $reference_aliases as $alias ) {
			if ( ! empty( $link_map[ $alias ] ) ) {
				return $link_map[ $alias ] . $parts['suffix'];
			}
		}

		$file_candidates = array_values(
			array_filter(
				$reference_aliases,
				function ( $alias ) {
					return $this->security->is_html_reference( $alias );
				}
			)
		);

		foreach ( $file_candidates as $candidate ) {
			$absolute_path = trailingslashit( $context['deployment_path'] ) . $candidate;

			if ( file_exists( $absolute_path ) ) {
				$warnings[] = sprintf(
					/* translators: 1: original link, 2: package file */
					__( 'The link "%1$s" points to "%2$s" inside the uploaded package. No WordPress page is mapped for it yet, so it will open the deployment file URL directly.', 'reputifly-static-page-deployer' ),
					$value,
					$candidate
				);

				return trailingslashit( $context['deployment_url'] ) . ltrim( $candidate, '/' ) . $parts['suffix'];
			}
		}

		$warnings[] = sprintf(
			/* translators: 1: original link, 2: package file */
			__( 'The link "%1$s" points to "%2$s" inside the uploaded package, but that file could not be found after extraction.', 'reputifly-static-page-deployer' ),
			$value,
			$resolved
		);

		return '';
	}

	/**
	 * Extract imported metadata values from the source head.
	 *
	 * @param DOMNode $head Head node.
	 * @return array
	 */
	protected function extract_imported_metadata( DOMNode $head ) {
		$metadata = array(
			'json_ld' => array(),
		);

		foreach ( $head->childNodes as $node ) {
			if ( XML_ELEMENT_NODE !== $node->nodeType ) {
				continue;
			}

			$tag_name = strtolower( $node->nodeName );

			if ( 'title' === $tag_name ) {
				$metadata['title'] = trim( $node->textContent );
				continue;
			}

			if ( 'meta' === $tag_name ) {
				if ( $node->hasAttribute( 'charset' ) ) {
					$metadata['charset'] = $node->getAttribute( 'charset' );
				}

				$name     = strtolower( trim( $node->getAttribute( 'name' ) ) );
				$property = strtolower( trim( $node->getAttribute( 'property' ) ) );
				$content  = $node->getAttribute( 'content' );

				switch ( $name ) {
					case 'description':
						$metadata['meta_description'] = $content;
						break;
					case 'robots':
						$metadata['robots'] = $content;
						break;
					case 'viewport':
						$metadata['viewport'] = $content;
						break;
					case 'twitter:card':
						$metadata['twitter_card'] = $content;
						break;
					case 'twitter:title':
						$metadata['twitter_title'] = $content;
						break;
					case 'twitter:description':
						$metadata['twitter_description'] = $content;
						break;
					case 'twitter:image':
						$metadata['twitter_image'] = $content;
						break;
				}

				switch ( $property ) {
					case 'og:title':
						$metadata['og_title'] = $content;
						break;
					case 'og:description':
						$metadata['og_description'] = $content;
						break;
					case 'og:image':
						$metadata['og_image'] = $content;
						break;
				}

				continue;
			}

			if ( 'link' === $tag_name && 'canonical' === strtolower( trim( $node->getAttribute( 'rel' ) ) ) ) {
				$metadata['canonical_url'] = $node->getAttribute( 'href' );
				continue;
			}

			if ( 'script' === $tag_name && false !== strpos( strtolower( $node->getAttribute( 'type' ) ), 'ld+json' ) ) {
				$metadata['json_ld'][] = trim( $node->textContent );
			}
		}

		return $metadata;
	}

	/**
	 * Extract non-managed head tags for later preservation.
	 *
	 * @param DOMNode $head Head node.
	 * @return string
	 */
	protected function extract_extra_head_html( DOMNode $head ) {
		$html = '';

		foreach ( $head->childNodes as $node ) {
			if ( $this->is_managed_head_node( $node ) ) {
				continue;
			}

			$html .= $head->ownerDocument->saveHTML( $node );
		}

		return trim( $html );
	}

	/**
	 * Determine whether the node is handled by plugin metadata controls.
	 *
	 * @param DOMNode $node DOM node.
	 * @return bool
	 */
	protected function is_managed_head_node( DOMNode $node ) {
		if ( XML_ELEMENT_NODE !== $node->nodeType ) {
			return false;
		}

		$tag_name = strtolower( $node->nodeName );

		if ( in_array( $tag_name, array( 'title', 'base' ), true ) ) {
			return true;
		}

		if ( 'meta' === $tag_name ) {
			$name     = strtolower( trim( $node->getAttribute( 'name' ) ) );
			$property = strtolower( trim( $node->getAttribute( 'property' ) ) );

			if ( $node->hasAttribute( 'charset' ) ) {
				return true;
			}

			return in_array( $name, array( 'description', 'robots', 'viewport', 'twitter:card', 'twitter:title', 'twitter:description', 'twitter:image' ), true )
				|| in_array( $property, array( 'og:title', 'og:description', 'og:image' ), true );
		}

		if ( 'link' === $tag_name && 'canonical' === strtolower( trim( $node->getAttribute( 'rel' ) ) ) ) {
			return true;
		}

		return 'script' === $tag_name && false !== strpos( strtolower( $node->getAttribute( 'type' ) ), 'ld+json' );
	}

	/**
	 * Serialize element attributes.
	 *
	 * @param DOMElement $element Element.
	 * @return string
	 */
	protected function serialize_attributes( DOMElement $element ) {
		$attributes = array();

		foreach ( $element->attributes as $attribute ) {
			$attributes[] = sprintf( '%s="%s"', $attribute->nodeName, esc_attr( $attribute->nodeValue ) );
		}

		return trim( implode( ' ', $attributes ) );
	}

	/**
	 * Get inner HTML of a node.
	 *
	 * @param DOMNode $node DOM node.
	 * @return string
	 */
	protected function get_inner_html( DOMNode $node ) {
		$html = '';

		foreach ( $node->childNodes as $child ) {
			$html .= $node->ownerDocument->saveHTML( $child );
		}

		return trim( $html );
	}

	/**
	 * Pick the first non-empty metadata field from a stack of arrays.
	 *
	 * @param array  $sources  Source arrays.
	 * @param string $key      Metadata key.
	 * @param string $fallback Fallback value.
	 * @return string
	 */
	protected function pick_first( array $sources, $key, $fallback = '' ) {
		foreach ( $sources as $source ) {
			if ( empty( $source ) || ! is_array( $source ) ) {
				continue;
			}

			if ( isset( $source[ $key ] ) && '' !== trim( (string) $source[ $key ] ) ) {
				return trim( (string) $source[ $key ] );
			}
		}

		return $fallback;
	}

	/**
	 * Build JSON-LD blocks.
	 *
	 * @param array $page_meta Page-level metadata.
	 * @param array $imported  Imported metadata.
	 * @return array
	 */
	protected function build_json_ld_blocks( array $page_meta, array $imported ) {
		if ( ! empty( $page_meta['json_ld'] ) ) {
			return $this->normalize_json_ld_blocks( $page_meta['json_ld'] );
		}

		if ( ! empty( $imported['json_ld'] ) && is_array( $imported['json_ld'] ) ) {
			return array_map( 'trim', $imported['json_ld'] );
		}

		return array();
	}

	/**
	 * Normalize JSON-LD textarea content into one or more blocks.
	 *
	 * @param string $value Raw JSON-LD field.
	 * @return array
	 */
	protected function normalize_json_ld_blocks( $value ) {
		$value = trim( (string) $value );

		if ( '' === $value ) {
			return array();
		}

		if ( false !== stripos( $value, '<script' ) ) {
			preg_match_all( '#<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#is', $value, $matches );

			if ( ! empty( $matches[1] ) ) {
				return array_map( 'trim', $matches[1] );
			}
		}

		return array( $value );
	}
}
