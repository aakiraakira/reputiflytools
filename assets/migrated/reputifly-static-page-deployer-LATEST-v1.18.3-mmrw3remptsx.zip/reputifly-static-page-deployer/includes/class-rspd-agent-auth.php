<?php
/**
 * Agentic AI authentication and key management.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Agent API key helper.
 */
class RSPD_Agent_Auth {

	/**
	 * Prefix used for temporarily exposing a newly generated raw key to the current admin.
	 *
	 * @var string
	 */
	const RAW_KEY_TRANSIENT_PREFIX = 'rspd_agent_raw_key_';

	/**
	 * Storage helper.
	 *
	 * @var RSPD_Storage
	 */
	protected $storage;

	/**
	 * Security helper.
	 *
	 * @var RSPD_Security
	 */
	protected $security;

	/**
	 * Constructor.
	 *
	 * @param RSPD_Storage  $storage  Storage helper.
	 * @param RSPD_Security $security Security helper.
	 */
	public function __construct( RSPD_Storage $storage, RSPD_Security $security ) {
		$this->storage  = $storage;
		$this->security = $security;
	}

	/**
	 * Return the default full capability set for the primary key.
	 *
	 * @return array
	 */
	public function get_default_capabilities() {
		return array(
			'introspection'                 => true,
			'deployment_read'              => true,
			'deployment_code_read'         => true,
			'website_pages_deploy'         => true,
			'software_apps_deploy'         => true,
			'deploy_delete'                => true,
			'deploy_rebuild'               => true,
			'page_overrides_manage'        => true,
			'layout_injections_manage'     => true,
			'replace_urls'                 => true,
			'seo_manage'                   => true,
			'ab_testing_manage'            => true,
			'labs_elementor_export'        => true,
			'labs_restore_elementor_source'=> true,
			'license_read'                 => true,
			'license_recheck'              => true,
			'agent_access_manage'          => true,
		);
	}

	/**
	 * Get all keys.
	 *
	 * @return array
	 */
	public function get_keys() {
		return $this->storage->get_agent_keys();
	}

	/**
	 * Get a key record.
	 *
	 * @param string $key_id Key identifier.
	 * @return array
	 */
	public function get_key( $key_id ) {
		return $this->storage->get_agent_key( $key_id );
	}

	/**
	 * Get the primary key identifier.
	 *
	 * @return string
	 */
	public function get_primary_key_id() {
		return $this->storage->get_primary_agent_key_id();
	}

	/**
	 * Get the primary key record.
	 *
	 * @return array
	 */
	public function get_primary_key() {
		$key_id = $this->get_primary_key_id();

		return '' !== $key_id ? $this->get_key( $key_id ) : array();
	}

	/**
	 * Generate a new primary key with the full capability set.
	 *
	 * @param int $user_id Current admin user id for one-time key reveal.
	 * @return array
	 */
	public function generate_primary_key( $user_id = 0 ) {
		$user_id     = $user_id ? absint( $user_id ) : get_current_user_id();
		$current_key = $this->get_primary_key();

		if ( ! empty( $current_key['id'] ) ) {
			$this->set_key_status( $current_key['id'], 'revoked' );
		}

		return $this->create_key( 'Primary Agent Key', $this->get_default_capabilities(), true, $user_id );
	}

	/**
	 * Create a new key.
	 *
	 * @param string $label Key label.
	 * @param array  $capabilities Capability payload.
	 * @param bool   $set_primary Whether this becomes the primary key.
	 * @param int    $user_id Admin user id for one-time reveal.
	 * @return array
	 */
	public function create_key( $label, array $capabilities = array(), $set_primary = false, $user_id = 0 ) {
		$keys   = $this->get_keys();
		$key_id = '';

		while ( '' === $key_id || isset( $keys[ $key_id ] ) ) {
			$key_id = 'agt' . strtolower( wp_generate_password( 10, false, false ) );
		}

		$secret = strtolower( wp_generate_password( 40, false, false ) );
		$token  = 'rspdai_' . $key_id . '.' . $secret;
		$record = array(
			'id'                  => $key_id,
			'label'               => '' !== trim( (string) $label ) ? sanitize_text_field( $label ) : 'Agent Key',
			'status'              => 'active',
			'secret_hash'         => wp_hash_password( $secret ),
			'secret_token'        => $this->encrypt_agent_token( $token ),
			'capabilities'        => $this->normalize_capabilities( $capabilities, empty( $capabilities ) ),
			'created_at'          => time(),
			'last_used_at'        => 0,
			'last_used_ip'        => '',
			'last_used_user_agent'=> '',
			'last_endpoint'       => '',
		);

		$this->storage->update_agent_key( $key_id, $record );

		if ( $set_primary ) {
			$this->storage->set_primary_agent_key_id( $key_id );
		}

		$this->store_plaintext_key_for_user( $key_id, $token, $user_id );

		return array(
			'id'     => $key_id,
			'key'    => $token,
			'record' => $record,
		);
	}

	/**
	 * Normalize a capability payload against known keys.
	 *
	 * @param array $capabilities Submitted capability payload.
	 * @param bool  $default_full Whether missing keys should default to full access.
	 * @return array
	 */
	public function normalize_capabilities( array $capabilities, $default_full = false ) {
		$defaults = $this->get_default_capabilities();
		$clean    = array();

		foreach ( $defaults as $key => $enabled ) {
			if ( array_key_exists( $key, $capabilities ) ) {
				$clean[ $key ] = ! empty( $capabilities[ $key ] );
			} else {
				$clean[ $key ] = $default_full ? (bool) $enabled : false;
			}
		}

		return $clean;
	}

	/**
	 * Mark a key active or revoked.
	 *
	 * @param string $key_id Key identifier.
	 * @param string $status New status.
	 * @return array
	 */
	public function set_key_status( $key_id, $status ) {
		$key_id = sanitize_key( (string) $key_id );
		$status = 'revoked' === sanitize_key( (string) $status ) ? 'revoked' : 'active';
		$key    = $this->get_key( $key_id );

		if ( empty( $key ) ) {
			return array();
		}

		$key['status'] = $status;
		$this->storage->update_agent_key( $key_id, $key );

		return $key;
	}

	/**
	 * Get the one-time plaintext key for the current admin if it is still available.
	 *
	 * @param string $key_id Key identifier.
	 * @param int    $user_id User id.
	 * @return string
	 */
	public function get_plaintext_key_for_user( $key_id, $user_id = 0 ) {
		$user_id = $user_id ? absint( $user_id ) : get_current_user_id();
		$key_id  = sanitize_key( (string) $key_id );

		if ( ! $user_id || '' === $key_id ) {
			return '';
		}

		$key = get_transient( $this->get_plaintext_key_transient_name( $user_id, $key_id ) );

		if ( is_string( $key ) && '' !== $key ) {
			return $key;
		}

		$record = $this->get_key( $key_id );
		if ( ! empty( $record['secret_token'] ) ) {
			$decrypted = $this->decrypt_agent_token( (string) $record['secret_token'] );
			if ( '' !== $decrypted ) {
				$this->store_plaintext_key_for_user( $key_id, $decrypted, $user_id );
				return $decrypted;
			}
		}

		return '';
	}

	/**
	 * Persist the raw key temporarily for a specific admin user.
	 *
	 * @param string $key_id Key identifier.
	 * @param string $token Plaintext token.
	 * @param int    $user_id User id.
	 * @return void
	 */
	protected function store_plaintext_key_for_user( $key_id, $token, $user_id = 0 ) {
		$user_id = $user_id ? absint( $user_id ) : get_current_user_id();
		$key_id  = sanitize_key( (string) $key_id );

		if ( ! $user_id || '' === $key_id || '' === trim( (string) $token ) ) {
			return;
		}

		set_transient( $this->get_plaintext_key_transient_name( $user_id, $key_id ), (string) $token, WEEK_IN_SECONDS );
	}

	/**
	 * Build the transient name used for one-time key reveal.
	 *
	 * @param int    $user_id User id.
	 * @param string $key_id Key identifier.
	 * @return string
	 */
	protected function get_plaintext_key_transient_name( $user_id, $key_id ) {
		return self::RAW_KEY_TRANSIENT_PREFIX . absint( $user_id ) . '_' . sanitize_key( (string) $key_id );
	}

	/**
	 * Encrypt an agent token for reliable later download.
	 *
	 * @param string $token Plaintext bearer token.
	 * @return string
	 */
	protected function encrypt_agent_token( $token ) {
		$token = (string) $token;

		if ( '' === $token || ! function_exists( 'openssl_encrypt' ) ) {
			return '';
		}

		$key = $this->get_encryption_key_material();
		if ( '' === $key ) {
			return '';
		}

		$iv_length = openssl_cipher_iv_length( 'aes-256-cbc' );
		if ( ! is_int( $iv_length ) || $iv_length <= 0 ) {
			return '';
		}

		try {
			$iv = random_bytes( $iv_length );
		} catch ( Exception $exception ) {
			return '';
		}

		$cipher = openssl_encrypt( $token, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv );
		if ( false === $cipher ) {
			return '';
		}

		return base64_encode( $iv . $cipher );
	}

	/**
	 * Decrypt a previously stored agent token.
	 *
	 * @param string $payload Encrypted token payload.
	 * @return string
	 */
	protected function decrypt_agent_token( $payload ) {
		$payload = (string) $payload;

		if ( '' === $payload || ! function_exists( 'openssl_decrypt' ) ) {
			return '';
		}

		$key = $this->get_encryption_key_material();
		if ( '' === $key ) {
			return '';
		}

		$decoded = base64_decode( $payload, true );
		if ( false === $decoded ) {
			return '';
		}

		$iv_length = openssl_cipher_iv_length( 'aes-256-cbc' );
		if ( ! is_int( $iv_length ) || $iv_length <= 0 || strlen( $decoded ) <= $iv_length ) {
			return '';
		}

		$iv     = substr( $decoded, 0, $iv_length );
		$cipher = substr( $decoded, $iv_length );
		$token  = openssl_decrypt( $cipher, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv );

		return is_string( $token ) ? $token : '';
	}

	/**
	 * Derive stable key material from WordPress salts.
	 *
	 * @return string
	 */
	protected function get_encryption_key_material() {
		$material = '';

		foreach ( array( 'AUTH_KEY', 'SECURE_AUTH_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'NONCE_SALT' ) as $constant ) {
			if ( defined( $constant ) ) {
				$material .= (string) constant( $constant );
			}
		}

		if ( '' === $material ) {
			return '';
		}

		return hash( 'sha256', $material, true );
	}

	/**
	 * Authenticate a REST request using the Bearer token.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return array|WP_Error
	 */
	public function authenticate_request( WP_REST_Request $request ) {
		$header = trim( (string) $request->get_header( 'authorization' ) );

		if ( '' === $header && isset( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
			$header = trim( (string) wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] ) );
		}

		if ( '' === $header || 0 !== stripos( $header, 'Bearer ' ) ) {
			return new WP_Error( 'rspd_agent_missing_token', __( 'Missing Bearer token.', 'reputifly-static-page-deployer' ), array( 'status' => 401 ) );
		}

		$token = trim( substr( $header, 7 ) );
		if ( ! preg_match( '/^rspdai_([a-z0-9]+)\.([a-z0-9]+)$/i', $token, $matches ) ) {
			return new WP_Error( 'rspd_agent_invalid_token', __( 'Invalid agent token format.', 'reputifly-static-page-deployer' ), array( 'status' => 401 ) );
		}

		$key_id = sanitize_key( (string) $matches[1] );
		$secret = (string) $matches[2];
		$key    = $this->get_key( $key_id );

		if ( empty( $key ) ) {
			return new WP_Error( 'rspd_agent_unknown_key', __( 'The supplied agent key is not recognized.', 'reputifly-static-page-deployer' ), array( 'status' => 401 ) );
		}

		if ( empty( $key['status'] ) || 'active' !== $key['status'] ) {
			return new WP_Error( 'rspd_agent_key_revoked', __( 'This agent key has been revoked.', 'reputifly-static-page-deployer' ), array( 'status' => 403 ) );
		}

		if ( empty( $key['secret_hash'] ) || ! wp_check_password( $secret, $key['secret_hash'] ) ) {
			return new WP_Error( 'rspd_agent_secret_mismatch', __( 'The supplied agent key is not valid.', 'reputifly-static-page-deployer' ), array( 'status' => 401 ) );
		}

		return array(
			'id'           => $key_id,
			'label'        => isset( $key['label'] ) ? (string) $key['label'] : 'Agent Key',
			'capabilities' => ! empty( $key['capabilities'] ) && is_array( $key['capabilities'] ) ? $key['capabilities'] : $this->get_default_capabilities(),
			'record'       => $key,
		);
	}

	/**
	 * Check whether an authenticated agent may use a capability.
	 *
	 * @param array        $auth Auth context.
	 * @param string|array $capabilities Required capability or list.
	 * @param bool         $match_any Whether any one capability is sufficient.
	 * @return bool
	 */
	public function can( array $auth, $capabilities, $match_any = false ) {
		$current = ! empty( $auth['capabilities'] ) && is_array( $auth['capabilities'] ) ? $auth['capabilities'] : array();
		$needed  = is_array( $capabilities ) ? $capabilities : array( (string) $capabilities );

		if ( empty( $needed ) ) {
			return true;
		}

		if ( $match_any ) {
			foreach ( $needed as $capability ) {
				if ( ! empty( $current[ $capability ] ) ) {
					return true;
				}
			}

			return false;
		}

		foreach ( $needed as $capability ) {
			if ( empty( $current[ $capability ] ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Update last-used metadata for a key.
	 *
	 * @param string          $key_id Key identifier.
	 * @param string          $endpoint Endpoint path.
	 * @param WP_REST_Request $request REST request.
	 * @return void
	 */
	public function touch_key_usage( $key_id, $endpoint, WP_REST_Request $request ) {
		$key = $this->get_key( $key_id );

		if ( empty( $key ) ) {
			return;
		}

		$key['last_used_at']         = time();
		$key['last_used_ip']         = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$key['last_used_user_agent'] = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		$key['last_endpoint']        = sanitize_text_field( (string) $endpoint );

		$this->storage->update_agent_key( $key_id, $key );
	}

	/**
	 * Record one audit event.
	 *
	 * @param string          $key_id Key identifier or empty string.
	 * @param string          $endpoint Endpoint path.
	 * @param string          $method HTTP method.
	 * @param bool            $success Whether the action succeeded.
	 * @param string          $summary Human-readable summary.
	 * @param WP_REST_Request $request REST request.
	 * @return void
	 */
	public function record_audit( $key_id, $endpoint, $method, $success, $summary, WP_REST_Request $request ) {
		$this->storage->add_agent_audit_event(
			array(
				'timestamp'   => time(),
				'key_id'      => sanitize_key( (string) $key_id ),
				'endpoint'    => sanitize_text_field( (string) $endpoint ),
				'method'      => sanitize_text_field( strtoupper( (string) $method ) ),
				'success'     => ! empty( $success ),
				'summary'     => sanitize_text_field( (string) $summary ),
				'ip'          => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
				'user_agent'  => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
			)
		);
	}

	/**
	 * Build the downloadable JSON profile payload for agents.
	 *
	 * @param string $api_base API base URL.
	 * @param array  $license_context License status payload.
	 * @param array  $endpoint_index Endpoint catalog.
	 * @param array  $payload_templates Payload template examples.
	 * @param string $raw_key Plaintext key if still available for the current admin.
	 * @param array  $capabilities Capability payload.
	 * @return array
	 */
	public function build_profile_payload( $api_base, array $license_context, array $endpoint_index, array $payload_templates, $raw_key = '', array $capabilities = array() ) {
		return array(
			'site_url'               => home_url(),
			'api_base'               => untrailingslashit( (string) $api_base ),
			'plugin_version'         => RSPD_VERSION,
			'license_status'         => array(
				'status'    => isset( $license_context['status'] ) ? (string) $license_context['status'] : 'unknown',
				'label'     => isset( $license_context['label'] ) ? (string) $license_context['label'] : 'Unknown',
				'locked'    => ! empty( $license_context['locked'] ),
				'message'   => isset( $license_context['message'] ) ? (string) $license_context['message'] : '',
				'install_id'=> isset( $license_context['install_id'] ) ? (string) $license_context['install_id'] : '',
			),
			'authentication'         => array(
				'type'         => 'bearer',
				'header'       => 'Authorization',
				'format'       => 'Bearer <agent_key>',
				'agent_key'    => (string) $raw_key,
				'note'         => '' !== trim( (string) $raw_key ) ? 'Use this key exactly as provided in the Authorization header.' : 'Generate or regenerate the primary key from the Agentic AI screen before handing this profile to an agent.',
			),
			'capabilities'           => ! empty( $capabilities ) ? $capabilities : $this->get_default_capabilities(),
			'endpoint_index'         => $endpoint_index,
			'context_read_endpoints' => array(
				'deployment_manifest'   => '/deployments/{page_id}/manifest',
				'deployment_files'      => '/deployments/{page_id}/files',
				'deployment_file'       => '/deployments/{page_id}/file?path=...',
				'deployment_rendered'   => '/deployments/{page_id}/rendered-html',
				'software_manifest'     => '/software-apps/{slug}/manifest',
				'software_files'        => '/software-apps/{slug}/files',
				'software_file'         => '/software-apps/{slug}/file?path=...',
			),
			'recommended_workflow'   => array(
				'Fetch site context.',
				'List WordPress pages and Archimedes deployments.',
				'Pull current managed code/context before changing existing deployments.',
				'Upload a ZIP package.',
				'Inspect the returned scan manifest.',
				'Choose explicit deployment targets.',
				'Deploy.',
				'Verify the result summary and updated routes.',
			),
			'payload_templates'      => $payload_templates,
		);
	}
}
