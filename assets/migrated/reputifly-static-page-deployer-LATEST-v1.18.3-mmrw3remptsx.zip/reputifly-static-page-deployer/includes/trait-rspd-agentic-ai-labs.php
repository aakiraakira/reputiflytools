<?php
/**
 * Agentic AI SEO, A/B testing, and Labs action callbacks.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait RSPD_Agentic_AI_Labs_Trait {

	protected function sanitize_schema_payload( array $raw ) {
		$schema         = array();
		$schema['type'] = sanitize_key( isset( $raw['type'] ) ? $raw['type'] : 'none' );

		if ( 'custom_json' === $schema['type'] ) {
			$json_ld = isset( $raw['json_ld'] ) ? trim( wp_unslash( (string) $raw['json_ld'] ) ) : '';
			if ( '' !== $json_ld ) {
				$decoded = json_decode( $json_ld, true );
				if ( JSON_ERROR_NONE !== json_last_error() ) {
					return new WP_Error(
						'rspd_agent_invalid_schema_json',
						__( 'Invalid JSON-LD payload: ', 'reputifly-static-page-deployer' ) . json_last_error_msg(),
						array( 'status' => 400 )
					);
				}
				$schema['json_ld'] = wp_json_encode( $decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			}

			return $schema;
		}

		$text_fields = array(
			'name',
			'description',
			'telephone',
			'email',
			'street_address',
			'city',
			'state',
			'postal_code',
			'country',
			'hours',
			'price_range',
			'business_type',
			'author_name',
			'publisher_name',
			'publisher_logo',
			'date_published',
			'brand_name',
			'price',
			'currency',
			'provider_name',
			'area_served',
		);

		foreach ( $text_fields as $field ) {
			if ( isset( $raw[ $field ] ) && '' !== (string) $raw[ $field ] ) {
				$schema[ $field ] = sanitize_text_field( (string) $raw[ $field ] );
			}
		}

		if ( isset( $raw['faqs'] ) && is_array( $raw['faqs'] ) ) {
			$faqs = array();
			foreach ( $raw['faqs'] as $faq ) {
				if ( empty( $faq['question'] ) || empty( $faq['answer'] ) ) {
					continue;
				}
				$faqs[] = array(
					'question' => sanitize_text_field( (string) $faq['question'] ),
					'answer'   => sanitize_textarea_field( (string) $faq['answer'] ),
				);
			}
			if ( ! empty( $faqs ) ) {
				$schema['faqs'] = $faqs;
			}
		}

		return $schema;
	}

	protected function sanitize_social_payload( array $raw ) {
		$allowed = array( 'og_title', 'og_description', 'og_image', 'og_type', 'og_site_name', 'twitter_card' );
		$social  = array();

		foreach ( $allowed as $key ) {
			if ( isset( $raw[ $key ] ) && '' !== (string) $raw[ $key ] ) {
				$social[ $key ] = sanitize_text_field( (string) $raw[ $key ] );
			}
		}

		return $social;
	}

	protected function maybe_store_labs_result( array $summary ) {
		$user_id = get_current_user_id();
		if ( $user_id ) {
			set_transient( 'rspd_labs_result_' . $user_id, $summary, HOUR_IN_SECONDS );
		}
	}

	public function rest_post_seo_schema( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'seo_manage' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
					return new WP_Error( 'rspd_agent_invalid_page', __( 'Invalid page.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$payload = $this->get_request_payload( $request );
				$raw     = ! empty( $payload['schema'] ) && is_array( $payload['schema'] ) ? $payload['schema'] : array();
				$schema  = $this->sanitize_schema_payload( $raw );

				if ( is_wp_error( $schema ) ) {
					return $schema;
				}

				$config           = $this->storage->get_page_config( $page_id );
				$config['schema'] = $schema;
				$this->storage->update_page_config( $page_id, $config );
				delete_transient( 'rspd_render_' . $page_id );
				$this->bridge->purge_frontend_cache_for_page_public( $page_id );

				return array(
					'message'   => 'Schema saved.',
					'page_id'   => $page_id,
					'score'     => $this->bridge->calculate_seo_score_public( $config ),
					'breakdown' => $this->bridge->get_score_breakdown_public( $config ),
					'type'      => isset( $schema['type'] ) ? $schema['type'] : 'none',
				);
			}
		);
	}

	public function rest_post_seo_social( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'seo_manage' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
					return new WP_Error( 'rspd_agent_invalid_page', __( 'Invalid page.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$payload = $this->get_request_payload( $request );
				$raw     = ! empty( $payload['social'] ) && is_array( $payload['social'] ) ? $payload['social'] : array();
				$social  = $this->sanitize_social_payload( $raw );

				$config           = $this->storage->get_page_config( $page_id );
				$config['social'] = $social;
				$this->storage->update_page_config( $page_id, $config );
				delete_transient( 'rspd_render_' . $page_id );
				$this->bridge->purge_frontend_cache_for_page_public( $page_id );

				return array(
					'message'   => 'Social tags saved.',
					'page_id'   => $page_id,
					'score'     => $this->bridge->calculate_seo_score_public( $config ),
					'breakdown' => $this->bridge->get_score_breakdown_public( $config ),
					'has_og'    => ! empty( $social['og_title'] ) || ! empty( $social['og_image'] ),
				);
			}
		);
	}

	public function rest_post_ab_create( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'ab_testing_manage' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$payload         = $this->get_request_payload( $request );
				$page_id         = isset( $payload['page_id'] ) ? absint( $payload['page_id'] ) : 0;
				$variant_html    = isset( $payload['variant_html'] ) ? (string) $payload['variant_html'] : '';
				$weight_control  = isset( $payload['weight_control'] ) ? absint( $payload['weight_control'] ) : 50;
				$weight_variant  = isset( $payload['weight_variant'] ) ? absint( $payload['weight_variant'] ) : 50;

				if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
					return new WP_Error( 'rspd_agent_invalid_page', __( 'Invalid page.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}
				if ( '' === trim( $variant_html ) ) {
					return new WP_Error( 'rspd_agent_variant_html_required', __( 'Variant HTML is required.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}
				if ( 100 !== ( $weight_control + $weight_variant ) ) {
					return new WP_Error( 'rspd_agent_invalid_ab_weights', __( 'Weights must sum to 100.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$config = $this->storage->get_page_config( $page_id );
				if ( empty( $config['deployment_rel_dir'] ) ) {
					return new WP_Error( 'rspd_agent_ab_requires_deployment', __( 'Page must be deployed first.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}
				if ( ! empty( $config['ab_test']['enabled'] ) ) {
					return new WP_Error( 'rspd_agent_ab_exists', __( 'This page already has an active test.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$result = $this->deployer->deploy_ab_variant( $page_id, 'variant_b', $variant_html );
				if ( is_wp_error( $result ) ) {
					return $result;
				}

				$ab_test = array(
					'enabled'    => true,
					'created_at' => time(),
					'variants'   => array(
						'control'   => array(
							'label'              => 'Control (Original)',
							'weight'             => $weight_control,
							'deployment_rel_dir' => $config['deployment_rel_dir'],
							'cache_version'      => isset( $config['cache_version'] ) ? $config['cache_version'] : '',
						),
						'variant_b' => array(
							'label'              => 'Variant B',
							'weight'             => $weight_variant,
							'deployment_rel_dir' => $result['deployment_rel_dir'],
							'cache_version'      => $result['cache_version'],
						),
					),
				);

				$this->storage->update_ab_test_config( $page_id, $ab_test );
				delete_transient( 'rspd_render_' . $page_id );
				$this->bridge->purge_frontend_cache_for_page_public( $page_id );

				return array(
					'message' => 'A/B test created.',
					'page_id' => $page_id,
					'title'   => get_the_title( $page_id ),
				);
			}
		);
	}

	public function rest_post_ab_toggle( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'ab_testing_manage' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$payload = $this->get_request_payload( $request );
				$enabled = ! empty( $payload['enabled'] );

				$ab_test = $this->storage->get_ab_test_config( $page_id );
				if ( empty( $ab_test ) ) {
					return new WP_Error( 'rspd_agent_ab_missing', __( 'No test found.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$ab_test['enabled'] = $enabled;
				$this->storage->update_ab_test_config( $page_id, $ab_test );
				delete_transient( 'rspd_render_' . $page_id );
				$this->bridge->purge_frontend_cache_for_page_public( $page_id );

				return array(
					'message' => $enabled ? 'Test resumed.' : 'Test paused.',
					'page_id' => $page_id,
					'enabled' => $enabled,
				);
			}
		);
	}

	public function rest_post_ab_update_split( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'ab_testing_manage' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$payload = $this->get_request_payload( $request );
				$weights = ! empty( $payload['weights'] ) && is_array( $payload['weights'] ) ? $payload['weights'] : array();
				$ab_test = $this->storage->get_ab_test_config( $page_id );

				if ( empty( $ab_test['variants'] ) ) {
					return new WP_Error( 'rspd_agent_ab_missing', __( 'No test found.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$total = 0;
				foreach ( $weights as $key => $weight ) {
					$weight = absint( $weight );
					if ( isset( $ab_test['variants'][ $key ] ) ) {
						$ab_test['variants'][ $key ]['weight'] = $weight;
						$total += $weight;
					}
				}

				if ( 100 !== $total ) {
					return new WP_Error( 'rspd_agent_invalid_ab_weights', __( 'Weights must sum to 100.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$this->storage->update_ab_test_config( $page_id, $ab_test );
				delete_transient( 'rspd_render_' . $page_id );
				$this->bridge->purge_frontend_cache_for_page_public( $page_id );

				return array(
					'message' => 'Split updated.',
					'page_id' => $page_id,
					'weights' => wp_list_pluck( $ab_test['variants'], 'weight' ),
				);
			}
		);
	}

	public function rest_post_ab_end( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'ab_testing_manage' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$payload = $this->get_request_payload( $request );
				$winner  = isset( $payload['winner'] ) ? sanitize_key( $payload['winner'] ) : '';
				$ab_test = $this->storage->get_ab_test_config( $page_id );

				if ( empty( $ab_test['variants'][ $winner ] ) ) {
					return new WP_Error( 'rspd_agent_invalid_ab_winner', __( 'Invalid winner.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$config = $this->storage->get_page_config( $page_id );
				if ( 'control' !== $winner ) {
					$winner_variant                 = $ab_test['variants'][ $winner ];
					$config['deployment_rel_dir']  = $winner_variant['deployment_rel_dir'];
					$config['cache_version']       = wp_generate_password( 12, false, false );
				}

				foreach ( $ab_test['variants'] as $key => $variant ) {
					if ( $key === $winner || 'control' === $key ) {
						continue;
					}
					if ( ! empty( $variant['deployment_rel_dir'] ) ) {
						$this->deployer->delete_variant_deployment( $variant['deployment_rel_dir'] );
					}
				}

				unset( $config['ab_test'] );
				$this->storage->update_page_config( $page_id, $config );
				delete_transient( 'rspd_render_' . $page_id );
				$this->bridge->purge_frontend_cache_for_page_public( $page_id );

				return array(
					'message' => 'Test ended. "' . $ab_test['variants'][ $winner ]['label'] . '" is now the permanent version.',
					'page_id' => $page_id,
					'winner'  => $winner,
				);
			}
		);
	}

	public function rest_post_elementor_export( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'labs_elementor_export' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				if ( ! $this->bridge->is_elementor_active_public() ) {
					return new WP_Error( 'rspd_agent_elementor_inactive', __( 'Elementor is not active on this site yet.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				$payload   = $this->get_request_payload( $request );
				$raw_items = ! empty( $payload['items'] ) && is_array( $payload['items'] ) ? array_values( $payload['items'] ) : array();
				$jobs      = array();
				$failures  = array();

				foreach ( $raw_items as $item ) {
					$item      = is_array( $item ) ? $item : array();
					$source_id = isset( $item['source_id'] ) ? absint( $item['source_id'] ) : 0;
					if ( ! $source_id ) {
						continue;
					}

					$source_page = get_post( $source_id );
					if ( ! $source_page instanceof WP_Post || 'page' !== $source_page->post_type ) {
						$failures[] = array(
							'source_id'    => $source_id,
							'source_title' => 'Unknown Source',
							'message'      => 'The selected Elementor source page could not be found.',
						);
						continue;
					}

					$target_mode       = sanitize_key( isset( $item['target_mode'] ) ? $item['target_mode'] : 'create_new' );
					$jobs[ $source_id ] = array(
						'source_id'    => $source_id,
						'source_page'  => $source_page,
						'source_title' => $source_page->post_title,
						'item'         => $item,
						'target_mode'  => in_array( $target_mode, array( 'create_new', 'existing', 'in_place' ), true ) ? $target_mode : 'create_new',
					);
				}

				if ( empty( $jobs ) ) {
					return new WP_Error( 'rspd_agent_labs_missing_items', __( 'Select at least one Elementor source page before converting.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
				}

				foreach ( $jobs as $source_id => $job ) {
					$target = $this->bridge->resolve_labs_target_page_public( $job['source_page'], $job['target_mode'], $job['item'] );
					if ( is_wp_error( $target ) ) {
						$failures[] = array(
							'source_id'    => $source_id,
							'source_title' => $job['source_title'],
							'message'      => $target->get_error_message(),
						);
						unset( $jobs[ $source_id ] );
						continue;
					}

					$jobs[ $source_id ]['target_page_id'] = (int) $target['page']->ID;
					$jobs[ $source_id ]['target_page']    = $target['page'];
					$jobs[ $source_id ]['target_url']     = get_permalink( $target['page'] );
					$jobs[ $source_id ]['created_new']    = ! empty( $target['created_new'] );
				}

				if ( empty( $jobs ) ) {
					$summary = array(
						'converted_count' => 0,
						'created_count'   => 0,
						'warning_count'   => 0,
						'failed_count'    => count( $failures ),
						'items'           => array(),
						'failures'        => $failures,
					);
					$this->maybe_store_labs_result( $summary );
					return array(
						'summary' => $summary,
						'message' => 'No Elementor pages could be converted.',
					);
				}

				$link_map = $this->bridge->build_labs_internal_link_map_public( $jobs );
				$results  = array();
				$warnings = 0;
				$created  = 0;

				foreach ( $jobs as $job ) {
					if ( 'in_place' === $job['target_mode'] ) {
						$this->bridge->backup_elementor_source_page_public( $job['source_page'] );
					}

					$conversion = $this->deployer->export_elementor_page_to_page(
						$job['source_page'],
						$job['target_page_id'],
						array(
							'target_mode' => $job['target_mode'],
							'link_map'    => $link_map,
						)
					);

					if ( is_wp_error( $conversion ) ) {
						if ( ! empty( $job['created_new'] ) && ! empty( $job['target_page_id'] ) ) {
							wp_delete_post( (int) $job['target_page_id'], true );
						}

						$failures[] = array(
							'source_id'    => (int) $job['source_id'],
							'source_title' => $job['source_title'],
							'message'      => $conversion->get_error_message(),
						);
						continue;
					}

					if ( ! empty( $job['created_new'] ) ) {
						$created++;
					}

					$item_warnings = ! empty( $conversion['warnings'] ) && is_array( $conversion['warnings'] ) ? $conversion['warnings'] : array();
					$warnings     += count( $item_warnings );
					$this->bridge->purge_frontend_cache_for_page_public( $job['target_page_id'] );

					$results[] = array(
						'source_id'    => (int) $job['source_id'],
						'source_title' => $job['source_title'],
						'target_id'    => (int) $job['target_page_id'],
						'target_title' => get_the_title( $job['target_page_id'] ),
						'target_url'   => get_permalink( $job['target_page_id'] ),
						'target_mode'  => $job['target_mode'],
						'warnings'     => $item_warnings,
					);
				}

				$summary = array(
					'converted_count' => count( $results ),
					'created_count'   => $created,
					'warning_count'   => $warnings,
					'failed_count'    => count( $failures ),
					'items'           => $results,
					'failures'        => $failures,
				);

				$this->maybe_store_labs_result( $summary );

				return array(
					'summary' => $summary,
					'message' => empty( $results ) ? 'No Elementor pages were converted successfully.' : sprintf( 'Elementor export completed. %d page%s converted.', count( $results ), 1 === count( $results ) ? '' : 's' ),
				);
			}
		);
	}

	public function rest_post_restore_elementor( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'labs_restore_elementor_source' ),
			true,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$backup  = $page_id ? $this->storage->get_elementor_backup( $page_id ) : array();

				if ( ! $page_id || empty( $backup ) ) {
					return new WP_Error( 'rspd_agent_elementor_backup_missing', __( 'No saved Elementor source backup was found for that page.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$post_data       = isset( $backup['post'] ) && is_array( $backup['post'] ) ? $backup['post'] : array();
				$post_data['ID'] = $page_id;
				$updated         = wp_update_post( wp_slash( $post_data ), true );

				if ( is_wp_error( $updated ) ) {
					return new WP_Error( 'rspd_agent_restore_failed', __( 'The Elementor source could not be restored: ', 'reputifly-static-page-deployer' ) . $updated->get_error_message(), array( 'status' => 500 ) );
				}

				$managed_meta_keys = array( '_wp_page_template', '_thumbnail_id' );
				foreach ( get_post_meta( $page_id ) as $meta_key => $values ) {
					if ( 0 === strpos( $meta_key, '_elementor' ) || in_array( $meta_key, $managed_meta_keys, true ) ) {
						delete_post_meta( $page_id, $meta_key );
					}
				}

				if ( ! empty( $backup['meta'] ) && is_array( $backup['meta'] ) ) {
					foreach ( $backup['meta'] as $meta_key => $values ) {
						delete_post_meta( $page_id, $meta_key );
						foreach ( is_array( $values ) ? $values : array( $values ) as $value ) {
							add_post_meta( $page_id, $meta_key, maybe_unserialize( $value ) );
						}
					}
				}

				$this->deployer->delete_deployment( $page_id );
				$this->storage->delete_elementor_backup( $page_id );
				$this->bridge->purge_frontend_cache_for_page_public( $page_id );

				return array(
					'message' => 'Elementor source restored successfully on the original page URL.',
					'page_id' => $page_id,
				);
			}
		);
	}
}
