<?php
/**
 * Agentic AI REST helpers and callbacks.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait RSPD_Agentic_AI_REST_Trait {

	protected function register_mutating_rest_routes() {
		$this->register_route( '/license/recheck', WP_REST_Server::CREATABLE, 'rest_post_license_recheck' );
		$this->register_route( '/keys', WP_REST_Server::CREATABLE, 'rest_post_create_key' );
		$this->register_route( '/keys/(?P<key_id>[a-z0-9_-]+)', WP_REST_Server::DELETABLE, 'rest_delete_key' );
		$this->register_route( '/uploads', WP_REST_Server::CREATABLE, 'rest_post_upload' );
		$this->register_route( '/uploads/(?P<upload_id>[a-z0-9_-]+)', WP_REST_Server::DELETABLE, 'rest_delete_upload' );
		$this->register_route( '/pages/(?P<page_id>\\d+)', WP_REST_Server::CREATABLE, 'rest_post_update_page' );
		$this->register_route( '/pages/(?P<page_id>\\d+)/duplicate', WP_REST_Server::CREATABLE, 'rest_post_duplicate_page' );
		$this->register_route( '/pages/(?P<page_id>\\d+)/trash', WP_REST_Server::CREATABLE, 'rest_post_trash_page' );
		$this->register_route( '/pages/(?P<page_id>\\d+)/restore', WP_REST_Server::CREATABLE, 'rest_post_restore_page' );
		$this->register_route( '/pages/(?P<page_id>\\d+)', WP_REST_Server::DELETABLE, 'rest_delete_wordpress_page' );
		$this->register_route( '/deploy/website-pages', WP_REST_Server::CREATABLE, 'rest_post_deploy_website_pages' );
		$this->register_route( '/deploy/software-app', WP_REST_Server::CREATABLE, 'rest_post_deploy_software_app' );
		$this->register_route( '/deploy/raw-page', WP_REST_Server::CREATABLE, 'rest_post_deploy_raw_page' );
		$this->register_route( '/deploy/rebuild/page/(?P<page_id>\\d+)', WP_REST_Server::CREATABLE, 'rest_post_rebuild_page' );
		$this->register_route( '/deploy/rebuild/all', WP_REST_Server::CREATABLE, 'rest_post_rebuild_all' );
		$this->register_route( '/deploy/page/(?P<page_id>\\d+)', WP_REST_Server::DELETABLE, 'rest_delete_page' );
		$this->register_route( '/deployments/(?P<page_id>\\d+)/patch-file', WP_REST_Server::CREATABLE, 'rest_post_patch_deployment_file' );
		$this->register_route( '/deploy/software-app/(?P<slug>[a-z0-9-]+)', WP_REST_Server::DELETABLE, 'rest_delete_software_app' );
		$this->register_route( '/software-apps/(?P<slug>[a-z0-9-]+)/update', WP_REST_Server::CREATABLE, 'rest_post_update_software_app' );
		$this->register_route( '/software-apps/(?P<slug>[a-z0-9-]+)/rename', WP_REST_Server::CREATABLE, 'rest_post_rename_software_app' );
		$this->register_route( '/software-apps/(?P<slug>[a-z0-9-]+)/entry-file', WP_REST_Server::CREATABLE, 'rest_post_update_software_entry_file' );
		$this->register_route( '/software-apps/(?P<slug>[a-z0-9-]+)/patch-file', WP_REST_Server::CREATABLE, 'rest_post_patch_software_file' );
		$this->register_route( '/content/layout-injections', WP_REST_Server::CREATABLE, 'rest_post_layout_injections' );
		$this->register_route( '/content/page-overrides/(?P<page_id>\\d+)', WP_REST_Server::CREATABLE, 'rest_post_page_overrides' );
		$this->register_route( '/tools/replace-urls', WP_REST_Server::CREATABLE, 'rest_post_replace_urls' );
		$this->register_route( '/seo/schema/(?P<page_id>\\d+)', WP_REST_Server::CREATABLE, 'rest_post_seo_schema' );
		$this->register_route( '/seo/social/(?P<page_id>\\d+)', WP_REST_Server::CREATABLE, 'rest_post_seo_social' );
		$this->register_route( '/ab/create', WP_REST_Server::CREATABLE, 'rest_post_ab_create' );
		$this->register_route( '/ab/toggle/(?P<page_id>\\d+)', WP_REST_Server::CREATABLE, 'rest_post_ab_toggle' );
		$this->register_route( '/ab/update-split/(?P<page_id>\\d+)', WP_REST_Server::CREATABLE, 'rest_post_ab_update_split' );
		$this->register_route( '/ab/end/(?P<page_id>\\d+)', WP_REST_Server::CREATABLE, 'rest_post_ab_end' );
		$this->register_route( '/labs/elementor-export', WP_REST_Server::CREATABLE, 'rest_post_elementor_export' );
		$this->register_route( '/labs/restore-elementor/(?P<page_id>\\d+)', WP_REST_Server::CREATABLE, 'rest_post_restore_elementor' );
	}

	protected function build_pages_payload() {
		$all_pages         = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future', 'trash' ),
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'suppress_filters' => false,
			)
		);
		$deployment_map    = array();
		$elementor_sources = array();
		$restorable_map    = array();

		foreach ( $this->storage->get_deployments() as $deployment ) {
			if ( ! empty( $deployment['page']->ID ) ) {
				$deployment_map[ (int) $deployment['page']->ID ] = $deployment;
			}
		}

		if ( $this->bridge->is_elementor_active_public() ) {
			foreach ( $this->bridge->get_elementor_source_pages_public() as $entry ) {
				if ( ! empty( $entry['page']->ID ) ) {
					$elementor_sources[ (int) $entry['page']->ID ] = $entry;
				}
			}
			foreach ( $this->bridge->get_restorable_elementor_exports_public() as $entry ) {
				if ( ! empty( $entry['page']->ID ) ) {
					$restorable_map[ (int) $entry['page']->ID ] = $entry;
				}
			}
		}

		$pages = array();

		foreach ( $all_pages as $page ) {
			$page_id         = (int) $page->ID;
			$deployment      = isset( $deployment_map[ $page_id ] ) ? $deployment_map[ $page_id ] : null;
			$config          = $deployment ? $deployment['config'] : $this->storage->get_page_config( $page_id );
			$elementor_entry = isset( $elementor_sources[ $page_id ] ) ? $elementor_sources[ $page_id ] : null;
			$restorable      = isset( $restorable_map[ $page_id ] ) ? $restorable_map[ $page_id ] : null;

			$pages[] = array(
				'id'                     => $page_id,
				'title'                  => $page->post_title,
				'slug'                   => $page->post_name,
				'status'                 => $page->post_status,
				'trashed'                => 'trash' === $page->post_status,
				'permalink'              => get_permalink( $page ),
				'managed'                => ! empty( $config ),
				'deployment_status'      => ! empty( $deployment['status'] ) ? $deployment['status'] : ( ! empty( $config['enabled'] ) ? 'Active' : 'Inactive' ),
				'source_type'            => ! empty( $config['source_type'] ) ? $config['source_type'] : '',
				'render_mode'            => ! empty( $config['render_mode'] ) ? $config['render_mode'] : '',
				'raw_html'               => ! empty( $config['raw_html'] ),
				'entry_file'             => ! empty( $config['entry_file'] ) ? $config['entry_file'] : '',
				'deployment_rel_dir'     => ! empty( $config['deployment_rel_dir'] ) ? $config['deployment_rel_dir'] : '',
				'cache_version'          => ! empty( $config['cache_version'] ) ? $config['cache_version'] : '',
				'updated_at'             => ! empty( $config['updated_at'] ) ? (int) $config['updated_at'] : 0,
				'elementor_source'       => ! empty( $elementor_entry ),
				'elementor_risk_badges'  => ! empty( $elementor_entry['risk_badges'] ) ? array_values( $elementor_entry['risk_badges'] ) : array(),
				'elementor_restorable'   => ! empty( $restorable ),
			);
		}

		return $pages;
	}

	protected function build_deployments_payload() {
		$results = array();

		foreach ( $this->storage->get_deployments() as $deployment ) {
			$page_id = ! empty( $deployment['page']->ID ) ? (int) $deployment['page']->ID : 0;
			$config  = ! empty( $deployment['config'] ) && is_array( $deployment['config'] ) ? $deployment['config'] : array();

			$results[] = array(
				'page_id'            => $page_id,
				'title'              => $page_id ? get_the_title( $page_id ) : '',
				'permalink'          => ! empty( $deployment['permalink'] ) ? $deployment['permalink'] : '',
				'status'             => ! empty( $deployment['status'] ) ? $deployment['status'] : ( ! empty( $config['enabled'] ) ? 'Active' : 'Inactive' ),
				'source_type'        => ! empty( $config['source_type'] ) ? $config['source_type'] : '',
				'render_mode'        => ! empty( $config['render_mode'] ) ? $config['render_mode'] : '',
				'raw_html'           => ! empty( $config['raw_html'] ),
				'entry_file'         => ! empty( $config['entry_file'] ) ? $config['entry_file'] : '',
				'html_files'         => ! empty( $config['html_files'] ) ? array_values( $config['html_files'] ) : array(),
				'deployment_rel_dir' => ! empty( $config['deployment_rel_dir'] ) ? $config['deployment_rel_dir'] : '',
				'updated_at'         => ! empty( $deployment['updated_at'] ) ? (int) $deployment['updated_at'] : 0,
				'package_key'        => ! empty( $config['package_key'] ) ? $config['package_key'] : '',
				'has_ab_test'        => ! empty( $config['ab_test']['variants'] ),
			);
		}

		return $results;
	}

	protected function build_software_apps_payload() {
		$results = array();

		foreach ( $this->storage->get_software_apps() as $slug => $record ) {
			$results[] = array(
				'slug'               => $slug,
				'label'              => ! empty( $record['label'] ) ? $record['label'] : ucfirst( str_replace( '-', ' ', $slug ) ),
				'url'                => $this->storage->get_software_mount_url( $slug ),
				'entry_file'         => ! empty( $record['entry_file'] ) ? $record['entry_file'] : '',
				'html_files'         => ! empty( $record['html_files'] ) ? array_values( $record['html_files'] ) : array(),
				'deployment_rel_dir' => ! empty( $record['relative_dir'] ) ? $record['relative_dir'] : '',
				'source_type'        => ! empty( $record['source_type'] ) ? $record['source_type'] : 'software_app',
				'updated_at'         => ! empty( $record['updated_at'] ) ? (int) $record['updated_at'] : 0,
				'routes'             => $this->storage->get_software_app_routes( $slug ),
			);
		}

		return array_values( $results );
	}

	protected function build_layout_injections_payload() {
		$settings = $this->storage->get_settings();
		$layout   = ! empty( $settings['layout_injections'] ) && is_array( $settings['layout_injections'] ) ? $settings['layout_injections'] : array();
		$page_ids = ! empty( $layout['page_ids'] ) && is_array( $layout['page_ids'] ) ? array_values( array_unique( array_map( 'absint', $layout['page_ids'] ) ) ) : array();
		$pages    = array();

		foreach ( $page_ids as $page_id ) {
			$page = get_post( $page_id );
			if ( ! $page instanceof WP_Post || 'page' !== $page->post_type ) {
				continue;
			}

			$pages[] = array(
				'id'        => $page_id,
				'title'     => $page->post_title,
				'permalink' => get_permalink( $page ),
			);
		}

		return array(
			'header_html' => ! empty( $layout['header_html'] ) ? $layout['header_html'] : '',
			'body_html'   => ! empty( $layout['body_html'] ) ? $layout['body_html'] : '',
			'footer_html' => ! empty( $layout['footer_html'] ) ? $layout['footer_html'] : '',
			'page_ids'    => $page_ids,
			'pages'       => $pages,
		);
	}

	protected function build_keys_payload() {
		$keys       = array();
		$primary_id = $this->auth->get_primary_key_id();

		foreach ( $this->auth->get_keys() as $record ) {
			$keys[] = array(
				'id'                  => isset( $record['id'] ) ? (string) $record['id'] : '',
				'label'               => isset( $record['label'] ) ? (string) $record['label'] : '',
				'status'              => isset( $record['status'] ) ? (string) $record['status'] : 'revoked',
				'capabilities'        => ! empty( $record['capabilities'] ) && is_array( $record['capabilities'] ) ? $record['capabilities'] : array(),
				'created_at'          => ! empty( $record['created_at'] ) ? (int) $record['created_at'] : 0,
				'last_used_at'        => ! empty( $record['last_used_at'] ) ? (int) $record['last_used_at'] : 0,
				'last_used_ip'        => ! empty( $record['last_used_ip'] ) ? (string) $record['last_used_ip'] : '',
				'last_used_user_agent'=> ! empty( $record['last_used_user_agent'] ) ? (string) $record['last_used_user_agent'] : '',
				'last_endpoint'       => ! empty( $record['last_endpoint'] ) ? (string) $record['last_endpoint'] : '',
				'is_primary'          => ! empty( $record['id'] ) && $record['id'] === $primary_id,
			);
		}

		return $keys;
	}

	protected function build_audit_payload() {
		return array_values( array_reverse( $this->storage->get_agent_audit_log() ) );
	}

	protected function build_elementor_sources_payload() {
		if ( ! $this->bridge->is_elementor_active_public() ) {
			return array();
		}

		$results = array();

		foreach ( $this->bridge->get_elementor_source_pages_public() as $entry ) {
			if ( empty( $entry['page'] ) || ! $entry['page'] instanceof WP_Post ) {
				continue;
			}

			$source_page = $entry['page'];
			$results[]   = array(
				'id'               => (int) $source_page->ID,
				'title'            => $source_page->post_title,
				'slug'             => $source_page->post_name,
				'permalink'        => ! empty( $entry['permalink'] ) ? $entry['permalink'] : get_permalink( $source_page ),
				'risk_badges'      => ! empty( $entry['risk_badges'] ) ? array_values( $entry['risk_badges'] ) : array(),
				'existing_target'  => ! empty( $entry['existing_deployment']['page']->ID ) ? (int) $entry['existing_deployment']['page']->ID : 0,
				'default_new_slug' => $this->bridge->get_elementor_default_target_slug_public( $source_page ),
			);
		}

		return $results;
	}

	protected function build_restorable_exports_payload() {
		if ( ! $this->bridge->is_elementor_active_public() ) {
			return array();
		}

		$results = array();

		foreach ( $this->bridge->get_restorable_elementor_exports_public() as $entry ) {
			if ( empty( $entry['page'] ) || ! $entry['page'] instanceof WP_Post ) {
				continue;
			}

			$page      = $entry['page'];
			$results[] = array(
				'page_id'              => (int) $page->ID,
				'title'                => $page->post_title,
				'permalink'            => ! empty( $entry['permalink'] ) ? $entry['permalink'] : get_permalink( $page ),
				'backup_title'         => ! empty( $entry['backup_title'] ) ? $entry['backup_title'] : '',
				'backup_created_at'    => ! empty( $entry['backup_created_at'] ) ? (int) $entry['backup_created_at'] : 0,
				'backup_created_label' => ! empty( $entry['backup_created_label'] ) ? $entry['backup_created_label'] : '',
			);
		}

		return $results;
	}

	protected function find_deployment_record( $page_id ) {
		$page_id = absint( $page_id );

		foreach ( $this->storage->get_deployments() as $deployment ) {
			if ( ! empty( $deployment['page']->ID ) && (int) $deployment['page']->ID === $page_id ) {
				return $deployment;
			}
		}

		return array();
	}

	protected function build_deployment_manifest_payload( $page_id ) {
		$page_id = absint( $page_id );
		$page    = get_post( $page_id );
		$config  = $this->storage->get_page_config( $page_id );

		if ( ! $page instanceof WP_Post || 'page' !== $page->post_type || empty( $config['deployment_rel_dir'] ) ) {
			return new WP_Error( 'rspd_agent_missing_deployment', __( 'No managed deployment exists for that page.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
		}

		$absolute_dir = $this->storage->get_deployment_path( $config['deployment_rel_dir'] );
		$bundle       = $this->storage->load_render_bundle( $config['deployment_rel_dir'] );
		$resolved     = $this->storage->resolve_page_config( $page_id );

		return array(
			'page'              => array(
				'id'        => $page_id,
				'title'     => $page->post_title,
				'slug'      => $page->post_name,
				'status'    => $page->post_status,
				'permalink' => get_permalink( $page ),
			),
			'config'            => $config,
			'resolved_config'   => $resolved,
			'source_type'       => ! empty( $config['source_type'] ) ? $config['source_type'] : '',
			'deployment_rel_dir'=> $config['deployment_rel_dir'],
			'public_asset_base' => $this->storage->get_public_deployment_url( $page_id ),
			'html_files'        => ! empty( $config['html_files'] ) ? array_values( $config['html_files'] ) : array(),
			'entry_file'        => ! empty( $config['entry_file'] ) ? $config['entry_file'] : '',
			'bundle'            => array(
				'has_raw_document' => ! empty( $bundle['raw_document'] ),
				'generated_at'     => ! empty( $bundle['generated_at'] ) ? (int) $bundle['generated_at'] : 0,
				'metadata'         => ! empty( $bundle['metadata'] ) ? $bundle['metadata'] : array(),
			),
			'files'             => $this->build_file_tree( $absolute_dir ),
		);
	}

	protected function build_software_manifest_payload( $slug ) {
		$slug   = trim( sanitize_title( (string) $slug ), '/' );
		$record = $this->storage->get_software_app( $slug );

		if ( empty( $record['relative_dir'] ) ) {
			return new WP_Error( 'rspd_agent_missing_software_app', __( 'No software app exists for that slug.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
		}

		$absolute_dir = $this->storage->get_deployment_path( $record['relative_dir'] );

		return array(
			'slug'        => $slug,
			'label'       => ! empty( $record['label'] ) ? $record['label'] : ucfirst( str_replace( '-', ' ', $slug ) ),
			'url'         => $this->storage->get_software_mount_url( $slug ),
			'entry_file'  => ! empty( $record['entry_file'] ) ? $record['entry_file'] : '',
			'html_files'  => ! empty( $record['html_files'] ) ? array_values( $record['html_files'] ) : array(),
			'source_type' => ! empty( $record['source_type'] ) ? $record['source_type'] : 'software_app',
			'updated_at'  => ! empty( $record['updated_at'] ) ? (int) $record['updated_at'] : 0,
			'routes'      => $this->storage->get_software_app_routes( $slug ),
			'files'       => $this->build_file_tree( $absolute_dir ),
		);
	}

	protected function build_file_tree( $absolute_root ) {
		$absolute_root = wp_normalize_path( (string) $absolute_root );
		if ( '' === $absolute_root || ! is_dir( $absolute_root ) ) {
			return array();
		}

		$items    = array();
		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $absolute_root, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::SELF_FIRST
		);

		foreach ( $iterator as $item ) {
			$path     = wp_normalize_path( $item->getPathname() );
			$relative = ltrim( str_replace( $absolute_root, '', $path ), '/' );

			if ( '' === $relative ) {
				continue;
			}

			$items[] = array(
				'path'     => $relative,
				'type'     => $item->isDir() ? 'directory' : 'file',
				'size'     => $item->isDir() ? 0 : (int) $item->getSize(),
				'modified' => (int) $item->getMTime(),
				'mime'     => $item->isDir() ? 'directory' : $this->detect_mime_type( $path, $relative ),
			);
		}

		usort(
			$items,
			static function ( $left, $right ) {
				return strcmp( $left['path'], $right['path'] );
			}
		);

		return $items;
	}

	protected function build_file_payload( $absolute_root, $relative_path ) {
		$absolute_root = wp_normalize_path( (string) $absolute_root );
		$relative_path = $this->security->normalize_relative_path( $relative_path );

		if ( '' === $relative_path ) {
			return new WP_Error( 'rspd_agent_invalid_file_path', __( 'A valid file path is required.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
		}

		$absolute_path = $this->security->safe_join( $absolute_root, $relative_path );
		if ( ! $absolute_path ) {
			return new WP_Error( 'rspd_agent_invalid_file_path', __( 'The requested file path is outside the managed deployment.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
		}

		$absolute_path = wp_normalize_path( $absolute_path );

		if ( ! file_exists( $absolute_path ) ) {
			return new WP_Error( 'rspd_agent_missing_file', __( 'The requested file could not be found.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
		}

		if ( is_dir( $absolute_path ) ) {
			return array(
				'path'       => $relative_path,
				'type'       => 'directory',
				'is_text'    => false,
				'mime'       => 'directory',
				'content'    => null,
				'size'       => 0,
				'modified'   => (int) filemtime( $absolute_path ),
			);
		}

		$is_text = $this->is_text_file( $relative_path );
		$content = $is_text ? $this->storage->read_file( $absolute_path ) : null;

		return array(
			'path'     => $relative_path,
			'type'     => 'file',
			'is_text'  => $is_text,
			'mime'     => $this->detect_mime_type( $absolute_path, $relative_path ),
			'content'  => $content,
			'size'     => (int) filesize( $absolute_path ),
			'modified' => (int) filemtime( $absolute_path ),
		);
	}

	protected function build_rendered_html_payload( $page_id ) {
		$page_id   = absint( $page_id );
		$config    = $this->storage->get_page_config( $page_id );
		$permalink = get_permalink( $page_id );

		if ( ! $page_id || empty( $config['deployment_rel_dir'] ) || empty( $permalink ) ) {
			return new WP_Error( 'rspd_agent_missing_deployment', __( 'No managed deployment exists for that page.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
		}

		$response = wp_remote_get(
			$permalink,
			array(
				'timeout'    => 20,
				'redirection'=> 3,
				'user-agent' => 'Reputifly-Agentic-AI/' . RSPD_VERSION,
				'headers'    => array(
					'Cache-Control' => 'no-cache',
					'Pragma'        => 'no-cache',
				),
			)
		);

		if ( ! is_wp_error( $response ) ) {
			$status = (int) wp_remote_retrieve_response_code( $response );
			$body   = (string) wp_remote_retrieve_body( $response );

			if ( $status >= 200 && $status < 300 && '' !== $body ) {
				return array(
					'page_id'    => $page_id,
					'permalink'  => $permalink,
					'source'     => 'live_request',
					'status'     => $status,
					'html'       => $body,
				);
			}
		}

		$bundle = $this->storage->load_render_bundle( $config['deployment_rel_dir'] );
		if ( empty( $bundle ) ) {
			return new WP_Error( 'rspd_agent_missing_rendered_html', __( 'The live page could not be captured and no render bundle is available.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
		}

		return array(
			'page_id'   => $page_id,
			'permalink' => $permalink,
			'source'    => 'stored_bundle',
			'status'    => 200,
			'html'      => $this->build_rendered_html_from_bundle( $bundle ),
		);
	}

	protected function build_rendered_html_from_bundle( array $bundle ) {
		if ( ! empty( $bundle['raw_document'] ) ) {
			return (string) $bundle['raw_document'];
		}

		$doctype    = ! empty( $bundle['doctype'] ) ? trim( (string) $bundle['doctype'] ) : '<!DOCTYPE html>';
		$html_attrs = $this->format_html_attributes( isset( $bundle['html_attrs'] ) ? $bundle['html_attrs'] : '' );
		$body_attrs = $this->format_html_attributes( isset( $bundle['body_attrs'] ) ? $bundle['body_attrs'] : '' );
		$head_html  = ! empty( $bundle['head_html'] ) ? (string) $bundle['head_html'] : '';
		$body_html  = ! empty( $bundle['body_html'] ) ? (string) $bundle['body_html'] : '';

		return trim(
			$doctype . "\n" .
			'<html' . ( $html_attrs ? ' ' . $html_attrs : '' ) . '>' . "\n" .
			'<head>' . "\n" . $head_html . "\n" . '</head>' . "\n" .
			'<body' . ( $body_attrs ? ' ' . $body_attrs : '' ) . '>' . "\n" . $body_html . "\n" . '</body>' . "\n" .
			'</html>'
		);
	}

	protected function format_html_attributes( $attrs ) {
		if ( is_array( $attrs ) ) {
			$pairs = array();
			foreach ( $attrs as $name => $value ) {
				$name = preg_replace( '/[^a-zA-Z0-9:_-]/', '', (string) $name );
				if ( '' === $name ) {
					continue;
				}
				$pairs[] = $name . '="' . esc_attr( (string) $value ) . '"';
			}
			return implode( ' ', $pairs );
		}

		return trim( (string) $attrs );
	}

	public function rest_get_profile( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'introspection' ),
			false,
			function ( $auth ) {
				$profile                         = $this->auth->build_profile_payload( rest_url( self::REST_NS . self::REST_BASE ), $this->license->get_status_context(), $this->get_endpoint_index(), $this->get_payload_templates(), '', $auth['capabilities'] );
				$profile['authenticated_key_id'] = $auth['id'];
				$profile['message']              = 'Agent profile loaded.';
				return $profile;
			}
		);
	}

	public function rest_get_context( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'introspection' ),
			false,
			function () {
				$payload            = $this->build_context_payload();
				$payload['message'] = 'Site context loaded.';
				return $payload;
			}
		);
	}

	public function rest_get_license( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'license_read' ),
			false,
			function () {
				return array(
					'license' => $this->license->get_status_context(),
					'message' => 'License status loaded.',
				);
			}
		);
	}

	public function rest_get_pages( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'introspection', 'deployment_read' ),
			false,
			function () {
				return array(
					'pages'   => $this->build_pages_payload(),
					'message' => 'WordPress pages loaded.',
				);
			},
			array( 'match_any' => true )
		);
	}

	public function rest_get_deployments( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deployment_read' ),
			false,
			function () {
				return array(
					'deployments' => $this->build_deployments_payload(),
					'message'     => 'Managed deployments loaded.',
				);
			}
		);
	}

	public function rest_get_software_apps( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deployment_read' ),
			false,
			function () {
				return array(
					'software_apps' => $this->build_software_apps_payload(),
					'message'       => 'Software apps loaded.',
				);
			}
		);
	}

	public function rest_get_layout_injections( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deployment_read', 'layout_injections_manage' ),
			false,
			function () {
				return array(
					'layout_injections' => $this->build_layout_injections_payload(),
					'message'           => 'Layout injections loaded.',
				);
			},
			array( 'match_any' => true )
		);
	}

	public function rest_get_elementor_sources( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'introspection', 'labs_elementor_export' ),
			false,
			function () {
				return array(
					'elementor_active' => $this->bridge->is_elementor_active_public(),
					'sources'          => $this->build_elementor_sources_payload(),
					'message'          => 'Elementor sources loaded.',
				);
			},
			array( 'match_any' => true )
		);
	}

	public function rest_get_restorable_exports( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'introspection', 'labs_restore_elementor_source' ),
			false,
			function () {
				return array(
					'restorable' => $this->build_restorable_exports_payload(),
					'message'    => 'Restorable Elementor exports loaded.',
				);
			},
			array( 'match_any' => true )
		);
	}

	public function rest_get_keys( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'agent_access_manage' ),
			false,
			function () {
				return array(
					'keys'    => $this->build_keys_payload(),
					'message' => 'Agent keys loaded.',
				);
			}
		);
	}

	public function rest_get_audit_log( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'agent_access_manage' ),
			false,
			function () {
				return array(
					'audit_log' => $this->build_audit_payload(),
					'message'   => 'Agent audit log loaded.',
				);
			}
		);
	}

	public function rest_get_deployment_manifest( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deployment_code_read' ),
			false,
			function ( $auth, WP_REST_Request $request ) {
				$manifest            = $this->build_deployment_manifest_payload( $request['page_id'] );
				if ( is_wp_error( $manifest ) ) {
					return $manifest;
				}
				$manifest['message'] = 'Deployment manifest loaded.';
				return $manifest;
			}
		);
	}

	public function rest_get_deployment_files( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deployment_code_read' ),
			false,
			function ( $auth, WP_REST_Request $request ) {
				$manifest = $this->build_deployment_manifest_payload( $request['page_id'] );
				if ( is_wp_error( $manifest ) ) {
					return $manifest;
				}
				return array(
					'page_id' => absint( $request['page_id'] ),
					'files'   => $manifest['files'],
					'message' => 'Deployment file tree loaded.',
				);
			}
		);
	}

	public function rest_get_deployment_file( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deployment_code_read' ),
			false,
			function ( $auth, WP_REST_Request $request ) {
				$page_id = absint( $request['page_id'] );
				$config  = $this->storage->get_page_config( $page_id );

				if ( empty( $config['deployment_rel_dir'] ) ) {
					return new WP_Error( 'rspd_agent_missing_deployment', __( 'No managed deployment exists for that page.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$file = $this->build_file_payload( $this->storage->get_deployment_path( $config['deployment_rel_dir'] ), $request->get_param( 'path' ) );
				if ( is_wp_error( $file ) ) {
					return $file;
				}
				$file['public_url'] = trailingslashit( $this->storage->get_public_deployment_url( $page_id ) ) . ltrim( $file['path'], '/' );
				$file['message']    = 'Deployment file loaded.';
				return $file;
			}
		);
	}

	public function rest_get_deployment_rendered_html( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deployment_code_read' ),
			false,
			function ( $auth, WP_REST_Request $request ) {
				$result            = $this->build_rendered_html_payload( $request['page_id'] );
				if ( is_wp_error( $result ) ) {
					return $result;
				}
				$result['message'] = 'Rendered HTML loaded.';
				return $result;
			}
		);
	}

	public function rest_get_software_manifest( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deployment_code_read' ),
			false,
			function ( $auth, WP_REST_Request $request ) {
				$manifest            = $this->build_software_manifest_payload( $request['slug'] );
				if ( is_wp_error( $manifest ) ) {
					return $manifest;
				}
				$manifest['message'] = 'Software app manifest loaded.';
				return $manifest;
			}
		);
	}

	public function rest_get_software_files( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deployment_code_read' ),
			false,
			function ( $auth, WP_REST_Request $request ) {
				$manifest = $this->build_software_manifest_payload( $request['slug'] );
				if ( is_wp_error( $manifest ) ) {
					return $manifest;
				}
				return array(
					'slug'    => sanitize_title( $request['slug'] ),
					'files'   => $manifest['files'],
					'message' => 'Software app file tree loaded.',
				);
			}
		);
	}

	public function rest_get_software_file( WP_REST_Request $request ) {
		return $this->with_agent_access(
			$request,
			array( 'deployment_code_read' ),
			false,
			function ( $auth, WP_REST_Request $request ) {
				$slug   = trim( sanitize_title( (string) $request['slug'] ), '/' );
				$record = $this->storage->get_software_app( $slug );

				if ( empty( $record['relative_dir'] ) ) {
					return new WP_Error( 'rspd_agent_missing_software_app', __( 'No software app exists for that slug.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
				}

				$file = $this->build_file_payload( $this->storage->get_deployment_path( $record['relative_dir'] ), $request->get_param( 'path' ) );
				if ( is_wp_error( $file ) ) {
					return $file;
				}
				$file['public_url'] = $this->storage->get_software_file_url( $slug, $file['path'] );
				$file['message']    = 'Software app file loaded.';
				return $file;
			}
		);
	}

	protected function create_upload_session( array $file ) {
		if ( empty( $file['tmp_name'] ) || empty( $file['name'] ) || ! empty( $file['error'] ) ) {
			return new WP_Error( 'rspd_agent_invalid_upload', __( 'A valid ZIP upload is required.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
		}

		$filename = sanitize_file_name( (string) $file['name'] );
		$ext      = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

		if ( 'zip' !== $ext ) {
			return new WP_Error( 'rspd_agent_upload_type', __( 'Agent uploads must be ZIP files in this version.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
		}

		$upload_id  = sanitize_key( 'upload_' . wp_generate_password( 12, false, false ) );
		$paths      = $this->storage->create_agent_upload_directory( $upload_id );
		$zip_path   = trailingslashit( $paths['absolute_dir'] ) . 'package.zip';
		$source_dir = trailingslashit( $paths['absolute_dir'] ) . 'source';

		wp_mkdir_p( $source_dir );

		$moved = false;
		if ( is_uploaded_file( $file['tmp_name'] ) ) {
			$moved = @move_uploaded_file( $file['tmp_name'], $zip_path );
		}
		if ( ! $moved ) {
			$moved = @copy( $file['tmp_name'], $zip_path );
		}
		if ( ! $moved ) {
			$this->storage->delete_agent_upload_session( $upload_id, true );
			return new WP_Error( 'rspd_agent_upload_store_failed', __( 'The uploaded ZIP could not be stored for processing.', 'reputifly-static-page-deployer' ), array( 'status' => 500 ) );
		}

		$extract = $this->extract_upload_zip( $zip_path, $source_dir );
		if ( is_wp_error( $extract ) ) {
			$this->storage->delete_agent_upload_session( $upload_id, true );
			return $extract;
		}

		$source_root = wp_normalize_path( $this->bridge->flatten_single_root_folder_public( $source_dir ) );
		$html_files  = $this->scan_html_files( $source_root );
		$entry_file  = $this->detect_entry_file( $html_files, '' );

		if ( empty( $html_files ) ) {
			$this->storage->delete_agent_upload_session( $upload_id, true );
			return new WP_Error( 'rspd_agent_upload_no_html', __( 'The uploaded ZIP did not contain any HTML files.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
		}

		$session = array(
			'upload_id'           => $upload_id,
			'relative_dir'        => $paths['relative_dir'],
			'absolute_dir'        => $paths['absolute_dir'],
			'zip_path'            => $zip_path,
			'source_absolute_dir' => $source_root,
			'original_filename'   => $filename,
			'html_files'          => $html_files,
			'entry_file'          => $entry_file,
			'package_type'        => count( $html_files ) > 1 ? 'multi_page' : 'single_page',
			'created_at'          => time(),
			'expires_at'          => time() + self::UPLOAD_TTL,
			'suggestions'         => $this->build_upload_suggestions( $html_files ),
			'warnings'            => ! empty( $extract['warnings'] ) ? array_values( array_unique( $extract['warnings'] ) ) : array(),
		);

		$this->storage->update_agent_upload_session( $upload_id, $session );

		return $session;
	}

	protected function build_upload_suggestions( array $html_files ) {
		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		$page_by_slug = array();

		foreach ( $pages as $page ) {
			$page_by_slug[ $page->post_name ] = $page;
		}

		$suggestions = array();

		foreach ( $html_files as $html_file ) {
			$suggested_slug = $this->bridge->derive_slug_from_html_file_public( $html_file, basename( $html_file ) );
			$match          = isset( $page_by_slug[ $suggested_slug ] ) ? $page_by_slug[ $suggested_slug ] : null;

			$suggestions[] = array(
				'source_file'      => $html_file,
				'suggested_slug'   => $suggested_slug,
				'suggested_title'  => ucwords( str_replace( array( '-', '_' ), ' ', preg_replace( '/\.html?$/i', '', basename( $html_file ) ) ) ),
				'existing_page_id' => $match instanceof WP_Post ? (int) $match->ID : 0,
				'existing_title'   => $match instanceof WP_Post ? $match->post_title : '',
				'target_mode'      => $match instanceof WP_Post ? 'existing' : 'new',
			);
		}

		return $suggestions;
	}

	protected function extract_upload_zip( $zip_path, $target_dir ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'rspd_agent_ziparchive_missing', __( 'ZipArchive is required on this server for Agentic AI uploads.', 'reputifly-static-page-deployer' ), array( 'status' => 500 ) );
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $zip_path ) ) {
			return new WP_Error( 'rspd_agent_zip_open_failed', __( 'The uploaded ZIP could not be opened.', 'reputifly-static-page-deployer' ), array( 'status' => 400 ) );
		}

		$warnings = array();

		for ( $index = 0; $index < $zip->numFiles; $index++ ) {
			$name = $zip->getNameIndex( $index );
			if ( ! $name || '/' === substr( $name, -1 ) ) {
				continue;
			}

			$name = str_replace( '\\', '/', $name );
			if ( preg_match( '#(^|/)\\.\\.(?:/|$)#', $name ) || preg_match( '#^[a-zA-Z]:#', $name ) || 0 === strpos( $name, '/' ) ) {
				$warnings[] = sprintf( __( 'Skipped unsafe ZIP entry: %s', 'reputifly-static-page-deployer' ), $name );
				continue;
			}

			$relative = $this->security->normalize_relative_path( $name );
			if ( '' === $relative ) {
				$warnings[] = sprintf( __( 'Skipped unreadable ZIP entry: %s', 'reputifly-static-page-deployer' ), $name );
				continue;
			}

			$destination = $this->security->safe_join( $target_dir, $relative );
			if ( ! $destination ) {
				$warnings[] = sprintf( __( 'Skipped unsafe ZIP path: %s', 'reputifly-static-page-deployer' ), $name );
				continue;
			}

			wp_mkdir_p( dirname( $destination ) );

			$stream = $zip->getStream( $name );
			if ( ! $stream ) {
				$warnings[] = sprintf( __( 'Could not read ZIP entry: %s', 'reputifly-static-page-deployer' ), $name );
				continue;
			}

			$target = fopen( $destination, 'wb' );
			if ( false === $target ) {
				fclose( $stream );
				$warnings[] = sprintf( __( 'Could not write extracted file: %s', 'reputifly-static-page-deployer' ), $relative );
				continue;
			}

			stream_copy_to_stream( $stream, $target );
			fclose( $stream );
			fclose( $target );
		}

		$zip->close();

		return array( 'warnings' => $warnings );
	}

	protected function scan_html_files( $absolute_dir ) {
		$absolute_dir = wp_normalize_path( (string) $absolute_dir );
		if ( '' === $absolute_dir || ! is_dir( $absolute_dir ) ) {
			return array();
		}

		$files    = array();
		$iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $absolute_dir, RecursiveDirectoryIterator::SKIP_DOTS ) );

		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() ) {
				continue;
			}

			if ( preg_match( '/\.html?$/i', $file->getFilename() ) ) {
				$files[] = ltrim( str_replace( $absolute_dir, '', wp_normalize_path( $file->getPathname() ) ), '/' );
			}
		}

		sort( $files );
		return array_values( array_unique( $files ) );
	}

	protected function detect_entry_file( array $html_files, $requested_file ) {
		$requested_file = $this->security->normalize_relative_path( $requested_file );

		if ( $requested_file && in_array( $requested_file, $html_files, true ) ) {
			return $requested_file;
		}

		foreach ( array( 'index.html', 'index.htm' ) as $root_index ) {
			if ( in_array( $root_index, $html_files, true ) ) {
				return $root_index;
			}
		}

		foreach ( $html_files as $html_file ) {
			$basename = strtolower( basename( $html_file ) );
			if ( 'index.html' === $basename || 'index.htm' === $basename ) {
				return $html_file;
			}
		}

		return ! empty( $html_files ) ? (string) reset( $html_files ) : '';
	}

	protected function create_page( $title, $slug = '', $status = 'publish' ) {
		$title = sanitize_text_field( (string) $title );
		$slug  = sanitize_title( (string) $slug );
		$title = '' !== $title ? $title : __( 'New Archimedes Page', 'reputifly-static-page-deployer' );
		$slug  = '' !== $slug ? $slug : sanitize_title( $title );
		$slug  = wp_unique_post_slug( $slug, 0, $status, 'page', 0 );

		$page_id = wp_insert_post(
			array(
				'post_type'   => 'page',
				'post_status' => $status,
				'post_title'  => $title,
				'post_name'   => $slug,
			),
			true
		);

		if ( is_wp_error( $page_id ) ) {
			return $page_id;
		}

		return get_post( $page_id );
	}

	protected function normalize_render_mode_input( $value, $raw_html = null ) {
		$value = sanitize_key( (string) $value );

		if ( in_array( $value, array( 'display_as_is', 'display-as-is', 'displayasis', 'raw', 'raw_html' ), true ) ) {
			return array(
				'render_mode' => 'isolated',
				'raw_html'    => 1,
			);
		}

		if ( 'compatibility' === $value ) {
			return array(
				'render_mode' => 'compatibility',
				'raw_html'    => null === $raw_html ? 0 : ( ! empty( $raw_html ) ? 1 : 0 ),
			);
		}

		return array(
			'render_mode' => in_array( $value, array( 'isolated', 'compatibility' ), true ) ? $value : 'isolated',
			'raw_html'    => null === $raw_html ? 1 : ( ! empty( $raw_html ) ? 1 : 0 ),
		);
	}

	protected function sanitize_direct_overrides( array $submitted ) {
		if ( isset( $submitted['render_mode']['enabled'] ) ) {
			return $this->bridge->normalize_submitted_overrides_public( $submitted );
		}

		$overrides = array();

		foreach ( array( 'render_mode', 'preserve_imported_head', 'prefer_plugin_metadata', 'raw_html' ) as $key ) {
			if ( array_key_exists( $key, $submitted ) ) {
				$overrides[ $key ] = 'render_mode' === $key ? sanitize_key( $submitted[ $key ] ) : ( ! empty( $submitted[ $key ] ) ? 1 : 0 );
			}
		}

		if ( ! empty( $submitted['compatibility'] ) && is_array( $submitted['compatibility'] ) ) {
			$overrides['compatibility'] = array(
				'wp_head'   => ! empty( $submitted['compatibility']['wp_head'] ) ? 1 : 0,
				'wp_footer' => ! empty( $submitted['compatibility']['wp_footer'] ) ? 1 : 0,
			);
		}

		if ( ! empty( $submitted['performance'] ) && is_array( $submitted['performance'] ) ) {
			$overrides['performance'] = array();
			foreach ( $submitted['performance'] as $key => $value ) {
				$overrides['performance'][ sanitize_key( $key ) ] = is_scalar( $value ) ? sanitize_textarea_field( (string) $value ) : $value;
			}
		}

		if ( ! empty( $submitted['metadata'] ) && is_array( $submitted['metadata'] ) ) {
			$overrides['metadata'] = array();
			foreach ( $submitted['metadata'] as $key => $value ) {
				$overrides['metadata'][ sanitize_key( $key ) ] = sanitize_text_field( (string) $value );
			}
		}

		return $overrides;
	}

	protected function apply_page_render_preferences( $page_id, array $item ) {
		$page_id = absint( $page_id );
		$config  = $this->storage->get_page_config( $page_id );

		if ( empty( $config ) ) {
			return new WP_Error( 'rspd_agent_missing_deployment', __( 'No managed deployment exists for that page.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
		}

		$render = $this->normalize_render_mode_input(
			isset( $item['render_mode'] ) ? $item['render_mode'] : ( isset( $item['raw_html'] ) && ! empty( $item['raw_html'] ) ? 'display_as_is' : 'isolated' ),
			isset( $item['raw_html'] ) ? $item['raw_html'] : null
		);

		$config['render_mode'] = $render['render_mode'];
		$config['raw_html']    = $render['raw_html'];

		if ( array_key_exists( 'preserve_imported_head', $item ) ) {
			$config['preserve_imported_head'] = ! empty( $item['preserve_imported_head'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'prefer_plugin_metadata', $item ) ) {
			$config['prefer_plugin_metadata'] = ! empty( $item['prefer_plugin_metadata'] ) ? 1 : 0;
		}
		if ( ! empty( $item['compatibility'] ) && is_array( $item['compatibility'] ) ) {
			$config['compatibility'] = array(
				'wp_head'   => ! empty( $item['compatibility']['wp_head'] ) ? 1 : 0,
				'wp_footer' => ! empty( $item['compatibility']['wp_footer'] ) ? 1 : 0,
			);
		}
		if ( ! empty( $item['page_overrides'] ) && is_array( $item['page_overrides'] ) ) {
			$config['page_overrides'] = $this->sanitize_direct_overrides( $item['page_overrides'] );
		}

		$config['updated_at'] = time();
		$this->storage->update_page_config( $page_id, $config );

		return $config;
	}

	protected function is_text_file( $relative_path ) {
		$ext = strtolower( pathinfo( (string) $relative_path, PATHINFO_EXTENSION ) );
		return in_array( $ext, array( 'html', 'htm', 'css', 'js', 'mjs', 'json', 'txt', 'xml', 'svg', 'map', 'md', 'webmanifest', 'csv' ), true );
	}

	protected function detect_mime_type( $absolute_path, $relative_path = '' ) {
		$relative_path = (string) $relative_path;
		$wp_filetype   = $relative_path ? wp_check_filetype( $relative_path ) : array();

		if ( ! empty( $wp_filetype['type'] ) ) {
			return $wp_filetype['type'];
		}

		if ( function_exists( 'mime_content_type' ) && is_file( $absolute_path ) ) {
			$mime = @mime_content_type( $absolute_path );
			if ( $mime ) {
				return $mime;
			}
		}

		return 'application/octet-stream';
	}

	protected function validate_upload_session( $upload_id ) {
		$upload_id = sanitize_key( (string) $upload_id );
		$session   = $this->storage->get_agent_upload_session( $upload_id );

		if ( empty( $session ) || empty( $session['source_absolute_dir'] ) || ! is_dir( $session['source_absolute_dir'] ) ) {
			return new WP_Error( 'rspd_agent_upload_missing', __( 'That upload session could not be found. Upload the package again.', 'reputifly-static-page-deployer' ), array( 'status' => 404 ) );
		}

		if ( ! empty( $session['expires_at'] ) && (int) $session['expires_at'] < time() ) {
			$this->storage->delete_agent_upload_session( $upload_id, true );
			return new WP_Error( 'rspd_agent_upload_expired', __( 'That upload session has expired. Upload the package again.', 'reputifly-static-page-deployer' ), array( 'status' => 410 ) );
		}

		return $session;
	}
}
