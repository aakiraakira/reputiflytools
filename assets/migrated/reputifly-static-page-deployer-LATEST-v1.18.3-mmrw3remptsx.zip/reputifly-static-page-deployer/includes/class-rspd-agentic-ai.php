<?php
/**
 * Agentic AI admin screen and REST control layer.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/trait-rspd-agentic-ai-rest.php';
require_once __DIR__ . '/trait-rspd-agentic-ai-actions.php';
require_once __DIR__ . '/trait-rspd-agentic-ai-labs.php';

class RSPD_Agentic_AI_Bridge extends RSPD_Admin {

	public function __construct( RSPD_Storage $storage, RSPD_Security $security, RSPD_Deployer $deployer, RSPD_License $license ) {
		$this->storage  = $storage;
		$this->security = $security;
		$this->deployer = $deployer;
		$this->license  = $license;
	}

	public function get_logo_url_public() {
		return $this->logo_url;
	}

	public function sanitize_layout_markup_public( $markup ) {
		return $this->sanitize_layout_markup( $markup );
	}

	public function refresh_layout_target_page_public( $page_id, array $config ) {
		$this->refresh_layout_target_page( $page_id, $config );
	}

	public function purge_frontend_cache_for_page_public( $page_id ) {
		$this->purge_frontend_cache_for_page( $page_id );
	}

	public function get_replace_targets_for_page_public( array $config ) {
		return $this->get_replace_targets_for_page( $config );
	}

	public function is_elementor_active_public() {
		return $this->is_elementor_active();
	}

	public function get_elementor_source_pages_public() {
		return $this->get_elementor_source_pages();
	}

	public function get_restorable_elementor_exports_public() {
		return $this->get_restorable_elementor_exports();
	}

	public function resolve_labs_target_page_public( WP_Post $source_page, $target_mode, array $item ) {
		return $this->resolve_labs_target_page( $source_page, $target_mode, $item );
	}

	public function build_labs_internal_link_map_public( array $jobs ) {
		return $this->build_labs_internal_link_map( $jobs );
	}

	public function backup_elementor_source_page_public( WP_Post $page ) {
		$this->backup_elementor_source_page( $page );
	}

	public function detect_elementor_risk_badges_public( WP_Post $page ) {
		return $this->detect_elementor_risk_badges( $page );
	}

	public function get_elementor_default_target_slug_public( WP_Post $page ) {
		return $this->get_elementor_default_target_slug( $page );
	}

	public function derive_slug_from_html_file_public( $html_file, $fallback_title = '' ) {
		return $this->derive_slug_from_html_file( $html_file, $fallback_title );
	}

	public function normalize_submitted_overrides_public( array $submitted ) {
		return $this->normalize_submitted_overrides( $submitted );
	}

	public function calculate_seo_score_public( array $config ) {
		return $this->calculate_seo_score( $config );
	}

	public function get_score_breakdown_public( array $config ) {
		return $this->get_score_breakdown( $config );
	}

	public function flatten_single_root_folder_public( $dir ) {
		return $this->flatten_single_root_folder( $dir );
	}
}

class RSPD_Agentic_AI {

	use RSPD_Agentic_AI_REST_Trait;
	use RSPD_Agentic_AI_Actions_Trait;
	use RSPD_Agentic_AI_Labs_Trait;

	const SLUG        = 'reputifly-deploy-agentic-ai';
	const LEGACY_SLUG = 'rspd-agentic-ai';
	const REST_NS     = 'reputifly/v1';
	const REST_BASE   = '/agent';
	const UPLOAD_TTL  = 1800;

	protected $storage;
	protected $security;
	protected $deployer;
	protected $license;
	protected $auth;
	protected $bridge;

	public function __construct( RSPD_Storage $storage, RSPD_Security $security, RSPD_Deployer $deployer, RSPD_License $license, RSPD_Agent_Auth $auth ) {
		$this->storage  = $storage;
		$this->security = $security;
		$this->deployer = $deployer;
		$this->license  = $license;
		$this->auth     = $auth;
		$this->bridge   = new RSPD_Agentic_AI_Bridge( $storage, $security, $deployer, $license );

		add_action( 'admin_menu', array( $this, 'register_menu' ), 99 );
		add_action( 'init', array( $this, 'maybe_cleanup_upload_sessions' ) );
		add_action( 'admin_post_rspd_agentic_ai_generate_key', array( $this, 'handle_generate_key' ) );
		add_action( 'admin_post_rspd_agentic_ai_toggle_key', array( $this, 'handle_toggle_key' ) );
		add_action( 'admin_post_rspd_agentic_ai_download_profile', array( $this, 'handle_download_profile' ) );
		add_action( 'admin_post_rspd_agentic_ai_connection_test', array( $this, 'handle_connection_test' ) );
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
	}

	public function maybe_cleanup_upload_sessions() {
		$this->storage->cleanup_expired_agent_upload_sessions();
	}

	public function register_menu() {
		add_submenu_page(
			RSPD_Admin::MENU_SLUG,
			'Agentic AI',
			'Agentic AI',
			'manage_options',
			self::SLUG,
			array( $this, 'render_page' )
		);

		add_submenu_page(
			null,
			'Agentic AI',
			'Agentic AI',
			'manage_options',
			self::LEGACY_SLUG,
			array( $this, 'render_page' )
		);
	}

	protected function get_admin_page_url( array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::SLUG ), $args ), admin_url( 'admin.php' ) );
	}

	protected function build_agent_profile_payload( $raw_key = '' ) {
		$primary      = $this->auth->get_primary_key();
		$capabilities = ! empty( $primary['capabilities'] ) && is_array( $primary['capabilities'] ) ? $primary['capabilities'] : $this->auth->get_default_capabilities();

		return $this->auth->build_profile_payload(
			rest_url( self::REST_NS . self::REST_BASE ),
			$this->license->get_status_context(),
			$this->get_endpoint_index(),
			$this->get_payload_templates(),
			$raw_key,
			$capabilities
		);
	}

	protected function get_endpoint_index() {
		return array(
			'read'     => array(
				'profile'             => '/profile',
				'context'             => '/context',
				'license'             => '/license',
				'pages'               => '/pages',
				'deployments'         => '/deployments',
				'software_apps'       => '/software-apps',
				'layout_injections'   => '/layout-injections',
				'elementor_sources'   => '/labs/elementor-sources',
				'restorable_exports'  => '/labs/restorable',
				'keys'                => '/keys',
				'audit_log'           => '/audit-log',
				'deployment_manifest' => '/deployments/{page_id}/manifest',
				'deployment_files'    => '/deployments/{page_id}/files',
				'deployment_file'     => '/deployments/{page_id}/file?path=...',
				'deployment_rendered' => '/deployments/{page_id}/rendered-html',
				'software_manifest'   => '/software-apps/{slug}/manifest',
				'software_files'      => '/software-apps/{slug}/files',
				'software_file'       => '/software-apps/{slug}/file?path=...',
			),
			'mutating' => array(
				'license_recheck'     => '/license/recheck',
				'create_key'          => '/keys',
				'revoke_key'          => '/keys/{key_id}',
				'upload'              => '/uploads',
				'delete_upload'       => '/uploads/{upload_id}',
				'update_page'         => '/pages/{page_id}',
				'duplicate_page'      => '/pages/{page_id}/duplicate',
				'trash_page'          => '/pages/{page_id}/trash',
				'restore_page'        => '/pages/{page_id}/restore',
				'delete_page_full'    => '/pages/{page_id}',
				'deploy_website_pages'=> '/deploy/website-pages',
				'deploy_software_app' => '/deploy/software-app',
				'deploy_raw_page'     => '/deploy/raw-page',
				'rebuild_page'        => '/deploy/rebuild/page/{page_id}',
				'rebuild_all'         => '/deploy/rebuild/all',
				'delete_page'         => '/deploy/page/{page_id}',
				'patch_deployment'    => '/deployments/{page_id}/patch-file',
				'delete_software_app' => '/deploy/software-app/{slug}',
				'update_software_app' => '/software-apps/{slug}/update',
				'rename_software_app' => '/software-apps/{slug}/rename',
				'software_entry_file' => '/software-apps/{slug}/entry-file',
				'patch_software_file' => '/software-apps/{slug}/patch-file',
				'layout_injections'   => '/content/layout-injections',
				'page_overrides'      => '/content/page-overrides/{page_id}',
				'replace_urls'        => '/tools/replace-urls',
				'seo_schema'          => '/seo/schema/{page_id}',
				'seo_social'          => '/seo/social/{page_id}',
				'ab_create'           => '/ab/create',
				'ab_toggle'           => '/ab/toggle/{page_id}',
				'ab_update_split'     => '/ab/update-split/{page_id}',
				'ab_end'              => '/ab/end/{page_id}',
				'elementor_export'    => '/labs/elementor-export',
				'restore_elementor'   => '/labs/restore-elementor/{page_id}',
			),
		);
	}

	protected function get_payload_templates() {
		return array(
			'deploy_website_pages' => array(
				'upload_id' => 'upload_abc123',
				'items'     => array(
					array(
						'source_file'      => 'home.html',
						'target_mode'      => 'existing',
						'existing_page_id' => 2,
						'render_mode'      => 'display_as_is',
						'raw_html'         => true,
					),
					array(
						'source_file'      => 'about.html',
						'target_mode'      => 'existing',
						'existing_page_id' => 7,
						'render_mode'      => 'display_as_is',
						'raw_html'         => true,
					),
					array(
						'source_file' => 'service.html',
						'target_mode' => 'new',
						'title'       => 'Service',
						'slug'        => 'service',
						'render_mode' => 'display_as_is',
						'raw_html'    => true,
					),
				),
			),
			'deploy_software_app'   => array(
				'upload_id'   => 'upload_abc123',
				'parent_slug' => 'invoicing-software',
				'entry_file'  => 'index.html',
				'label'       => 'Invoicing Software',
			),
			'deploy_raw_page'       => array(
				'page_id'       => 12,
				'combined_code' => '<!doctype html><html><body><h1>Hello</h1></body></html>',
				'render_mode'   => 'display_as_is',
				'raw_html'      => true,
			),
			'update_page'           => array(
				'title'  => 'About Us',
				'slug'   => 'about-us',
				'status' => 'publish',
			),
			'duplicate_page'        => array(
				'title'  => 'About Us Copy',
				'slug'   => 'about-us-copy',
				'status' => 'draft',
			),
			'patch_deployment_file' => array(
				'path'          => 'home.html',
				'content'       => '<!doctype html><html><body><h1>Updated</h1></body></html>',
				'rebuild_after' => true,
			),
			'update_software_app'   => array(
				'upload_id'   => 'upload_abc123',
				'entry_file'  => 'index.html',
				'label'       => 'Invoicing Software',
			),
			'rename_software_app'   => array(
				'new_slug' => 'invoicing-software-v2',
				'label'    => 'Invoicing Software',
			),
			'software_entry_file'   => array(
				'entry_file' => 'dashboard.html',
			),
			'patch_software_file'   => array(
				'path'    => 'js/app.js',
				'content' => 'console.log(\"updated\");',
			),
			'layout_injections'     => array(
				'header_html' => '<header>...</header>',
				'body_html'   => '',
				'footer_html' => '<footer>...</footer>',
				'page_ids'    => array( 12, 15 ),
			),
			'replace_urls'          => array(
				'page_ids'     => array( 12, 15 ),
				'original_url' => 'https://old-domain.com/example',
				'new_url'      => 'https://new-domain.com/example',
			),
			'elementor_export'      => array(
				'items' => array(
					array(
						'source_id'   => 44,
						'target_mode' => 'create_new',
						'new_title'   => 'Home Archimedes',
						'new_slug'    => 'home-archimedes',
					),
				),
			),
		);
	}

	protected function register_route( $path, $methods, $callback ) {
		register_rest_route(
			self::REST_NS,
			self::REST_BASE . $path,
			array(
				'methods'             => $methods,
				'callback'            => array( $this, $callback ),
				'permission_callback' => '__return_true',
			)
		);
	}

	protected function with_agent_access( WP_REST_Request $request, $required_caps, $mutating, callable $callback, array $options = array() ) {
		$endpoint = (string) $request->get_route();
		$method   = (string) $request->get_method();
		$auth     = $this->auth->authenticate_request( $request );

		if ( is_wp_error( $auth ) ) {
			$this->auth->record_audit( '', $endpoint, $method, false, $auth->get_error_message(), $request );
			return $auth;
		}

		$this->auth->touch_key_usage( $auth['id'], $endpoint, $request );

		if ( ! $this->auth->can( $auth, $required_caps, ! empty( $options['match_any'] ) ) ) {
			$error = new WP_Error( 'rspd_agent_forbidden', __( 'This agent key is not allowed to perform that action.', 'reputifly-static-page-deployer' ), array( 'status' => 403 ) );
			$this->auth->record_audit( $auth['id'], $endpoint, $method, false, $error->get_error_message(), $request );
			return $error;
		}

		if ( $mutating && empty( $options['allow_when_locked'] ) ) {
			$this->license->maybe_refresh_status( false, 'agent_api' );
			if ( $this->license->should_block_admin() ) {
				$context = $this->license->get_status_context();
				$error   = new WP_Error(
					'rspd_agent_license_locked',
					! empty( $context['message'] ) ? $context['message'] : __( 'The plugin license is not active on this site.', 'reputifly-static-page-deployer' ),
					array(
						'status'  => 403,
						'license' => $context,
					)
				);
				$this->auth->record_audit( $auth['id'], $endpoint, $method, false, $error->get_error_message(), $request );
				return $error;
			}
		}

		$result = call_user_func( $callback, $auth, $request );

		if ( is_wp_error( $result ) ) {
			$this->auth->record_audit( $auth['id'], $endpoint, $method, false, $result->get_error_message(), $request );
			return $result;
		}

		$summary = ! empty( $options['success_summary'] ) ? (string) $options['success_summary'] : 'Agent action completed.';
		if ( is_array( $result ) && ! empty( $result['message'] ) ) {
			$summary = (string) $result['message'];
		}

		$this->auth->record_audit( $auth['id'], $endpoint, $method, true, $summary, $request );

		return $result;
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'reputifly-static-page-deployer' ) );
		}

		$this->license->maybe_refresh_status( false, 'admin_screen' );

		$notice        = $this->storage->consume_admin_notice();
		$primary       = $this->auth->get_primary_key();
		$primary_id    = ! empty( $primary['id'] ) ? (string) $primary['id'] : '';
		$raw_key       = $primary_id ? $this->auth->get_plaintext_key_for_user( $primary_id ) : '';
		$profile       = $this->build_agent_profile_payload( $raw_key );
		$audit_log     = array_slice( array_reverse( $this->storage->get_agent_audit_log() ), 0, 12 );
		$license       = $this->license->get_status_context();
		$capabilities  = ! empty( $primary['capabilities'] ) && is_array( $primary['capabilities'] ) ? $primary['capabilities'] : $this->auth->get_default_capabilities();
		$keys          = $this->auth->get_keys();
		$logo_url      = $this->bridge->get_logo_url_public();
		$endpoint_json = wp_json_encode( $this->get_endpoint_index(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		$profile_json  = wp_json_encode( $profile, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		$cap_json      = wp_json_encode( $capabilities, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		$site_context  = $this->build_context_payload();
		$active_count  = count( array_filter( $capabilities ) );
		?>
		<div class="rspd-wrap rspd-agent-wrap" id="rspd-agentic-ai-page">
			<?php $this->render_notice( $notice ); ?>

			<div class="rspd-header">
				<div class="rspd-header-row">
					<div class="rspd-section-title-wrap">
						<?php if ( $logo_url ) : ?>
							<img src="<?php echo esc_url( $logo_url ); ?>" alt="" class="rspd-agent-header-logo">
						<?php endif; ?>
						<div>
							<h1 class="rspd-brand-accent">Archimedes AI</h1>
							<p>Secure access to the Archimedes API for trusted AI agents.</p>
						</div>
					</div>
				</div>
			</div>

			<div class="rspd-panel rspd-agent-hero-panel">
				<div class="rspd-agent-hero-copy">
					<span class="rspd-agent-eyebrow">One-file handoff</span>
					<h2>Generate the key, download the file, hand it to your agent.</h2>
					<p>The profile JSON is the handoff file for Cursor or any other trusted AI workflow.</p>
				</div>

				<div class="rspd-agent-actions">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="rspd_agentic_ai_generate_key">
						<?php wp_nonce_field( 'rspd_agentic_ai_generate_key' ); ?>
						<button type="submit" class="rspd-button rspd-button-primary"><?php echo $primary_id ? 'Regenerate Primary Key' : 'Generate Primary Key'; ?></button>
					</form>

					<?php if ( $primary_id ) : ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="rspd_agentic_ai_download_profile">
							<?php wp_nonce_field( 'rspd_agentic_ai_download_profile' ); ?>
							<button type="submit" class="rspd-button rspd-button-primary">Download Agent File</button>
						</form>

						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="rspd_agentic_ai_connection_test">
							<?php wp_nonce_field( 'rspd_agentic_ai_connection_test' ); ?>
							<button type="submit" class="rspd-button rspd-button-ghost">Run Connection Test</button>
						</form>

						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="rspd_agentic_ai_toggle_key">
							<input type="hidden" name="key_id" value="<?php echo esc_attr( $primary_id ); ?>">
							<?php wp_nonce_field( 'rspd_agentic_ai_toggle_key' ); ?>
							<button type="submit" class="rspd-button rspd-button-danger"><?php echo ! empty( $primary['status'] ) && 'active' === $primary['status'] ? 'Revoke Key' : 'Reactivate Key'; ?></button>
						</form>
					<?php endif; ?>
				</div>

				<div class="rspd-agent-stat-grid rspd-agent-hero-stats">
					<div>
						<label class="rspd-field-label">Access</label>
						<div class="rspd-agent-key-field"><?php echo ! empty( $primary['status'] ) && 'active' === $primary['status'] ? 'All Capabilities Allowed' : 'Generate key to begin'; ?></div>
					</div>
					<div>
						<label class="rspd-field-label">Archimedes API</label>
						<div class="rspd-agent-key-field">Ready</div>
					</div>
					<div>
						<label class="rspd-field-label">License</label>
						<div class="rspd-agent-key-field"><?php echo ! empty( $license['label'] ) ? esc_html( $license['label'] ) : 'Unknown'; ?></div>
					</div>
					<div>
						<label class="rspd-field-label">Last Used</label>
						<div class="rspd-agent-key-field"><?php echo ! empty( $primary['last_used_at'] ) ? esc_html( wp_date( 'M j, Y g:i A', (int) $primary['last_used_at'] ) ) : 'Never'; ?></div>
					</div>
				</div>

				<?php if ( $primary_id && '' === $raw_key ) : ?>
					<p class="description">Regenerate once if you want a fresh live key embedded into the downloaded file.</p>
				<?php endif; ?>
			</div>

			<div class="rspd-agent-advanced">
				<details class="rspd-agent-details" open>
					<summary>Documentation</summary>
					<ol class="rspd-agent-steps">
						<li>Fetch site context.</li>
						<li>List pages and current Archimedes deployments.</li>
						<li>Pull current deployment code/context before changing managed pages.</li>
						<li>Upload a ZIP package.</li>
						<li>Inspect the returned scan manifest.</li>
						<li>Choose explicit targets.</li>
						<li>Deploy and verify the result summary.</li>
						<li>Never guess blindly.</li>
					</ol>
				</details>

				<details class="rspd-agent-details">
					<summary>Advanced: Downloaded Agent File Preview</summary>
					<textarea class="rspd-agent-json" readonly><?php echo esc_textarea( $profile_json ); ?></textarea>
				</details>

				<details class="rspd-agent-details">
					<summary>Advanced: Full Capability JSON</summary>
					<textarea class="rspd-agent-json" readonly><?php echo esc_textarea( $cap_json ); ?></textarea>
				</details>

				<details class="rspd-agent-details">
					<summary>Advanced: Site Context</summary>
					<textarea class="rspd-agent-json" readonly><?php echo esc_textarea( wp_json_encode( $site_context, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></textarea>
				</details>

				<details class="rspd-agent-details">
					<summary>Advanced: Endpoint Index</summary>
					<textarea class="rspd-agent-json" readonly><?php echo esc_textarea( $endpoint_json ); ?></textarea>
				</details>

				<details class="rspd-agent-details">
					<summary>Advanced: Current Raw Key</summary>
					<?php if ( $raw_key ) : ?>
						<textarea id="rspd-agent-raw-key" class="rspd-agent-json" readonly><?php echo esc_textarea( $raw_key ); ?></textarea>
						<p class="description">This plaintext key is only shown while it remains available for the current admin user. If you need it again later, regenerate the key.</p>
					<?php else : ?>
						<p class="description">No raw key is currently revealed. Regenerate the primary key if you need a fresh downloadable handoff file.</p>
					<?php endif; ?>
				</details>

				<details class="rspd-agent-details">
					<summary>Advanced: Audit Log</summary>
					<?php if ( empty( $audit_log ) ) : ?>
						<p class="description">No agent calls have been recorded yet.</p>
					<?php else : ?>
						<div class="rspd-agent-audit">
							<?php foreach ( $audit_log as $event ) : ?>
								<div class="rspd-agent-audit-row">
									<div>
										<strong><?php echo esc_html( strtoupper( isset( $event['method'] ) ? $event['method'] : 'GET' ) ); ?></strong>
										<code><?php echo esc_html( isset( $event['endpoint'] ) ? $event['endpoint'] : '' ); ?></code>
									</div>
									<div>
										<span class="rspd-badge <?php echo ! empty( $event['success'] ) ? 'rspd-badge-success' : 'rspd-badge-warning'; ?>">
											<?php echo ! empty( $event['success'] ) ? 'Success' : 'Failed'; ?>
										</span>
									</div>
									<div><?php echo ! empty( $event['timestamp'] ) ? esc_html( wp_date( 'M j, Y g:i A', (int) $event['timestamp'] ) ) : ''; ?></div>
									<div><?php echo ! empty( $event['key_id'] ) ? esc_html( $event['key_id'] ) : 'No key'; ?></div>
									<div><?php echo ! empty( $event['summary'] ) ? esc_html( $event['summary'] ) : ''; ?></div>
								</div>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</details>
			</div>
		</div>
		<?php
	}

	protected function render_notice( array $notice ) {
		if ( empty( $notice['message'] ) ) {
			return;
		}

		$type = ! empty( $notice['type'] ) ? sanitize_html_class( $notice['type'] ) : 'success';
		?>
		<div class="notice notice-<?php echo esc_attr( $type ); ?> rspd-notice is-dismissible">
			<p><?php echo esc_html( $notice['message'] ); ?></p>
		</div>
		<?php
	}

	public function handle_generate_key() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'reputifly-static-page-deployer' ) );
		}

		check_admin_referer( 'rspd_agentic_ai_generate_key' );
		$result = $this->auth->generate_primary_key( get_current_user_id() );

		if ( empty( $result['id'] ) ) {
			$this->storage->set_admin_notice( 'The primary agent key could not be generated.', 'error' );
		} else {
			$this->storage->set_admin_notice( 'Primary Agent Key generated. Copy it from the Agentic AI screen or download the profile JSON now.', 'success' );
		}

		wp_safe_redirect( $this->get_admin_page_url() );
		exit;
	}

	public function handle_toggle_key() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'reputifly-static-page-deployer' ) );
		}

		check_admin_referer( 'rspd_agentic_ai_toggle_key' );

		$key_id = isset( $_POST['key_id'] ) ? sanitize_key( wp_unslash( $_POST['key_id'] ) ) : '';
		$key    = $key_id ? $this->auth->get_key( $key_id ) : array();

		if ( empty( $key ) ) {
			$this->storage->set_admin_notice( 'That agent key could not be found.', 'error' );
			wp_safe_redirect( $this->get_admin_page_url() );
			exit;
		}

		$new_status = ! empty( $key['status'] ) && 'active' === $key['status'] ? 'revoked' : 'active';
		$this->auth->set_key_status( $key_id, $new_status );
		$this->storage->set_admin_notice( 'revoked' === $new_status ? 'Agent key revoked.' : 'Agent key reactivated.' );

		wp_safe_redirect( $this->get_admin_page_url() );
		exit;
	}

	public function handle_download_profile() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'reputifly-static-page-deployer' ) );
		}

		check_admin_referer( 'rspd_agentic_ai_download_profile' );

		$primary = $this->auth->get_primary_key();
		if ( empty( $primary['id'] ) ) {
			$this->storage->set_admin_notice( 'Generate the primary agent key first, then download the agent file.', 'warning' );
			wp_safe_redirect( $this->get_admin_page_url() );
			exit;
		}

		$raw_key = $this->auth->get_plaintext_key_for_user( $primary['id'] );
		if ( '' === $raw_key ) {
			$this->storage->set_admin_notice( 'The current primary key could not be recovered for download. Regenerate the primary key once, then try the download again.', 'warning' );
			wp_safe_redirect( $this->get_admin_page_url() );
			exit;
		}

		$json = wp_json_encode( $this->build_agent_profile_payload( $raw_key ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		$body = $json ? $json : '{}';
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$host = is_string( $host ) ? strtolower( trim( $host ) ) : '';
		$host = preg_replace( '/^www\./', '', $host );

		if ( '' === $host ) {
			$filename = 'reputifly-agent-profile.json';
		} else {
			$filename = sprintf( 'reputifly-agent-profile-%s.json', sanitize_file_name( $host ) );
		}

		while ( ob_get_level() ) {
			ob_end_clean();
		}

		nocache_headers();
		if ( function_exists( 'header_remove' ) ) {
			header_remove( 'Content-Type' );
		}

		header( 'Content-Type: application/json; charset=' . get_bloginfo( 'charset' ) );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . strlen( $body ) );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
		echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	public function handle_connection_test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'reputifly-static-page-deployer' ) );
		}

		check_admin_referer( 'rspd_agentic_ai_connection_test' );

		$primary = $this->auth->get_primary_key();
		$raw_key = ! empty( $primary['id'] ) ? $this->auth->get_plaintext_key_for_user( $primary['id'] ) : '';

		if ( '' === $raw_key ) {
			$this->storage->set_admin_notice( 'The connection test needs the currently revealed plaintext key. Regenerate the primary key first, then run the test again.', 'warning' );
			wp_safe_redirect( $this->get_admin_page_url() );
			exit;
		}

		$request = new WP_REST_Request( 'GET', '/' . self::REST_NS . self::REST_BASE . '/profile' );
		$request->set_header( 'Authorization', 'Bearer ' . $raw_key );
		$response = rest_do_request( $request );

		if ( $response->is_error() ) {
			$error = $response->as_error();
			$this->storage->set_admin_notice( 'Connection test failed: ' . $error->get_error_message(), 'error' );
		} else {
			$data = $response->get_data();
			$msg  = 'Connection test passed. Agent namespace is reachable.';
			if ( ! empty( $data['license']['label'] ) ) {
				$msg .= ' License: ' . $data['license']['label'] . '.';
			}
			$this->storage->set_admin_notice( $msg );
		}

		wp_safe_redirect( $this->get_admin_page_url() );
		exit;
	}

	public function register_rest_routes() {
		$this->register_route( '/profile', WP_REST_Server::READABLE, 'rest_get_profile' );
		$this->register_route( '/context', WP_REST_Server::READABLE, 'rest_get_context' );
		$this->register_route( '/license', WP_REST_Server::READABLE, 'rest_get_license' );
		$this->register_route( '/pages', WP_REST_Server::READABLE, 'rest_get_pages' );
		$this->register_route( '/deployments', WP_REST_Server::READABLE, 'rest_get_deployments' );
		$this->register_route( '/software-apps', WP_REST_Server::READABLE, 'rest_get_software_apps' );
		$this->register_route( '/layout-injections', WP_REST_Server::READABLE, 'rest_get_layout_injections' );
		$this->register_route( '/labs/elementor-sources', WP_REST_Server::READABLE, 'rest_get_elementor_sources' );
		$this->register_route( '/labs/restorable', WP_REST_Server::READABLE, 'rest_get_restorable_exports' );
		$this->register_route( '/keys', WP_REST_Server::READABLE, 'rest_get_keys' );
		$this->register_route( '/audit-log', WP_REST_Server::READABLE, 'rest_get_audit_log' );
		$this->register_route( '/deployments/(?P<page_id>\\d+)/manifest', WP_REST_Server::READABLE, 'rest_get_deployment_manifest' );
		$this->register_route( '/deployments/(?P<page_id>\\d+)/files', WP_REST_Server::READABLE, 'rest_get_deployment_files' );
		$this->register_route( '/deployments/(?P<page_id>\\d+)/file', WP_REST_Server::READABLE, 'rest_get_deployment_file' );
		$this->register_route( '/deployments/(?P<page_id>\\d+)/rendered-html', WP_REST_Server::READABLE, 'rest_get_deployment_rendered_html' );
		$this->register_route( '/software-apps/(?P<slug>[a-z0-9-]+)/manifest', WP_REST_Server::READABLE, 'rest_get_software_manifest' );
		$this->register_route( '/software-apps/(?P<slug>[a-z0-9-]+)/files', WP_REST_Server::READABLE, 'rest_get_software_files' );
		$this->register_route( '/software-apps/(?P<slug>[a-z0-9-]+)/file', WP_REST_Server::READABLE, 'rest_get_software_file' );
		$this->register_mutating_rest_routes();
	}

	protected function get_request_payload( WP_REST_Request $request ) {
		$json = $request->get_json_params();
		if ( is_array( $json ) && ! empty( $json ) ) {
			return $json;
		}

		$body = $request->get_body_params();
		if ( is_array( $body ) && ! empty( $body ) ) {
			return $body;
		}

		$params = $request->get_params();
		unset( $params['route'] );

		return is_array( $params ) ? $params : array();
	}

	protected function build_context_payload() {
		$license      = $this->license->get_status_context();
		$deployments  = $this->storage->get_deployments();
		$software     = $this->storage->get_software_apps();
		$settings     = $this->storage->get_settings();
		$layout_ids   = ! empty( $settings['layout_injections']['page_ids'] ) && is_array( $settings['layout_injections']['page_ids'] ) ? $settings['layout_injections']['page_ids'] : array();
		$elementor_on = $this->bridge->is_elementor_active_public();

		return array(
			'site_url'               => home_url(),
			'site_name'              => get_bloginfo( 'name' ),
			'plugin_version'         => RSPD_VERSION,
			'license'                => $license,
			'counts'                 => array(
				'wordpress_pages'   => count( $this->build_pages_payload() ),
				'deployments'       => count( $deployments ),
				'software_apps'     => count( $software ),
				'layout_pages'      => count( $layout_ids ),
				'elementor_sources' => $elementor_on ? count( $this->bridge->get_elementor_source_pages_public() ) : 0,
			),
			'agent_api_base'         => rest_url( self::REST_NS . self::REST_BASE ),
			'layout_injections_used' => count( $layout_ids ),
			'elementor_active'       => $elementor_on,
			'server_time'            => wp_date( DATE_ATOM ),
		);
	}
}
