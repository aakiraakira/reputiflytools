<?php
/**
 * Security and path helpers.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Security helper class.
 */
class RSPD_Security {

	/**
	 * Allowed upload extensions.
	 *
	 * @var string[]
	 */
	protected $allowed_extensions = array(
		'html',
		'htm',
		'css',
		'js',
		'mjs',
		'json',
		'map',
		'txt',
		'xml',
		'svg',
		'png',
		'jpg',
		'jpeg',
		'gif',
		'webp',
		'avif',
		'ico',
		'bmp',
		'tif',
		'tiff',
		'woff',
		'woff2',
		'ttf',
		'otf',
		'eot',
		'mp4',
		'webm',
		'ogg',
		'ogv',
		'mp3',
		'wav',
		'wasm',
	);

	/**
	 * Require admin capability.
	 *
	 * @return void
	 */
	public function guard_manage_capability() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access Reputifly Static Page Deployer.', 'reputifly-static-page-deployer' ), 403 );
		}
	}

	/**
	 * Check the management capability.
	 *
	 * @return bool
	 */
	public function user_can_manage() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Verify a nonce field.
	 *
	 * @param string $action Nonce action.
	 * @param string $field  Submitted nonce field name.
	 * @return void
	 */
	public function verify_nonce( $action, $field = '_wpnonce' ) {
		$nonce = isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, $action ) ) {
			wp_die( esc_html__( 'Security check failed. Please refresh the page and try again.', 'reputifly-static-page-deployer' ), 403 );
		}
	}

	/**
	 * Get allowed file extensions.
	 *
	 * @return string[]
	 */
	public function get_allowed_extensions() {
		return $this->allowed_extensions;
	}

	/**
	 * Determine whether a file is allowed in deployment packages.
	 *
	 * @param string $filename Filename or relative path.
	 * @return bool
	 */
	public function is_allowed_file( $filename ) {
		$extension = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

		return $extension && in_array( $extension, $this->allowed_extensions, true );
	}

	/**
	 * Normalize a relative path and strip traversal attempts.
	 *
	 * @param string $path Raw relative path.
	 * @return string
	 */
	public function normalize_relative_path( $path ) {
		$path = wp_normalize_path( (string) $path );
		$path = preg_replace( '#^[./\\\\]+#', '', $path );

		if ( '' === $path || false !== strpos( $path, ':' ) ) {
			return '';
		}

		$segments = array();

		foreach ( explode( '/', $path ) as $segment ) {
			$segment = trim( $segment );

			if ( '' === $segment || '.' === $segment ) {
				continue;
			}

			if ( '..' === $segment ) {
				if ( empty( $segments ) ) {
					return '';
				}

				array_pop( $segments );
				continue;
			}

			$clean_segment = sanitize_file_name( $segment );

			if ( '' === $clean_segment ) {
				return '';
			}

			$segments[] = $clean_segment;
		}

		return implode( '/', $segments );
	}

	/**
	 * Join a base path and a relative path safely.
	 *
	 * @param string $base_dir Base directory.
	 * @param string $relative Relative path.
	 * @return string|false
	 */
	public function safe_join( $base_dir, $relative ) {
		$normalized = $this->normalize_relative_path( $relative );

		if ( '' === $normalized ) {
			return false;
		}

		$base_dir = trailingslashit( wp_normalize_path( $base_dir ) );
		$target   = wp_normalize_path( $base_dir . $normalized );

		if ( 0 !== strpos( $target, $base_dir ) ) {
			return false;
		}

		return $target;
	}

	/**
	 * Determine whether a URL-like reference is local and should be rewritten.
	 *
	 * @param string $reference Original reference.
	 * @return bool
	 */
	public function is_local_reference( $reference ) {
		$reference = trim( (string) $reference );

		if ( '' === $reference || '#' === $reference[0] ) {
			return false;
		}

		$lower = strtolower( $reference );

		foreach ( array( 'http://', 'https://', '//', 'data:', 'javascript:', 'mailto:', 'tel:' ) as $prefix ) {
			if ( 0 === strpos( $lower, $prefix ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Determine whether a reference points to an HTML document.
	 *
	 * @param string $reference Reference value.
	 * @return bool
	 */
	public function is_html_reference( $reference ) {
		$reference = preg_replace( '/[?#].*$/', '', (string) $reference );
		$extension = strtolower( pathinfo( $reference, PATHINFO_EXTENSION ) );

		return in_array( $extension, array( 'html', 'htm' ), true );
	}

	/**
	 * Build normalized aliases for an HTML document path or a route-like reference.
	 *
	 * Examples:
	 * - about.html => about.html, about
	 * - team/index.html => team/index.html, team/index, team, team/
	 * - about => about, about.html, about/index.html, about/
	 *
	 * @param string $reference Reference value.
	 * @return string[]
	 */
	public function build_html_reference_aliases( $reference ) {
		$reference = preg_replace( '/[?#].*$/', '', (string) $reference );
		$reference = trim( wp_normalize_path( $reference ) );

		if ( '' === $reference ) {
			return array();
		}

		$had_trailing_slash = '/' === substr( $reference, -1 );
		$normalized         = $this->normalize_relative_path( $reference );

		if ( '' === $normalized ) {
			return array();
		}

		$aliases   = array( $normalized );
		$extension = strtolower( pathinfo( $normalized, PATHINFO_EXTENSION ) );

		if ( in_array( $extension, array( 'html', 'htm' ), true ) ) {
			$without_ext = preg_replace( '/\.(html?|htm)$/i', '', $normalized );
			$basename    = basename( $normalized );
			$base_stem   = preg_replace( '/\.(html?|htm)$/i', '', $basename );

			$aliases[] = $without_ext;
			$aliases[] = $basename;

			if ( '' !== $base_stem ) {
				$aliases[] = $base_stem;
			}

			if ( 'index' === strtolower( (string) $base_stem ) ) {
				$directory = trim( dirname( $normalized ), './' );

				if ( '' !== $directory ) {
					$aliases[] = $directory;
					$aliases[] = $directory . '/';
				}
			}
		} else {
			$trimmed = rtrim( $normalized, '/' );

			if ( '' !== $trimmed ) {
				$aliases[] = $trimmed;
				$aliases[] = $trimmed . '.html';
				$aliases[] = $trimmed . '.htm';
				$aliases[] = $trimmed . '/index.html';
				$aliases[] = $trimmed . '/index.htm';
			}

			if ( $had_trailing_slash && '' !== $trimmed ) {
				$aliases[] = $trimmed . '/';
			}
		}

		$aliases = array_values(
			array_unique(
				array_filter(
					array_map(
						static function ( $alias ) {
							return trim( wp_normalize_path( (string) $alias ) );
						},
						$aliases
					),
					static function ( $alias ) {
						return '' !== $alias;
					}
				)
			)
		);

		return $aliases;
	}

	/**
	 * Split a reference into path and suffix.
	 *
	 * @param string $reference Reference value.
	 * @return array{path:string,suffix:string}
	 */
	public function split_reference( $reference ) {
		$reference = (string) $reference;
		$position  = strcspn( $reference, '?#' );

		if ( $position >= strlen( $reference ) ) {
			return array(
				'path'   => $reference,
				'suffix' => '',
			);
		}

		return array(
			'path'   => substr( $reference, 0, $position ),
			'suffix' => substr( $reference, $position ),
		);
	}

	/**
	 * Resolve a reference relative to the current HTML file directory.
	 *
	 * @param string $reference Relative or root-relative reference.
	 * @param string $current_dir Current entry file directory.
	 * @return string
	 */
	public function resolve_reference_path( $reference, $current_dir = '' ) {
		$parts = $this->split_reference( $reference );
		$path  = $parts['path'];

		if ( '' === $path ) {
			return '';
		}

		if ( 0 === strpos( $path, '/' ) ) {
			return $this->normalize_relative_path( ltrim( $path, '/' ) );
		}

		$base = trim( wp_normalize_path( $current_dir ), '/' );

		if ( '' !== $base ) {
			$path = $base . '/' . $path;
		}

		return $this->normalize_relative_path( $path );
	}
}
