<?php
/**
 * Storage layer.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Storage helper.
 */
class RSPD_Storage {

	/**
	 * Post meta key for deployment config.
	 *
	 * @var string
	 */
	const CONFIG_META_KEY = '_rspd_config';

	/**
	 * Option key holding active page map.
	 *
	 * @var string
	 */
	const PAGE_MAP_OPTION = 'rspd_page_map';

	/**
	 * Option key holding mounted software app deployments.
	 *
	 * @var string
	 */
	const SOFTWARE_APPS_OPTION = 'rspd_software_apps';

	/**
	 * Option key for plugin settings.
	 *
	 * @var string
	 */
	const SETTINGS_OPTION = 'rspd_settings';

	/**
	 * Post meta key used to preserve original Elementor-backed page state for
	 * in-place conversions performed from Labs.
	 *
	 * @var string
	 */
	const ELEMENTOR_BACKUP_META_KEY = '_rspd_elementor_backup';

	/**
	 * Option key for persisted licensing state.
	 *
	 * @var string
	 */
	const LICENSE_STATE_OPTION = 'rspd_license_state';

	/**
	 * Option key for Agentic AI API keys.
	 *
	 * @var string
	 */
	const AGENT_KEYS_OPTION = 'rspd_agent_keys';

	/**
	 * Option key for the primary Agentic AI key identifier.
	 *
	 * @var string
	 */
	const AGENT_PRIMARY_KEY_OPTION = 'rspd_agent_primary_key_id';

	/**
	 * Option key for the Agentic AI audit log.
	 *
	 * @var string
	 */
	const AGENT_AUDIT_OPTION = 'rspd_agent_audit_log';

	/**
	 * Option key for pending Agentic AI upload sessions.
	 *
	 * @var string
	 */
	const AGENT_UPLOADS_OPTION = 'rspd_agent_upload_sessions';

	/**
	 * Admin notice transient prefix.
	 *
	 * @var string
	 */
	const NOTICE_PREFIX = 'rspd_notice_';

	/**
	 * Security helper.
	 *
	 * @var RSPD_Security
	 */
	protected $security;

	/**
	 * Constructor.
	 *
	 * @param RSPD_Security $security Security helper.
	 */
	public function __construct( RSPD_Security $security ) {
		$this->security = $security;
	}

	/**
	 * Ensure the base uploads structure exists.
	 *
	 * @return void
	 */
	public function ensure_base_structure() {
		$directories = array(
			$this->get_base_dir(),
			$this->get_deployments_dir(),
			$this->get_agent_uploads_dir(),
		);

		foreach ( $directories as $directory ) {
			wp_mkdir_p( $directory );
		}

		$this->write_security_files();
	}

	/**
	 * Get the plugin upload base directory.
	 *
	 * @return string
	 */
	public function get_base_dir() {
		$upload_dir = wp_upload_dir();

		return wp_normalize_path( trailingslashit( $upload_dir['basedir'] ) . 'reputifly-static-page-deployer' );
	}

	/**
	 * Get the plugin upload base URL.
	 *
	 * @return string
	 */
	public function get_base_url() {
		$upload_dir = wp_upload_dir();

		return trailingslashit( $upload_dir['baseurl'] ) . 'reputifly-static-page-deployer';
	}

	/**
	 * Get the deployments directory.
	 *
	 * @return string
	 */
	public function get_deployments_dir() {
		return $this->get_base_dir() . '/deployments';
	}

	/**
	 * Get the working directory for Agentic AI upload sessions.
	 *
	 * @return string
	 */
	public function get_agent_uploads_dir() {
		return $this->get_base_dir() . '/agent-uploads';
	}

	/**
	 * Build a working directory for an Agentic AI upload session.
	 *
	 * @param string $upload_id Upload session id.
	 * @return array{relative_dir:string,absolute_dir:string}
	 */
	public function create_agent_upload_directory( $upload_id ) {
		$this->ensure_base_structure();

		$upload_id    = sanitize_key( (string) $upload_id );
		$relative_dir = sprintf( 'agent-uploads/%s', $upload_id );
		$absolute_dir = $this->get_deployment_path( $relative_dir );

		wp_mkdir_p( $absolute_dir );

		return array(
			'relative_dir' => $relative_dir,
			'absolute_dir' => $absolute_dir,
		);
	}

	/**
	 * Create a backup directory for a maintenance operation.
	 *
	 * @param string $operation Operation slug.
	 * @return array{relative_dir:string,absolute_dir:string}
	 */
	public function create_backup_directory( $operation ) {
		$this->ensure_base_structure();

		$operation    = sanitize_title( (string) $operation );
		$token        = strtolower( wp_generate_password( 6, false, false ) );
		$relative_dir = sprintf( 'backups/%s/run-%s-%s', $operation, gmdate( 'YmdHis' ), $token );
		$absolute_dir = $this->get_deployment_path( $relative_dir );

		wp_mkdir_p( $absolute_dir );

		return array(
			'relative_dir' => $relative_dir,
			'absolute_dir' => $absolute_dir,
		);
	}

	/**
	 * Build a new deployment folder.
	 *
	 * @param int $page_id Target page id.
	 * @return array{relative_dir:string,absolute_dir:string,url:string}
	 */
	public function create_deployment_directory( $page_id ) {
		$this->ensure_base_structure();

		$token        = strtolower( wp_generate_password( 8, false, false ) );
		$relative_dir = sprintf( 'deployments/page-%d/deploy-%s-%s', absint( $page_id ), gmdate( 'YmdHis' ), $token );
		$absolute_dir = $this->security->safe_join( $this->get_base_dir(), $relative_dir );

		if ( ! $absolute_dir ) {
			$absolute_dir = wp_normalize_path( $this->get_base_dir() . '/' . $relative_dir );
		}

		wp_mkdir_p( $absolute_dir );

		return array(
			'relative_dir' => $relative_dir,
			'absolute_dir' => $absolute_dir,
			'url'          => trailingslashit( $this->get_base_url() ) . trim( $relative_dir, '/' ),
		);
	}

	/**
	 * Build a new deployment folder for a mounted software app.
	 *
	 * @param string $slug Public parent slug.
	 * @return array{relative_dir:string,absolute_dir:string,url:string}
	 */
	public function create_software_deployment_directory( $slug ) {
		$this->ensure_base_structure();

		$safe_slug    = sanitize_title( (string) $slug );
		$token        = strtolower( wp_generate_password( 8, false, false ) );
		$relative_dir = sprintf( 'software/%s/release-%s-%s', $safe_slug, gmdate( 'YmdHis' ), $token );
		$absolute_dir = $this->security->safe_join( $this->get_base_dir(), $relative_dir );

		if ( ! $absolute_dir ) {
			$absolute_dir = wp_normalize_path( $this->get_base_dir() . '/' . $relative_dir );
		}

		wp_mkdir_p( $absolute_dir );

		return array(
			'relative_dir' => $relative_dir,
			'absolute_dir' => $absolute_dir,
			'url'          => $this->get_software_mount_url( $safe_slug ),
		);
	}

	/**
	 * Get an absolute path from a deployment-relative path.
	 *
	 * @param string $relative_dir Relative deployment directory.
	 * @return string
	 */
	public function get_deployment_path( $relative_dir ) {
		$safe_path = $this->security->safe_join( $this->get_base_dir(), $relative_dir );

		if ( $safe_path ) {
			return $safe_path;
		}

		return wp_normalize_path( $this->get_base_dir() . '/' . ltrim( $relative_dir, '/' ) );
	}

	/**
	 * Get a deployment URL from a relative path.
	 *
	 * @param string $relative_dir Relative deployment directory.
	 * @return string
	 */
	public function get_deployment_url( $relative_dir ) {
		return trailingslashit( $this->get_base_url() ) . trim( $relative_dir, '/' );
	}

	/**
	 * Get the public static-serving base URL for a managed page deployment.
	 *
	 * Uploaded packages are served through a WordPress route so hosts do not need
	 * to expose CSS/JS/HTML files directly from the uploads directory.
	 *
	 * @param int $page_id Managed page id.
	 * @return string
	 */
	public function get_public_deployment_url( $page_id ) {
		return trailingslashit( home_url( 'reputifly-static-assets/' . absint( $page_id ) ) );
	}

	/**
	 * Get the public mount URL for a software app slug.
	 *
	 * @param string $slug Software app slug.
	 * @param string $path Optional child path.
	 * @return string
	 */
	public function get_software_mount_url( $slug, $path = '' ) {
		$slug               = trim( sanitize_title( (string) $slug ), '/' );
		$raw_path           = wp_normalize_path( (string) $path );
		$has_trailing_slash = '' !== trim( $raw_path, '/' ) && '/' === substr( $raw_path, -1 );
		$path               = ltrim( $this->security->normalize_relative_path( $raw_path ), '/' );

		$url = trailingslashit( home_url( $slug ) );

		if ( '' !== $path ) {
			$url .= $path;
			if ( $has_trailing_slash ) {
				$url = trailingslashit( $url );
			}
		}

		return $url;
	}

	/**
	 * Get the public mounted URL for one HTML file in a software app.
	 *
	 * @param string $slug Software app slug.
	 * @param string $html_file HTML file path.
	 * @param string $root_entry_file Root entry file.
	 * @return string
	 */
	public function get_software_file_url( $slug, $html_file, $root_entry_file = '' ) {
		$html_file       = $this->security->normalize_relative_path( $html_file );
		$root_entry_file = $this->security->normalize_relative_path( $root_entry_file );

		if ( '' === $html_file || $html_file === $root_entry_file ) {
			return $this->get_software_mount_url( $slug );
		}

		$basename = strtolower( basename( $html_file ) );

		if ( in_array( $basename, array( 'index.html', 'index.htm' ), true ) ) {
			$directory = trim( dirname( $html_file ), './' );

			if ( '' !== $directory ) {
				return $this->get_software_mount_url( $slug, trailingslashit( $directory ) );
			}
		}

		return $this->get_software_mount_url( $slug, $html_file );
	}

	/**
	 * Build route summaries for a mounted software app.
	 *
	 * @param string $slug Software app slug.
	 * @param string $root_entry_file Root entry file.
	 * @param array  $html_files HTML files in the package.
	 * @return array
	 */
	public function get_software_app_routes( $slug, $root_entry_file, array $html_files ) {
		$routes = array();

		foreach ( $html_files as $html_file ) {
			$normalized = $this->security->normalize_relative_path( $html_file );

			if ( '' === $normalized ) {
				continue;
			}

			$routes[] = array(
				'file'    => $normalized,
				'url'     => $this->get_software_file_url( $slug, $normalized, $root_entry_file ),
				'is_root' => $normalized === $this->security->normalize_relative_path( $root_entry_file ),
			);
		}

		return $routes;
	}

	/**
	 * Persist a file.
	 *
	 * @param string $absolute_path File path.
	 * @param string $contents File contents.
	 * @return bool
	 */
	public function write_file( $absolute_path, $contents ) {
		wp_mkdir_p( dirname( $absolute_path ) );

		return false !== file_put_contents( $absolute_path, $contents );
	}

	/**
	 * Read a file if it exists.
	 *
	 * @param string $absolute_path File path.
	 * @return string
	 */
	public function read_file( $absolute_path ) {
		if ( ! is_readable( $absolute_path ) ) {
			return '';
		}

		$contents = file_get_contents( $absolute_path );

		return false === $contents ? '' : (string) $contents;
	}

	/**
	 * Save the render bundle into deployment storage.
	 *
	 * @param string $relative_dir Deployment folder.
	 * @param array  $bundle Render bundle.
	 * @return bool
	 */
	public function save_render_bundle( $relative_dir, array $bundle ) {
		$path = $this->get_deployment_path( trailingslashit( $relative_dir ) . 'render.json' );

		return $this->write_file( $path, wp_json_encode( $bundle, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
	}

	/**
	 * Load a render bundle from deployment storage.
	 *
	 * @param string $relative_dir Deployment folder.
	 * @return array
	 */
	public function load_render_bundle( $relative_dir ) {
		$path = $this->get_deployment_path( trailingslashit( $relative_dir ) . 'render.json' );

		if ( ! is_readable( $path ) ) {
			return array();
		}

		$data = json_decode( $this->read_file( $path ), true );

		return is_array( $data ) ? $data : array();
	}

	/**
	 * Get deployment config from page meta.
	 *
	 * @param int $page_id Page id.
	 * @return array
	 */
	public function get_page_config( $page_id ) {
		$config = get_post_meta( $page_id, self::CONFIG_META_KEY, true );

		return is_array( $config ) ? $config : array();
	}

	/**
	 * Persist deployment config and refresh the map.
	 *
	 * @param int   $page_id Page id.
	 * @param array $config Config payload.
	 * @return void
	 */
	public function update_page_config( $page_id, array $config ) {
		update_post_meta( $page_id, self::CONFIG_META_KEY, $config );
		$this->update_page_map_entry( $page_id, $config );
		delete_transient( 'rspd_render_' . absint( $page_id ) );
	}

	/**
	 * Replace an exact string inside replaceable text files in a deployment directory.
	 *
	 * @param string $relative_dir Relative deployment directory.
	 * @param string $search Exact original string.
	 * @param string $replace Exact replacement string.
	 * @param string $backup_absolute_dir Optional absolute backup directory.
	 * @return array
	 */
	public function replace_string_in_deployment( $relative_dir, $search, $replace, $backup_absolute_dir = '' ) {
		$results = array(
			'files_changed'     => 0,
			'replacement_count' => 0,
			'backed_up_files'   => 0,
			'changed_files'     => array(),
			'errors'            => array(),
		);

		$relative_dir = trim( (string) $relative_dir, '/' );
		$directory    = $this->get_deployment_path( $relative_dir );

		if ( '' === $relative_dir || ! is_dir( $directory ) || '' === (string) $search ) {
			return $results;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $directory, FilesystemIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::LEAVES_ONLY
		);

		foreach ( $iterator as $file ) {
			if ( ! $file instanceof SplFileInfo || ! $file->isFile() ) {
				continue;
			}

			$absolute_path = wp_normalize_path( $file->getPathname() );

			if ( ! $this->is_replaceable_text_file( $absolute_path ) ) {
				continue;
			}

			$contents = $this->read_file( $absolute_path );

			if ( '' === $contents && filesize( $absolute_path ) > 0 ) {
				continue;
			}

			if ( false !== strpos( $contents, "\0" ) || false === strpos( $contents, $search ) ) {
				continue;
			}

			$replacement_count = 0;
			$updated_contents  = str_replace( $search, $replace, $contents, $replacement_count );

			if ( $replacement_count < 1 || $updated_contents === $contents ) {
				continue;
			}

			$relative_file = ltrim( str_replace( wp_normalize_path( $directory ), '', $absolute_path ), '/\\' );

			if ( '' !== $backup_absolute_dir ) {
				$backup_path = wp_normalize_path( trailingslashit( $backup_absolute_dir ) . trailingslashit( $relative_dir ) . $relative_file );

				if ( $this->write_file( $backup_path, $contents ) ) {
					$results['backed_up_files']++;
				}
			}

			if ( ! $this->write_file( $absolute_path, $updated_contents ) ) {
				$results['errors'][] = $relative_file;
				continue;
			}

			$results['files_changed']++;
			$results['replacement_count'] += $replacement_count;
			$results['changed_files'][] = trailingslashit( $relative_dir ) . $relative_file;
		}

		return $results;
	}

	/**
	 * Delete deployment config and cache.
	 *
	 * @param int $page_id Page id.
	 * @return void
	 */
	public function delete_page_config( $page_id ) {
		delete_post_meta( $page_id, self::CONFIG_META_KEY );
		$this->remove_page_map_entry( $page_id );
		delete_transient( 'rspd_render_' . absint( $page_id ) );
	}

	/**
	 * Get the active page map.
	 *
	 * @return array
	 */
	public function get_page_map() {
		$page_map = get_option( self::PAGE_MAP_OPTION, array() );

		if ( ! is_array( $page_map ) ) {
			return array();
		}

		return $this->sanitize_page_map( $page_map, true );
	}

	/**
	 * Set the active page map.
	 *
	 * @param array $page_map Page map.
	 * @return void
	 */
	public function set_page_map( array $page_map ) {
		update_option( self::PAGE_MAP_OPTION, $page_map, false );
	}

	/**
	 * Remove stale page-map entries and refresh derived summary fields.
	 *
	 * @param array $page_map Stored page map.
	 * @param bool  $persist  Whether to write changes back to the option.
	 * @return array
	 */
	protected function sanitize_page_map( array $page_map, $persist = false ) {
		$clean   = array();
		$changed = false;

		foreach ( $page_map as $page_id => $entry ) {
			$page_id = absint( $page_id );

			if ( ! $page_id ) {
				$changed = true;
				continue;
			}

			$page = get_post( $page_id );

			if ( ! $page || 'page' !== $page->post_type || 'trash' === $page->post_status ) {
				$changed = true;
				continue;
			}

			$config = $this->get_page_config( $page_id );

			if ( empty( $config ) || empty( $config['deployment_rel_dir'] ) ) {
				$changed = true;
				continue;
			}

			$has_overrides  = ! empty( $config['page_overrides'] ) && is_array( $config['page_overrides'] );
			$override_count = $has_overrides ? $this->count_override_keys( $config['page_overrides'] ) : 0;
			$normalized     = array(
				'enabled'        => ! empty( $config['enabled'] ),
				'deployment_id'  => isset( $config['deployment_id'] ) ? (string) $config['deployment_id'] : '',
				'render_mode'    => isset( $config['render_mode'] ) ? (string) $config['render_mode'] : 'isolated',
				'updated_at'     => isset( $config['updated_at'] ) ? (int) $config['updated_at'] : 0,
				'cache_version'  => isset( $config['cache_version'] ) ? (string) $config['cache_version'] : '',
				'relative_dir'   => isset( $config['deployment_rel_dir'] ) ? (string) $config['deployment_rel_dir'] : '',
				'entry_file'     => isset( $config['entry_file'] ) ? (string) $config['entry_file'] : '',
				'package_key'    => isset( $config['package_key'] ) ? (string) $config['package_key'] : '',
				'source_type'    => isset( $config['source_type'] ) ? (string) $config['source_type'] : 'paste',
				'diagnostics'    => isset( $config['diagnostics'] ) && is_array( $config['diagnostics'] ) ? $config['diagnostics'] : array(),
				'last_permalink' => get_permalink( $page_id ),
				'has_overrides'  => $has_overrides && $override_count > 0,
				'override_count' => $override_count,
			);

			if ( ! is_array( $entry ) || wp_json_encode( $normalized ) !== wp_json_encode( $entry ) ) {
				$changed = true;
			}

			$clean[ $page_id ] = $normalized;
		}

		if ( $persist && $changed ) {
			update_option( self::PAGE_MAP_OPTION, $clean, false );
		}

		return $clean;
	}

	/**
	 * Update one page map entry.
	 *
	 * @param int   $page_id Page id.
	 * @param array $config Deployment config.
	 * @return void
	 */
	public function update_page_map_entry( $page_id, array $config ) {
		$page_map             = $this->get_page_map();
		$has_overrides  = ! empty( $config['page_overrides'] ) && is_array( $config['page_overrides'] );
		$override_count = $has_overrides ? $this->count_override_keys( $config['page_overrides'] ) : 0;

		$page_map[ $page_id ] = array(
			'enabled'        => ! empty( $config['enabled'] ),
			'deployment_id'  => isset( $config['deployment_id'] ) ? (string) $config['deployment_id'] : '',
			'render_mode'    => isset( $config['render_mode'] ) ? (string) $config['render_mode'] : 'isolated',
			'updated_at'     => isset( $config['updated_at'] ) ? (int) $config['updated_at'] : time(),
			'cache_version'  => isset( $config['cache_version'] ) ? (string) $config['cache_version'] : '',
			'relative_dir'   => isset( $config['deployment_rel_dir'] ) ? (string) $config['deployment_rel_dir'] : '',
			'entry_file'     => isset( $config['entry_file'] ) ? (string) $config['entry_file'] : '',
			'package_key'    => isset( $config['package_key'] ) ? (string) $config['package_key'] : '',
			'source_type'    => isset( $config['source_type'] ) ? (string) $config['source_type'] : 'paste',
			'diagnostics'    => isset( $config['diagnostics'] ) && is_array( $config['diagnostics'] ) ? $config['diagnostics'] : array(),
			'last_permalink' => get_permalink( $page_id ),
			'has_overrides'  => $has_overrides,
			'override_count' => $override_count,
		);

		$this->set_page_map( $page_map );
	}

	/**
	 * Remove one page map entry.
	 *
	 * @param int $page_id Page id.
	 * @return void
	 */
	public function remove_page_map_entry( $page_id ) {
		$page_map = $this->get_page_map();

		if ( isset( $page_map[ $page_id ] ) ) {
			unset( $page_map[ $page_id ] );
			$this->set_page_map( $page_map );
		}
	}

	/**
	 * Get all mounted software apps.
	 *
	 * @return array
	 */
	public function get_software_apps() {
		$apps = get_option( self::SOFTWARE_APPS_OPTION, array() );

		if ( ! is_array( $apps ) ) {
			return array();
		}

		return $this->sanitize_software_apps( $apps, true );
	}

	/**
	 * Persist mounted software apps.
	 *
	 * @param array $apps Software app records.
	 * @return void
	 */
	public function set_software_apps( array $apps ) {
		update_option( self::SOFTWARE_APPS_OPTION, $apps, false );
	}

	/**
	 * Normalize software app records and prune stale entries.
	 *
	 * @param array $apps Stored app records.
	 * @param bool  $persist Whether to write back changes.
	 * @return array
	 */
	protected function sanitize_software_apps( array $apps, $persist = false ) {
		$clean   = array();
		$changed = false;

		foreach ( $apps as $slug => $record ) {
			$slug = trim( sanitize_title( (string) $slug ), '/' );

			if ( '' === $slug || ! is_array( $record ) ) {
				$changed = true;
				continue;
			}

			$relative_dir = isset( $record['relative_dir'] ) ? (string) $record['relative_dir'] : '';

			if ( '' === $relative_dir ) {
				$changed = true;
				continue;
			}

			$absolute_dir = $this->get_deployment_path( $relative_dir );

			if ( ! is_dir( $absolute_dir ) ) {
				$changed = true;
				continue;
			}

			$html_files = array();
			if ( ! empty( $record['html_files'] ) && is_array( $record['html_files'] ) ) {
				foreach ( $record['html_files'] as $html_file ) {
					$normalized = $this->security->normalize_relative_path( $html_file );
					if ( '' !== $normalized ) {
						$html_files[] = $normalized;
					}
				}
			}

			sort( $html_files );

			$clean[ $slug ] = array(
				'enabled'        => ! empty( $record['enabled'] ),
				'slug'           => $slug,
				'label'          => isset( $record['label'] ) ? (string) $record['label'] : '',
				'deployment_id'  => isset( $record['deployment_id'] ) ? (string) $record['deployment_id'] : '',
				'relative_dir'   => $relative_dir,
				'entry_file'     => isset( $record['entry_file'] ) ? (string) $record['entry_file'] : '',
				'html_files'     => array_values( array_unique( $html_files ) ),
				'package_key'    => isset( $record['package_key'] ) ? (string) $record['package_key'] : '',
				'source_type'    => isset( $record['source_type'] ) ? (string) $record['source_type'] : 'software_app',
				'updated_at'     => isset( $record['updated_at'] ) ? (int) $record['updated_at'] : 0,
				'mount_url'      => $this->get_software_mount_url( $slug ),
			);

			if ( wp_json_encode( $clean[ $slug ] ) !== wp_json_encode( $record ) ) {
				$changed = true;
			}
		}

		if ( $persist && $changed ) {
			update_option( self::SOFTWARE_APPS_OPTION, $clean, false );
		}

		return $clean;
	}

	/**
	 * Get one mounted software app by slug.
	 *
	 * @param string $slug Software app slug.
	 * @return array
	 */
	public function get_software_app( $slug ) {
		$slug = trim( sanitize_title( (string) $slug ), '/' );
		$apps = $this->get_software_apps();

		return isset( $apps[ $slug ] ) && is_array( $apps[ $slug ] ) ? $apps[ $slug ] : array();
	}

	/**
	 * Update one mounted software app record.
	 *
	 * @param string $slug Software app slug.
	 * @param array  $record App record.
	 * @return void
	 */
	public function update_software_app( $slug, array $record ) {
		$slug = trim( sanitize_title( (string) $slug ), '/' );

		if ( '' === $slug ) {
			return;
		}

		$apps         = $this->get_software_apps();
		$record['slug'] = $slug;
		$apps[ $slug ] = $record;
		$this->set_software_apps( $apps );
	}

	/**
	 * Remove one mounted software app.
	 *
	 * @param string $slug Software app slug.
	 * @param bool   $remove_directory Whether to delete the deployment directory too.
	 * @return void
	 */
	public function remove_software_app( $slug, $remove_directory = false ) {
		$slug = trim( sanitize_title( (string) $slug ), '/' );
		$apps = $this->get_software_apps();

		if ( empty( $apps[ $slug ] ) ) {
			return;
		}

		if ( $remove_directory && ! empty( $apps[ $slug ]['relative_dir'] ) ) {
			$this->remove_deployment_directory( $apps[ $slug ]['relative_dir'] );
		}

		unset( $apps[ $slug ] );
		$this->set_software_apps( $apps );
	}

	/**
	 * Build a map of HTML filenames to WordPress permalinks across all deployments.
	 *
	 * Used to rewrite inter-page links (e.g. about.html → /about/).
	 *
	 * @param int $exclude_page_id Page to exclude (the page being built).
	 * @return array Associative array of html_filename => permalink.
	 */
	public function build_html_link_map( $exclude_page_id = 0, $package_key = '' ) {
		$page_map      = $this->get_page_map();
		$package_key   = trim( (string) $package_key );
		$alias_targets = array();

		foreach ( $page_map as $page_id => $entry ) {
			$page_id = absint( $page_id );

			if ( $page_id === $exclude_page_id ) {
				continue;
			}

			if ( empty( $entry['enabled'] ) || empty( $entry['entry_file'] ) ) {
				continue;
			}

			if ( '' !== $package_key ) {
				$entry_package_key = isset( $entry['package_key'] ) ? trim( (string) $entry['package_key'] ) : '';

				if ( '' === $entry_package_key || $entry_package_key !== $package_key ) {
					continue;
				}
			}

			$permalink = get_permalink( $page_id );

			if ( ! $permalink ) {
				continue;
			}

			$entry_file = (string) $entry['entry_file'];
			$aliases    = $this->security->build_html_reference_aliases( $entry_file );

			foreach ( $aliases as $alias ) {
				if ( ! isset( $alias_targets[ $alias ] ) ) {
					$alias_targets[ $alias ] = array();
				}

				$alias_targets[ $alias ][ $permalink ] = true;
			}
		}

		$link_map = array();

		foreach ( $alias_targets as $alias => $targets ) {
			if ( 1 === count( $targets ) ) {
				$link_map[ $alias ] = array_key_first( $targets );
			}
		}

		return $link_map;
	}

	/**
	 * Generate a stable package key from a deployment directory tree.
	 *
	 * Pages copied from the same uploaded site bundle should share a key so
	 * internal link rewriting only maps within that bundle, not across every
	 * deployed site in WordPress.
	 *
	 * @param string $directory Absolute directory path.
	 * @return string
	 */
	public function generate_package_key_from_directory( $directory ) {
		$directory = wp_normalize_path( (string) $directory );

		if ( '' === $directory || ! is_dir( $directory ) ) {
			return '';
		}

		$manifest = array();
		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $directory, RecursiveDirectoryIterator::SKIP_DOTS )
		);

		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() ) {
				continue;
			}

			$relative = ltrim( str_replace( $directory, '', wp_normalize_path( $file->getPathname() ) ), '/' );

			if ( '' === $relative ) {
				continue;
			}

			$manifest[] = $relative . '|' . (string) $file->getSize();
		}

		if ( empty( $manifest ) ) {
			return '';
		}

		sort( $manifest );

		return 'pkg_' . substr( sha1( implode( "\n", $manifest ) ), 0, 20 );
	}

	/**
	 * Get merged settings.
	 *
	 * @return array
	 */
	public function get_settings() {
		$saved = get_option( self::SETTINGS_OPTION, array() );

		return $this->merge_settings( $this->get_default_settings(), is_array( $saved ) ? $saved : array() );
	}

	/**
	 * Update saved settings.
	 *
	 * @param array $settings Settings payload.
	 * @return void
	 */
	public function update_settings( array $settings ) {
		update_option( self::SETTINGS_OPTION, $this->merge_settings( $this->get_default_settings(), $settings ), false );
	}

	/**
	 * Get default settings.
	 *
	 * @return array
	 */
	public function get_default_settings() {
		return array(
			'defaults' => array(
				'render_mode'            => 'isolated',
				'preserve_imported_head' => 1,
				'prefer_plugin_metadata' => 1,
				'raw_html'               => 1,
				'compatibility_wp_head'  => 1,
				'compatibility_wp_footer'=> 1,
			),
			'metadata' => array(
				'description'  => '',
				'robots'       => 'index,follow',
				'twitter_card' => 'summary_large_image',
				'viewport'     => 'width=device-width, initial-scale=1',
				'charset'      => 'UTF-8',
			),
			'performance' => array(
				'enable_html_cache'    => 1,
				'minify_html'          => 1,
				'minify_inline'        => 0,
				'defer_scripts'        => 0,
				'lazy_load_images'     => 1,
				'disable_emoji'        => 1,
				'disable_wp_embed'     => 1,
				'asset_fingerprinting' => 1,
				'hero_image'           => '',
				'preload_styles'       => '',
				'preconnect_urls'      => '',
				'dns_prefetch_urls'    => '',
				'critical_css'         => '',
			),
			'debug' => array(
				'enabled'              => 0,
				'iframe_preview_mode'  => 0,
			),
			'license' => array(
				'api_base_url'      => 'https://asia-southeast1-reputifly-plugin.cloudfunctions.net',
				'request_endpoint'  => 'licenseCheck',
				'check_endpoint'    => 'licenseCheck',
				'check_interval'    => 15 * MINUTE_IN_SECONDS,
				'grace_period'      => DAY_IN_SECONDS,
			),
			'data' => array(
				'remove_on_uninstall' => 0,
			),
			'layout_injections' => array(
				'header_html' => '',
				'body_html'   => '',
				'footer_html' => '',
				'page_ids'    => array(),
			),
		);
	}

	/**
	 * Get default licensing state.
	 *
	 * @return array
	 */
	public function get_default_license_state() {
		return array(
			'install_id'        => '',
			'license_key'       => '',
			'license_key_masked'=> '',
			'license_source'    => 'legacy',
			'key_status'        => '',
			'license_status'    => 'unregistered',
			'last_check_at'     => 0,
			'last_response_at'  => 0,
			'last_success_at'   => 0,
			'next_check_after'  => 0,
			'lease_token'       => '',
			'lease_expires_at'  => 0,
			'status_message'    => '',
			'normalized_domain' => '',
			'validated_once'    => 0,
			'last_error'        => '',
		);
	}

	/**
	 * Get persisted licensing state merged with defaults.
	 *
	 * @return array
	 */
	public function get_license_state() {
		$saved = get_option( self::LICENSE_STATE_OPTION, array() );

		return $this->merge_settings( $this->get_default_license_state(), is_array( $saved ) ? $saved : array() );
	}

	/**
	 * Persist licensing state.
	 *
	 * @param array $state State payload.
	 * @return void
	 */
	public function update_license_state( array $state ) {
		update_option( self::LICENSE_STATE_OPTION, $this->merge_settings( $this->get_default_license_state(), $state ), false );
	}

	/**
	 * Get all Agentic AI keys keyed by id.
	 *
	 * @return array
	 */
	public function get_agent_keys() {
		$keys = get_option( self::AGENT_KEYS_OPTION, array() );

		return is_array( $keys ) ? $keys : array();
	}

	/**
	 * Persist Agentic AI keys.
	 *
	 * @param array $keys Key records keyed by id.
	 * @return void
	 */
	public function update_agent_keys( array $keys ) {
		update_option( self::AGENT_KEYS_OPTION, $keys, false );
	}

	/**
	 * Get one Agentic AI key record.
	 *
	 * @param string $key_id Key identifier.
	 * @return array
	 */
	public function get_agent_key( $key_id ) {
		$key_id = sanitize_key( (string) $key_id );
		$keys   = $this->get_agent_keys();

		return ( '' !== $key_id && ! empty( $keys[ $key_id ] ) && is_array( $keys[ $key_id ] ) ) ? $keys[ $key_id ] : array();
	}

	/**
	 * Persist one Agentic AI key record.
	 *
	 * @param string $key_id Key identifier.
	 * @param array  $record Key record.
	 * @return void
	 */
	public function update_agent_key( $key_id, array $record ) {
		$key_id = sanitize_key( (string) $key_id );

		if ( '' === $key_id ) {
			return;
		}

		$keys           = $this->get_agent_keys();
		$keys[ $key_id ] = $record;
		$this->update_agent_keys( $keys );
	}

	/**
	 * Remove one Agentic AI key record.
	 *
	 * @param string $key_id Key identifier.
	 * @return void
	 */
	public function delete_agent_key( $key_id ) {
		$key_id = sanitize_key( (string) $key_id );
		$keys   = $this->get_agent_keys();

		if ( isset( $keys[ $key_id ] ) ) {
			unset( $keys[ $key_id ] );
			$this->update_agent_keys( $keys );
		}
	}

	/**
	 * Get the primary Agentic AI key id.
	 *
	 * @return string
	 */
	public function get_primary_agent_key_id() {
		return sanitize_key( (string) get_option( self::AGENT_PRIMARY_KEY_OPTION, '' ) );
	}

	/**
	 * Persist the primary Agentic AI key id.
	 *
	 * @param string $key_id Key identifier.
	 * @return void
	 */
	public function set_primary_agent_key_id( $key_id ) {
		update_option( self::AGENT_PRIMARY_KEY_OPTION, sanitize_key( (string) $key_id ), false );
	}

	/**
	 * Get Agentic AI audit events.
	 *
	 * @return array
	 */
	public function get_agent_audit_log() {
		$events = get_option( self::AGENT_AUDIT_OPTION, array() );

		return is_array( $events ) ? array_values( $events ) : array();
	}

	/**
	 * Add one Agentic AI audit event.
	 *
	 * @param array $event Event payload.
	 * @return void
	 */
	public function add_agent_audit_event( array $event ) {
		$events   = $this->get_agent_audit_log();
		$events[] = $event;
		$events   = array_slice( array_values( $events ), -200 );
		update_option( self::AGENT_AUDIT_OPTION, $events, false );
	}

	/**
	 * Get persisted Agentic AI upload sessions.
	 *
	 * @return array
	 */
	public function get_agent_upload_sessions() {
		$sessions = get_option( self::AGENT_UPLOADS_OPTION, array() );

		return is_array( $sessions ) ? $sessions : array();
	}

	/**
	 * Persist Agentic AI upload sessions.
	 *
	 * @param array $sessions Session payload keyed by upload id.
	 * @return void
	 */
	public function update_agent_upload_sessions( array $sessions ) {
		update_option( self::AGENT_UPLOADS_OPTION, $sessions, false );
	}

	/**
	 * Get one Agentic AI upload session.
	 *
	 * @param string $upload_id Upload session id.
	 * @return array
	 */
	public function get_agent_upload_session( $upload_id ) {
		$upload_id = sanitize_key( (string) $upload_id );
		$sessions  = $this->get_agent_upload_sessions();

		return ( '' !== $upload_id && ! empty( $sessions[ $upload_id ] ) && is_array( $sessions[ $upload_id ] ) ) ? $sessions[ $upload_id ] : array();
	}

	/**
	 * Persist one Agentic AI upload session.
	 *
	 * @param string $upload_id Upload session id.
	 * @param array  $session Session payload.
	 * @return void
	 */
	public function update_agent_upload_session( $upload_id, array $session ) {
		$upload_id = sanitize_key( (string) $upload_id );

		if ( '' === $upload_id ) {
			return;
		}

		$sessions             = $this->get_agent_upload_sessions();
		$sessions[ $upload_id ] = $session;
		$this->update_agent_upload_sessions( $sessions );
	}

	/**
	 * Delete one Agentic AI upload session and optionally its working directory.
	 *
	 * @param string $upload_id Upload session id.
	 * @param bool   $remove_directory Whether to delete the session directory too.
	 * @return void
	 */
	public function delete_agent_upload_session( $upload_id, $remove_directory = true ) {
		$upload_id = sanitize_key( (string) $upload_id );
		$sessions  = $this->get_agent_upload_sessions();

		if ( empty( $sessions[ $upload_id ] ) || ! is_array( $sessions[ $upload_id ] ) ) {
			return;
		}

		$session = $sessions[ $upload_id ];
		unset( $sessions[ $upload_id ] );
		$this->update_agent_upload_sessions( $sessions );

		if ( $remove_directory && ! empty( $session['relative_dir'] ) ) {
			$this->remove_deployment_directory( (string) $session['relative_dir'] );
		}
	}

	/**
	 * Remove expired Agentic AI upload sessions and their directories.
	 *
	 * @return void
	 */
	public function cleanup_expired_agent_upload_sessions() {
		$sessions = $this->get_agent_upload_sessions();

		if ( empty( $sessions ) ) {
			return;
		}

		$now = time();
		foreach ( $sessions as $upload_id => $session ) {
			$expires_at = ! empty( $session['expires_at'] ) ? absint( $session['expires_at'] ) : 0;

			if ( $expires_at > 0 && $expires_at <= $now ) {
				$this->delete_agent_upload_session( $upload_id, true );
			}
		}
	}

	/**
	 * Recursively merge settings.
	 *
	 * @param array $defaults Default settings.
	 * @param array $overrides Saved or submitted settings.
	 * @return array
	 */
	protected function merge_settings( array $defaults, array $overrides ) {
		foreach ( $defaults as $key => $value ) {
			if ( is_array( $value ) ) {
				$override_value = isset( $overrides[ $key ] ) && is_array( $overrides[ $key ] ) ? $overrides[ $key ] : array();

				// Preserve list-style arrays (for example selected page ids) instead of recursively
				// merging them back into an empty default array.
				if ( $this->is_list_array( $value ) || ( empty( $value ) && $this->is_list_array( $override_value ) ) ) {
					$defaults[ $key ] = $override_value;
					continue;
				}

				$defaults[ $key ] = $this->merge_settings(
					$value,
					$override_value
				);
				continue;
			}

			if ( array_key_exists( $key, $overrides ) ) {
				$defaults[ $key ] = $overrides[ $key ];
			}
		}

		return $defaults;
	}

	/**
	 * Determine whether an array is list-like (numeric sequential keys).
	 *
	 * @param array $value Candidate array.
	 * @return bool
	 */
	protected function is_list_array( array $value ) {
		if ( array() === $value ) {
			return true;
		}

		return array_keys( $value ) === range( 0, count( $value ) - 1 );
	}

	/**
	 * Resolve the effective config for a page by merging global defaults with page overrides.
	 *
	 * @param int $page_id Page id.
	 * @return array Effective config (same shape as _rspd_config).
	 */
	public function resolve_page_config( $page_id ) {
		$config   = $this->get_page_config( $page_id );
		$settings = $this->get_settings();

		if ( empty( $config ) ) {
			return $config;
		}

		$overrides = isset( $config['page_overrides'] ) && is_array( $config['page_overrides'] )
			? $config['page_overrides']
			: array();

		// Flat render-behavior keys: page overrides win, then stored config, then global defaults.
		$flat_keys = array( 'render_mode', 'preserve_imported_head', 'prefer_plugin_metadata', 'raw_html' );
		foreach ( $flat_keys as $key ) {
			if ( array_key_exists( $key, $overrides ) ) {
				$config[ $key ] = $overrides[ $key ];
			} elseif ( ! array_key_exists( $key, $config ) && isset( $settings['defaults'][ $key ] ) ) {
				$config[ $key ] = $settings['defaults'][ $key ];
			}
		}

		// Compatibility: page overrides win, then stored config, then global defaults.
		$compat_overrides = isset( $overrides['compatibility'] ) && is_array( $overrides['compatibility'] )
			? $overrides['compatibility']
			: array();
		if ( ! isset( $config['compatibility'] ) || ! is_array( $config['compatibility'] ) ) {
			$config['compatibility'] = array();
		}
		$config['compatibility']['wp_head'] = array_key_exists( 'wp_head', $compat_overrides )
			? $compat_overrides['wp_head']
			: ( isset( $config['compatibility']['wp_head'] ) ? $config['compatibility']['wp_head'] : ( ! empty( $settings['defaults']['compatibility_wp_head'] ) ? 1 : 0 ) );
		$config['compatibility']['wp_footer'] = array_key_exists( 'wp_footer', $compat_overrides )
			? $compat_overrides['wp_footer']
			: ( isset( $config['compatibility']['wp_footer'] ) ? $config['compatibility']['wp_footer'] : ( ! empty( $settings['defaults']['compatibility_wp_footer'] ) ? 1 : 0 ) );

		// Performance: start from global, keep stored deployment values, then apply page overrides.
		$global_perf    = isset( $settings['performance'] ) && is_array( $settings['performance'] ) ? $settings['performance'] : array();
		$stored_perf    = isset( $config['performance'] ) && is_array( $config['performance'] ) ? $config['performance'] : array();
		$perf_overrides = isset( $overrides['performance'] ) && is_array( $overrides['performance'] ) ? $overrides['performance'] : array();
		$config['performance'] = array_merge( $global_perf, $stored_perf, $perf_overrides );

		// Metadata: page overrides win, then stored deployment values, then global defaults.
		$global_meta    = isset( $settings['metadata'] ) && is_array( $settings['metadata'] ) ? $settings['metadata'] : array();
		$meta_overrides = isset( $overrides['metadata'] ) && is_array( $overrides['metadata'] ) ? $overrides['metadata'] : array();
		$inheritable    = array( 'robots', 'twitter_card', 'viewport', 'charset' );
		if ( ! isset( $config['metadata'] ) || ! is_array( $config['metadata'] ) ) {
			$config['metadata'] = array();
		}
		foreach ( $inheritable as $key ) {
			if ( array_key_exists( $key, $meta_overrides ) ) {
				$config['metadata'][ $key ] = $meta_overrides[ $key ];
			} elseif ( ! array_key_exists( $key, $config['metadata'] ) && isset( $global_meta[ $key ] ) ) {
				$config['metadata'][ $key ] = $global_meta[ $key ];
			}
		}

		return $config;
	}

	/**
	 * Count the total number of individual overridden settings.
	 *
	 * @param array $overrides The page_overrides array.
	 * @return int
	 */
	public function count_override_keys( array $overrides ) {
		$count = 0;
		foreach ( $overrides as $key => $value ) {
			if ( is_array( $value ) ) {
				$count += count( $value );
			} else {
				++$count;
			}
		}
		return $count;
	}

	/**
	 * Apply a page_overrides array on top of an already-resolved config.
	 *
	 * Used for variant-specific overrides during A/B testing.
	 *
	 * @param array $config    Already-resolved config (from resolve_page_config).
	 * @param array $overrides The page_overrides array to overlay.
	 * @return array Modified config.
	 */
	public function apply_overrides_to_config( array $config, array $overrides ) {
		// Flat render-behavior keys.
		$flat_keys = array( 'render_mode', 'preserve_imported_head', 'prefer_plugin_metadata', 'raw_html' );
		foreach ( $flat_keys as $key ) {
			if ( array_key_exists( $key, $overrides ) ) {
				$config[ $key ] = $overrides[ $key ];
			}
		}

		// Compatibility.
		if ( ! empty( $overrides['compatibility'] ) && is_array( $overrides['compatibility'] ) ) {
			if ( ! isset( $config['compatibility'] ) || ! is_array( $config['compatibility'] ) ) {
				$config['compatibility'] = array();
			}
			foreach ( $overrides['compatibility'] as $k => $v ) {
				$config['compatibility'][ $k ] = $v;
			}
		}

		// Performance.
		if ( ! empty( $overrides['performance'] ) && is_array( $overrides['performance'] ) ) {
			if ( ! isset( $config['performance'] ) || ! is_array( $config['performance'] ) ) {
				$config['performance'] = array();
			}
			$config['performance'] = array_merge( $config['performance'], $overrides['performance'] );
		}

		// Metadata.
		if ( ! empty( $overrides['metadata'] ) && is_array( $overrides['metadata'] ) ) {
			if ( ! isset( $config['metadata'] ) || ! is_array( $config['metadata'] ) ) {
				$config['metadata'] = array();
			}
			$inheritable = array( 'robots', 'twitter_card', 'viewport', 'charset' );
			foreach ( $inheritable as $key ) {
				if ( array_key_exists( $key, $overrides['metadata'] ) ) {
					$config['metadata'][ $key ] = $overrides['metadata'][ $key ];
				}
			}
		}

		return $config;
	}

	/**
	 * Remove a deployment directory.
	 *
	 * @param string $relative_dir Deployment-relative directory.
	 * @return void
	 */
	public function remove_deployment_directory( $relative_dir ) {
		$path = $this->get_deployment_path( $relative_dir );

		if ( ! $path || ! is_dir( $path ) ) {
			return;
		}

		$this->delete_directory_recursive( $path );
	}

	/**
	 * Save a transient-backed admin notice.
	 *
	 * @param string $message Notice message.
	 * @param string $type Notice type.
	 * @return void
	 */
	public function set_admin_notice( $message, $type = 'success' ) {
		if ( ! function_exists( 'get_current_user_id' ) ) {
			return;
		}

		set_transient(
			self::NOTICE_PREFIX . get_current_user_id(),
			array(
				'message' => (string) $message,
				'type'    => (string) $type,
			),
			MINUTE_IN_SECONDS
		);
	}

	/**
	 * Consume the current user's admin notice.
	 *
	 * @return array
	 */
	public function consume_admin_notice() {
		$user_id = get_current_user_id();
		$key     = self::NOTICE_PREFIX . $user_id;
		$notice  = get_transient( $key );

		if ( $notice ) {
			delete_transient( $key );
		}

		return is_array( $notice ) ? $notice : array();
	}

	/**
	 * Get deployment summaries keyed to WordPress pages.
	 *
	 * @return array
	 */
	public function get_deployments() {
		$page_map = $this->get_page_map();

		if ( empty( $page_map ) ) {
			return array();
		}

		$page_ids = array_map( 'absint', array_keys( $page_map ) );
		$pages    = get_pages(
			array(
				'include'     => $page_ids,
				'sort_column' => 'post_title',
				'sort_order'  => 'asc',
			)
		);
		$results  = array();

		foreach ( $pages as $page ) {
			$config = $this->get_page_config( $page->ID );

			if ( empty( $config ) ) {
				continue;
			}

			$results[] = array(
				'page'       => $page,
				'config'     => $config,
				'permalink'  => get_permalink( $page ),
				'status'     => ! empty( $config['enabled'] ) ? 'Active' : 'Disabled',
				'updated_at' => ! empty( $config['updated_at'] ) ? (int) $config['updated_at'] : 0,
			);
		}

		return $results;
	}

	/**
	 * Persist an Elementor source backup for an in-place Labs conversion.
	 *
	 * @param int   $page_id Target page id.
	 * @param array $backup  Backup payload.
	 * @return void
	 */
	public function save_elementor_backup( $page_id, array $backup ) {
		update_post_meta( absint( $page_id ), self::ELEMENTOR_BACKUP_META_KEY, $backup );
	}

	/**
	 * Get the stored Elementor source backup for a page.
	 *
	 * @param int $page_id Target page id.
	 * @return array
	 */
	public function get_elementor_backup( $page_id ) {
		$backup = get_post_meta( absint( $page_id ), self::ELEMENTOR_BACKUP_META_KEY, true );

		return is_array( $backup ) ? $backup : array();
	}

	/**
	 * Remove a stored Elementor source backup.
	 *
	 * @param int $page_id Target page id.
	 * @return void
	 */
	public function delete_elementor_backup( $page_id ) {
		delete_post_meta( absint( $page_id ), self::ELEMENTOR_BACKUP_META_KEY );
	}

	// ─── A/B Testing Helpers ───

	/**
	 * Get A/B test config for a page.
	 *
	 * @param int $page_id Page id.
	 * @return array
	 */
	public function get_ab_test_config( $page_id ) {
		$config = $this->get_page_config( $page_id );
		return isset( $config['ab_test'] ) && is_array( $config['ab_test'] ) ? $config['ab_test'] : array();
	}

	/**
	 * Update A/B test config and clear variant caches.
	 *
	 * @param int   $page_id Page id.
	 * @param array $ab_test A/B test config.
	 * @return void
	 */
	public function update_ab_test_config( $page_id, array $ab_test ) {
		$config             = $this->get_page_config( $page_id );
		$config['ab_test']  = $ab_test;
		update_post_meta( $page_id, self::CONFIG_META_KEY, $config );
		$this->update_page_map_entry( $page_id, $config );

		// Clear base + all variant transients.
		delete_transient( 'rspd_render_' . absint( $page_id ) );
		if ( ! empty( $ab_test['variants'] ) && is_array( $ab_test['variants'] ) ) {
			foreach ( array_keys( $ab_test['variants'] ) as $key ) {
				delete_transient( 'rspd_render_' . absint( $page_id ) . '_' . sanitize_key( $key ) );
			}
		}
	}

	/**
	 * Create a deployment directory for an A/B variant.
	 *
	 * @param int    $page_id    Page id.
	 * @param string $variant_key Variant key (e.g. 'variant_b').
	 * @return array{relative_dir:string,absolute_dir:string,url:string}
	 */
	public function create_variant_deployment_directory( $page_id, $variant_key ) {
		$this->ensure_base_structure();

		$token        = strtolower( wp_generate_password( 8, false, false ) );
		$relative_dir = sprintf(
			'deployments/page-%d/%s-deploy-%s-%s',
			absint( $page_id ),
			sanitize_key( $variant_key ),
			gmdate( 'YmdHis' ),
			$token
		);
		$absolute_dir = $this->security->safe_join( $this->get_base_dir(), $relative_dir );

		if ( ! $absolute_dir ) {
			$absolute_dir = wp_normalize_path( $this->get_base_dir() . '/' . $relative_dir );
		}

		wp_mkdir_p( $absolute_dir );

		return array(
			'relative_dir' => $relative_dir,
			'absolute_dir' => $absolute_dir,
			'url'          => trailingslashit( $this->get_base_url() ) . trim( $relative_dir, '/' ),
		);
	}

	/**
	 * Count local files inside a deployment directory.
	 *
	 * @param string $relative_dir Deployment-relative directory.
	 * @return int
	 */
	public function count_local_files( $relative_dir ) {
		$directory = $this->get_deployment_path( $relative_dir );

		if ( ! is_dir( $directory ) ) {
			return 0;
		}

		$count = 0;

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator(
				$directory,
				RecursiveDirectoryIterator::SKIP_DOTS
			)
		);

		foreach ( $iterator as $file_info ) {
			if ( $file_info->isFile() ) {
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Write upload-area hardening files.
	 *
	 * FIXED in v1.1: Removed 'Options -Indexes' and 'php_flag engine off'
	 * which cause 500 Internal Server Errors on PHP-FPM and restricted
	 * shared hosting. Now uses <IfModule> wrappers for max compatibility.
	 * Also removed web.config which could interfere on IIS/Windows hosts.
	 *
	 * @return void
	 */
	protected function write_security_files() {
		$base = $this->get_base_dir();

		$htaccess = "# Reputifly Static Page Deployer - Block PHP execution.\n"
			. "<FilesMatch \"\\.(php|phar|phtml|cgi|pl|py|sh|exe|bat|cmd)$\">\n"
			. "  <IfModule mod_authz_core.c>\n"
			. "    Require all denied\n"
			. "  </IfModule>\n"
			. "  <IfModule !mod_authz_core.c>\n"
			. "    Order deny,allow\n"
			. "    Deny from all\n"
			. "  </IfModule>\n"
			. "</FilesMatch>\n";

		$files = array(
			$base . '/index.html' => '',
			$base . '/.htaccess'  => $htaccess,
		);

		foreach ( $files as $path => $contents ) {
			if ( ! file_exists( $path ) ) {
				$this->write_file( $path, $contents );
			}
		}
	}

	/**
	 * Recursively delete a directory.
	 *
	 * @param string $directory Absolute directory path.
	 * @return void
	 */
	protected function delete_directory_recursive( $directory ) {
		if ( ! is_dir( $directory ) ) {
			return;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator(
				$directory,
				RecursiveDirectoryIterator::SKIP_DOTS
			),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $iterator as $file_info ) {
			if ( $file_info->isDir() ) {
				rmdir( $file_info->getPathname() );
			} else {
				unlink( $file_info->getPathname() );
			}
		}

		rmdir( $directory );
	}

	/**
	 * Determine whether a file should be treated as safe text for URL replacement.
	 *
	 * @param string $absolute_path Absolute path.
	 * @return bool
	 */
	protected function is_replaceable_text_file( $absolute_path ) {
		$extension = strtolower( pathinfo( $absolute_path, PATHINFO_EXTENSION ) );
		$allowed   = array(
			'html',
			'htm',
			'css',
			'js',
			'mjs',
			'json',
			'svg',
			'txt',
			'xml',
			'map',
			'md',
			'webmanifest',
		);

		return in_array( $extension, $allowed, true );
	}
}
