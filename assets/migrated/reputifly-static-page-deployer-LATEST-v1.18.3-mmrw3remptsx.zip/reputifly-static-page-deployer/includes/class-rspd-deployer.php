<?php
/**
 * Deployment manager.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles importing, rebuilding, and deleting deployments.
 */
class RSPD_Deployer {

	/**
	 * Storage helper.
	 *
	 * @var RSPD_Storage
	 */
	protected $storage;

	/**
	 * Security helper.
	 *
	 * @var RSPD_Security
	 */
	protected $security;

	/**
	 * Metadata helper.
	 *
	 * @var RSPD_Metadata
	 */
	protected $metadata;

	/**
	 * Performance helper.
	 *
	 * @var RSPD_Performance
	 */
	protected $performance;

	/**
	 * Constructor.
	 *
	 * @param RSPD_Storage     $storage     Storage helper.
	 * @param RSPD_Security    $security    Security helper.
	 * @param RSPD_Metadata    $metadata    Metadata helper.
	 * @param RSPD_Performance $performance Performance helper.
	 */
	public function __construct( RSPD_Storage $storage, RSPD_Security $security, RSPD_Metadata $metadata, RSPD_Performance $performance ) {
		$this->storage     = $storage;
		$this->security    = $security;
		$this->metadata    = $metadata;
		$this->performance = $performance;
	}

	/**
	 * Save or rebuild a deployment from admin form data.
	 *
	 * @param array $request Request payload.
	 * @param array $files   Uploaded files.
	 * @return array|WP_Error
	 */
	public function save_deployment( array $request, array $files = array() ) {
		$page_id = isset( $request['page_id'] ) ? absint( $request['page_id'] ) : 0;

		if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
			return new WP_Error( 'rspd_invalid_page', __( 'Please select a valid WordPress page.', 'reputifly-static-page-deployer' ) );
		}

		$page     = get_post( $page_id );
		$settings = $this->storage->get_settings();
		$existing = $this->storage->get_page_config( $page_id );

		$config = array(
			'enabled'                => ! empty( $request['enabled'] ) ? 1 : 0,
			'render_mode'            => $this->normalize_render_mode( isset( $request['render_mode'] ) ? $request['render_mode'] : $settings['defaults']['render_mode'] ),
			'preserve_imported_head' => array_key_exists( 'preserve_imported_head', $request ) ? ( ! empty( $request['preserve_imported_head'] ) ? 1 : 0 ) : 1,
			'prefer_plugin_metadata' => array_key_exists( 'prefer_plugin_metadata', $request ) ? ( ! empty( $request['prefer_plugin_metadata'] ) ? 1 : 0 ) : ( ! empty( $settings['defaults']['prefer_plugin_metadata'] ) ? 1 : 0 ),
			'raw_html'               => array_key_exists( 'raw_html', $request ) ? ( ! empty( $request['raw_html'] ) ? 1 : 0 ) : ( ! empty( $settings['defaults']['raw_html'] ) ? 1 : 0 ),
			'compatibility'          => array(
				'wp_head'   => array_key_exists( 'compatibility_wp_head', $request ) ? ( ! empty( $request['compatibility_wp_head'] ) ? 1 : 0 ) : ( ! empty( $settings['defaults']['compatibility_wp_head'] ) ? 1 : 0 ),
				'wp_footer' => array_key_exists( 'compatibility_wp_footer', $request ) ? ( ! empty( $request['compatibility_wp_footer'] ) ? 1 : 0 ) : ( ! empty( $settings['defaults']['compatibility_wp_footer'] ) ? 1 : 0 ),
			),
			'metadata'               => $this->normalize_metadata_config(
				isset( $request['metadata'] ) && is_array( $request['metadata'] ) ? $request['metadata'] : array(),
				$settings
			),
			'performance'            => $this->performance->normalize_options(
				isset( $request['performance'] ) && is_array( $request['performance'] ) ? $request['performance'] : array(),
				$settings
			),
		);

		$import_method = sanitize_key( isset( $request['import_method'] ) ? $request['import_method'] : ( ! empty( $existing['source_type'] ) ? $existing['source_type'] : 'paste' ) );
		$import_result = null;
		$new_source    = false;
		$preserve_existing_source = ! empty( $request['preserve_existing_source'] ) && ! empty( $existing );

		if ( 'upload' === $import_method && ! empty( $files['deployment_package']['name'] ) && UPLOAD_ERR_NO_FILE !== (int) $files['deployment_package']['error'] ) {
			$import_result = $this->import_uploaded_package( $files['deployment_package'], $page, $config, $settings, isset( $request['entry_file'] ) ? $request['entry_file'] : '' );
			$new_source    = true;
		} elseif ( 'paste' === $import_method && isset( $request['combined_code'] ) && '' !== trim( wp_unslash( $request['combined_code'] ) ) ) {
			$combined_html = wp_unslash( $request['combined_code'] );

			if ( $preserve_existing_source && $this->can_update_existing_entry_source( $existing ) ) {
				$import_result = $this->update_existing_entry_source( $existing, $combined_html, $page, $config, $settings );
			} else {
				$import_result = $this->import_pasted_source( $combined_html, $page, $config, $settings );
				$new_source    = true;
			}
		} elseif ( ! empty( $existing ) ) {
			$import_result = $this->reuse_existing_source( $existing, $page, $config, $settings, isset( $request['entry_file'] ) ? $request['entry_file'] : '' );
		} else {
			return new WP_Error( 'rspd_missing_source', __( 'Add pasted code or upload a ZIP/HTML package before saving.', 'reputifly-static-page-deployer' ) );
		}

		if ( is_wp_error( $import_result ) ) {
			return $import_result;
		}

		if ( ! empty( $import_result['effective_config'] ) && is_array( $import_result['effective_config'] ) ) {
			$config = array_merge( $config, $import_result['effective_config'] );
		}

		$final_config = array_merge(
			$existing,
			$config,
			array(
				'deployment_id'       => $import_result['deployment_id'],
				'deployment_rel_dir'  => $import_result['deployment_rel_dir'],
				'entry_file'          => $import_result['entry_file'],
				'package_key'         => ! empty( $import_result['package_key'] ) ? $import_result['package_key'] : ( ! empty( $existing['package_key'] ) ? $existing['package_key'] : '' ),
				'source_type'         => $import_result['source_type'],
				'html_files'          => $import_result['html_files'],
				'updated_at'          => time(),
				'cache_version'       => wp_generate_password( 12, false, false ),
				'diagnostics'         => $import_result['bundle']['diagnostics'],
				'last_warnings'       => $import_result['warnings'],
			)
		);

		// Preserve per-page overrides through re-deployments.
		if ( ! empty( $existing['page_overrides'] ) && is_array( $existing['page_overrides'] ) ) {
			$final_config['page_overrides'] = $existing['page_overrides'];
		}

		$this->storage->save_render_bundle( $import_result['deployment_rel_dir'], $import_result['bundle'] );
		$this->storage->update_page_config( $page_id, $final_config );

		if ( $new_source && ! empty( $existing['deployment_rel_dir'] ) && $existing['deployment_rel_dir'] !== $final_config['deployment_rel_dir'] ) {
			$this->storage->remove_deployment_directory( $existing['deployment_rel_dir'] );
		}

		return array(
			'page_id'  => $page_id,
			'config'   => $final_config,
			'warnings' => $import_result['warnings'],
		);
	}

	/**
	 * Delete a deployment from the selected page.
	 *
	 * @param int $page_id Page id.
	 * @return bool
	 */
	public function delete_deployment( $page_id ) {
		$config = $this->storage->get_page_config( $page_id );

		if ( ! empty( $config['deployment_rel_dir'] ) ) {
			$this->storage->remove_deployment_directory( $config['deployment_rel_dir'] );
		}

		$this->storage->delete_page_config( $page_id );

		return true;
	}

	/**
	 * Delete a mounted software app deployment.
	 *
	 * @param string $slug Software app slug.
	 * @return bool
	 */
	public function delete_software_app( $slug ) {
		$this->storage->remove_software_app( $slug, true );

		return true;
	}

	/**
	 * Rebuild all deployments after a settings change.
	 *
	 * @return array
	 */
	public function rebuild_all_deployments() {
		$results = array();

		foreach ( $this->storage->get_deployments() as $deployment ) {
			$page_id = isset( $deployment['page']->ID ) ? (int) $deployment['page']->ID : 0;

			if ( ! $page_id ) {
				continue;
			}

			$results[ $page_id ] = $this->rebuild_page_deployment( $page_id );
		}

		return $results;
	}

	/**
	 * Rebuild a single page deployment from stored source files.
	 *
	 * @param int $page_id Page id.
	 * @return array|WP_Error
	 */
	public function rebuild_page_deployment( $page_id ) {
		$raw_config = $this->storage->get_page_config( $page_id );

		if ( empty( $raw_config ) ) {
			return new WP_Error( 'rspd_missing_config', __( 'No deployment exists for that page.', 'reputifly-static-page-deployer' ) );
		}

		// Resolve effective config by merging global settings with page overrides.
		$config = $this->storage->resolve_page_config( $page_id );

		$page   = get_post( $page_id );
		$result = $this->reuse_existing_source( $raw_config, $page, $config, $this->storage->get_settings(), isset( $raw_config['entry_file'] ) ? $raw_config['entry_file'] : '' );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$effective_config = ! empty( $result['effective_config'] ) && is_array( $result['effective_config'] ) ? array_merge( $config, $result['effective_config'] ) : $config;

		// Update raw config with new bundle data but preserve page_overrides.
		$raw_config['diagnostics']           = $result['bundle']['diagnostics'];
		$raw_config['last_warnings']         = $result['warnings'];
		$raw_config['updated_at']            = time();
		$raw_config['cache_version']         = wp_generate_password( 12, false, false );
		$raw_config['package_key']           = ! empty( $result['package_key'] ) ? $result['package_key'] : ( ! empty( $raw_config['package_key'] ) ? $raw_config['package_key'] : '' );

		// Sync resolved values to flat config keys (renderer reads directly).
		$raw_config['render_mode']            = $effective_config['render_mode'];
		$raw_config['preserve_imported_head'] = $effective_config['preserve_imported_head'];
		$raw_config['prefer_plugin_metadata'] = $effective_config['prefer_plugin_metadata'];
		$raw_config['raw_html']               = ! empty( $effective_config['raw_html'] ) ? 1 : 0;
		$raw_config['compatibility']          = $effective_config['compatibility'];
		$raw_config['performance']            = $effective_config['performance'];
		$raw_config['metadata']               = $effective_config['metadata'];

		$this->storage->save_render_bundle( $result['deployment_rel_dir'], $result['bundle'] );
		$this->storage->update_page_config( $page_id, $raw_config );

		return $result;
	}

	/**
	 * Deploy a prepared local static package directory onto an existing WordPress page.
	 *
	 * This is used by Labs exports so they can hand off into the same proven static
	 * package pipeline that ZIP/folder uploads already use.
	 *
	 * @param string $source_dir Absolute source directory.
	 * @param int    $page_id Target page id.
	 * @param array  $options Deployment options.
	 * @return array|WP_Error
	 */
	public function deploy_local_static_package_to_page( $source_dir, $page_id, array $options = array() ) {
		$source_dir = wp_normalize_path( (string) $source_dir );
		$page_id    = absint( $page_id );
		$page       = $page_id ? get_post( $page_id ) : null;

		if ( ! $page instanceof WP_Post || 'page' !== $page->post_type ) {
			return new WP_Error( 'rspd_invalid_target_page', __( 'The selected target page is invalid.', 'reputifly-static-page-deployer' ) );
		}

		if ( ! is_dir( $source_dir ) ) {
			return new WP_Error( 'rspd_invalid_local_package', __( 'The prepared static package directory could not be found.', 'reputifly-static-page-deployer' ) );
		}

		$settings          = $this->storage->get_settings();
		$existing          = $this->storage->get_page_config( $page_id );
		$requested_file    = ! empty( $options['entry_file'] ) ? sanitize_text_field( (string) $options['entry_file'] ) : '';
		$source_type       = ! empty( $options['source_type'] ) ? sanitize_key( (string) $options['source_type'] ) : 'upload';
		$deployment        = $this->storage->create_deployment_directory( $page_id );
		$warnings          = ! empty( $options['warnings'] ) && is_array( $options['warnings'] ) ? $options['warnings'] : array();
		$elementor_export  = ! empty( $options['elementor_export'] ) && is_array( $options['elementor_export'] ) ? $options['elementor_export'] : array();

		if ( ! $this->copy_directory_recursive( $source_dir, $deployment['absolute_dir'] ) ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return new WP_Error( 'rspd_local_package_copy_failed', __( 'The prepared static package could not be copied into deployment storage.', 'reputifly-static-page-deployer' ) );
		}

		$html_files = $this->scan_html_files( $deployment['absolute_dir'] );
		$entry_file = $this->detect_entry_file( $html_files, $requested_file );

		if ( empty( $html_files ) || ! $entry_file ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return new WP_Error( 'rspd_local_package_missing_entry', __( 'The prepared package did not contain a readable entry HTML file.', 'reputifly-static-page-deployer' ) );
		}

		$html = $this->storage->read_file( trailingslashit( $deployment['absolute_dir'] ) . $entry_file );

		if ( '' === $html ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return new WP_Error( 'rspd_local_package_entry_unreadable', __( 'The prepared package entry file could not be read.', 'reputifly-static-page-deployer' ) );
		}

		$config = array(
			'enabled'                => 1,
			'render_mode'            => $this->normalize_render_mode( $settings['defaults']['render_mode'] ),
			'preserve_imported_head' => 1,
			'prefer_plugin_metadata' => 0,
			'raw_html'               => 1,
			'compatibility'          => array(
				'wp_head'   => 0,
				'wp_footer' => 0,
			),
			'metadata'               => $this->normalize_metadata_config( array(), $settings ),
			'performance'            => $this->performance->normalize_options( array(), $settings ),
		);

		$config     = $this->normalize_uploaded_package_render_config( $config );
		$package_key = $this->storage->generate_package_key_from_directory( $deployment['absolute_dir'] );
		$config['package_key'] = $package_key;

		$bundle = $this->build_bundle(
			$html,
			$page,
			$config,
			$settings,
			$deployment,
			$entry_file,
			$source_type,
			$html_files
		);

		if ( is_wp_error( $bundle ) ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return $bundle;
		}

		$final_config = array_merge(
			$existing,
			$config,
			array(
				'deployment_id'       => basename( $deployment['relative_dir'] ),
				'deployment_rel_dir'  => $deployment['relative_dir'],
				'entry_file'          => $entry_file,
				'package_key'         => $package_key,
				'source_type'         => $source_type,
				'html_files'          => $html_files,
				'updated_at'          => time(),
				'cache_version'       => wp_generate_password( 12, false, false ),
				'diagnostics'         => $bundle['bundle']['diagnostics'],
				'last_warnings'       => array_values( array_unique( array_merge( $warnings, $bundle['warnings'] ) ) ),
			)
		);

		if ( ! empty( $elementor_export ) ) {
			$final_config['elementor_export'] = $elementor_export;
		}

		if ( ! empty( $existing['page_overrides'] ) && is_array( $existing['page_overrides'] ) ) {
			$final_config['page_overrides'] = $existing['page_overrides'];
		}

		$this->storage->save_render_bundle( $deployment['relative_dir'], $bundle['bundle'] );
		$this->storage->update_page_config( $page_id, $final_config );

		if ( ! empty( $existing['deployment_rel_dir'] ) && $existing['deployment_rel_dir'] !== $final_config['deployment_rel_dir'] ) {
			$this->storage->remove_deployment_directory( $existing['deployment_rel_dir'] );
		}

		return array(
			'page_id'  => $page_id,
			'config'   => $final_config,
			'warnings' => $final_config['last_warnings'],
		);
	}

	/**
	 * Export one live Elementor page into an Archimedes deployment target.
	 *
	 * @param WP_Post $source_page Elementor source page.
	 * @param int     $target_page_id Target page id.
	 * @param array   $options Export options.
	 * @return array|WP_Error
	 */
	public function export_elementor_page_to_page( WP_Post $source_page, $target_page_id, array $options = array() ) {
		$source_url = get_permalink( $source_page );

		if ( empty( $source_url ) ) {
			return new WP_Error( 'rspd_elementor_source_url_missing', __( 'The Elementor source page does not have a public URL to capture.', 'reputifly-static-page-deployer' ) );
		}

		$temp = $this->storage->create_backup_directory( 'elementor-export-temp' );

		try {
			$capture = $this->capture_elementor_frontend_package(
				$source_page,
				$source_url,
				$temp['absolute_dir'],
				! empty( $options['link_map'] ) && is_array( $options['link_map'] ) ? $options['link_map'] : array()
			);

			if ( is_wp_error( $capture ) ) {
				return $capture;
			}

			$deploy_result = $this->deploy_local_static_package_to_page(
				$temp['absolute_dir'],
				$target_page_id,
				array(
					'entry_file'       => 'index.html',
					'source_type'      => 'elementor_export',
					'warnings'         => ! empty( $capture['warnings'] ) ? $capture['warnings'] : array(),
					'elementor_export' => array(
						'source_page_id'   => (int) $source_page->ID,
						'source_permalink' => $source_url,
						'converted_at'     => time(),
						'target_mode'      => ! empty( $options['target_mode'] ) ? sanitize_key( (string) $options['target_mode'] ) : 'create_new',
					),
				)
			);

			if ( is_wp_error( $deploy_result ) ) {
				return $deploy_result;
			}

			$deploy_result['captured_asset_count'] = ! empty( $capture['asset_count'] ) ? (int) $capture['asset_count'] : 0;
			return $deploy_result;
		} finally {
			$this->remove_directory_recursive( $temp['absolute_dir'] );
		}
	}

	/**
	 * Deploy a static software app under a dedicated parent slug.
	 *
	 * This keeps the uploaded project intact and mounts it under a stable
	 * WordPress path such as `/renobros-employee/`.
	 *
	 * @param string $source_dir Absolute scanned package directory.
	 * @param string $slug Parent slug.
	 * @param string $requested_entry_file Optional entry file.
	 * @param string $label Optional display label.
	 * @return array|WP_Error
	 */
	public function deploy_software_app_from_directory( $source_dir, $slug, $requested_entry_file = '', $label = '' ) {
		$source_dir = wp_normalize_path( (string) $source_dir );
		$slug       = trim( sanitize_title( (string) $slug ), '/' );
		$label      = sanitize_text_field( (string) $label );

		if ( '' === $slug ) {
			return new WP_Error( 'rspd_invalid_software_slug', __( 'Add a valid parent folder slug for the software app.', 'reputifly-static-page-deployer' ) );
		}

		if ( ! is_dir( $source_dir ) ) {
			return new WP_Error( 'rspd_invalid_software_source', __( 'The uploaded software package could not be found.', 'reputifly-static-page-deployer' ) );
		}

		$html_files = $this->scan_html_files( $source_dir );

		if ( empty( $html_files ) ) {
			return new WP_Error( 'rspd_software_no_html', __( 'The uploaded software package did not contain any HTML files.', 'reputifly-static-page-deployer' ) );
		}

		$entry_file = $this->detect_entry_file( $html_files, $requested_entry_file );

		if ( ! $entry_file ) {
			return new WP_Error( 'rspd_software_missing_entry', __( 'The selected software entry file could not be found.', 'reputifly-static-page-deployer' ) );
		}

		$existing_app     = $this->storage->get_software_app( $slug );
		$previous_release = ! empty( $existing_app['relative_dir'] ) ? (string) $existing_app['relative_dir'] : '';
		$deployment       = $this->storage->create_software_deployment_directory( $slug );

		if ( ! $this->copy_directory_recursive( $source_dir, $deployment['absolute_dir'] ) ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return new WP_Error( 'rspd_software_copy_failed', __( 'The software package could not be copied into deployment storage.', 'reputifly-static-page-deployer' ) );
		}

		$html_files = $this->scan_html_files( $deployment['absolute_dir'] );
		$entry_file = $this->detect_entry_file( $html_files, $entry_file );

		if ( ! $entry_file ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return new WP_Error( 'rspd_software_entry_missing', __( 'The software entry file could not be resolved after upload.', 'reputifly-static-page-deployer' ) );
		}

		$package_key = $this->storage->generate_package_key_from_directory( $deployment['absolute_dir'] );
		$link_map    = $this->build_software_html_link_map( $slug, $html_files, $entry_file );
		$warnings    = array();
		$root_context = array(
			'page_permalink'       => $this->get_software_file_public_url( $slug, $entry_file, $entry_file ),
			'deployment_url'       => untrailingslashit( $this->storage->get_software_mount_url( $slug ) ),
			'deployment_path'      => $deployment['absolute_dir'],
			'entry_file'           => $entry_file,
			'entry_dir'            => '.' === dirname( $entry_file ) ? '' : dirname( $entry_file ),
			'deployment_base_href' => $this->get_software_base_href( $slug, $entry_file ),
			'fingerprint_assets'   => false,
			'default_charset'      => get_bloginfo( 'charset' ),
			'default_viewport'     => 'width=device-width, initial-scale=1',
			'html_link_map'        => $link_map,
			'package_key'          => $package_key,
		);

		$this->rewrite_deployment_javascript_routes( $deployment['absolute_dir'], $root_context, $warnings );

		$preprocess_result = $this->preprocess_software_html_files( $deployment['absolute_dir'], $slug, $entry_file, $html_files, $link_map, $warnings );

		if ( is_wp_error( $preprocess_result ) ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return $preprocess_result;
		}

		$record = array(
			'enabled'        => 1,
			'slug'           => $slug,
			'label'          => '' !== $label ? $label : ucwords( str_replace( '-', ' ', $slug ) ),
			'deployment_id'  => basename( $deployment['relative_dir'] ),
			'relative_dir'   => $deployment['relative_dir'],
			'entry_file'     => $entry_file,
			'html_files'     => $html_files,
			'package_key'    => $package_key,
			'source_type'    => 'software_app',
			'updated_at'     => time(),
			'mount_url'      => $this->storage->get_software_mount_url( $slug ),
		);

		$this->storage->update_software_app( $slug, $record );

		if ( '' !== $previous_release && $previous_release !== $deployment['relative_dir'] ) {
			$this->storage->remove_deployment_directory( $previous_release );
		}

		return array(
			'slug'       => $slug,
			'label'      => $record['label'],
			'url'        => $record['mount_url'],
			'entry_file' => $entry_file,
			'html_files' => $html_files,
			'routes'     => $this->storage->get_software_app_routes( $slug, $entry_file, $html_files ),
			'warnings'   => array_values( array_unique( $warnings ) ),
			'replaced'   => ! empty( $existing_app ),
		);
	}

	/**
	 * Import pasted HTML/CSS/JS.
	 *
	 * @param string  $html     Combined pasted source.
	 * @param WP_Post $page     Target page.
	 * @param array   $config   Deployment config.
	 * @param array   $settings Plugin settings.
	 * @return array|WP_Error
	 */
	protected function import_pasted_source( $html, WP_Post $page, array $config, array $settings ) {
		$deployment = $this->storage->create_deployment_directory( $page->ID );
		$entry_file = 'source.html';

		if ( ! $this->storage->write_file( $deployment['absolute_dir'] . '/' . $entry_file, $html ) ) {
			return new WP_Error( 'rspd_write_failed', __( 'The plugin could not write the pasted source into the deployment directory.', 'reputifly-static-page-deployer' ) );
		}

		$bundle = $this->build_bundle(
			$html,
			$page,
			$config,
			$settings,
			$deployment,
			$entry_file,
			'paste',
			array( $entry_file )
		);

		if ( is_wp_error( $bundle ) ) {
			return $bundle;
		}

		return array(
			'deployment_id'      => basename( $deployment['relative_dir'] ),
			'deployment_rel_dir' => $deployment['relative_dir'],
			'entry_file'         => $entry_file,
			'package_key'        => '',
			'source_type'        => 'paste',
			'html_files'         => array( $entry_file ),
			'bundle'             => $bundle['bundle'],
			'warnings'           => $bundle['warnings'],
		);
	}

	/**
	 * Determine whether an existing deployment can safely be edited in place.
	 *
	 * @param array $existing Existing deployment config.
	 * @return bool
	 */
	protected function can_update_existing_entry_source( array $existing ) {
		$source_type = isset( $existing['source_type'] ) ? sanitize_key( (string) $existing['source_type'] ) : 'paste';

		if ( empty( $existing['deployment_rel_dir'] ) || empty( $existing['entry_file'] ) ) {
			return false;
		}

		return $this->is_static_package_source_type( $source_type ) || 'paste' === $source_type;
	}

	/**
	 * Update the existing deployment entry file in place and rebuild from the same package.
	 *
	 * @param array   $existing Existing deployment config.
	 * @param string  $html     Updated HTML source.
	 * @param WP_Post $page     Target page.
	 * @param array   $config   Deployment config.
	 * @param array   $settings Plugin settings.
	 * @return array|WP_Error
	 */
	protected function update_existing_entry_source( array $existing, $html, WP_Post $page, array $config, array $settings ) {
		if ( empty( $existing['deployment_rel_dir'] ) || empty( $existing['entry_file'] ) ) {
			return new WP_Error( 'rspd_missing_deployment', __( 'The existing deployment folder could not be found.', 'reputifly-static-page-deployer' ) );
		}

		$relative_dir = $existing['deployment_rel_dir'];
		$absolute_dir = $this->storage->get_deployment_path( $relative_dir );
		$entry_file   = ltrim( (string) $existing['entry_file'], '/\\' );
		$entry_path   = trailingslashit( $absolute_dir ) . $entry_file;
		$source_type  = isset( $existing['source_type'] ) ? sanitize_key( (string) $existing['source_type'] ) : 'paste';
		$package_key  = ! empty( $existing['package_key'] ) ? (string) $existing['package_key'] : '';
		$original_html = $this->storage->read_file( $entry_path );

		if ( ! $this->storage->write_file( $entry_path, $html ) ) {
			return new WP_Error( 'rspd_write_failed', __( 'The plugin could not save the updated source into the existing deployment.', 'reputifly-static-page-deployer' ) );
		}

		$html_files = ! empty( $existing['html_files'] ) && is_array( $existing['html_files'] ) ? $existing['html_files'] : $this->scan_html_files( $absolute_dir );
		$html_files = array_values( array_unique( array_merge( $html_files, array( $entry_file ) ) ) );

		if ( $this->is_static_package_source_type( $source_type ) ) {
			$config = $this->normalize_uploaded_package_render_config( $config );

			if ( '' === $package_key ) {
				$package_key = $this->storage->generate_package_key_from_directory( $absolute_dir );
			}
		}

		$config['package_key'] = $package_key;

		$deployment = array(
			'relative_dir' => $relative_dir,
			'absolute_dir' => $absolute_dir,
			'url'          => $this->storage->get_deployment_url( $relative_dir ),
		);

		$bundle = $this->build_bundle(
			$html,
			$page,
			$config,
			$settings,
			$deployment,
			$entry_file,
			$source_type,
			$html_files
		);

		if ( is_wp_error( $bundle ) ) {
			$this->storage->write_file( $entry_path, $original_html );
			return $bundle;
		}

		return array(
			'deployment_id'      => ! empty( $existing['deployment_id'] ) ? $existing['deployment_id'] : basename( $relative_dir ),
			'deployment_rel_dir' => $relative_dir,
			'entry_file'         => $entry_file,
			'package_key'        => $package_key,
			'source_type'        => $source_type,
			'html_files'         => $html_files,
			'effective_config'   => array(
				'render_mode'            => $config['render_mode'],
				'preserve_imported_head' => $config['preserve_imported_head'],
				'prefer_plugin_metadata' => $config['prefer_plugin_metadata'],
				'raw_html'               => ! empty( $config['raw_html'] ) ? 1 : 0,
				'compatibility'          => $config['compatibility'],
				'performance'            => $config['performance'],
				'metadata'               => $config['metadata'],
			),
			'bundle'             => $bundle['bundle'],
			'warnings'           => $bundle['warnings'],
		);
	}

	/**
	 * Import an uploaded package.
	 *
	 * @param array   $file           Uploaded file array.
	 * @param WP_Post $page           Target page.
	 * @param array   $config         Deployment config.
	 * @param array   $settings       Plugin settings.
	 * @param string  $requested_file Requested entry file.
	 * @return array|WP_Error
	 */
	protected function import_uploaded_package( array $file, WP_Post $page, array $config, array $settings, $requested_file ) {
		if ( empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error( 'rspd_invalid_upload', __( 'The uploaded package could not be read.', 'reputifly-static-page-deployer' ) );
		}

		if ( ! empty( $file['error'] ) ) {
			return new WP_Error( 'rspd_upload_error', $this->get_upload_error_message( (int) $file['error'] ) );
		}

		$deployment = $this->storage->create_deployment_directory( $page->ID );
		$extension  = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		$html_files = array();
		$warnings   = array();
		$package_key = '';

		if ( 'zip' === $extension ) {
			$result = $this->extract_zip_package( $file['tmp_name'], $deployment['absolute_dir'] );

			if ( is_wp_error( $result ) ) {
				$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
				return $result;
			}

			$html_files = $result['html_files'];
			$warnings   = $result['warnings'];
		} elseif ( in_array( $extension, array( 'html', 'htm' ), true ) ) {
			$entry_file = sanitize_file_name( $file['name'] );

			if ( ! move_uploaded_file( $file['tmp_name'], $deployment['absolute_dir'] . '/' . $entry_file ) ) {
				$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
				return new WP_Error( 'rspd_move_failed', __( 'The uploaded HTML file could not be stored in the deployment directory.', 'reputifly-static-page-deployer' ) );
			}

			$html_files = array( $entry_file );
		} else {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return new WP_Error( 'rspd_invalid_package', __( 'Upload either a ZIP package or a standalone HTML file.', 'reputifly-static-page-deployer' ) );
		}

		if ( empty( $html_files ) ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return new WP_Error( 'rspd_no_html', __( 'The uploaded package did not contain any HTML files.', 'reputifly-static-page-deployer' ) );
		}

		$package_key           = $this->storage->generate_package_key_from_directory( $deployment['absolute_dir'] );

		$entry_file = $this->detect_entry_file( $html_files, $requested_file );

		if ( ! $entry_file ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return new WP_Error( 'rspd_missing_entry', __( 'The selected entry file could not be found in the uploaded package.', 'reputifly-static-page-deployer' ) );
		}

		$html = $this->storage->read_file( $deployment['absolute_dir'] . '/' . $entry_file );

		if ( '' === $html ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return new WP_Error( 'rspd_entry_unreadable', __( 'The chosen entry HTML file could not be read.', 'reputifly-static-page-deployer' ) );
		}

		$config = $this->normalize_uploaded_package_render_config( $config );
		$config['package_key'] = $package_key;

		$bundle = $this->build_bundle(
			$html,
			$page,
			$config,
			$settings,
			$deployment,
			$entry_file,
			'upload',
			$html_files
		);

		if ( is_wp_error( $bundle ) ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return $bundle;
		}

		return array(
			'deployment_id'      => basename( $deployment['relative_dir'] ),
			'deployment_rel_dir' => $deployment['relative_dir'],
			'entry_file'         => $entry_file,
			'package_key'        => $package_key,
			'source_type'        => 'upload',
			'html_files'         => $html_files,
			'effective_config'   => array(
				'render_mode'            => $config['render_mode'],
				'preserve_imported_head' => $config['preserve_imported_head'],
				'prefer_plugin_metadata' => $config['prefer_plugin_metadata'],
				'raw_html'               => ! empty( $config['raw_html'] ) ? 1 : 0,
				'compatibility'          => $config['compatibility'],
				'performance'            => $config['performance'],
				'metadata'               => $config['metadata'],
			),
			'bundle'             => $bundle['bundle'],
			'warnings'           => array_merge( $warnings, $bundle['warnings'] ),
		);
	}

	/**
	 * Rebuild from already stored deployment files.
	 *
	 * @param array   $existing       Existing deployment config.
	 * @param WP_Post $page           Target page.
	 * @param array   $config         Updated deployment config.
	 * @param array   $settings       Plugin settings.
	 * @param string  $requested_file Optional entry file override.
	 * @return array|WP_Error
	 */
	protected function reuse_existing_source( array $existing, WP_Post $page, array $config, array $settings, $requested_file ) {
		if ( empty( $existing['deployment_rel_dir'] ) ) {
			return new WP_Error( 'rspd_missing_deployment', __( 'The existing deployment folder could not be found.', 'reputifly-static-page-deployer' ) );
		}

		$relative_dir = $existing['deployment_rel_dir'];
		$absolute_dir = $this->storage->get_deployment_path( $relative_dir );
		$package_key  = ! empty( $existing['package_key'] ) ? (string) $existing['package_key'] : '';
		$deployment   = array(
			'relative_dir' => $relative_dir,
			'absolute_dir' => $absolute_dir,
			'url'          => $this->storage->get_deployment_url( $relative_dir ),
		);
		$html_files    = ! empty( $existing['html_files'] ) && is_array( $existing['html_files'] ) ? $existing['html_files'] : $this->scan_html_files( $absolute_dir );
		$entry_file    = $this->detect_entry_file( $html_files, $requested_file ? $requested_file : ( isset( $existing['entry_file'] ) ? $existing['entry_file'] : '' ) );

		if ( ! $entry_file ) {
			return new WP_Error( 'rspd_missing_entry', __( 'The stored deployment no longer has a readable entry HTML file.', 'reputifly-static-page-deployer' ) );
		}

		$html = $this->storage->read_file( $absolute_dir . '/' . $entry_file );

		if ( '' === $html ) {
			return new WP_Error( 'rspd_entry_unreadable', __( 'The stored entry HTML file could not be read.', 'reputifly-static-page-deployer' ) );
		}

		if ( $this->is_static_package_source_type( isset( $existing['source_type'] ) ? $existing['source_type'] : 'upload' ) ) {
			$config = $this->normalize_uploaded_package_render_config( $config );

			if ( '' === $package_key ) {
				$package_key = $this->storage->generate_package_key_from_directory( $absolute_dir );
			}
		}

		$config['package_key'] = $package_key;

		$bundle = $this->build_bundle(
			$html,
			$page,
			$config,
			$settings,
			$deployment,
			$entry_file,
			isset( $existing['source_type'] ) ? $existing['source_type'] : 'upload',
			$html_files
		);

		if ( is_wp_error( $bundle ) ) {
			return $bundle;
		}

		return array(
			'deployment_id'      => ! empty( $existing['deployment_id'] ) ? $existing['deployment_id'] : basename( $relative_dir ),
			'deployment_rel_dir' => $relative_dir,
			'entry_file'         => $entry_file,
			'package_key'        => $package_key,
			'source_type'        => isset( $existing['source_type'] ) ? $existing['source_type'] : 'upload',
			'html_files'         => $html_files,
			'effective_config'   => array(
				'render_mode'            => $config['render_mode'],
				'preserve_imported_head' => $config['preserve_imported_head'],
				'prefer_plugin_metadata' => $config['prefer_plugin_metadata'],
				'raw_html'               => ! empty( $config['raw_html'] ) ? 1 : 0,
				'compatibility'          => $config['compatibility'],
				'performance'            => $config['performance'],
				'metadata'               => $config['metadata'],
			),
			'bundle'             => $bundle['bundle'],
			'warnings'           => $bundle['warnings'],
		);
	}

	/**
	 * Build the saved render bundle.
	 *
	 * @param string  $html         Entry HTML.
	 * @param WP_Post $page         Target page.
	 * @param array   $config       Deployment config.
	 * @param array   $settings     Plugin settings.
	 * @param array   $deployment   Deployment paths and URLs.
	 * @param string  $entry_file   Entry file.
	 * @param string  $source_type  Source type.
	 * @param array   $html_files   Known html files.
	 * @return array|WP_Error
	 */
	protected function build_bundle( $html, WP_Post $page, array $config, array $settings, array $deployment, $entry_file, $source_type, array $html_files ) {
		$deployment_url = $this->is_static_package_source_type( $source_type ) ? $this->storage->get_public_deployment_url( $page->ID ) : $deployment['url'];
		$deployment_base_href = $this->get_uploaded_package_base_href( $source_type, $deployment_url, $entry_file );
		$package_key = ! empty( $config['package_key'] ) ? (string) $config['package_key'] : '';
		$context     = array(
			'page_permalink'       => get_permalink( $page ),
			'deployment_url'       => $deployment_url,
			'deployment_path'      => $deployment['absolute_dir'],
			'entry_file'           => $entry_file,
			'entry_dir'            => '.' === dirname( $entry_file ) ? '' : dirname( $entry_file ),
			'deployment_base_href' => $deployment_base_href,
			'fingerprint_assets'   => ! empty( $config['performance']['asset_fingerprinting'] ),
			'default_charset'      => ! empty( $settings['metadata']['charset'] ) ? $settings['metadata']['charset'] : get_bloginfo( 'charset' ),
			'default_viewport'     => ! empty( $config['metadata']['viewport'] ) ? $config['metadata']['viewport'] : ( ! empty( $settings['metadata']['viewport'] ) ? $settings['metadata']['viewport'] : 'width=device-width, initial-scale=1' ),
			'html_link_map'        => $this->storage->build_html_link_map( $page->ID, $package_key ),
			'managed_page_id'      => $page->ID,
			'package_key'          => $package_key,
		);
		$preprocess_warnings = array();

		$this->rewrite_deployment_javascript_routes( $deployment['absolute_dir'], $context, $preprocess_warnings );

		if ( $this->is_static_package_source_type( $source_type ) ) {
			$uploaded_bundle = $this->build_uploaded_package_bundle(
				$html,
				$page,
				$config,
				$settings,
				$deployment,
				$entry_file,
				$html_files,
				$context
			);

			if ( is_wp_error( $uploaded_bundle ) ) {
				return $uploaded_bundle;
			}

			$uploaded_bundle['warnings'] = array_values(
				array_unique(
					array_merge(
						$preprocess_warnings,
						isset( $uploaded_bundle['warnings'] ) && is_array( $uploaded_bundle['warnings'] ) ? $uploaded_bundle['warnings'] : array()
					)
				)
			);

			return $uploaded_bundle;
		}

		// Raw HTML mode: preserve the imported document structure, but still rewrite
		// local asset and navigation references so static projects remain portable.
		if ( ! empty( $config['raw_html'] ) ) {
			$raw_bundle = $this->build_raw_bundle( $html, $page, $config, $settings, $deployment, $entry_file, $source_type, $html_files, $context );

			if ( is_wp_error( $raw_bundle ) ) {
				return $raw_bundle;
			}

			$raw_bundle['warnings'] = array_values(
				array_unique(
					array_merge(
						$preprocess_warnings,
						isset( $raw_bundle['warnings'] ) && is_array( $raw_bundle['warnings'] ) ? $raw_bundle['warnings'] : array()
					)
				)
			);

			return $raw_bundle;
		}

		$parsed = $this->metadata->parse_source( $html, $context, $config['performance'] );

		if ( is_wp_error( $parsed ) ) {
			return $parsed;
		}

		$resolved_performance = $this->resolve_performance_urls( $config['performance'], $context );
		$head_config          = $config;
		$head_config['performance'] = $resolved_performance;
		$metadata             = $this->metadata->build_final_metadata( $parsed, $config, $page, $settings );
		$html_attrs           = ! empty( $parsed['html_attrs'] ) ? $parsed['html_attrs'] : '';

		if ( false === stripos( $html_attrs, 'lang=' ) ) {
			$html_attrs = trim( $html_attrs . ' ' . $this->default_html_attributes() );
		}

		$body_html     = $parsed['body_html'];
		$full_link_map = $this->build_full_link_map( $context, $entry_file, $html_files );

		if ( ! empty( $full_link_map ) ) {
			$body_html .= $this->build_link_rewriter_script( $full_link_map );
		}

		$head_html = $this->metadata->build_head_html( $metadata, $head_config, $parsed );
		$head_html = $this->prepend_base_href_tag( $head_html, $deployment_base_href );

		$bundle               = array(
			'doctype'      => $parsed['doctype'],
			'html_attrs'   => $html_attrs ? $html_attrs : $this->default_html_attributes(),
			'body_attrs'   => $parsed['body_attrs'] ? $parsed['body_attrs'] : 'class="rspd-deployed-page"',
			'head_html'    => $head_html,
			'body_html'    => $body_html,
			'metadata'     => $metadata,
			'asset_refs'   => $parsed['asset_refs'],
			'entry_file'   => $entry_file,
			'html_files'   => $html_files,
			'source_type'  => $source_type,
			'render_mode'  => $config['render_mode'],
			'compatibility'=> $config['compatibility'],
			'performance'  => $resolved_performance,
			'generated_at' => time(),
		);

		if ( ! empty( $config['performance']['minify_html'] ) ) {
			$bundle['head_html'] = $this->performance->minify_fragment( $bundle['head_html'] );
			$bundle['body_html'] = $this->performance->minify_fragment( $bundle['body_html'] );
		}

		$diag_config            = $config;
		$diag_config['deployment_rel_dir'] = $deployment['relative_dir'];
		$bundle['diagnostics'] = $this->performance->build_diagnostics( $bundle, $diag_config );

		return array(
			'bundle'   => $bundle,
			'warnings' => array_values(
				array_unique(
					array_merge(
						$preprocess_warnings,
						isset( $parsed['warnings'] ) && is_array( $parsed['warnings'] ) ? $parsed['warnings'] : array()
					)
				)
			),
		);
	}

	/**
	 * Build a raw bundle that skips DOMDocument processing entirely.
	 *
	 * The HTML is served exactly as provided, with only lightweight
	 * string-level SEO tag injection into the <head>.
	 *
	 * @param string  $html        Source HTML.
	 * @param WP_Post $page        Target page.
	 * @param array   $config      Deployment config.
	 * @param array   $settings    Plugin settings.
	 * @param array   $deployment  Deployment paths.
	 * @param string  $entry_file  Entry filename.
	 * @param string  $source_type Source type.
	 * @param array   $html_files  HTML file list.
	 * @param array   $context     Deployment context.
	 * @return array|WP_Error
	 */
	protected function build_raw_bundle( $html, WP_Post $page, array $config, array $settings, array $deployment, $entry_file, $source_type, array $html_files, array $context ) {
		$warnings = array();
		$html     = $this->metadata->rewrite_raw_document( $html, $context, $warnings );

		if ( is_wp_error( $html ) ) {
			return $html;
		}

		$html = $this->inject_base_href_into_document(
			$html,
			! empty( $context['deployment_base_href'] ) ? $context['deployment_base_href'] : ''
		);

		// Build SEO metadata to inject.
		$seo_tags = $this->build_raw_seo_tags( $page, $config, $settings );

		// Inject SEO tags into <head> if present, right after opening <head>.
		if ( $seo_tags && preg_match( '/<head[^>]*>/i', $html, $m, PREG_OFFSET_CAPTURE ) ) {
			$insert_pos = $m[0][1] + strlen( $m[0][0] );
			$html       = substr( $html, 0, $insert_pos ) . "\n" . $seo_tags . "\n" . substr( $html, $insert_pos );
		}

		// String-level Google Fonts optimization: add display=swap if missing.
		$html = preg_replace_callback(
			'/(<link[^>]*href=["\'])([^"\']*fonts\.googleapis\.com\/css[^"\']*)(["\']\s*)/i',
			function ( $m ) {
				$url = $m[2];
				if ( false === strpos( $url, 'display=' ) ) {
					$sep = false === strpos( $url, '?' ) ? '?' : '&';
					$url .= $sep . 'display=swap';
				}
				return $m[1] . $url . $m[3];
			},
			$html
		);

		$bundle = array(
			'raw_document' => $html,
			'metadata'     => array(
				'title'       => $page->post_title,
				'description' => '',
				'canonical'   => get_permalink( $page ),
			),
			'asset_refs'   => array(),
			'entry_file'   => $entry_file,
			'html_files'   => $html_files,
			'source_type'  => $source_type,
			'render_mode'  => 'isolated',
			'compatibility'=> array( 'wp_head' => 0, 'wp_footer' => 0 ),
			'performance'  => isset( $config['performance'] ) ? $config['performance'] : array(),
			'generated_at' => time(),
			'diagnostics'  => array(),
		);

		return array(
			'bundle'   => $bundle,
			'warnings' => $warnings,
		);
	}

	/**
	 * Build an uploaded static package bundle with minimal document surgery.
	 *
	 * ZIP/folder deployments should behave like a static host: keep the package
	 * intact, serve the chosen HTML document, and only add base-path and route
	 * handling that WordPress needs.
	 *
	 * @param string  $html        Source HTML.
	 * @param WP_Post $page        Target page.
	 * @param array   $config      Deployment config.
	 * @param array   $settings    Plugin settings.
	 * @param array   $deployment  Deployment paths.
	 * @param string  $entry_file  Entry file.
	 * @param array   $html_files  HTML file list.
	 * @param array   $context     Deployment context.
	 * @return array|WP_Error
	 */
	protected function build_uploaded_package_bundle( $html, WP_Post $page, array $config, array $settings, array $deployment, $entry_file, array $html_files, array $context ) {
		$raw_bundle = $this->build_raw_bundle( $html, $page, $config, $settings, $deployment, $entry_file, 'upload', $html_files, $context );

		if ( is_wp_error( $raw_bundle ) ) {
			return $raw_bundle;
		}

		$full_link_map = $this->build_full_link_map( $context, $entry_file, $html_files );

		if ( ! empty( $full_link_map ) && ! empty( $raw_bundle['bundle']['raw_document'] ) ) {
			$raw_bundle['bundle']['raw_document'] = $this->inject_before_body_close(
				$raw_bundle['bundle']['raw_document'],
				$this->build_link_rewriter_script( $full_link_map )
			);
		}

		$raw_bundle['bundle']['asset_refs']  = array();
		$raw_bundle['bundle']['render_mode'] = 'isolated';
		$raw_bundle['bundle']['compatibility'] = array(
			'wp_head'   => 0,
			'wp_footer' => 0,
		);

		return $raw_bundle;
	}

	/**
	 * Normalize uploaded packages into static-host mode.
	 *
	 * ZIP/folder deployments should be treated as complete static sites rather than
	 * inheriting per-site defaults that can strip styling or change render behavior.
	 *
	 * @param array $config Deployment config.
	 * @return array
	 */
	protected function normalize_uploaded_package_render_config( array $config ) {
		$config['render_mode']            = 'isolated';
		$config['preserve_imported_head'] = 1;
		$config['prefer_plugin_metadata'] = 0;
		$config['raw_html']               = 1;
		$config['compatibility']          = array(
			'wp_head'   => 0,
			'wp_footer' => 0,
		);

		return $config;
	}

	/**
	 * Get a deployment base URL for uploaded static packages.
	 *
	 * @param string $source_type Source type.
	 * @param array  $deployment  Deployment paths.
	 * @param string $entry_file  Entry file.
	 * @return string
	 */
	protected function get_uploaded_package_base_href( $source_type, $deployment_url, $entry_file ) {
		if ( ! $this->is_static_package_source_type( $source_type ) ) {
			return '';
		}

		$base = trailingslashit( $deployment_url );
		$dir  = '.' === dirname( $entry_file ) ? '' : trim( dirname( $entry_file ), '/' );

		if ( '' !== $dir ) {
			$base .= trailingslashit( $dir );
		}

		return $base;
	}

	/**
	 * Prepend a base tag to generated head markup.
	 *
	 * @param string $head_html Existing head markup.
	 * @param string $base_href Base URL.
	 * @return string
	 */
	protected function prepend_base_href_tag( $head_html, $base_href ) {
		if ( '' === trim( (string) $base_href ) ) {
			return (string) $head_html;
		}

		return '<base href="' . esc_url( $base_href ) . '">' . "\n" . ltrim( (string) $head_html );
	}

	/**
	 * Inject a base tag into a raw uploaded document if needed.
	 *
	 * @param string $html      Raw HTML document.
	 * @param string $base_href Base URL.
	 * @return string
	 */
	protected function inject_base_href_into_document( $html, $base_href ) {
		if ( '' === trim( (string) $base_href ) ) {
			return (string) $html;
		}

		if ( preg_match( '/<base\b/i', (string) $html ) ) {
			return (string) $html;
		}

		if ( preg_match( '/<head[^>]*>/i', (string) $html, $matches, PREG_OFFSET_CAPTURE ) ) {
			$insert_pos = $matches[0][1] + strlen( $matches[0][0] );
			return substr( $html, 0, $insert_pos ) . "\n" . '<base href="' . esc_url( $base_href ) . '">' . "\n" . substr( $html, $insert_pos );
		}

		return (string) $html;
	}

	/**
	 * Build a combined html link map for in-document and JS-injected navigation.
	 *
	 * @param array  $context    Deployment context.
	 * @param string $entry_file Entry file.
	 * @param array  $html_files Available HTML files.
	 * @return array
	 */
	protected function build_full_link_map( array $context, $entry_file, array $html_files ) {
		$full_link_map = array();
		$asset_alias_targets = array();

		foreach ( isset( $context['html_link_map'] ) && is_array( $context['html_link_map'] ) ? $context['html_link_map'] : array() as $map_key => $map_target ) {
			$full_link_map[ $map_key ] = $map_target;
		}

		foreach ( $this->security->build_html_reference_aliases( $entry_file ) as $alias ) {
			$full_link_map[ $alias ] = $context['page_permalink'];
		}

		foreach ( $html_files as $html_file ) {
			$deployment_target = trailingslashit( $context['deployment_url'] ) . ltrim( $html_file, '/' );

			foreach ( $this->security->build_html_reference_aliases( $html_file ) as $alias ) {
				if ( ! isset( $asset_alias_targets[ $alias ] ) ) {
					$asset_alias_targets[ $alias ] = array();
				}

				$asset_alias_targets[ $alias ][ $deployment_target ] = true;
			}
		}

		foreach ( $asset_alias_targets as $alias => $targets ) {
			if ( isset( $full_link_map[ $alias ] ) ) {
				continue;
			}

			if ( 1 === count( $targets ) ) {
				$full_link_map[ $alias ] = array_key_first( $targets );
			}
		}

		return $full_link_map;
	}

	/**
	 * Inject markup before </body>, or append it if the closing tag is missing.
	 *
	 * @param string $html   HTML document.
	 * @param string $markup Markup to insert.
	 * @return string
	 */
	protected function inject_before_body_close( $html, $markup ) {
		if ( '' === trim( (string) $markup ) ) {
			return (string) $html;
		}

		if ( preg_match( '/<\/body>/i', (string) $html ) ) {
			return (string) preg_replace( '/<\/body>/i', $markup . "\n</body>", (string) $html, 1 );
		}

		return (string) $html . "\n" . $markup;
	}

	/**
	 * Copy a directory tree into a deployment directory.
	 *
	 * @param string $source_dir Source directory.
	 * @param string $destination_dir Destination directory.
	 * @return bool
	 */
	protected function copy_directory_recursive( $source_dir, $destination_dir ) {
		if ( ! is_dir( $source_dir ) ) {
			return false;
		}

		wp_mkdir_p( $destination_dir );

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $source_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::SELF_FIRST
		);

		foreach ( $iterator as $item ) {
			$source_path = wp_normalize_path( $item->getPathname() );
			$relative    = ltrim( str_replace( wp_normalize_path( $source_dir ), '', $source_path ), '/' );
			$target_path = wp_normalize_path( trailingslashit( $destination_dir ) . $relative );

			if ( $item->isDir() ) {
				wp_mkdir_p( $target_path );
				continue;
			}

			wp_mkdir_p( dirname( $target_path ) );

			if ( ! copy( $source_path, $target_path ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Rewrite every HTML file in a mounted software app against its parent slug.
	 *
	 * @param string $deployment_dir Deployment directory.
	 * @param string $slug App slug.
	 * @param string $root_entry_file Root entry file.
	 * @param array  $html_files HTML files in the package.
	 * @param array  $link_map Resolved HTML link map.
	 * @param array  $warnings Collected warnings.
	 * @return true|WP_Error
	 */
	protected function preprocess_software_html_files( $deployment_dir, $slug, $root_entry_file, array $html_files, array $link_map, array &$warnings ) {
		foreach ( $html_files as $html_file ) {
			$absolute_path = trailingslashit( $deployment_dir ) . $html_file;
			$html          = $this->storage->read_file( $absolute_path );

			if ( '' === $html ) {
				return new WP_Error( 'rspd_software_html_unreadable', sprintf( __( 'The HTML file "%s" could not be read during software deployment.', 'reputifly-static-page-deployer' ), $html_file ) );
			}

			$current_url  = $this->get_software_file_public_url( $slug, $html_file, $root_entry_file );
			$file_context = array(
				'page_permalink'       => $current_url,
				'deployment_url'       => untrailingslashit( $this->storage->get_software_mount_url( $slug ) ),
				'deployment_path'      => $deployment_dir,
				'entry_file'           => $html_file,
				'entry_dir'            => '.' === dirname( $html_file ) ? '' : dirname( $html_file ),
				'deployment_base_href' => $this->get_software_base_href( $slug, $html_file ),
				'fingerprint_assets'   => false,
				'default_charset'      => get_bloginfo( 'charset' ),
				'default_viewport'     => 'width=device-width, initial-scale=1',
				'html_link_map'        => $link_map,
			);
			$file_warnings = array();
			$rewritten     = $this->metadata->rewrite_raw_document( $html, $file_context, $file_warnings );

			if ( is_wp_error( $rewritten ) ) {
				return $rewritten;
			}

			$rewritten     = $this->inject_base_href_into_document( $rewritten, $file_context['deployment_base_href'] );
			$full_link_map = $link_map;

			foreach ( $this->security->build_html_reference_aliases( $html_file ) as $alias ) {
				$full_link_map[ $alias ] = $current_url;
			}

			if ( ! empty( $full_link_map ) ) {
				$rewritten = $this->inject_before_body_close( $rewritten, $this->build_link_rewriter_script( $full_link_map ) );
			}

			if ( ! $this->storage->write_file( $absolute_path, $rewritten ) ) {
				return new WP_Error( 'rspd_software_html_write_failed', sprintf( __( 'The HTML file "%s" could not be rewritten for software deployment.', 'reputifly-static-page-deployer' ), $html_file ) );
			}

			if ( ! empty( $file_warnings ) ) {
				$warnings = array_merge( $warnings, $file_warnings );
			}
		}

		return true;
	}

	/**
	 * Build the public mounted URL for one HTML file in a software app.
	 *
	 * @param string $slug App slug.
	 * @param string $html_file HTML file path.
	 * @param string $root_entry_file Root entry file.
	 * @return string
	 */
	protected function get_software_file_public_url( $slug, $html_file, $root_entry_file ) {
		$html_file       = $this->security->normalize_relative_path( $html_file );
		$root_entry_file = $this->security->normalize_relative_path( $root_entry_file );

		if ( '' === $html_file || $html_file === $root_entry_file ) {
			return $this->storage->get_software_mount_url( $slug );
		}

		$basename = strtolower( basename( $html_file ) );

		if ( in_array( $basename, array( 'index.html', 'index.htm' ), true ) ) {
			$directory = trim( dirname( $html_file ), './' );

			if ( '' !== $directory ) {
				return $this->storage->get_software_mount_url( $slug, trailingslashit( $directory ) );
			}
		}

		return $this->storage->get_software_mount_url( $slug, $html_file );
	}

	/**
	 * Build a base href for one HTML file in a mounted software app.
	 *
	 * @param string $slug App slug.
	 * @param string $html_file HTML file path.
	 * @return string
	 */
	protected function get_software_base_href( $slug, $html_file ) {
		$html_file = $this->security->normalize_relative_path( $html_file );

		if ( '' === $html_file ) {
			return $this->storage->get_software_mount_url( $slug );
		}

		$dir = trim( dirname( $html_file ), './' );

		if ( '' === $dir ) {
			return $this->storage->get_software_mount_url( $slug );
		}

		return $this->storage->get_software_mount_url( $slug, trailingslashit( $dir ) );
	}

	/**
	 * Build mounted software app link targets for all HTML files in the package.
	 *
	 * @param string $slug App slug.
	 * @param array  $html_files HTML files in the package.
	 * @param string $root_entry_file Root entry file.
	 * @return array
	 */
	protected function build_software_html_link_map( $slug, array $html_files, $root_entry_file ) {
		$alias_targets = array();

		foreach ( $html_files as $html_file ) {
			$target = $this->get_software_file_public_url( $slug, $html_file, $root_entry_file );

			foreach ( $this->security->build_html_reference_aliases( $html_file ) as $alias ) {
				if ( ! isset( $alias_targets[ $alias ] ) ) {
					$alias_targets[ $alias ] = array();
				}

				$alias_targets[ $alias ][ $target ] = true;
			}
		}

		$link_map = array();

		foreach ( $alias_targets as $alias => $targets ) {
			if ( 1 === count( $targets ) ) {
				$link_map[ $alias ] = array_key_first( $targets );
			}
		}

		return $link_map;
	}

	/**
	 * Build lightweight SEO tags for raw mode injection.
	 *
	 * @param WP_Post $page     Target page.
	 * @param array   $config   Deployment config.
	 * @param array   $settings Plugin settings.
	 * @return string
	 */
	protected function build_raw_seo_tags( WP_Post $page, array $config, array $settings ) {
		$tags = array();
		$meta = isset( $config['metadata'] ) && is_array( $config['metadata'] ) ? $config['metadata'] : array();
		$defaults = isset( $settings['metadata'] ) && is_array( $settings['metadata'] ) ? $settings['metadata'] : array();

		$canonical = get_permalink( $page );
		$tags[]    = '<link rel="canonical" href="' . esc_url( $canonical ) . '">';

		$description = ! empty( $meta['description'] ) ? $meta['description'] : ( ! empty( $defaults['description'] ) ? $defaults['description'] : '' );
		if ( $description ) {
			$tags[] = '<meta name="description" content="' . esc_attr( $description ) . '">';
		}

		$og_title = ! empty( $meta['og_title'] ) ? $meta['og_title'] : $page->post_title;
		$tags[]   = '<meta property="og:title" content="' . esc_attr( $og_title ) . '">';
		$tags[]   = '<meta property="og:url" content="' . esc_url( $canonical ) . '">';

		if ( $description ) {
			$tags[] = '<meta property="og:description" content="' . esc_attr( $description ) . '">';
		}

		$og_image = ! empty( $meta['og_image'] ) ? $meta['og_image'] : ( ! empty( $defaults['og_image'] ) ? $defaults['og_image'] : '' );
		if ( $og_image ) {
			$tags[] = '<meta property="og:image" content="' . esc_url( $og_image ) . '">';
		}

		return implode( "\n", $tags );
	}

	/**
	 * Extract a ZIP package securely.
	 *
	 * @param string $zip_file  Temporary zip path.
	 * @param string $target_dir Absolute deployment directory.
	 * @return array|WP_Error
	 */
	protected function extract_zip_package( $zip_file, $target_dir ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'rspd_zip_missing', __( 'ZipArchive is required to import ZIP deployment packages on this server.', 'reputifly-static-page-deployer' ) );
		}

		$zip = new ZipArchive();

		if ( true !== $zip->open( $zip_file ) ) {
			return new WP_Error( 'rspd_zip_open', __( 'The ZIP package could not be opened.', 'reputifly-static-page-deployer' ) );
		}

		$entries   = array();
		$html_files = array();
		$warnings   = array();

		for ( $index = 0; $index < $zip->numFiles; $index++ ) {
			$entry_name = $zip->getNameIndex( $index );

			if ( ! $entry_name || '/' === substr( $entry_name, -1 ) ) {
				continue;
			}

			$safe_relative = $this->security->normalize_relative_path( $entry_name );

			if ( ! $safe_relative ) {
				$warnings[] = sprintf( __( 'Skipped an unsafe ZIP entry: %s', 'reputifly-static-page-deployer' ), $entry_name );
				continue;
			}

			if ( ! $this->security->is_allowed_file( $safe_relative ) ) {
				$warnings[] = sprintf( __( 'Skipped a disallowed file type: %s', 'reputifly-static-page-deployer' ), $safe_relative );
				continue;
			}

			$entries[] = array(
				'zip_name'      => $entry_name,
				'safe_relative' => $safe_relative,
			);
		}

		$entries = $this->strip_single_root_directory_from_zip_entries( $entries );

		foreach ( $entries as $entry ) {
			$safe_relative = $entry['safe_relative'];
			$destination   = $this->security->safe_join( $target_dir, $safe_relative );

			if ( ! $destination ) {
				$warnings[] = sprintf( __( 'Skipped an invalid ZIP destination: %s', 'reputifly-static-page-deployer' ), $safe_relative );
				continue;
			}

			wp_mkdir_p( dirname( $destination ) );

			$stream = $zip->getStream( $entry['zip_name'] );

			if ( ! $stream ) {
				$warnings[] = sprintf( __( 'Could not read ZIP entry: %s', 'reputifly-static-page-deployer' ), $safe_relative );
				continue;
			}

			$contents = stream_get_contents( $stream );
			fclose( $stream );

			if ( false === $contents ) {
				$warnings[] = sprintf( __( 'Could not extract ZIP entry: %s', 'reputifly-static-page-deployer' ), $safe_relative );
				continue;
			}

			$this->storage->write_file( $destination, $contents );

			if ( in_array( strtolower( pathinfo( $safe_relative, PATHINFO_EXTENSION ) ), array( 'html', 'htm' ), true ) ) {
				$html_files[] = $safe_relative;
			}
		}

		$zip->close();

		sort( $html_files );

		return array(
			'html_files' => array_values( array_unique( $html_files ) ),
			'warnings'   => $warnings,
		);
	}

	/**
	 * Remove one shared wrapper folder from ZIP entry paths.
	 *
	 * @param array $entries Extractable ZIP entries.
	 * @return array
	 */
	protected function strip_single_root_directory_from_zip_entries( array $entries ) {
		if ( empty( $entries ) ) {
			return $entries;
		}

		$root_segment = '';

		foreach ( $entries as $entry ) {
			$path = isset( $entry['safe_relative'] ) ? (string) $entry['safe_relative'] : '';

			if ( false === strpos( $path, '/' ) ) {
				return $entries;
			}

			$first_segment = strtok( $path, '/' );

			if ( '' === $first_segment ) {
				return $entries;
			}

			if ( '' === $root_segment ) {
				$root_segment = $first_segment;
				continue;
			}

			if ( $root_segment !== $first_segment ) {
				return $entries;
			}
		}

		if ( '' === $root_segment ) {
			return $entries;
		}

		foreach ( $entries as $index => $entry ) {
			$path          = (string) $entry['safe_relative'];
			$stripped_path = preg_replace( '#^' . preg_quote( $root_segment, '#' ) . '/#', '', $path, 1 );

			if ( empty( $stripped_path ) ) {
				return $entries;
			}

			$entries[ $index ]['safe_relative'] = $stripped_path;
		}

		return $entries;
	}

	/**
	 * Rewrite local HTML route strings inside extracted JS files.
	 *
	 * @param string $deployment_dir Deployment directory path.
	 * @param array  $context        Deployment context.
	 * @param array  $warnings       Collected warnings.
	 * @return void
	 */
	protected function rewrite_deployment_javascript_routes( $deployment_dir, array $context, array &$warnings ) {
		if ( ! is_dir( $deployment_dir ) ) {
			return;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $deployment_dir, RecursiveDirectoryIterator::SKIP_DOTS )
		);

		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() ) {
				continue;
			}

			$extension = strtolower( $file->getExtension() );

			if ( ! in_array( $extension, array( 'js', 'mjs' ), true ) ) {
				continue;
			}

			$path     = wp_normalize_path( $file->getPathname() );
			$contents = $this->storage->read_file( $path );

			if ( '' === $contents ) {
				continue;
			}

			$rewritten = $this->metadata->rewrite_javascript_navigation_references( $contents, $context, $warnings );

			if ( $rewritten !== $contents ) {
				$this->storage->write_file( $path, $rewritten );
			}
		}
	}

	/**
	 * Scan an existing deployment for HTML files.
	 *
	 * @param string $absolute_dir Deployment directory.
	 * @return array
	 */
	protected function scan_html_files( $absolute_dir ) {
		if ( ! is_dir( $absolute_dir ) ) {
			return array();
		}

		$html_files = array();
		$iterator   = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $absolute_dir, RecursiveDirectoryIterator::SKIP_DOTS )
		);

		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() ) {
				continue;
			}

			$relative = ltrim( str_replace( wp_normalize_path( $absolute_dir ), '', wp_normalize_path( $file->getPathname() ) ), '/' );
			$ext      = strtolower( pathinfo( $relative, PATHINFO_EXTENSION ) );

			if ( in_array( $ext, array( 'html', 'htm' ), true ) ) {
				$html_files[] = $relative;
			}
		}

		sort( $html_files );

		return array_values( array_unique( $html_files ) );
	}

	/**
	 * Resolve entry file selection.
	 *
	 * @param array  $html_files     Available HTML files.
	 * @param string $requested_file Requested entry file.
	 * @return string
	 */
	protected function detect_entry_file( array $html_files, $requested_file ) {
		$requested_file = $this->security->normalize_relative_path( $requested_file );

		if ( $requested_file && in_array( $requested_file, $html_files, true ) ) {
			return $requested_file;
		}

		if ( $requested_file ) {
			$basename_matches = array_values(
				array_filter(
					$html_files,
					function ( $html_file ) use ( $requested_file ) {
						return basename( $html_file ) === basename( $requested_file );
					}
				)
			);

			if ( 1 === count( $basename_matches ) ) {
				return $basename_matches[0];
			}
		}

		foreach ( array( 'index.html', 'index.htm' ) as $candidate ) {
			if ( in_array( $candidate, $html_files, true ) ) {
				return $candidate;
			}
		}

		foreach ( $html_files as $html_file ) {
			$basename = strtolower( basename( $html_file ) );

			if ( in_array( $basename, array( 'index.html', 'index.htm' ), true ) ) {
				return $html_file;
			}
		}

		return ! empty( $html_files[0] ) ? $html_files[0] : '';
	}

	/**
	 * Normalize metadata fields.
	 *
	 * @param array $submitted Submitted metadata.
	 * @param array $settings  Plugin settings.
	 * @return array
	 */
	protected function normalize_metadata_config( array $submitted, array $settings ) {
		$defaults = isset( $settings['metadata'] ) && is_array( $settings['metadata'] ) ? $settings['metadata'] : array();

		return array(
			'seo_title'           => isset( $submitted['seo_title'] ) ? sanitize_text_field( wp_unslash( $submitted['seo_title'] ) ) : '',
			'meta_description'    => isset( $submitted['meta_description'] ) ? sanitize_text_field( wp_unslash( $submitted['meta_description'] ) ) : '',
			'canonical_url'       => isset( $submitted['canonical_url'] ) ? esc_url_raw( wp_unslash( $submitted['canonical_url'] ) ) : '',
			'robots'              => isset( $submitted['robots'] ) ? sanitize_text_field( wp_unslash( $submitted['robots'] ) ) : ( isset( $defaults['robots'] ) ? $defaults['robots'] : '' ),
			'og_title'            => isset( $submitted['og_title'] ) ? sanitize_text_field( wp_unslash( $submitted['og_title'] ) ) : '',
			'og_description'      => isset( $submitted['og_description'] ) ? sanitize_text_field( wp_unslash( $submitted['og_description'] ) ) : '',
			'og_image'            => isset( $submitted['og_image'] ) ? esc_url_raw( wp_unslash( $submitted['og_image'] ) ) : '',
			'twitter_card'        => isset( $submitted['twitter_card'] ) ? sanitize_text_field( wp_unslash( $submitted['twitter_card'] ) ) : ( isset( $defaults['twitter_card'] ) ? $defaults['twitter_card'] : 'summary_large_image' ),
			'twitter_title'       => isset( $submitted['twitter_title'] ) ? sanitize_text_field( wp_unslash( $submitted['twitter_title'] ) ) : '',
			'twitter_description' => isset( $submitted['twitter_description'] ) ? sanitize_text_field( wp_unslash( $submitted['twitter_description'] ) ) : '',
			'twitter_image'       => isset( $submitted['twitter_image'] ) ? esc_url_raw( wp_unslash( $submitted['twitter_image'] ) ) : '',
			'json_ld'             => isset( $submitted['json_ld'] ) ? trim( wp_unslash( $submitted['json_ld'] ) ) : '',
			'viewport'            => isset( $submitted['viewport'] ) ? sanitize_text_field( wp_unslash( $submitted['viewport'] ) ) : ( isset( $defaults['viewport'] ) ? $defaults['viewport'] : 'width=device-width, initial-scale=1' ),
			'charset'             => isset( $submitted['charset'] ) ? sanitize_text_field( wp_unslash( $submitted['charset'] ) ) : ( isset( $defaults['charset'] ) ? $defaults['charset'] : get_bloginfo( 'charset' ) ),
		);
	}

	/**
	 * Normalize render mode.
	 *
	 * @param string $render_mode Requested mode.
	 * @return string
	 */
	protected function normalize_render_mode( $render_mode ) {
		$render_mode = sanitize_key( $render_mode );

		return in_array( $render_mode, array( 'isolated', 'compatibility' ), true ) ? $render_mode : 'isolated';
	}

	/**
	 * Resolve performance URLs to deployment URLs where appropriate.
	 *
	 * @param array $performance Performance config.
	 * @param array $context     Deployment context.
	 * @return array
	 */
	protected function resolve_performance_urls( array $performance, array $context ) {
		$resolved = $performance;

		$resolved['hero_image']      = $this->resolve_reference_for_output( isset( $performance['hero_image'] ) ? $performance['hero_image'] : '', $context );
		$resolved['preload_styles']  = $this->resolve_multiline_references( isset( $performance['preload_styles'] ) ? $performance['preload_styles'] : '', $context );
		$resolved['preconnect_urls'] = $this->resolve_multiline_references( isset( $performance['preconnect_urls'] ) ? $performance['preconnect_urls'] : '', $context );
		$resolved['dns_prefetch_urls'] = $this->resolve_multiline_references( isset( $performance['dns_prefetch_urls'] ) ? $performance['dns_prefetch_urls'] : '', $context );

		return $resolved;
	}

	/**
	 * Resolve multiline URLs.
	 *
	 * @param string $value   Raw textarea value.
	 * @param array  $context Deployment context.
	 * @return string
	 */
	protected function resolve_multiline_references( $value, array $context ) {
		$lines = preg_split( '/\r\n|\r|\n/', (string) $value );
		$lines = is_array( $lines ) ? $lines : array();
		$urls  = array();

		foreach ( $lines as $line ) {
			$line = trim( $line );

			if ( '' === $line ) {
				continue;
			}

			$urls[] = $this->resolve_reference_for_output( $line, $context );
		}

		return implode( "\n", $urls );
	}

	/**
	 * Resolve a possibly-relative asset path to its final deployment URL.
	 *
	 * @param string $value   Reference value.
	 * @param array  $context Deployment context.
	 * @return string
	 */
	protected function resolve_reference_for_output( $value, array $context ) {
		$value = trim( (string) $value );

		if ( '' === $value || ! $this->security->is_local_reference( $value ) ) {
			return $value;
		}

		$parts    = $this->security->split_reference( $value );
		$resolved = $this->security->resolve_reference_path( $parts['path'], isset( $context['entry_dir'] ) ? $context['entry_dir'] : '' );

		if ( ! $resolved ) {
			return $value;
		}

		$url      = trailingslashit( $context['deployment_url'] ) . ltrim( $resolved, '/' ) . $parts['suffix'];
		$absolute = trailingslashit( $context['deployment_path'] ) . $resolved;

		if ( ! empty( $context['fingerprint_assets'] ) && is_file( $absolute ) ) {
			$separator = false === strpos( $url, '?' ) ? '?' : '&';
			$url      .= $separator . 'v=' . substr( md5_file( $absolute ), 0, 10 );
		}

		return $url;
	}

	/**
	 * Provide a safe fallback lang attribute.
	 *
	 * @return string
	 */
	protected function default_html_attributes() {
		return 'lang="' . esc_attr( str_replace( '_', '-', get_locale() ) ) . '"';
	}

	/**
	 * Build a small inline script that rewrites .html links to WordPress slugs.
	 *
	 * Handles both static links and dynamically injected ones (e.g. from components.js).
	 *
	 * @param array $link_map Associative array of html_filename => permalink.
	 * @return string Script tag HTML.
	 */
	protected function build_link_rewriter_script( array $link_map ) {
		// Build a basename-only map for fallback matching.
		$base_map = array();
		foreach ( $link_map as $key => $url ) {
			$bn = basename( $key );
			if ( ! isset( $base_map[ $bn ] ) ) {
				$base_map[ $bn ] = $url;
			}
		}
		$json     = wp_json_encode( $link_map, JSON_UNESCAPED_SLASHES );
		$base_json = wp_json_encode( $base_map, JSON_UNESCAPED_SLASHES );

		return "\n" . '<script id="rspd-link-rewriter">'
			. '(function(){'
			. 'var m=' . $json . ',b=' . $base_json . ';'
			. 'function n(h){'
			// Normalize same-origin absolute URLs into matchable local paths.
			.   'if(!h)return"";'
			.   'try{'
			.     'var u=new URL(h,window.location.href);'
			.     'var raw=String(h||"");'
			.     'var isAbsolute=/^[a-z][a-z0-9+.-]*:\\/\\//i.test(raw)||raw.indexOf("//")===0;'
			.     'if(isAbsolute&&u.origin!==window.location.origin)return"";'
			.     'h=u.pathname+u.search+u.hash;'
			.   '}catch(e){}'
			.   'h=h.split("#")[0].split("?")[0];'
			.   'while(h.indexOf("./")===0){h=h.substring(2);}'
			.   'while(h.indexOf("../")===0){h=h.substring(3);}'
			.   'h=h.replace(/^\\/+/,"");'
			.   'return h;'
			. '}'
			. 'function s(h){'
			.   'var q=h.search(/[?#]/);'
			.   'return q>=0?h.substring(q):"";'
			. '}'
			. 'function f(h){'
			// Extract just the filename (basename) from any path.
			.   'var p=h.lastIndexOf("/");'
			.   'return p>=0?h.substring(p+1):h;'
			. '}'
			. 'function r(root){'
			.   'var links=root.querySelectorAll("a[href]");'
			.   'for(var i=0;i<links.length;i++){'
			.     'var raw=links[i].getAttribute("href");'
			.     'if(!raw||raw.charAt(0)==="#"||/^mailto:/i.test(raw)||/^tel:/i.test(raw))continue;'
			.     'var h=n(raw);'
			.     'if(!h)continue;'
			.     'var suffix=s(raw);'
			.     'var target=m[h]||m[raw]||b[f(h)];'
			.     'if(target)links[i].setAttribute("href",target+suffix);'
			.   '}'
			. '}'
			. 'r(document);'
			. 'if(typeof MutationObserver!=="undefined"){'
			.   'new MutationObserver(function(muts){'
			.     'for(var j=0;j<muts.length;j++){'
			.       'var added=muts[j].addedNodes;'
			.       'for(var k=0;k<added.length;k++){'
			.         'if(added[k].querySelectorAll)r(added[k]);'
			.       '}'
			.     '}'
			.   '}).observe(document.body,{childList:true,subtree:true});'
			. '}'
			. '})();'
			. '</script>';
	}

	// ─── Merge Sections ───

	// ─── A/B Testing ───

	/**
	 * Deploy an A/B variant for an existing page deployment.
	 *
	 * @param int    $page_id     Target WordPress page ID (must have existing deployment).
	 * @param string $variant_key Variant identifier (e.g. 'variant_b').
	 * @param string $html_code   The variant HTML source.
	 * @return array|WP_Error     { deployment_rel_dir, cache_version } on success.
	 */
	public function deploy_ab_variant( $page_id, $variant_key, $html_code ) {
		$page = get_post( $page_id );
		if ( ! $page || 'page' !== $page->post_type ) {
			return new WP_Error( 'rspd_invalid_page', 'Invalid page.' );
		}

		$existing = $this->storage->get_page_config( $page_id );
		if ( empty( $existing['deployment_rel_dir'] ) ) {
			return new WP_Error( 'rspd_no_deployment', 'Page must have an existing deployment first.' );
		}

		// Resolve effective config (performance, metadata, etc.) for this page.
		$config   = $this->storage->resolve_page_config( $page_id );
		$settings = $this->storage->get_settings();

		// Create variant deployment directory.
		$deployment = $this->storage->create_variant_deployment_directory( $page_id, $variant_key );
		$entry_file = 'source.html';

		if ( ! $this->storage->write_file( $deployment['absolute_dir'] . '/' . $entry_file, $html_code ) ) {
			return new WP_Error( 'rspd_write_failed', 'Could not write variant source file.' );
		}

		// Build render bundle using existing pipeline.
		$bundle = $this->build_bundle(
			$html_code,
			$page,
			$config,
			$settings,
			$deployment,
			$entry_file,
			'paste',
			array( $entry_file )
		);

		if ( is_wp_error( $bundle ) ) {
			return $bundle;
		}

		// Save render bundle to variant directory.
		$this->storage->save_render_bundle( $deployment['relative_dir'], $bundle['bundle'] );

		return array(
			'deployment_rel_dir' => $deployment['relative_dir'],
			'cache_version'      => wp_generate_password( 12, false, false ),
		);
	}

	/**
	 * Delete a variant's deployment directory.
	 *
	 * @param string $deployment_rel_dir Variant deployment relative directory.
	 * @return void
	 */
	public function delete_variant_deployment( $deployment_rel_dir ) {
		if ( ! empty( $deployment_rel_dir ) ) {
			$this->storage->remove_deployment_directory( $deployment_rel_dir );
		}
	}

	/**
	 * Rebuild a variant's deployment with updated overrides.
	 *
	 * @param int    $page_id     WordPress page ID.
	 * @param string $variant_key Variant key (e.g. 'control', 'variant_b').
	 * @return array|WP_Error
	 */
	public function rebuild_variant_deployment( $page_id, $variant_key ) {
		$raw_config = $this->storage->get_page_config( $page_id );

		if ( empty( $raw_config ) ) {
			return new WP_Error( 'rspd_missing_config', 'No deployment exists for that page.' );
		}

		if ( empty( $raw_config['ab_test']['variants'][ $variant_key ] ) ) {
			return new WP_Error( 'rspd_missing_variant', 'Variant not found.' );
		}

		$variant = $raw_config['ab_test']['variants'][ $variant_key ];
		if ( empty( $variant['deployment_rel_dir'] ) ) {
			return new WP_Error( 'rspd_no_variant_dir', 'Variant has no deployment directory.' );
		}

		// Resolve effective config, then overlay variant-specific overrides.
		$config   = $this->storage->resolve_page_config( $page_id );
		$settings = $this->storage->get_settings();

		if ( ! empty( $variant['page_overrides'] ) && is_array( $variant['page_overrides'] ) ) {
			$config = $this->storage->apply_overrides_to_config( $config, $variant['page_overrides'] );
		}

		$page = get_post( $page_id );

		// Read existing source from variant directory.
		$source_path = $this->storage->get_deployment_path( $variant['deployment_rel_dir'] ) . '/source.html';
		$html_code   = $this->storage->read_file( $source_path );

		if ( empty( $html_code ) ) {
			return new WP_Error( 'rspd_no_source', 'Could not read variant source file.' );
		}

		$deployment = array(
			'relative_dir' => $variant['deployment_rel_dir'],
			'absolute_dir' => $this->storage->get_deployment_path( $variant['deployment_rel_dir'] ),
			'url'          => $this->storage->get_deployment_url( $variant['deployment_rel_dir'] ),
		);

		$bundle = $this->build_bundle(
			$html_code,
			$page,
			$config,
			$settings,
			$deployment,
			'source.html',
			'paste',
			array( 'source.html' )
		);

		if ( is_wp_error( $bundle ) ) {
			return $bundle;
		}

		$this->storage->save_render_bundle( $variant['deployment_rel_dir'], $bundle['bundle'] );

		// Update variant cache version.
		$raw_config['ab_test']['variants'][ $variant_key ]['cache_version'] = wp_generate_password( 12, false, false );
		$this->storage->update_page_config( $page_id, $raw_config );

		return $bundle;
	}

	/**
	 * Deploy a page from multiple merged HTML sections.
	 *
	 * @param array $sections Array of [ 'title' => string, 'code' => string ].
	 * @param int   $page_id  Target WordPress page ID.
	 * @return array|WP_Error
	 */
	public function import_merged_sections( array $sections, $page_id ) {
		$page = get_post( $page_id );

		if ( ! $page || 'page' !== $page->post_type ) {
			return new WP_Error( 'rspd_invalid_page', __( 'Invalid page.', 'reputifly-static-page-deployer' ) );
		}

		$settings = $this->storage->get_settings();
		$existing = $this->storage->get_page_config( $page_id );

		// Remove old deployment.
		if ( ! empty( $existing['deployment_rel_dir'] ) ) {
			$this->storage->remove_deployment_directory( $existing['deployment_rel_dir'] );
		}

		$deployment  = $this->storage->create_deployment_directory( $page_id );
		$merged_html = $this->merge_sections_to_html( $sections );
		$entry_file  = 'source.html';

		if ( ! $this->storage->write_file( $deployment['absolute_dir'] . '/' . $entry_file, $merged_html ) ) {
			return new WP_Error( 'rspd_write_failed', __( 'Could not write merged source.', 'reputifly-static-page-deployer' ) );
		}

		// Merge deployments always use raw mode (skip DOMDocument)
		// and isolated mode with no WP head/footer.
		$config = array(
			'enabled'                => 1,
			'raw_html'               => 1,
			'render_mode'            => 'isolated',
			'preserve_imported_head' => 1,
			'prefer_plugin_metadata' => 0,
			'compatibility'          => array(
				'wp_head'   => 0,
				'wp_footer' => 0,
			),
			'metadata'               => array(),
			'performance'            => $this->performance->normalize_options( array(), $settings ),
		);

		$bundle = $this->build_bundle(
			$merged_html, $page, $config, $settings,
			$deployment, $entry_file, 'merge', array( $entry_file )
		);

		if ( is_wp_error( $bundle ) ) {
			$this->storage->remove_deployment_directory( $deployment['relative_dir'] );
			return $bundle;
		}

		$final_config = array_merge( $config, array(
			'deployment_id'      => basename( $deployment['relative_dir'] ),
			'deployment_rel_dir' => $deployment['relative_dir'],
			'entry_file'         => $entry_file,
			'source_type'        => 'merge',
			'html_files'         => array( $entry_file ),
			'sections'           => $sections,
			'updated_at'         => time(),
			'cache_version'      => wp_generate_password( 12, false, false ),
			'diagnostics'        => $bundle['bundle']['diagnostics'],
			'last_warnings'      => $bundle['warnings'],
		) );

		// Preserve per-page overrides through re-deployments.
		if ( ! empty( $existing['page_overrides'] ) && is_array( $existing['page_overrides'] ) ) {
			$final_config['page_overrides'] = $existing['page_overrides'];
		}

		$this->storage->save_render_bundle( $deployment['relative_dir'], $bundle['bundle'] );
		$this->storage->update_page_config( $page_id, $final_config );

		return array(
			'page_id' => $page_id,
			'config'  => $final_config,
		);
	}

	/**
	 * Combine multiple HTML sections into a single document using iframes.
	 *
	 * Each section is rendered inside its own <iframe srcdoc="..."> so it has
	 * complete isolation — its own CSS, JS, and DOM context.  A small script
	 * auto-resizes every iframe to match its content height (using both the
	 * onload event and a ResizeObserver for dynamic content).
	 *
	 * This mirrors the proven approach used in the Reputifly proposal builder.
	 *
	 * @param array $sections Array of [ 'title' => string, 'code' => string ].
	 * @return string Full HTML document.
	 */
	protected function merge_sections_to_html( array $sections ) {
		$iframes = array();

		foreach ( $sections as $i => $section ) {
			$code  = isset( $section['code'] ) ? $section['code'] : '';
			$title = isset( $section['title'] ) ? $section['title'] : 'Section ' . ( $i + 1 );

			// If the section is NOT a full HTML document, wrap it in one.
			if ( ! preg_match( '/<html[\s>]/i', $code ) ) {
				$code = "<!DOCTYPE html>\n<html lang=\"en\"><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"></head>"
					. "<body style=\"margin:0;padding:0;\">" . $code . "</body></html>";
			}

			// Ensure body has no margin so iframe sizing is accurate.
			if ( preg_match( '/<body([^>]*)>/i', $code, $bm ) ) {
				$body_tag  = $bm[0];
				$body_attr = $bm[1];
				// Inject margin:0 via inline style if not already present.
				if ( false === stripos( $body_attr, 'margin' ) ) {
					if ( preg_match( '/style\s*=\s*["\']([^"\']*)/i', $body_attr, $sm ) ) {
						$new_style = 'style="margin:0;' . $sm[1];
						$new_tag   = str_replace( $sm[0], $new_style, $body_tag );
					} else {
						$new_tag = str_replace( '>', ' style="margin:0;padding:0;">', $body_tag );
					}
					$code = str_replace( $body_tag, $new_tag, $code );
				}
			}

			// Also inject overflow:hidden on body so iframe has no inner scrollbar.
			$code = preg_replace(
				'/<body([^>]*)style\s*=\s*"([^"]*)"/i',
				'<body$1style="$2;overflow:hidden;"',
				$code,
				1
			);

			// Encode for srcdoc attribute (HTML entity encode & and ").
			$safe = str_replace( '&', '&amp;', $code );
			$safe = str_replace( '"', '&quot;', $safe );

			$iframes[] = '<!-- Section: ' . esc_html( $title ) . ' -->';
			$iframes[] = '<iframe srcdoc="' . $safe . '" scrolling="no" onload="rspdResize(this)" '
				. 'style="width:100%;border:none;display:block;overflow:hidden;" '
				. 'title="' . esc_attr( $title ) . '"></iframe>';
		}

		return '<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{margin:0;padding:0;background:#fff;overflow-x:hidden;}
iframe{width:100%;border:none;display:block;overflow:hidden;}
</style>
<script>
function rspdResize(f){try{
var h=f.contentWindow.document.documentElement.scrollHeight;
f.style.height=h+"px";
var ro=new ResizeObserver(function(){
f.style.height=f.contentWindow.document.documentElement.scrollHeight+"px";
});
ro.observe(f.contentWindow.document.body);
}catch(e){f.style.height="600px";}}
</script>
</head>
<body>
' . implode( "\n", $iframes ) . '
</body>
</html>';
	}

	/**
	 * Scope CSS selectors by prepending a parent class.
	 *
	 * Handles @media queries (recursively), skips @keyframes and @font-face.
	 *
	 * @param string $css    Raw CSS text.
	 * @param string $prefix Parent selector (e.g. '.rspd-section-1').
	 * @return string Scoped CSS.
	 */
	protected function scope_css_selectors( $css, $prefix ) {
		// Extract and preserve @keyframes / @font-face blocks.
		$preserved = array();
		$css = preg_replace_callback(
			'/@(keyframes|font-face)\s*[^{]*\{(?:[^{}]*|\{[^{}]*\})*\}/si',
			function ( $m ) use ( &$preserved ) {
				$key = '/*__RSPD_PRESERVED_' . count( $preserved ) . '*/';
				$preserved[ $key ] = $m[0];
				return $key;
			},
			$css
		);

		// Handle @media blocks recursively.
		$css = preg_replace_callback(
			'/@media\s*([^{]+)\{((?:[^{}]*|\{[^{}]*\})*)\}/si',
			function ( $m ) use ( $prefix ) {
				return '@media ' . $m[1] . '{' . $this->scope_css_selectors( $m[2], $prefix ) . '}';
			},
			$css
		);

		// Scope regular rules.
		$css = preg_replace_callback(
			'/([^@{}\/][^{]*)\{([^}]*)\}/s',
			function ( $m ) use ( $prefix ) {
				$selectors_raw = trim( $m[1] );
				$body          = $m[2];

				// Skip preserved placeholders.
				if ( false !== strpos( $selectors_raw, '__RSPD_PRESERVED_' ) ) {
					return $m[0];
				}

				$selectors = array_map( 'trim', explode( ',', $selectors_raw ) );
				$scoped    = array();

				foreach ( $selectors as $sel ) {
					if ( '' === $sel ) {
						continue;
					}
					// Replace root selectors with the section prefix.
					$s = preg_replace( '/^(html|body)\b/i', $prefix, $sel );
					if ( $s === $sel ) {
						$s = $prefix . ' ' . $sel;
					}
					$scoped[] = $s;
				}

				return implode( ', ', $scoped ) . ' {' . $body . '}';
			},
			$css
		);

		// Restore preserved blocks.
		foreach ( $preserved as $key => $value ) {
			$css = str_replace( $key, $value, $css );
		}

		return $css;
	}

	/**
	 * Determine whether a source type should use the static package deployment path.
	 *
	 * @param string $source_type Source type.
	 * @return bool
	 */
	protected function is_static_package_source_type( $source_type ) {
		return in_array( sanitize_key( (string) $source_type ), array( 'upload', 'elementor_export' ), true );
	}

	/**
	 * Capture the live rendered frontend of an Elementor page and localize its
	 * same-origin assets into a static package directory.
	 *
	 * @param WP_Post $source_page Elementor source page.
	 * @param string  $source_url Public frontend URL.
	 * @param string  $target_dir Package output directory.
	 * @param array   $link_map Internal selected-page link map.
	 * @return array|WP_Error
	 */
	protected function capture_elementor_frontend_package( WP_Post $source_page, $source_url, $target_dir, array $link_map ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return new WP_Error( 'rspd_dom_missing', __( 'DOMDocument is required to export Elementor pages.', 'reputifly-static-page-deployer' ) );
		}

		$response = wp_remote_get(
			$source_url,
			array(
				'timeout'    => 30,
				'redirection'=> 5,
				'headers'    => array(
					'Accept'     => 'text/html,application/xhtml+xml',
					'User-Agent' => 'Reputifly Archimedes Elementor Export/' . RSPD_VERSION,
					'Cache-Control' => 'no-cache',
					'Pragma'     => 'no-cache',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'rspd_elementor_fetch_failed', sprintf( __( 'Could not capture the Elementor page "%s": %s', 'reputifly-static-page-deployer' ), $source_page->post_title, $response->get_error_message() ) );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$html   = (string) wp_remote_retrieve_body( $response );

		if ( $status < 200 || $status >= 300 || '' === trim( $html ) ) {
			return new WP_Error( 'rspd_elementor_fetch_invalid', sprintf( __( 'The Elementor page "%1$s" returned an invalid response (%2$d).', 'reputifly-static-page-deployer' ), $source_page->post_title, $status ) );
		}

		$html = $this->strip_admin_markup_from_document( $html );
		$result = $this->localize_elementor_document_package( $html, $source_url, $target_dir, $link_map );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( ! $this->storage->write_file( trailingslashit( $target_dir ) . 'index.html', $result['html'] ) ) {
			return new WP_Error( 'rspd_elementor_index_write_failed', __( 'The generated Elementor export entry file could not be written.', 'reputifly-static-page-deployer' ) );
		}

		return array(
			'warnings'   => $result['warnings'],
			'asset_count'=> $result['asset_count'],
		);
	}

	/**
	 * Localize a captured Elementor HTML document into a self-contained package.
	 *
	 * @param string $html Captured HTML document.
	 * @param string $source_url Source URL.
	 * @param string $target_dir Export directory.
	 * @param array  $link_map Internal selected-page link map.
	 * @return array|WP_Error
	 */
	protected function localize_elementor_document_package( $html, $source_url, $target_dir, array $link_map ) {
		$target_dir = wp_normalize_path( (string) $target_dir );
		$doctype    = '<!doctype html>';
		if ( preg_match( '/<!doctype[^>]*>/i', (string) $html, $matches ) ) {
			$doctype = $matches[0];
		}

		$document = new DOMDocument();
		libxml_use_internal_errors( true );
		$loaded = $document->loadHTML( $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();

		if ( ! $loaded ) {
			return new WP_Error( 'rspd_elementor_html_invalid', __( 'The captured Elementor HTML could not be parsed.', 'reputifly-static-page-deployer' ) );
		}

		$warnings    = array();
		$asset_cache = array();

		foreach ( iterator_to_array( $document->getElementsByTagName( 'style' ) ) as $style_node ) {
			$style_node->nodeValue = $this->localize_css_content(
				(string) $style_node->nodeValue,
				$source_url,
				$target_dir,
				'index.html',
				$asset_cache,
				$warnings
			);
		}

		$xpath = new DOMXPath( $document );
		foreach ( $xpath->query( '//*[@style]' ) as $styled_node ) {
			$current_style = (string) $styled_node->getAttribute( 'style' );
			$styled_node->setAttribute(
				'style',
				$this->localize_css_content( $current_style, $source_url, $target_dir, 'index.html', $asset_cache, $warnings )
			);
		}

		foreach ( iterator_to_array( $document->getElementsByTagName( 'a' ) ) as $anchor ) {
			if ( ! $anchor->hasAttribute( 'href' ) ) {
				continue;
			}

			$rewritten_href = $this->rewrite_elementor_internal_href(
				(string) $anchor->getAttribute( 'href' ),
				$source_url,
				$link_map
			);

			if ( null !== $rewritten_href ) {
				$anchor->setAttribute( 'href', $rewritten_href );
			}
		}

		foreach ( iterator_to_array( $document->getElementsByTagName( 'link' ) ) as $link ) {
			if ( ! $link->hasAttribute( 'href' ) ) {
				continue;
			}

			if ( ! $this->is_asset_link_tag( $link ) ) {
				continue;
			}

			$asset_url = $this->resolve_url_against_base( (string) $link->getAttribute( 'href' ), $source_url );
			if ( ! $this->is_same_origin_url( $asset_url, $source_url ) ) {
				continue;
			}

			$localized = $this->download_elementor_asset( $asset_url, $target_dir, $asset_cache, $warnings );
			if ( '' !== $localized ) {
				$link->setAttribute( 'href', $localized );
			}

			if ( $link->hasAttribute( 'imagesrcset' ) ) {
				$link->setAttribute(
					'imagesrcset',
					$this->localize_srcset_value( (string) $link->getAttribute( 'imagesrcset' ), $source_url, $target_dir, 'index.html', $asset_cache, $warnings )
				);
			}
		}

		foreach ( iterator_to_array( $document->getElementsByTagName( 'script' ) ) as $script ) {
			if ( ! $script->hasAttribute( 'src' ) ) {
				continue;
			}

			$asset_url = $this->resolve_url_against_base( (string) $script->getAttribute( 'src' ), $source_url );
			if ( ! $this->is_same_origin_url( $asset_url, $source_url ) ) {
				continue;
			}

			$localized = $this->download_elementor_asset( $asset_url, $target_dir, $asset_cache, $warnings );
			if ( '' !== $localized ) {
				$script->setAttribute( 'src', $localized );
			}
		}

		$asset_attributes = array(
			'img'    => array( 'src', 'srcset' ),
			'source' => array( 'src', 'srcset' ),
			'video'  => array( 'src', 'poster' ),
			'audio'  => array( 'src' ),
			'track'  => array( 'src' ),
			'iframe' => array( 'src' ),
		);

		foreach ( $asset_attributes as $tag_name => $attributes ) {
			foreach ( iterator_to_array( $document->getElementsByTagName( $tag_name ) ) as $node ) {
				foreach ( $attributes as $attribute ) {
					if ( ! $node->hasAttribute( $attribute ) ) {
						continue;
					}

					if ( 'srcset' === $attribute ) {
						$node->setAttribute(
							$attribute,
							$this->localize_srcset_value( (string) $node->getAttribute( $attribute ), $source_url, $target_dir, 'index.html', $asset_cache, $warnings )
						);
						continue;
					}

					$asset_url = $this->resolve_url_against_base( (string) $node->getAttribute( $attribute ), $source_url );
					if ( ! $this->is_same_origin_url( $asset_url, $source_url ) ) {
						continue;
					}

					$localized = $this->download_elementor_asset( $asset_url, $target_dir, $asset_cache, $warnings );
					if ( '' !== $localized ) {
						$node->setAttribute( $attribute, $localized );
					}
				}
			}
		}

		$html_node = $document->getElementsByTagName( 'html' )->item( 0 );
		$final_html = $html_node ? $doctype . "\n" . $document->saveHTML( $html_node ) : $doctype . "\n" . $document->saveHTML();

		return array(
			'html'       => $final_html,
			'warnings'   => array_values( array_unique( $warnings ) ),
			'asset_count'=> count( $asset_cache ),
		);
	}

	/**
	 * Remove obvious wp-admin noise from a captured frontend document.
	 *
	 * @param string $html Captured HTML.
	 * @return string
	 */
	protected function strip_admin_markup_from_document( $html ) {
		$html = (string) $html;
		$html = preg_replace( '/<div[^>]+id=["\']wpadminbar["\'][\s\S]*?<\/div>/i', '', $html );
		$html = preg_replace( '/<style[^>]*>[^<]*html\s*\{\s*margin-top:\s*32px[^<]*<\/style>/i', '', $html );
		$html = str_replace( ' admin-bar', '', $html );

		return $html;
	}

	/**
	 * Determine whether a <link> tag points to an asset that should be localized.
	 *
	 * @param DOMElement $link Link element.
	 * @return bool
	 */
	protected function is_asset_link_tag( DOMElement $link ) {
		$rel = strtolower( trim( (string) $link->getAttribute( 'rel' ) ) );
		if ( '' === $rel ) {
			return false;
		}

		foreach ( array( 'stylesheet', 'preload', 'prefetch', 'modulepreload', 'icon', 'apple-touch-icon' ) as $asset_rel ) {
			if ( false !== strpos( $rel, $asset_rel ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Rewrite one internal anchor href if it targets another selected exported page.
	 *
	 * @param string $href Original href.
	 * @param string $source_url Current source page URL.
	 * @param array  $link_map Source alias -> target URL map.
	 * @return string|null
	 */
	protected function rewrite_elementor_internal_href( $href, $source_url, array $link_map ) {
		$href = trim( (string) $href );
		if ( '' === $href || '#' === substr( $href, 0, 1 ) || preg_match( '/^(mailto:|tel:|javascript:|data:)/i', $href ) ) {
			return null;
		}

		$absolute = $this->resolve_url_against_base( $href, $source_url );
		foreach ( $this->build_url_aliases( $absolute ) as $alias ) {
			if ( isset( $link_map[ $alias ] ) ) {
				$suffix = '';
				$parts  = wp_parse_url( $href );
				if ( ! empty( $parts['query'] ) ) {
					$suffix .= '?' . $parts['query'];
				}
				if ( ! empty( $parts['fragment'] ) ) {
					$suffix .= '#' . $parts['fragment'];
				}

				return $link_map[ $alias ] . $suffix;
			}
		}

		return null;
	}

	/**
	 * Localize a CSS srcset string into the package.
	 *
	 * @param string $srcset Srcset value.
	 * @param string $base_url Base URL.
	 * @param string $target_dir Export directory.
	 * @param string $current_rel_path Current local file path.
	 * @param array  $asset_cache Shared localized asset cache.
	 * @param array  $warnings Warning list.
	 * @return string
	 */
	protected function localize_srcset_value( $srcset, $base_url, $target_dir, $current_rel_path, array &$asset_cache, array &$warnings ) {
		$entries = array_map( 'trim', explode( ',', (string) $srcset ) );
		$rebuilt = array();

		foreach ( $entries as $entry ) {
			if ( '' === $entry ) {
				continue;
			}

			$parts = preg_split( '/\s+/', $entry, 2 );
			$url   = isset( $parts[0] ) ? $parts[0] : '';
			$desc  = isset( $parts[1] ) ? $parts[1] : '';
			$absolute = $this->resolve_url_against_base( $url, $base_url );

			if ( $this->is_same_origin_url( $absolute, $base_url ) ) {
				$localized = $this->download_elementor_asset( $absolute, $target_dir, $asset_cache, $warnings );
				if ( '' !== $localized ) {
					$url = $this->relative_path_between_files( $current_rel_path, $localized );
				}
			}

			$rebuilt[] = trim( $url . ' ' . $desc );
		}

		return implode( ', ', $rebuilt );
	}

	/**
	 * Localize CSS file/inline content by downloading same-origin assets and rewriting
	 * their references relative to the current CSS file or HTML document.
	 *
	 * @param string $css CSS content.
	 * @param string $base_url Base URL.
	 * @param string $target_dir Export directory.
	 * @param string $current_rel_path Current relative file path.
	 * @param array  $asset_cache Shared asset cache.
	 * @param array  $warnings Warning list.
	 * @return string
	 */
	protected function localize_css_content( $css, $base_url, $target_dir, $current_rel_path, array &$asset_cache, array &$warnings ) {
		$self = $this;

		$css = preg_replace_callback(
			'/url\(\s*([\'"]?)([^\'")]+)\1\s*\)/i',
			function ( $matches ) use ( $self, $base_url, $target_dir, $current_rel_path, &$asset_cache, &$warnings ) {
				$reference = trim( (string) $matches[2] );
				if ( '' === $reference || preg_match( '/^(data:|javascript:|about:|#)/i', $reference ) ) {
					return $matches[0];
				}

				$absolute = $self->resolve_url_against_base( $reference, $base_url );
				if ( ! $self->is_same_origin_url( $absolute, $base_url ) ) {
					return $matches[0];
				}

				$localized = $self->download_elementor_asset( $absolute, $target_dir, $asset_cache, $warnings );
				if ( '' === $localized ) {
					return $matches[0];
				}

				$relative = $self->relative_path_between_files( $current_rel_path, $localized );
				return 'url(' . $matches[1] . $relative . $matches[1] . ')';
			},
			(string) $css
		);

		$css = preg_replace_callback(
			'/@import\s+(?:url\()?\s*([\'"]?)([^\'")]+)\1\s*\)?/i',
			function ( $matches ) use ( $self, $base_url, $target_dir, $current_rel_path, &$asset_cache, &$warnings ) {
				$reference = trim( (string) $matches[2] );
				if ( '' === $reference ) {
					return $matches[0];
				}

				$absolute = $self->resolve_url_against_base( $reference, $base_url );
				if ( ! $self->is_same_origin_url( $absolute, $base_url ) ) {
					return $matches[0];
				}

				$localized = $self->download_elementor_asset( $absolute, $target_dir, $asset_cache, $warnings );
				if ( '' === $localized ) {
					return $matches[0];
				}

				$relative = $self->relative_path_between_files( $current_rel_path, $localized );
				return '@import url("' . $relative . '")';
			},
			$css
		);

		return (string) $css;
	}

	/**
	 * Download one same-origin asset into the export package, recursively rewriting
	 * CSS assets when needed.
	 *
	 * @param string $absolute_url Absolute source asset URL.
	 * @param string $target_dir Export directory.
	 * @param array  $asset_cache Shared asset cache.
	 * @param array  $warnings Warning list.
	 * @return string Relative localized asset path or empty string on failure.
	 */
	protected function download_elementor_asset( $absolute_url, $target_dir, array &$asset_cache, array &$warnings ) {
		$absolute_url = preg_replace( '/#.*$/', '', trim( (string) $absolute_url ) );

		if ( isset( $asset_cache[ $absolute_url ] ) ) {
			return $asset_cache[ $absolute_url ];
		}

		$relative_path = $this->build_local_asset_path_from_url( $absolute_url );
		if ( '' === $relative_path ) {
			return '';
		}

		$absolute_path = trailingslashit( wp_normalize_path( $target_dir ) ) . $relative_path;
		wp_mkdir_p( dirname( $absolute_path ) );

		$response = wp_remote_get(
			$absolute_url,
			array(
				'timeout'    => 25,
				'redirection'=> 5,
				'headers'    => array(
					'User-Agent' => 'Reputifly Archimedes Elementor Asset Export/' . RSPD_VERSION,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			$warnings[] = sprintf( 'Could not localize asset: %s', $absolute_url );
			return '';
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = (string) wp_remote_retrieve_body( $response );
		if ( $status < 200 || $status >= 300 || '' === $body ) {
			$warnings[] = sprintf( 'Asset returned an invalid response and stayed external: %s', $absolute_url );
			return '';
		}

		$extension = strtolower( pathinfo( wp_parse_url( $absolute_url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
		if ( 'css' === $extension ) {
			$body = $this->localize_css_content( $body, $absolute_url, $target_dir, $relative_path, $asset_cache, $warnings );
		}

		if ( ! $this->storage->write_file( $absolute_path, $body ) ) {
			$warnings[] = sprintf( 'Localized asset could not be written: %s', $absolute_url );
			return '';
		}

		$asset_cache[ $absolute_url ] = $relative_path;
		return $relative_path;
	}

	/**
	 * Build a stable local asset path from a source URL.
	 *
	 * @param string $absolute_url Absolute asset URL.
	 * @return string
	 */
	protected function build_local_asset_path_from_url( $absolute_url ) {
		$path = (string) wp_parse_url( $absolute_url, PHP_URL_PATH );
		$path = ltrim( wp_normalize_path( $path ), '/' );
		$path = $this->security->normalize_relative_path( $path );

		if ( '' === $path ) {
			return '';
		}

		$query = (string) wp_parse_url( $absolute_url, PHP_URL_QUERY );
		if ( '' !== $query ) {
			$extension = pathinfo( $path, PATHINFO_EXTENSION );
			$dirname   = '.' === dirname( $path ) ? '' : dirname( $path );
			$basename  = basename( $path, $extension ? '.' . $extension : '' );
			$suffix    = '-' . substr( sha1( $query ), 0, 8 );
			$filename  = $basename . $suffix . ( $extension ? '.' . $extension : '' );
			$path      = trim( $dirname ? $dirname . '/' . $filename : $filename, '/' );
		}

		return 'local-assets/' . ltrim( $path, '/' );
	}

	/**
	 * Resolve a possibly relative URL against a base URL.
	 *
	 * @param string $reference Reference URL.
	 * @param string $base_url Base URL.
	 * @return string
	 */
	protected function resolve_url_against_base( $reference, $base_url ) {
		$reference = trim( (string) $reference );
		$base_url  = trim( (string) $base_url );

		if ( '' === $reference ) {
			return '';
		}

		if ( preg_match( '#^https?://#i', $reference ) ) {
			return $reference;
		}

		$base = wp_parse_url( $base_url );
		if ( empty( $base['scheme'] ) || empty( $base['host'] ) ) {
			return $reference;
		}

		$origin = $base['scheme'] . '://' . $base['host'] . ( ! empty( $base['port'] ) ? ':' . $base['port'] : '' );

		if ( 0 === strpos( $reference, '//' ) ) {
			return $base['scheme'] . ':' . $reference;
		}

		if ( 0 === strpos( $reference, '/' ) ) {
			return $origin . $reference;
		}

		$base_path = ! empty( $base['path'] ) ? $base['path'] : '/';
		$base_dir  = preg_replace( '#/[^/]*$#', '/', $base_path );
		$combined  = $base_dir . $reference;
		$segments  = array();

		foreach ( explode( '/', wp_normalize_path( $combined ) ) as $segment ) {
			if ( '' === $segment || '.' === $segment ) {
				continue;
			}

			if ( '..' === $segment ) {
				array_pop( $segments );
				continue;
			}

			$segments[] = $segment;
		}

		return $origin . '/' . implode( '/', $segments );
	}

	/**
	 * Determine whether an absolute URL points to the same origin as the source page.
	 *
	 * @param string $candidate_url Candidate absolute URL.
	 * @param string $origin_url Source page URL.
	 * @return bool
	 */
	protected function is_same_origin_url( $candidate_url, $origin_url ) {
		$candidate = wp_parse_url( (string) $candidate_url );
		$origin    = wp_parse_url( (string) $origin_url );

		if ( empty( $candidate['host'] ) || empty( $origin['host'] ) ) {
			return false;
		}

		$candidate_port = ! empty( $candidate['port'] ) ? (string) $candidate['port'] : '';
		$origin_port    = ! empty( $origin['port'] ) ? (string) $origin['port'] : '';

		return strtolower( (string) $candidate['host'] ) === strtolower( (string) $origin['host'] )
			&& strtolower( (string) $candidate['scheme'] ) === strtolower( (string) $origin['scheme'] )
			&& $candidate_port === $origin_port;
	}

	/**
	 * Build URL aliases for exact-match internal link rewrites.
	 *
	 * @param string $url Absolute URL.
	 * @return array
	 */
	protected function build_url_aliases( $url ) {
		$url      = trim( (string) $url );
		$aliases  = array();
		$path     = wp_make_link_relative( $url );
		$path     = '' === $path ? '/' : $path;
		$trimmed  = untrailingslashit( $url );
		$trimmed_path = untrailingslashit( $path );

		if ( '' !== $url ) {
			$aliases[] = $url;
			$aliases[] = trailingslashit( $trimmed );
			$aliases[] = $trimmed;
		}

		if ( '' !== $trimmed_path ) {
			$aliases[] = $path;
			$aliases[] = trailingslashit( $trimmed_path );
			$aliases[] = $trimmed_path;
		}

		return array_values( array_unique( array_filter( $aliases ) ) );
	}

	/**
	 * Build a relative reference from one package file to another.
	 *
	 * @param string $from_rel_path Current file path.
	 * @param string $to_rel_path Destination file path.
	 * @return string
	 */
	protected function relative_path_between_files( $from_rel_path, $to_rel_path ) {
		$from_dir = trim( dirname( wp_normalize_path( (string) $from_rel_path ) ), './' );
		$to_path  = trim( wp_normalize_path( (string) $to_rel_path ), '/' );

		if ( '' === $from_dir ) {
			return $to_path;
		}

		$from_segments = '' === $from_dir ? array() : explode( '/', $from_dir );
		$to_segments   = explode( '/', $to_path );

		while ( ! empty( $from_segments ) && ! empty( $to_segments ) && $from_segments[0] === $to_segments[0] ) {
			array_shift( $from_segments );
			array_shift( $to_segments );
		}

		return str_repeat( '../', count( $from_segments ) ) . implode( '/', $to_segments );
	}

	/**
	 * Remove a directory tree recursively.
	 *
	 * @param string $absolute_dir Directory path.
	 * @return void
	 */
	protected function remove_directory_recursive( $absolute_dir ) {
		$absolute_dir = wp_normalize_path( (string) $absolute_dir );
		if ( '' === $absolute_dir || ! is_dir( $absolute_dir ) ) {
			return;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $absolute_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $iterator as $item ) {
			if ( $item->isDir() ) {
				@rmdir( $item->getPathname() );
				continue;
			}

			@unlink( $item->getPathname() );
		}

		@rmdir( $absolute_dir );
	}

	/**
	 * Convert upload errors into readable messages.
	 *
	 * @param int $error_code PHP upload error code.
	 * @return string
	 */
	protected function get_upload_error_message( $error_code ) {
		switch ( $error_code ) {
			case UPLOAD_ERR_INI_SIZE:
			case UPLOAD_ERR_FORM_SIZE:
				return __( 'The uploaded file exceeded the server upload size limit.', 'reputifly-static-page-deployer' );
			case UPLOAD_ERR_PARTIAL:
				return __( 'The uploaded file was only partially received.', 'reputifly-static-page-deployer' );
			case UPLOAD_ERR_NO_FILE:
				return __( 'No file was uploaded.', 'reputifly-static-page-deployer' );
			default:
				return __( 'The uploaded package could not be processed.', 'reputifly-static-page-deployer' );
		}
	}
}
