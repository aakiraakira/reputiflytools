<?php
/**
 * Frontend renderer.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles page interception and rendering templates.
 */
class RSPD_Renderer {

	/**
	 * Storage helper.
	 *
	 * @var RSPD_Storage
	 */
	protected $storage;

	/**
	 * Performance helper.
	 *
	 * @var RSPD_Performance
	 */
	protected $performance;

	/**
	 * Licensing helper.
	 *
	 * @var RSPD_License
	 */
	protected $license;

	/**
	 * Current page config.
	 *
	 * @var array|null
	 */
	protected $current_config = null;

	/**
	 * Current render bundle.
	 *
	 * @var array|null
	 */
	protected $current_bundle = null;

	/**
	 * Current managed page ID.
	 *
	 * @var int
	 */
	protected $managed_page_id = 0;

	/**
	 * Whether the current managed request is blocked by licensing.
	 *
	 * @var bool
	 */
	protected $license_blocked_request = false;

	/**
	 * Active A/B variant key (null if no test running).
	 *
	 * @var string|null
	 */
	protected $active_variant_key = null;

	/**
	 * Constructor.
	 *
	 * @param RSPD_Storage     $storage     Storage helper.
	 * @param RSPD_Performance $performance Performance helper.
	 * @param RSPD_License     $license     Licensing helper.
	 */
	public function __construct( RSPD_Storage $storage, RSPD_Performance $performance, RSPD_License $license ) {
		$this->storage     = $storage;
		$this->performance = $performance;
		$this->license     = $license;

		add_action( 'init', array( $this, 'register_asset_route' ), 0 );
		add_filter( 'query_vars', array( $this, 'register_query_vars' ) );
		add_action( 'admin_init', array( $this, 'maybe_flush_asset_routes' ) );
		add_action( 'template_redirect', array( $this, 'maybe_serve_software_request' ), -110 );
		add_action( 'template_redirect', array( $this, 'maybe_serve_asset_request' ), -100 );
		add_action( 'template_redirect', array( $this, 'prepare_request' ), 0 );
		add_filter( 'template_include', array( $this, 'maybe_override_template' ), 999 );
	}

	/**
	 * Register the public asset route for uploaded static packages.
	 *
	 * @return void
	 */
	public function register_asset_route() {
		add_rewrite_rule(
			'^reputifly-static-assets/([0-9]+)/?(.*)$',
			'index.php?rspd_asset_page=$matches[1]&rspd_asset_path=$matches[2]',
			'top'
		);
	}

	/**
	 * Register query vars for the public asset route.
	 *
	 * @param array $vars Existing vars.
	 * @return array
	 */
	public function register_query_vars( $vars ) {
		$vars[] = 'rspd_asset_page';
		$vars[] = 'rspd_asset_path';

		return $vars;
	}

	/**
	 * Flush asset routes once after plugin upgrades so the public route works.
	 *
	 * @return void
	 */
	public function maybe_flush_asset_routes() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$version = get_option( 'rspd_asset_route_version', '' );

		if ( RSPD_VERSION === $version ) {
			return;
		}

		$this->register_asset_route();
		flush_rewrite_rules( false );
		update_option( 'rspd_asset_route_version', RSPD_VERSION, false );
	}

	/**
	 * Serve mounted software apps before WordPress falls through to normal templates.
	 *
	 * @return void
	 */
	public function maybe_serve_software_request() {
		if ( is_admin() ) {
			return;
		}

		$request_path = $this->get_public_request_path();

		if ( '' === $request_path ) {
			return;
		}

		$segments = array_values( array_filter( explode( '/', $request_path ), 'strlen' ) );

		if ( empty( $segments[0] ) ) {
			return;
		}

		$slug = sanitize_title( rawurldecode( $segments[0] ) );
		$app  = $this->storage->get_software_app( $slug );

		if ( empty( $app['enabled'] ) || empty( $app['relative_dir'] ) ) {
			return;
		}

		$this->license->maybe_refresh_status( false, 'frontend' );

		if ( $this->license->should_block_frontend() ) {
			status_header( 403 );
			nocache_headers();
			include RSPD_PLUGIN_PATH . 'templates/inactive-license-template.php';
			exit;
		}

		$requested_path = implode( '/', array_slice( $segments, 1 ) );
		$file_path      = $this->resolve_software_request_file( $requested_path, $app );

		if ( '' === $file_path ) {
			$this->send_asset_error( 404 );
		}

		$deployment_dir = $this->storage->get_deployment_path( $app['relative_dir'] );
		$absolute_path  = trailingslashit( $deployment_dir ) . $file_path;

		if ( ! is_file( $absolute_path ) || ! is_readable( $absolute_path ) ) {
			$this->send_asset_error( 404 );
		}

		$mime = $this->detect_asset_mime_type( $absolute_path, $file_path );

		status_header( 200 );
		header( 'Content-Type: ' . $mime );
		header( 'Content-Length: ' . filesize( $absolute_path ) );
		header( 'Cache-Control: public, max-age=3600' );

		readfile( $absolute_path ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.file_ops_readfile
		exit;
	}

	/**
	 * Serve uploaded deployment files through WordPress.
	 *
	 * @return void
	 */
	public function maybe_serve_asset_request() {
		$page_id = absint( get_query_var( 'rspd_asset_page' ) );

		if ( ! $page_id ) {
			return;
		}

		$relative_path = (string) get_query_var( 'rspd_asset_path' );
		$relative_path = rspd()->security()->normalize_relative_path( $relative_path );

		if ( '' === $relative_path || 'render.json' === basename( $relative_path ) ) {
			$this->send_asset_error( 404 );
		}

		$config = $this->storage->get_page_config( $page_id );

		if ( empty( $config['enabled'] ) || empty( $config['deployment_rel_dir'] ) ) {
			$this->send_asset_error( 404 );
		}

		$this->license->maybe_refresh_status( false, 'asset' );

		if ( $this->license->should_block_frontend() ) {
			$this->send_asset_error( 403 );
		}

		$redirect_target = $this->resolve_asset_page_redirect( $page_id, $relative_path, $config );

		if ( $redirect_target ) {
			wp_safe_redirect( $redirect_target, 302 );
			exit;
		}

		$absolute_path = trailingslashit( $this->storage->get_deployment_path( $config['deployment_rel_dir'] ) ) . $relative_path;

		if ( ! is_file( $absolute_path ) || ! is_readable( $absolute_path ) ) {
			$this->send_asset_error( 404 );
		}

		$mime = $this->detect_asset_mime_type( $absolute_path, $relative_path );

		if ( headers_sent() ) {
			readfile( $absolute_path ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.file_ops_readfile
			exit;
		}

		status_header( 200 );
		header( 'Content-Type: ' . $mime );
		header( 'Content-Length: ' . filesize( $absolute_path ) );
		header( 'Cache-Control: public, max-age=3600' );

		readfile( $absolute_path ); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.file_ops_readfile
		exit;
	}

	/**
	 * Redirect HTML asset requests back to mapped WordPress pages when possible.
	 *
	 * This catches older/stale package links such as
	 * `/reputifly-static-assets/{page}/services.html` and sends them to the
	 * managed `/services/` page instead of exposing the raw asset URL.
	 *
	 * @param int    $page_id       Current managed page id from the asset route.
	 * @param string $relative_path Requested asset path.
	 * @param array  $config        Current page config.
	 * @return string
	 */
	protected function resolve_asset_page_redirect( $page_id, $relative_path, array $config ) {
		$security = rspd()->security();

		if ( ! $security->is_html_reference( $relative_path ) ) {
			return '';
		}

		$current_aliases = $security->build_html_reference_aliases( isset( $config['entry_file'] ) ? $config['entry_file'] : '' );
		$requested_aliases = $security->build_html_reference_aliases( $relative_path );

		if ( ! empty( array_intersect( $requested_aliases, $current_aliases ) ) ) {
			return get_permalink( $page_id );
		}

		$package_key = isset( $config['package_key'] ) ? trim( (string) $config['package_key'] ) : '';
		$link_map    = $this->storage->build_html_link_map( $page_id, $package_key );

		foreach ( $requested_aliases as $alias ) {
			if ( ! empty( $link_map[ $alias ] ) ) {
				return $link_map[ $alias ];
			}
		}

		return '';
	}

	/**
	 * Resolve a mounted software app request path to a file in its deployment.
	 *
	 * @param string $requested_path Request path after the app slug.
	 * @param array  $app Stored software app record.
	 * @return string
	 */
	protected function resolve_software_request_file( $requested_path, array $app ) {
		$deployment_dir  = $this->storage->get_deployment_path( $app['relative_dir'] );
		$raw_path        = wp_normalize_path( rawurldecode( (string) $requested_path ) );
		$requested_path  = trim( $raw_path, '/' );
		$security        = rspd()->security();
		$trailing_slash  = '' !== $requested_path && '/' === substr( $raw_path, -1 );

		if ( '' === $requested_path ) {
			return isset( $app['entry_file'] ) ? (string) $app['entry_file'] : '';
		}

		$candidates = array();
		$exact      = $security->normalize_relative_path( $requested_path );

		if ( '' !== $exact ) {
			$candidates[] = $exact;
		}

		if ( '' === pathinfo( $requested_path, PATHINFO_EXTENSION ) ) {
			$trimmed = trim( $requested_path, '/' );

			if ( '' !== $trimmed ) {
				$candidates[] = $security->normalize_relative_path( $trimmed . '.html' );
				$candidates[] = $security->normalize_relative_path( $trimmed . '.htm' );
				$candidates[] = $security->normalize_relative_path( $trimmed . '/index.html' );
				$candidates[] = $security->normalize_relative_path( $trimmed . '/index.htm' );
			}
		} elseif ( $trailing_slash ) {
			$candidates[] = $security->normalize_relative_path( trim( $requested_path, '/' ) . '/index.html' );
			$candidates[] = $security->normalize_relative_path( trim( $requested_path, '/' ) . '/index.htm' );
		}

		foreach ( array_values( array_unique( array_filter( $candidates ) ) ) as $candidate ) {
			$absolute = $security->safe_join( $deployment_dir, $candidate );

			if ( $absolute && is_file( $absolute ) ) {
				return $candidate;
			}
		}

		return '';
	}

	/**
	 * Get the current public request path relative to the site's home URL.
	 *
	 * @return string
	 */
	protected function get_public_request_path() {
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$request_path = (string) wp_parse_url( $request_uri, PHP_URL_PATH );
		$home_path    = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );

		$request_path = wp_normalize_path( rawurldecode( $request_path ) );
		$home_path    = wp_normalize_path( $home_path );

		if ( '' !== $home_path && '/' !== $home_path ) {
			$home_path = rtrim( $home_path, '/' );

			if ( 0 === strpos( $request_path, $home_path ) ) {
				$request_path = substr( $request_path, strlen( $home_path ) );
			}
		}

		return trim( (string) $request_path, '/' );
	}

	/**
	 * Detect the mime type for a served deployment asset.
	 *
	 * @param string $absolute_path Absolute file path.
	 * @param string $relative_path Relative deployment path.
	 * @return string
	 */
	protected function detect_asset_mime_type( $absolute_path, $relative_path ) {
		$type = wp_check_filetype( $relative_path );

		if ( ! empty( $type['type'] ) ) {
			return $type['type'];
		}

		$extension = strtolower( pathinfo( $absolute_path, PATHINFO_EXTENSION ) );
		$fallbacks = array(
			'css'  => 'text/css',
			'js'   => 'application/javascript',
			'mjs'  => 'application/javascript',
			'json' => 'application/json',
			'html' => 'text/html; charset=' . get_bloginfo( 'charset' ),
			'htm'  => 'text/html; charset=' . get_bloginfo( 'charset' ),
			'svg'  => 'image/svg+xml',
		);

		return isset( $fallbacks[ $extension ] ) ? $fallbacks[ $extension ] : 'application/octet-stream';
	}

	/**
	 * Send a simple asset error response.
	 *
	 * @param int $status HTTP status code.
	 * @return void
	 */
	protected function send_asset_error( $status ) {
		status_header( $status );
		nocache_headers();
		exit;
	}

	/**
	 * Apply runtime optimizations before template output.
	 *
	 * @return void
	 */
	public function prepare_request() {
		$config = $this->get_current_config();
		$bundle = $this->get_current_bundle();

		if ( empty( $config ) || empty( $bundle ) ) {
			return;
		}

		$this->performance->apply_runtime_hooks( $config );
	}

	/**
	 * Swap in a plugin-owned template for managed pages.
	 *
	 * @param string $template Resolved theme template.
	 * @return string
	 */
	public function maybe_override_template( $template ) {
		if ( $this->is_license_blocked_request() ) {
			return RSPD_PLUGIN_PATH . 'templates/inactive-license-template.php';
		}

		$config = $this->get_current_config();
		$bundle = $this->get_current_bundle();

		if ( empty( $config ) || empty( $bundle ) ) {
			return $template;
		}

		return RSPD_PLUGIN_PATH . 'templates/' . ( 'compatibility' === $config['render_mode'] ? 'compatibility-template.php' : 'isolated-template.php' );
	}

	/**
	 * Get the current page config if the request is managed.
	 *
	 * @return array
	 */
	public function get_current_config() {
		if ( null !== $this->current_config ) {
			return $this->current_config;
		}

		if ( is_admin() || ! is_page() ) {
			$this->current_config = array();
			return $this->current_config;
		}

		$page_id = $this->get_managed_page_id();

		if ( ! $page_id ) {
			$this->current_config = array();
			return $this->current_config;
		}

		$config = $this->storage->get_page_config( $page_id );

		if ( empty( $config['enabled'] ) || empty( $config['deployment_rel_dir'] ) ) {
			$this->current_config = array();
			return $this->current_config;
		}

		$this->license->maybe_refresh_status( false, 'frontend' );

		if ( $this->license->should_block_frontend() ) {
			$this->license_blocked_request = true;
			$this->current_config          = array();
			return $this->current_config;
		}

		// A/B test: resolve variant before caching config.
		$config = $this->resolve_ab_variant( $page_id, $config );

		$this->current_config = $config;

		return $this->current_config;
	}

	/**
	 * Get the current render bundle.
	 *
	 * @return array
	 */
	public function get_current_bundle() {
		if ( null !== $this->current_bundle ) {
			return $this->current_bundle;
		}

		$config = $this->get_current_config();

		if ( empty( $config ) ) {
			$this->current_bundle = array();
			return $this->current_bundle;
		}

		$bundle = $this->storage->load_render_bundle( $config['deployment_rel_dir'] );

		if ( empty( $bundle ) || ! is_array( $bundle ) ) {
			$this->current_bundle = array();
			return $this->current_bundle;
		}

		$this->current_bundle = $bundle;

		return $this->current_bundle;
	}

	/**
	 * Determine whether the current page is a managed deployment.
	 *
	 * @return int
	 */
	protected function get_managed_page_id() {
		if ( $this->managed_page_id > 0 ) {
			return $this->managed_page_id;
		}

		$page_id  = get_queried_object_id();
		$page_map = $this->storage->get_page_map();

		if ( ! $page_id || empty( $page_map[ $page_id ]['enabled'] ) ) {
			return 0;
		}

		$config = $this->storage->get_page_config( $page_id );

		if ( empty( $config['enabled'] ) || empty( $config['deployment_rel_dir'] ) ) {
			return 0;
		}

		$this->managed_page_id = absint( $page_id );

		return $this->managed_page_id;
	}

	/**
	 * Check whether the current managed page should show the inactive-license template.
	 *
	 * @return bool
	 */
	protected function is_license_blocked_request() {
		$this->get_current_config();

		return $this->license_blocked_request && $this->get_managed_page_id() > 0;
	}

	/**
	 * Render the isolated output with optional HTML transient caching.
	 *
	 * @return string
	 */
	public function render_isolated_page() {
		$config = $this->get_current_config();
		$bundle = $this->get_current_bundle();

		if ( empty( $config ) || empty( $bundle ) ) {
			return '';
		}

		$this->send_headers( $bundle );

		$page_id       = get_queried_object_id();
		$layout_blocks = $this->get_layout_injections_for_page( $page_id );
		$cache_enabled = ! empty( $config['performance']['enable_html_cache'] );
		$transient_key = 'rspd_render_' . absint( $page_id );
		if ( $this->active_variant_key ) {
			$transient_key .= '_' . sanitize_key( $this->active_variant_key );
		}
		if ( ! empty( $layout_blocks['hash'] ) ) {
			$transient_key .= '_shell_' . substr( sanitize_key( $layout_blocks['hash'] ), 0, 12 );
		}

		if ( $cache_enabled ) {
			$cached = get_transient( $transient_key );

			if ( ! empty( $cached['cache_version'] ) && ! empty( $config['cache_version'] ) && $cached['cache_version'] === $config['cache_version'] && ! empty( $cached['html'] ) ) {
				return (string) $cached['html'];
			}
		}

		// Raw mode: serve the HTML exactly as stored, skip compose_document.
		if ( ! empty( $bundle['raw_document'] ) ) {
			$html = $bundle['raw_document'];
		} else {
			$html = rspd()->metadata()->compose_document( $bundle );

			if ( ! empty( $bundle['performance']['minify_html'] ) ) {
				$html = $this->performance->minify_html( $html );
			}
		}

		// Inject schema JSON-LD if configured (runs on both raw and composed HTML).
		$schema_tag = $this->build_schema_tag( $config, $page_id );
		if ( $schema_tag ) {
			$html = $this->inject_into_head( $html, $schema_tag );
		}

		// Inject Open Graph + Twitter Card meta tags if configured.
		$og_tags = $this->build_social_tags( $config, $page_id );
		if ( $og_tags ) {
			$html = $this->inject_into_head( $html, $og_tags );
		}

		$html = $this->apply_layout_injections_to_document( $html, $layout_blocks );

		if ( $cache_enabled ) {
			set_transient(
				$transient_key,
				array(
					'cache_version' => isset( $config['cache_version'] ) ? $config['cache_version'] : '',
					'html'          => $html,
				),
				DAY_IN_SECONDS
			);
		}

		return $html;
	}

	/**
	 * Prepare compatibility template context.
	 *
	 * @return array
	 */
	public function get_compatibility_context() {
		$config = $this->get_current_config();
		$bundle = $this->get_current_bundle();

		if ( empty( $config ) || empty( $bundle ) ) {
			return array();
		}

		$this->send_headers( $bundle );
		$page_id       = get_queried_object_id();
		$layout_blocks = $this->get_layout_injections_for_page( $page_id );
		$head_html     = isset( $bundle['head_html'] ) ? $bundle['head_html'] : '';
		$body_html     = isset( $bundle['body_html'] ) ? $bundle['body_html'] : '';

		if ( ! empty( $layout_blocks ) ) {
			$head_html = $this->merge_layout_head_markup( $head_html, $layout_blocks );
			$body_html = $this->wrap_body_content_with_layout_injections( $body_html, $layout_blocks );
		}

		return array(
			'doctype'         => ! empty( $bundle['doctype'] ) ? $bundle['doctype'] : '<!doctype html>',
			'html_attrs'      => ! empty( $bundle['html_attrs'] ) ? $bundle['html_attrs'] : 'lang="' . esc_attr( str_replace( '_', '-', get_locale() ) ) . '"',
			'body_attrs'      => ! empty( $bundle['body_attrs'] ) ? $bundle['body_attrs'] : 'class="rspd-deployed-page"',
			'head_html'       => $head_html,
			'body_html'       => $body_html,
			'allow_wp_head'   => ! empty( $config['compatibility']['wp_head'] ),
			'allow_wp_footer' => ! empty( $config['compatibility']['wp_footer'] ),
		);
	}

	/**
	 * Resolve A/B test variant for the current visitor.
	 *
	 * @param int   $page_id Page ID.
	 * @param array $config  Full page config.
	 * @return array Modified config (deployment_rel_dir swapped to variant).
	 */
	protected function resolve_ab_variant( $page_id, array $config ) {
		if ( empty( $config['ab_test']['enabled'] ) || empty( $config['ab_test']['variants'] ) ) {
			return $config;
		}

		$variants   = $config['ab_test']['variants'];
		$cookie_key = 'rspd_ab_' . absint( $page_id );

		// Check existing cookie.
		$assigned = isset( $_COOKIE[ $cookie_key ] ) ? sanitize_key( $_COOKIE[ $cookie_key ] ) : '';

		if ( empty( $assigned ) || ! isset( $variants[ $assigned ] ) ) {
			// Weighted random selection.
			$total = 0;
			foreach ( $variants as $v ) {
				$total += isset( $v['weight'] ) ? absint( $v['weight'] ) : 0;
			}
			if ( $total < 1 ) {
				$total = 1;
			}

			$rand = mt_rand( 1, $total );
			$sum  = 0;
			foreach ( $variants as $key => $v ) {
				$sum += isset( $v['weight'] ) ? absint( $v['weight'] ) : 0;
				if ( $rand <= $sum ) {
					$assigned = $key;
					break;
				}
			}

			// Set cookie (30 days, scoped to page path).
			if ( ! headers_sent() ) {
				$path = wp_make_link_relative( get_permalink( $page_id ) );
				setcookie( $cookie_key, $assigned, time() + ( 30 * DAY_IN_SECONDS ), $path, '', is_ssl(), false );
			}
		}

		$this->active_variant_key = $assigned;

		// Swap deployment directory + cache version to variant's values.
		if ( isset( $variants[ $assigned ] ) ) {
			$v = $variants[ $assigned ];
			if ( ! empty( $v['deployment_rel_dir'] ) ) {
				$config['deployment_rel_dir'] = $v['deployment_rel_dir'];
			}
			if ( ! empty( $v['cache_version'] ) ) {
				$config['cache_version'] = $v['cache_version'];
			}

			// Apply variant-specific page overrides on top of the resolved config.
			if ( ! empty( $v['page_overrides'] ) && is_array( $v['page_overrides'] ) ) {
				$config = $this->storage->apply_overrides_to_config( $config, $v['page_overrides'] );
			}
		}

		return $config;
	}

	/**
	 * Build a JSON-LD <script> tag from the page schema config.
	 *
	 * @param array $config  Page config.
	 * @param int   $page_id WordPress page ID.
	 * @return string JSON-LD script tag or empty string.
	 */
	protected function build_schema_tag( array $config, $page_id ) {
		if ( empty( $config['schema']['type'] ) || 'none' === $config['schema']['type'] ) {
			return '';
		}

		$s    = $config['schema'];
		$type = $s['type'];

		// Pro Mode: raw JSON-LD — inject directly (validated JSON stored at save time).
		if ( 'custom_json' === $type && ! empty( $s['json_ld'] ) ) {
			$decoded = json_decode( $s['json_ld'], true );
			if ( json_last_error() === JSON_ERROR_NONE && is_array( $decoded ) ) {
				// Ensure @context is present for Google.
				if ( empty( $decoded['@context'] ) ) {
					$decoded['@context'] = 'https://schema.org';
				}
				return '<script type="application/ld+json">'
					. wp_json_encode( $decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT )
					. '</script>';
			}
			return '';
		}

		$url  = get_permalink( $page_id );
		$post = get_post( $page_id );
		$name = ! empty( $s['name'] ) ? $s['name'] : ( $post ? $post->post_title : '' );
		$desc = isset( $s['description'] ) ? $s['description'] : '';
		$schema = array();

		switch ( $type ) {
			case 'local_business':
				$btype  = ! empty( $s['business_type'] ) ? $s['business_type'] : 'LocalBusiness';
				$schema = array( '@context' => 'https://schema.org', '@type' => $btype, 'name' => $name, 'url' => $url );
				if ( $desc )                        $schema['description']  = $desc;
				if ( ! empty( $s['telephone'] ) )   $schema['telephone']    = $s['telephone'];
				if ( ! empty( $s['email'] ) )       $schema['email']        = $s['email'];
				if ( ! empty( $s['hours'] ) )       $schema['openingHours'] = $s['hours'];
				if ( ! empty( $s['price_range'] ) ) $schema['priceRange']   = $s['price_range'];
				$addr_fields = array(
					'streetAddress'   => isset( $s['street_address'] ) ? $s['street_address'] : '',
					'addressLocality' => isset( $s['city'] )           ? $s['city'] : '',
					'addressRegion'   => isset( $s['state'] )          ? $s['state'] : '',
					'postalCode'      => isset( $s['postal_code'] )    ? $s['postal_code'] : '',
					'addressCountry'  => isset( $s['country'] )        ? $s['country'] : 'US',
				);
				$addr_clean = array_filter( $addr_fields );
				if ( ! empty( $addr_clean ) ) {
					$schema['address'] = array_merge( array( '@type' => 'PostalAddress' ), $addr_clean );
				}
				break;

			case 'webpage':
				$schema = array( '@context' => 'https://schema.org', '@type' => 'WebPage', 'name' => $name, 'url' => $url );
				if ( $desc ) $schema['description'] = $desc;
				break;

			case 'article':
				$schema = array( '@context' => 'https://schema.org', '@type' => 'Article', 'headline' => $name, 'url' => $url );
				if ( $desc )                           $schema['description']   = $desc;
				if ( ! empty( $s['author_name'] ) )    $schema['author']        = array( '@type' => 'Person', 'name' => $s['author_name'] );
				if ( ! empty( $s['publisher_name'] ) ) {
					$pub = array( '@type' => 'Organization', 'name' => $s['publisher_name'] );
					if ( ! empty( $s['publisher_logo'] ) ) {
						$pub['logo'] = array( '@type' => 'ImageObject', 'url' => $s['publisher_logo'] );
					}
					$schema['publisher'] = $pub;
				}
				if ( ! empty( $s['date_published'] ) ) $schema['datePublished'] = $s['date_published'];
				$schema['dateModified'] = gmdate( 'Y-m-d' );
				break;

			case 'faq':
				$faqs  = isset( $s['faqs'] ) && is_array( $s['faqs'] ) ? $s['faqs'] : array();
				$items = array();
				foreach ( $faqs as $faq ) {
					if ( ! empty( $faq['question'] ) && ! empty( $faq['answer'] ) ) {
						$items[] = array(
							'@type' => 'Question',
							'name'  => $faq['question'],
							'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $faq['answer'] ),
						);
					}
				}
				if ( empty( $items ) ) return '';
				$schema = array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $items );
				break;

			case 'product':
				$schema = array( '@context' => 'https://schema.org', '@type' => 'Product', 'name' => $name, 'url' => $url );
				if ( $desc )                       $schema['description'] = $desc;
				if ( ! empty( $s['brand_name'] ) ) $schema['brand']       = array( '@type' => 'Brand', 'name' => $s['brand_name'] );
				if ( ! empty( $s['price'] ) ) {
					$schema['offers'] = array(
						'@type'         => 'Offer',
						'price'         => $s['price'],
						'priceCurrency' => ! empty( $s['currency'] ) ? $s['currency'] : 'USD',
						'availability'  => 'https://schema.org/InStock',
					);
				}
				break;

			case 'service':
				$schema = array( '@context' => 'https://schema.org', '@type' => 'Service', 'name' => $name, 'url' => $url );
				if ( $desc )                           $schema['description'] = $desc;
				if ( ! empty( $s['provider_name'] ) )  $schema['provider']    = array( '@type' => 'LocalBusiness', 'name' => $s['provider_name'] );
				if ( ! empty( $s['area_served'] ) )    $schema['areaServed']  = $s['area_served'];
				break;

			default:
				return '';
		}

		if ( empty( $schema ) ) {
			return '';
		}

		return '<script type="application/ld+json">'
			. wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT )
			. '</script>';
	}

	/**
	 * Build Open Graph + Twitter Card meta tags from page social config.
	 *
	 * @param array $config  Page config.
	 * @param int   $page_id WordPress page ID.
	 * @return string Meta tags or empty string.
	 */
	protected function build_social_tags( array $config, $page_id ) {
		if ( empty( $config['social'] ) || ! is_array( $config['social'] ) ) {
			return '';
		}

		$s    = $config['social'];
		$post = get_post( $page_id );
		$url  = get_permalink( $page_id );
		$tags = array();

		// Open Graph tags.
		$og_title = ! empty( $s['og_title'] ) ? $s['og_title'] : ( $post ? $post->post_title : '' );
		if ( $og_title ) {
			$tags[] = '<meta property="og:title" content="' . esc_attr( $og_title ) . '">';
		}
		if ( ! empty( $s['og_description'] ) ) {
			$tags[] = '<meta property="og:description" content="' . esc_attr( $s['og_description'] ) . '">';
		}
		if ( ! empty( $s['og_image'] ) ) {
			$tags[] = '<meta property="og:image" content="' . esc_url( $s['og_image'] ) . '">';
		}
		$og_type = ! empty( $s['og_type'] ) ? $s['og_type'] : 'website';
		$tags[] = '<meta property="og:type" content="' . esc_attr( $og_type ) . '">';
		$tags[] = '<meta property="og:url" content="' . esc_url( $url ) . '">';
		if ( ! empty( $s['og_site_name'] ) ) {
			$tags[] = '<meta property="og:site_name" content="' . esc_attr( $s['og_site_name'] ) . '">';
		}

		// Twitter Card tags — inherit from OG if not set separately.
		$tw_card = ! empty( $s['twitter_card'] ) ? $s['twitter_card'] : ( ! empty( $s['og_image'] ) ? 'summary_large_image' : 'summary' );
		$tags[] = '<meta name="twitter:card" content="' . esc_attr( $tw_card ) . '">';
		if ( $og_title ) {
			$tags[] = '<meta name="twitter:title" content="' . esc_attr( $og_title ) . '">';
		}
		if ( ! empty( $s['og_description'] ) ) {
			$tags[] = '<meta name="twitter:description" content="' . esc_attr( $s['og_description'] ) . '">';
		}
		if ( ! empty( $s['og_image'] ) ) {
			$tags[] = '<meta name="twitter:image" content="' . esc_url( $s['og_image'] ) . '">';
		}

		if ( empty( $tags ) ) {
			return '';
		}

		return '<!-- Reputifly Social Tags -->' . "\n" . implode( "\n", $tags );
	}

	/**
	 * Inject a tag immediately after <head>.
	 *
	 * @param string $html Full HTML document.
	 * @param string $tag  Tag string to inject.
	 * @return string Modified HTML.
	 */
	protected function inject_into_head( $html, $tag ) {
		if ( preg_match( '/<head[^>]*>/i', $html, $m, PREG_OFFSET_CAPTURE ) ) {
			$pos  = $m[0][1] + strlen( $m[0][0] );
			return substr( $html, 0, $pos ) . "\n" . $tag . "\n" . substr( $html, $pos );
		}
		// Fallback: inject after <!DOCTYPE> or at start of document.
		if ( preg_match( '/<!doctype[^>]*>/i', $html, $m, PREG_OFFSET_CAPTURE ) ) {
			$pos = $m[0][1] + strlen( $m[0][0] );
			return substr( $html, 0, $pos ) . "\n<head>\n" . $tag . "\n</head>\n" . substr( $html, $pos );
		}
		return $tag . "\n" . $html;
	}

	/**
	 * Get reusable layout injections for one managed page.
	 *
	 * @param int $page_id Managed page id.
	 * @return array
	 */
	protected function get_layout_injections_for_page( $page_id ) {
		$page_id = absint( $page_id );

		if ( ! $page_id ) {
			return array();
		}

		$settings = $this->storage->get_settings();
		$layout   = isset( $settings['layout_injections'] ) && is_array( $settings['layout_injections'] ) ? $settings['layout_injections'] : array();
		$page_ids = array_map( 'absint', isset( $layout['page_ids'] ) && is_array( $layout['page_ids'] ) ? $layout['page_ids'] : array() );

		if ( ! in_array( $page_id, $page_ids, true ) ) {
			return array();
		}

		$header = $this->normalize_layout_markup_block( 'header', isset( $layout['header_html'] ) ? $layout['header_html'] : '' );
		$body   = $this->normalize_layout_markup_block( 'body', isset( $layout['body_html'] ) ? $layout['body_html'] : '' );
		$footer = $this->normalize_layout_markup_block( 'footer', isset( $layout['footer_html'] ) ? $layout['footer_html'] : '' );

		if ( $this->is_empty_layout_block( $header ) && $this->is_empty_layout_block( $body ) && $this->is_empty_layout_block( $footer ) ) {
			return array();
		}

		$blocks = array(
			'header' => $header,
			'body'   => $body,
			'footer' => $footer,
		);

		$blocks['hash'] = sha1( wp_json_encode( $blocks ) . '|' . $page_id );

		return $blocks;
	}

	/**
	 * Apply reusable layout blocks to a full HTML document.
	 *
	 * @param string $html   Full HTML document.
	 * @param array  $blocks Layout blocks.
	 * @return string
	 */
	protected function apply_layout_injections_to_document( $html, array $blocks ) {
		if ( empty( $blocks ) ) {
			return (string) $html;
		}

		$html = $this->merge_layout_head_markup( $html, $blocks );

		$header = $this->build_named_layout_block( 'header', isset( $blocks['header']['body_html'] ) ? $blocks['header']['body_html'] : '' );
		$body   = $this->build_named_layout_block( 'body', isset( $blocks['body']['body_html'] ) ? $blocks['body']['body_html'] : '' );
		$footer = $this->build_named_layout_block( 'footer', isset( $blocks['footer']['body_html'] ) ? $blocks['footer']['body_html'] : '' );

		if ( preg_match( '/<body\b[^>]*>/i', (string) $html, $matches, PREG_OFFSET_CAPTURE ) ) {
			$insert_pos = $matches[0][1] + strlen( $matches[0][0] );
			$html       = substr( $html, 0, $insert_pos ) . $header . substr( $html, $insert_pos );
		} else {
			$html = $header . (string) $html;
		}

		if ( preg_match( '/<\/body>/i', (string) $html, $matches, PREG_OFFSET_CAPTURE ) ) {
			$insert_pos = $matches[0][1];
			return substr( $html, 0, $insert_pos ) . $body . $footer . substr( $html, $insert_pos );
		}

		return (string) $html . $body . $footer;
	}

	/**
	 * Wrap compatibility-mode body content with reusable layout blocks.
	 *
	 * @param string $body_html Existing body HTML.
	 * @param array  $blocks    Layout blocks.
	 * @return string
	 */
	protected function wrap_body_content_with_layout_injections( $body_html, array $blocks ) {
		if ( empty( $blocks ) ) {
			return (string) $body_html;
		}

		return $this->build_named_layout_block( 'header', isset( $blocks['header']['body_html'] ) ? $blocks['header']['body_html'] : '' )
			. (string) $body_html
			. $this->build_named_layout_block( 'body', isset( $blocks['body']['body_html'] ) ? $blocks['body']['body_html'] : '' )
			. $this->build_named_layout_block( 'footer', isset( $blocks['footer']['body_html'] ) ? $blocks['footer']['body_html'] : '' );
	}

	/**
	 * Merge reusable layout head markup into a full HTML document or head fragment.
	 *
	 * @param string $html_or_head Existing HTML document or head markup.
	 * @param array  $blocks       Normalized layout blocks.
	 * @return string
	 */
	protected function merge_layout_head_markup( $html_or_head, array $blocks ) {
		$head_markup = '';

		foreach ( array( 'header', 'body', 'footer' ) as $name ) {
			if ( empty( $blocks[ $name ]['head_html'] ) ) {
				continue;
			}

			$head_markup .= $this->build_named_layout_block( $name . ' head', $blocks[ $name ]['head_html'] );
		}

		if ( '' === $head_markup ) {
			return (string) $html_or_head;
		}

		return $this->inject_into_head( (string) $html_or_head, $head_markup );
	}

	/**
	 * Normalize one reusable layout snippet.
	 *
	 * Supports either fragment markup or a full HTML document with head/body.
	 *
	 * @param string $name Block name.
	 * @param string $html Raw HTML/CSS/JS.
	 * @return array
	 */
	protected function normalize_layout_markup_block( $name, $html ) {
		$raw = trim( (string) $html );

		if ( '' === $raw ) {
			return array(
				'name'      => (string) $name,
				'head_html' => '',
				'body_html' => '',
			);
		}

		$head_html = '';
		$body_html = $raw;

		if ( preg_match( '/<head\b[^>]*>(.*?)<\/head>/is', $raw, $matches ) ) {
			$head_html = trim( (string) $matches[1] );
		}

		if ( preg_match( '/<body\b[^>]*>(.*?)<\/body>/is', $raw, $matches ) ) {
			$body_html = trim( (string) $matches[1] );
		} elseif ( '' !== $head_html ) {
			$body_html = trim( preg_replace( '/<!doctype[^>]*>/is', '', $raw ) );
			$body_html = trim( preg_replace( '/<html\b[^>]*>|<\/html>/is', '', $body_html ) );
			$body_html = trim( preg_replace( '/<head\b[^>]*>.*?<\/head>/is', '', $body_html ) );
			$body_html = trim( preg_replace( '/<body\b[^>]*>|<\/body>/is', '', $body_html ) );
		}

		if ( '' !== $head_html ) {
			$head_html = trim( preg_replace( '/<title\b[^>]*>.*?<\/title>/is', '', $head_html ) );
			$head_html = trim( preg_replace( '/<meta\b[^>]*charset[^>]*>/is', '', $head_html ) );
		}

		return array(
			'name'      => (string) $name,
			'head_html' => $head_html,
			'body_html' => $body_html,
		);
	}

	/**
	 * Check whether a normalized layout block has any output.
	 *
	 * @param array $block Normalized block.
	 * @return bool
	 */
	protected function is_empty_layout_block( array $block ) {
		return empty( $block['head_html'] ) && empty( $block['body_html'] );
	}

	/**
	 * Build one named reusable layout block.
	 *
	 * @param string $name Block name.
	 * @param string $html Raw HTML/CSS/JS.
	 * @return string
	 */
	protected function build_named_layout_block( $name, $html ) {
		$html = trim( (string) $html );

		if ( '' === $html ) {
			return '';
		}

		return "\n" . '<!-- Reputifly Global ' . esc_html( ucfirst( $name ) ) . ' -->' . "\n" . $html . "\n";
	}

	/**
	 * Send HTML headers for managed pages.
	 *
	 * @param array $bundle Render bundle.
	 * @return void
	 */
	protected function send_headers( array $bundle ) {
		if ( headers_sent() ) {
			return;
		}

		status_header( 200 );
		header( 'Content-Type: text/html; charset=' . ( ! empty( $bundle['metadata']['charset'] ) ? $bundle['metadata']['charset'] : get_bloginfo( 'charset' ) ) );

		// Prevent CDN/proxy from caching wrong A/B variant.
		if ( $this->active_variant_key ) {
			header( 'Vary: Cookie' );
			header( 'Cache-Control: private, no-cache' );
		}
	}
}
