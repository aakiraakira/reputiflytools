<?php
/**
 * Performance helper.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Performance utilities for preprocessing and runtime.
 */
class RSPD_Performance {

	/**
	 * Security helper.
	 *
	 * @var RSPD_Security
	 */
	protected $security;

	/**
	 * Storage helper.
	 *
	 * @var RSPD_Storage
	 */
	protected $storage;

	/**
	 * Constructor.
	 *
	 * @param RSPD_Security $security Security helper.
	 * @param RSPD_Storage  $storage  Storage helper.
	 */
	public function __construct( RSPD_Security $security, RSPD_Storage $storage ) {
		$this->security = $security;
		$this->storage  = $storage;
	}

	/**
	 * Merge per-page performance settings with global defaults.
	 *
	 * @param array $submitted Submitted per-page values.
	 * @param array $settings  Global plugin settings.
	 * @return array
	 */
	public function normalize_options( array $submitted, array $settings ) {
		$defaults = isset( $settings['performance'] ) && is_array( $settings['performance'] ) ? $settings['performance'] : array();

		$boolean_keys = array(
			'enable_html_cache',
			'minify_html',
			'minify_inline',
			'defer_scripts',
			'lazy_load_images',
			'disable_emoji',
			'disable_wp_embed',
			'asset_fingerprinting',
		);

		$text_keys = array(
			'hero_image',
			'preload_styles',
			'preconnect_urls',
			'dns_prefetch_urls',
			'critical_css',
		);

		$options = $defaults;

		foreach ( $boolean_keys as $key ) {
			$options[ $key ] = array_key_exists( $key, $submitted ) ? ( ! empty( $submitted[ $key ] ) ? 1 : 0 ) : ( ! empty( $defaults[ $key ] ) ? 1 : 0 );
		}

		foreach ( $text_keys as $key ) {
			if ( 'critical_css' === $key ) {
				$options[ $key ] = isset( $submitted[ $key ] ) ? trim( wp_unslash( $submitted[ $key ] ) ) : ( isset( $defaults[ $key ] ) ? (string) $defaults[ $key ] : '' );
				continue;
			}

			$options[ $key ] = isset( $submitted[ $key ] ) ? trim( sanitize_textarea_field( wp_unslash( $submitted[ $key ] ) ) ) : ( isset( $defaults[ $key ] ) ? (string) $defaults[ $key ] : '' );
		}

		return $options;
	}

	/**
	 * Apply DOM-level optimizations during preprocessing.
	 *
	 * @param DOMDocument $document   Document being processed.
	 * @param array       $context    Deployment context.
	 * @param array       $options    Performance options.
	 * @param array       $asset_refs Asset references.
	 * @param array       $warnings   Collected warnings.
	 * @return void
	 */
	public function apply_dom_optimizations( DOMDocument $document, array $context, array $options, array &$asset_refs, array &$warnings ) {
		if ( ! empty( $options['defer_scripts'] ) ) {
			foreach ( $document->getElementsByTagName( 'script' ) as $script ) {
				if ( ! $script->hasAttribute( 'src' ) || $script->hasAttribute( 'async' ) || $script->hasAttribute( 'defer' ) || $script->hasAttribute( 'nomodule' ) ) {
					continue;
				}

				if ( 'module' === strtolower( trim( $script->getAttribute( 'type' ) ) ) ) {
					continue;
				}

				$script->setAttribute( 'defer', 'defer' );
			}
		}

		if ( ! empty( $options['minify_inline'] ) ) {
			foreach ( $document->getElementsByTagName( 'style' ) as $style ) {
				$style->nodeValue = $this->minify_css( $style->textContent );
			}

			foreach ( $document->getElementsByTagName( 'script' ) as $script ) {
				if ( $script->hasAttribute( 'src' ) ) {
					continue;
				}

				$type = strtolower( trim( $script->getAttribute( 'type' ) ) );
				$code = $script->textContent;

				if ( false !== strpos( $type, 'ld+json' ) ) {
					$script->nodeValue = trim( $code );
					continue;
				}

				$script->nodeValue = $this->minify_inline_javascript( $code );
			}
		}

		if ( ! empty( $options['lazy_load_images'] ) || ! empty( $options['hero_image'] ) ) {
			$hero_image = trim( (string) $options['hero_image'] );
			$hero_match = '';

			if ( $hero_image && $this->security->is_local_reference( $hero_image ) ) {
				$hero_match = $this->normalize_relative_url_from_context( $hero_image, $context );
			} elseif ( $hero_image ) {
				$hero_match = $hero_image;
			}

			foreach ( $document->getElementsByTagName( 'img' ) as $index => $image ) {
				$current_src = $image->getAttribute( 'src' );
				$is_hero     = $hero_match && $current_src && $this->urls_match( $current_src, $hero_match );

				if ( $is_hero ) {
					$image->setAttribute( 'fetchpriority', 'high' );
					$image->setAttribute( 'decoding', 'async' );
					if ( $image->hasAttribute( 'loading' ) ) {
						$image->removeAttribute( 'loading' );
					}
					continue;
				}

				if ( ! empty( $options['lazy_load_images'] ) && 0 !== $index ) {
					if ( ! $image->hasAttribute( 'loading' ) ) {
						$image->setAttribute( 'loading', 'lazy' );
					}
					if ( ! $image->hasAttribute( 'decoding' ) ) {
						$image->setAttribute( 'decoding', 'async' );
					}
				}
			}
		}

		// Always optimize Google Fonts loading.
		$this->optimize_google_fonts( $document );
	}

	/**
	 * Remove WordPress extras only on managed pages.
	 *
	 * @param array $config Deployment config.
	 * @return void
	 */
	public function apply_runtime_hooks( array $config ) {
		$options = isset( $config['performance'] ) && is_array( $config['performance'] ) ? $config['performance'] : array();

		if ( ! empty( $options['disable_emoji'] ) ) {
			remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
			remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
			remove_action( 'wp_print_styles', 'print_emoji_styles' );
			remove_action( 'admin_print_styles', 'print_emoji_styles' );
			remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
			remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
			remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
		}

		if ( ! empty( $options['disable_wp_embed'] ) ) {
			remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
			remove_action( 'wp_head', 'wp_oembed_add_host_js' );
			remove_action( 'rest_api_init', 'wp_oembed_register_route' );
			remove_filter( 'oembed_dataparse', 'wp_filter_oembed_result', 10 );
		}
	}

	/**
	 * Optimize Google Fonts loading for all deployments.
	 *
	 * - Appends &display=swap to Google Fonts CSS URLs to prevent render-blocking.
	 * - Auto-injects preconnect hints for fonts.googleapis.com and fonts.gstatic.com.
	 *
	 * @param DOMDocument $document Document being processed.
	 * @return void
	 */
	protected function optimize_google_fonts( DOMDocument $document ) {
		$has_google_fonts = false;
		$head             = $document->getElementsByTagName( 'head' )->item( 0 );

		foreach ( $document->getElementsByTagName( 'link' ) as $link ) {
			$href = $link->getAttribute( 'href' );

			if ( false === strpos( $href, 'fonts.googleapis.com/css' ) ) {
				continue;
			}

			$has_google_fonts = true;

			// Ensure display=swap is present in the URL.
			if ( false === strpos( $href, 'display=' ) ) {
				$separator = false === strpos( $href, '?' ) ? '?' : '&';
				$link->setAttribute( 'href', $href . $separator . 'display=swap' );
			}
		}

		if ( ! $has_google_fonts || ! $head ) {
			return;
		}

		// Check if preconnect hints already exist.
		$has_gfonts_preconnect  = false;
		$has_gstatic_preconnect = false;

		foreach ( $document->getElementsByTagName( 'link' ) as $link ) {
			if ( 'preconnect' !== strtolower( trim( $link->getAttribute( 'rel' ) ) ) ) {
				continue;
			}

			$href = $link->getAttribute( 'href' );

			if ( false !== strpos( $href, 'fonts.googleapis.com' ) ) {
				$has_gfonts_preconnect = true;
			}
			if ( false !== strpos( $href, 'fonts.gstatic.com' ) ) {
				$has_gstatic_preconnect = true;
			}
		}

		// Insert missing preconnect hints at the top of <head>.
		$first_child = $head->firstChild;

		if ( ! $has_gstatic_preconnect ) {
			$preconnect = $document->createElement( 'link' );
			$preconnect->setAttribute( 'rel', 'preconnect' );
			$preconnect->setAttribute( 'href', 'https://fonts.gstatic.com' );
			$preconnect->setAttribute( 'crossorigin', '' );
			$head->insertBefore( $preconnect, $first_child );
		}

		if ( ! $has_gfonts_preconnect ) {
			$preconnect = $document->createElement( 'link' );
			$preconnect->setAttribute( 'rel', 'preconnect' );
			$preconnect->setAttribute( 'href', 'https://fonts.googleapis.com' );
			$head->insertBefore( $preconnect, $head->firstChild );
		}
	}

	/**
	 * Minify a full HTML string conservatively.
	 *
	 * @param string $html HTML markup.
	 * @return string
	 */
	public function minify_html( $html ) {
		$html = preg_replace( '/<!--(?!\[if).*?-->/s', '', (string) $html );
		$html = preg_replace( '/>\s+</', '><', $html );

		return trim( (string) $html );
	}

	/**
	 * Minify a fragment using the same conservative rules.
	 *
	 * @param string $html HTML fragment.
	 * @return string
	 */
	public function minify_fragment( $html ) {
		return $this->minify_html( $html );
	}

	/**
	 * Build resource hints and critical CSS tags.
	 *
	 * @param array $options Performance options.
	 * @return string
	 */
	public function build_resource_hint_tags( array $options ) {
		$tags = array();

		foreach ( $this->split_lines( isset( $options['preconnect_urls'] ) ? $options['preconnect_urls'] : '' ) as $url ) {
			$tags[] = '<link rel="preconnect" href="' . esc_url( $url ) . '" crossorigin>';
		}

		foreach ( $this->split_lines( isset( $options['dns_prefetch_urls'] ) ? $options['dns_prefetch_urls'] : '' ) as $url ) {
			$tags[] = '<link rel="dns-prefetch" href="' . esc_url( $url ) . '">';
		}

		foreach ( $this->split_lines( isset( $options['preload_styles'] ) ? $options['preload_styles'] : '' ) as $url ) {
			$tags[] = '<link rel="preload" href="' . esc_url( $url ) . '" as="style">';
		}

		if ( ! empty( $options['hero_image'] ) ) {
			$tags[] = '<link rel="preload" href="' . esc_url( $options['hero_image'] ) . '" as="image">';
		}

		if ( ! empty( $options['critical_css'] ) ) {
			$tags[] = '<style id="rspd-critical-css">' . trim( (string) $options['critical_css'] ) . '</style>';
		}

		return implode( "\n", $tags );
	}

	/**
	 * Build diagnostics summary for the admin UI.
	 *
	 * @param array $bundle Render bundle.
	 * @param array $config Deployment config.
	 * @return array
	 */
	public function build_diagnostics( array $bundle, array $config ) {
		$asset_refs = isset( $bundle['asset_refs'] ) && is_array( $bundle['asset_refs'] ) ? $bundle['asset_refs'] : array();
		$missing    = array();

		foreach ( $asset_refs as $reference ) {
			if ( ! empty( $reference['is_local'] ) && empty( $reference['exists'] ) ) {
				$missing[] = $reference;
			}
		}

		return array(
			'html_size'         => strlen( (string) ( isset( $bundle['head_html'] ) ? $bundle['head_html'] : '' ) . (string) ( isset( $bundle['body_html'] ) ? $bundle['body_html'] : '' ) ),
			'local_asset_count' => ! empty( $config['deployment_rel_dir'] ) ? $this->storage->count_local_files( $config['deployment_rel_dir'] ) : 0,
			'has_title'         => ! empty( $bundle['metadata']['title'] ),
			'has_description'   => ! empty( $bundle['metadata']['description'] ),
			'has_canonical'     => ! empty( $bundle['metadata']['canonical'] ),
			'missing_assets'    => $missing,
			'lazy_loading'      => ! empty( $config['performance']['lazy_load_images'] ),
			'hero_preload'      => ! empty( $config['performance']['hero_image'] ),
			'deferred_scripts'  => ! empty( $config['performance']['defer_scripts'] ),
			'cached_render'     => ! empty( $config['performance']['enable_html_cache'] ),
		);
	}

	/**
	 * Minify CSS safely enough for inline blocks.
	 *
	 * @param string $css CSS string.
	 * @return string
	 */
	protected function minify_css( $css ) {
		$css = preg_replace( '#/\*.*?\*/#s', '', (string) $css );
		$css = preg_replace( '/\s+/', ' ', (string) $css );
		$css = preg_replace( '/\s*([{}:;,])\s*/', '$1', (string) $css );

		return trim( (string) $css );
	}

	/**
	 * Minify inline JavaScript conservatively.
	 *
	 * @param string $javascript JavaScript code.
	 * @return string
	 */
	protected function minify_inline_javascript( $javascript ) {
		$javascript = preg_replace( "/\r\n|\r/", "\n", (string) $javascript );
		$javascript = preg_replace( "/\n{2,}/", "\n", (string) $javascript );

		return trim( (string) $javascript );
	}

	/**
	 * Normalize a hero image path to a deployment URL.
	 *
	 * @param string $value   Submitted hero image reference.
	 * @param array  $context Deployment context.
	 * @return string
	 */
	protected function normalize_relative_url_from_context( $value, array $context ) {
		$parts    = $this->security->split_reference( $value );
		$resolved = $this->security->resolve_reference_path( $parts['path'], isset( $context['entry_dir'] ) ? $context['entry_dir'] : '' );

		if ( ! $resolved ) {
			return $value;
		}

		return trailingslashit( $context['deployment_url'] ) . ltrim( $resolved, '/' ) . $parts['suffix'];
	}

	/**
	 * Compare two URLs after stripping query strings and fragments.
	 *
	 * @param string $left  First URL.
	 * @param string $right Second URL.
	 * @return bool
	 */
	protected function urls_match( $left, $right ) {
		$left  = preg_replace( '/[?#].*$/', '', (string) $left );
		$right = preg_replace( '/[?#].*$/', '', (string) $right );

		return $left === $right;
	}

	/**
	 * Split newline-delimited settings into values.
	 *
	 * @param string $value Raw textarea value.
	 * @return string[]
	 */
	protected function split_lines( $value ) {
		$lines = preg_split( '/\r\n|\r|\n/', (string) $value );

		return array_values(
			array_filter(
				array_map( 'trim', is_array( $lines ) ? $lines : array() )
			)
		);
	}
}
