<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RSPD_Admin {

	const MENU_SLUG     = 'reputifly-deploy';
	const SETTINGS_SLUG = 'reputifly-deploy-settings';
	const TOOLS_SLUG    = 'reputifly-deploy-tools';
	const SEO_SLUG      = 'reputifly-deploy-seo';
	const AB_SLUG       = 'reputifly-deploy-ab-testing';
	const LABS_SLUG     = 'reputifly-deploy-labs';

	protected $storage;
	protected $security;
	protected $deployer;
	protected $license;
	protected $logo_url = 'https://reputifly.com/wp-content/uploads/2026/03/ChatGPT-Image-Mar-12-2026-02_08_28-AM.png';

	public function __construct( RSPD_Storage $storage, RSPD_Security $security, RSPD_Deployer $deployer, RSPD_License $license ) {
		$this->storage  = $storage;
		$this->security = $security;
		$this->deployer = $deployer;
		$this->license  = $license;

		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this, 'maybe_block_locked_ajax' ) );
		add_action( 'admin_init', array( $this, 'maybe_redirect_legacy_menu_slugs' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_notices', array( $this, 'render_admin_notice' ) );
		add_action( 'admin_post_rspd_deploy', array( $this, 'handle_deploy' ) );
		add_action( 'admin_post_rspd_delete', array( $this, 'handle_delete' ) );
		add_action( 'admin_post_rspd_delete_software', array( $this, 'handle_delete_software' ) );
		add_action( 'admin_post_rspd_save_layout_injections', array( $this, 'handle_save_layout_injections' ) );
		add_action( 'admin_post_rspd_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'admin_post_rspd_replace_urls', array( $this, 'handle_replace_urls' ) );
		add_action( 'admin_post_rspd_recheck_license', array( $this, 'handle_license_recheck' ) );
		add_action( 'admin_post_rspd_labs_export', array( $this, 'handle_labs_export' ) );
		add_action( 'admin_post_rspd_restore_elementor_source', array( $this, 'handle_restore_elementor_source' ) );

		// AJAX endpoints.
		add_action( 'wp_ajax_rspd_scan_zip', array( $this, 'ajax_scan_zip' ) );
		add_action( 'wp_ajax_rspd_deploy_multi', array( $this, 'ajax_deploy_multi' ) );
		add_action( 'wp_ajax_rspd_get_page_overrides', array( $this, 'ajax_get_page_overrides' ) );
		add_action( 'wp_ajax_rspd_save_page_overrides', array( $this, 'ajax_save_page_overrides' ) );
		add_action( 'wp_ajax_rspd_deploy_merge', array( $this, 'ajax_deploy_merge' ) );
		add_action( 'wp_ajax_rspd_scan_folder', array( $this, 'ajax_scan_folder' ) );
		add_action( 'wp_ajax_rspd_save_schema', array( $this, 'ajax_save_schema' ) );
		add_action( 'wp_ajax_rspd_save_social', array( $this, 'ajax_save_social' ) );
		add_action( 'wp_ajax_rspd_ab_create', array( $this, 'ajax_ab_create' ) );
		add_action( 'wp_ajax_rspd_ab_toggle', array( $this, 'ajax_ab_toggle' ) );
		add_action( 'wp_ajax_rspd_ab_end', array( $this, 'ajax_ab_end' ) );
		add_action( 'wp_ajax_rspd_ab_update_split', array( $this, 'ajax_ab_update_split' ) );
		add_action( 'wp_ajax_rspd_get_variant_overrides', array( $this, 'ajax_get_variant_overrides' ) );
		add_action( 'wp_ajax_rspd_save_variant_overrides', array( $this, 'ajax_save_variant_overrides' ) );
		add_filter( 'plugin_action_links_' . RSPD_PLUGIN_BASENAME, array( $this, 'add_plugin_action_links' ) );
	}

	public function register_menu() {
		add_menu_page(
			'Reputifly Deploy',
			'Reputifly Deploy',
			'manage_options',
			self::MENU_SLUG,
			array( $this, 'render_main_page' ),
			'dashicons-media-code',
			58
		);
		add_submenu_page( self::MENU_SLUG, 'Deploy', 'Deploy', 'manage_options', self::MENU_SLUG, array( $this, 'render_main_page' ) );
		add_submenu_page( self::MENU_SLUG, 'Settings', 'Settings', 'manage_options', self::SETTINGS_SLUG, array( $this, 'render_settings_page' ) );
		add_submenu_page( self::MENU_SLUG, 'Tools', 'Tools', 'manage_options', self::TOOLS_SLUG, array( $this, 'render_tools_page' ) );
		add_submenu_page( self::MENU_SLUG, 'SEO Intelligence', 'SEO Intelligence', 'manage_options', self::SEO_SLUG, array( $this, 'render_seo_page' ) );
		add_submenu_page( self::MENU_SLUG, 'A/B Testing', 'A/B Testing', 'manage_options', self::AB_SLUG, array( $this, 'render_ab_page' ) );
		add_submenu_page( self::MENU_SLUG, 'Labs', 'Labs', 'manage_options', self::LABS_SLUG, array( $this, 'render_labs_page' ) );

		// Hidden legacy routes so older bookmarks such as admin.php?page=rspd still work.
		add_submenu_page( null, 'Deploy', 'Deploy', 'manage_options', 'rspd', array( $this, 'render_main_page' ) );
		add_submenu_page( null, 'Settings', 'Settings', 'manage_options', 'rspd-settings', array( $this, 'render_settings_page' ) );
		add_submenu_page( null, 'Tools', 'Tools', 'manage_options', 'rspd-tools', array( $this, 'render_tools_page' ) );
		add_submenu_page( null, 'SEO Intelligence', 'SEO Intelligence', 'manage_options', 'rspd-seo', array( $this, 'render_seo_page' ) );
		add_submenu_page( null, 'A/B Testing', 'A/B Testing', 'manage_options', 'rspd-ab-testing', array( $this, 'render_ab_page' ) );
		add_submenu_page( null, 'Labs', 'Labs', 'manage_options', 'rspd-labs', array( $this, 'render_labs_page' ) );
	}

	/**
	 * Redirect old short menu slugs to the stable unique menu slugs.
	 *
	 * @return void
	 */
	public function maybe_redirect_legacy_menu_slugs() {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		$map = array(
			'rspd'            => self::MENU_SLUG,
			'rspd-settings'   => self::SETTINGS_SLUG,
			'rspd-tools'      => self::TOOLS_SLUG,
			'rspd-seo'        => self::SEO_SLUG,
			'rspd-ab-testing' => self::AB_SLUG,
			'rspd-labs'       => self::LABS_SLUG,
		);

		if ( empty( $page ) || ! isset( $map[ $page ] ) ) {
			return;
		}

		$args = wp_unslash( $_GET );
		$args['page'] = $map[ $page ];

		wp_safe_redirect( add_query_arg( array_map( 'sanitize_text_field', $args ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Build an admin URL for a plugin screen.
	 *
	 * @param string $page Screen slug.
	 * @param array  $args Extra query args.
	 * @return string
	 */
	protected function get_admin_page_url( $page, array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => $page ), $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * Add quick plugin-row action links.
	 *
	 * @param array $links Existing action links.
	 * @return array
	 */
	public function add_plugin_action_links( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( $this->get_admin_page_url( self::MENU_SLUG ) ) . '">Open Dashboard</a>',
			'<a href="' . esc_url( $this->get_admin_page_url( self::SETTINGS_SLUG ) ) . '">Access Status</a>'
		);

		return $links;
	}

	/**
	 * Render the shared access request form used on locked/plugin settings screens.
	 *
	 * @param array $context License context.
	 * @param bool  $show_hint Whether to show the helper hint.
	 * @return void
	 */
	protected function render_license_request_form( array $context, $show_hint = true ) {
		$current_key_label = ! empty( $context['license_key_masked'] ) ? $context['license_key_masked'] : 'No key saved yet';
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rspd-form rspd-license-request-form">
			<input type="hidden" name="action" value="rspd_recheck_license">
			<?php wp_nonce_field( 'rspd_recheck_license' ); ?>

			<div class="rspd-flow-steps">
				<div class="rspd-flow-step">
					<span class="rspd-step-number">1</span>
					<div>
						<strong>Paste key</strong>
						<p>Add the Reputifly key for this client.</p>
					</div>
				</div>
				<div class="rspd-flow-step">
					<span class="rspd-step-number">2</span>
					<div>
						<strong>Request access</strong>
						<p>Send this site to your Reputifly dashboard.</p>
					</div>
				</div>
				<div class="rspd-flow-step">
					<span class="rspd-step-number">3</span>
					<div>
						<strong>Go live</strong>
						<p>When approved, the plugin unlocks automatically.</p>
					</div>
				</div>
			</div>

			<div class="rspd-field rspd-license-key-field">
				<label class="rspd-field-label" for="rspd-license-key">Client Key</label>
				<input
					type="text"
					name="license_key"
					id="rspd-license-key"
					class="rspd-input"
					placeholder="RSPD-XXXX-XXXX-XXXX"
					autocomplete="off"
				>
				<span class="rspd-text-muted">Saved key: <?php echo esc_html( $current_key_label ); ?></span>
				<?php if ( $show_hint ) : ?>
				<span class="rspd-text-muted">You manage the client from your Reputifly dashboard. Revoke the key there any time you want this plugin to stop working.</span>
				<?php endif; ?>
			</div>

			<div class="rspd-license-actions">
				<button type="submit" class="rspd-btn-deploy">Request Access</button>
			</div>
		</form>
		<?php
	}

	/**
	 * Render the simple access summary cards.
	 *
	 * @param array $context License context.
	 * @return void
	 */
	protected function render_license_summary_cards( array $context ) {
		?>
		<div class="rspd-access-summary">
			<div class="rspd-access-card">
				<span class="rspd-license-meta-label">Site</span>
				<strong><?php echo esc_html( $context['domain'] ); ?></strong>
			</div>
			<div class="rspd-access-card">
				<span class="rspd-license-meta-label">Current Key</span>
				<strong><?php echo esc_html( ! empty( $context['license_key_masked'] ) ? $context['license_key_masked'] : 'No key saved yet' ); ?></strong>
			</div>
			<div class="rspd-access-card">
				<span class="rspd-license-meta-label">Status</span>
				<strong><?php echo esc_html( $context['label'] ); ?></strong>
			</div>
		</div>
		<?php
	}

	/**
	 * Render hidden technical details for troubleshooting only.
	 *
	 * @param array $context License context.
	 * @return void
	 */
	protected function render_license_technical_details( array $context ) {
		?>
		<div class="rspd-license-meta-grid rspd-license-meta-grid--secondary">
			<div class="rspd-license-meta-card">
				<span class="rspd-license-meta-label">Install ID</span>
				<strong><?php echo esc_html( $context['install_id'] ); ?></strong>
			</div>
			<div class="rspd-license-meta-card">
				<span class="rspd-license-meta-label">License Mode</span>
				<strong><?php echo 'key' === $context['license_source'] ? 'Key Based' : 'Legacy Approval'; ?></strong>
			</div>
			<div class="rspd-license-meta-card">
				<span class="rspd-license-meta-label">Last Check</span>
				<strong><?php echo $context['last_check_at'] ? esc_html( wp_date( 'Y-m-d H:i:s', $context['last_check_at'] ) ) : 'Never'; ?></strong>
			</div>
			<div class="rspd-license-meta-card">
				<span class="rspd-license-meta-label">Last Success</span>
				<strong><?php echo $context['last_success_at'] ? esc_html( wp_date( 'Y-m-d H:i:s', $context['last_success_at'] ) ) : 'Never'; ?></strong>
			</div>
		</div>
		<?php
	}

	/**
	 * Get mounted route summaries for a software app.
	 *
	 * @param array $app Software app record.
	 * @return array
	 */
	protected function get_software_app_routes( array $app ) {
		$slug       = isset( $app['slug'] ) ? (string) $app['slug'] : '';
		$entry_file = isset( $app['entry_file'] ) ? (string) $app['entry_file'] : '';
		$html_files = ! empty( $app['html_files'] ) && is_array( $app['html_files'] ) ? $app['html_files'] : array();

		return $this->storage->get_software_app_routes( $slug, $entry_file, $html_files );
	}

	public function enqueue_assets( $hook_suffix ) {
		if ( false === strpos( $hook_suffix, self::MENU_SLUG ) && false === strpos( $hook_suffix, 'rspd' ) ) {
			return;
		}
		wp_enqueue_style( 'rspd-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;700&display=swap', array(), null );
		wp_enqueue_style( 'rspd-admin', RSPD_PLUGIN_URL . 'assets/admin.css', array(), RSPD_VERSION );
		wp_enqueue_script( 'rspd-admin', RSPD_PLUGIN_URL . 'assets/admin.js', array(), RSPD_VERSION, true );

		// Pass pages list + AJAX info to JS.
		$pages = get_pages( array( 'sort_column' => 'post_title', 'sort_order' => 'asc' ) );
		$pages_list = array();
		foreach ( $pages as $p ) {
			$pages_list[] = array(
				'id'        => $p->ID,
				'title'     => $p->post_title,
				'slug'      => $p->post_name,
				'permalink' => get_permalink( $p ),
			);
		}
		// Also pass existing deployments so JS can show "override" options.
		$deployments = $this->storage->get_deployments();
		$deployed = array();
		foreach ( $deployments as $d ) {
			$deployed[] = array(
				'page_id'   => $d['page']->ID,
				'title'     => $d['page']->post_title,
				'permalink' => $d['permalink'],
			);
		}
		$software_apps = array();
		foreach ( $this->storage->get_software_apps() as $app_slug => $app ) {
			$software_apps[] = array(
				'slug'  => $app_slug,
				'label' => ! empty( $app['label'] ) ? $app['label'] : ucwords( str_replace( '-', ' ', $app_slug ) ),
				'url'   => $this->storage->get_software_mount_url( $app_slug ),
			);
		}
		// Detect merge edit mode.
		$edit_id         = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0;
		$edit_sections   = array();
		$edit_source_type = '';
		if ( $edit_id ) {
			$ec = $this->storage->get_page_config( $edit_id );
			$edit_source_type = isset( $ec['source_type'] ) ? $ec['source_type'] : '';
			if ( 'merge' === $edit_source_type && ! empty( $ec['sections'] ) && is_array( $ec['sections'] ) ) {
				$edit_sections = $ec['sections'];
			}
		}

		// Build per-page A/B test data for the deploy tab variant settings.
		$ab_tests = array();
		foreach ( $deployments as $d ) {
			$cfg = $d['config'];
			if ( ! empty( $cfg['ab_test']['enabled'] ) && ! empty( $cfg['ab_test']['variants'] ) ) {
				$ab_tests[ $d['page']->ID ] = $cfg['ab_test'];
			}
		}

		// Build per-page SEO data for the SEO Intelligence page.
		$seo_data = array();
		foreach ( $deployments as $d ) {
			$cfg = $d['config'];
			$seo_data[ $d['page']->ID ] = array(
				'schema'    => isset( $cfg['schema'] ) && is_array( $cfg['schema'] ) ? $cfg['schema'] : array(),
				'social'    => isset( $cfg['social'] ) && is_array( $cfg['social'] ) ? $cfg['social'] : array(),
				'score'     => $this->calculate_seo_score( $cfg ),
				'breakdown' => $this->get_score_breakdown( $cfg ),
				'permalink' => $d['permalink'],
				'title'     => $d['page']->post_title,
			);
		}

		wp_localize_script( 'rspd-admin', 'rspdData', array(
			'ajaxUrl'         => admin_url( 'admin-ajax.php' ),
			'scanNonce'       => wp_create_nonce( 'rspd_scan_zip' ),
			'deployNonce'     => wp_create_nonce( 'rspd_deploy_multi' ),
			'overridesNonce'  => wp_create_nonce( 'rspd_page_overrides' ),
			'mergeNonce'      => wp_create_nonce( 'rspd_deploy_merge' ),
			'folderNonce'     => wp_create_nonce( 'rspd_scan_folder' ),
			'schemaNonce'     => wp_create_nonce( 'rspd_save_schema' ),
			'socialNonce'     => wp_create_nonce( 'rspd_save_social' ),
			'abNonce'         => wp_create_nonce( 'rspd_ab_test' ),
			'pages'           => $pages_list,
			'deployed'        => $deployed,
			'softwareApps'    => $software_apps,
			'seoData'         => $seo_data,
			'editPageId'      => $edit_id,
			'editSourceType'  => $edit_source_type,
			'editSections'    => $edit_sections,
			'abTests'         => $ab_tests,
		) );
	}

	public function render_admin_notice() {
		$notice = $this->storage->consume_admin_notice();
		if ( empty( $notice['message'] ) ) {
			return;
		}
		$type = ! empty( $notice['type'] ) ? $notice['type'] : 'success';
		echo '<div class="notice rspd-notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>' . esc_html( $notice['message'] ) . '</p></div>';
	}

	/**
	 * Block plugin AJAX endpoints while the license is inactive.
	 *
	 * @return void
	 */
	public function maybe_block_locked_ajax() {
		if ( ! wp_doing_ajax() ) {
			return;
		}

		$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : '';

		if ( 0 !== strpos( $action, 'rspd_' ) ) {
			return;
		}

		$this->license->maybe_refresh_status( false, 'ajax' );

		if ( ! $this->license->should_block_admin() ) {
			return;
		}

		wp_send_json_error( $this->license->get_status_context()['message'], 403 );
	}

	/**
	 * Ensure the license allows admin features and redirect if blocked.
	 *
	 * @return void
	 */
	protected function guard_license_action() {
		$this->license->maybe_refresh_status( false, 'admin_action' );

		if ( ! $this->license->should_block_admin() ) {
			return;
		}

		$context = $this->license->get_status_context();
		$this->storage->set_admin_notice( $context['message'], 'error' );
		wp_safe_redirect( $this->get_admin_page_url( self::SETTINGS_SLUG ) );
		exit;
	}

	/**
	 * Render a lock screen for plugin pages.
	 *
	 * @param string $title Page title.
	 * @return void
	 */
	protected function render_license_locked_page( $title = 'Reputifly Deploy' ) {
		$context = $this->license->get_status_context();
		?>
		<div class="rspd-wrap">
			<div class="rspd-header">
				<div>
					<div class="rspd-header-row">
						<img src="<?php echo esc_url( $this->logo_url ); ?>" alt="Reputifly" class="rspd-logo">
						<div class="rspd-header-text">
							<h1><?php echo esc_html( $title ); ?></h1>
							<p class="rspd-subtitle">Paste the client key, click one button, and this site unlocks after approval.</p>
						</div>
					</div>
				</div>
			</div>

			<div class="rspd-panel rspd-license-locked-panel">
				<div class="rspd-license-panel-head">
					<div>
						<h2>Plugin Locked</h2>
						<p class="rspd-subtitle"><?php echo esc_html( $context['message'] ); ?></p>
					</div>
					<span class="rspd-license-pill rspd-license-pill--<?php echo esc_attr( $context['tone'] ); ?>"><?php echo esc_html( $context['label'] ); ?></span>
				</div>

				<?php $this->render_license_summary_cards( $context ); ?>

				<div class="rspd-license-actions" style="margin-top:16px;">
					<?php if ( ! empty( $context['can_request'] ) ) : ?>
						<?php $this->render_license_request_form( $context ); ?>
					<?php endif; ?>
					<a href="<?php echo esc_url( $this->get_admin_page_url( self::SETTINGS_SLUG ) ); ?>" class="rspd-btn-sm rspd-btn-secondary">Open Settings</a>
				</div>

				<?php $this->render_license_technical_details( $context ); ?>

				<?php if ( ! empty( $context['last_error'] ) ) : ?>
				<div class="rspd-license-error"><?php echo esc_html( $context['last_error'] ); ?></div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	// ─── MAIN PAGE ───

	public function render_main_page() {
		$this->license->maybe_refresh_status( false, 'admin_screen' );
		if ( $this->license->should_block_admin() ) {
			$this->render_license_locked_page( 'Reputifly Deploy' );
			return;
		}

		$deployments = $this->storage->get_deployments();
		$software_apps = $this->storage->get_software_apps();
		$settings    = $this->storage->get_settings();
		$layout_injections = isset( $settings['layout_injections'] ) && is_array( $settings['layout_injections'] ) ? $settings['layout_injections'] : array();
		$layout_page_ids = array_map( 'absint', isset( $layout_injections['page_ids'] ) && is_array( $layout_injections['page_ids'] ) ? $layout_injections['page_ids'] : array() );
		$layout_result = $this->consume_layout_result();
		$edit_id     = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0;
		$edit_config = $edit_id ? $this->storage->get_page_config( $edit_id ) : array();
		$edit_page   = $edit_id ? get_post( $edit_id ) : null;
		$pages       = get_pages( array( 'sort_column' => 'post_title', 'sort_order' => 'asc' ) );
		?>
		<div class="rspd-wrap">
			<div class="rspd-header">
				<div>
					<div class="rspd-header-row">
						<img src="<?php echo esc_url( $this->logo_url ); ?>" alt="Reputifly" class="rspd-logo">
						<div class="rspd-header-text">
							<h1>Reputifly <span class="rspd-brand-accent">Archimedes</span></h1>
							<p class="rspd-subtitle">Deploy static pages at the speed of thought.</p>
						</div>
					</div>
				</div>
			</div>

			<div class="rspd-panel rspd-quickstart-panel">
				<div class="rspd-flow-steps">
					<div class="rspd-flow-step">
						<span class="rspd-step-number">1</span>
						<div>
							<strong>Choose page</strong>
							<p>Use an existing page or create a new one.</p>
						</div>
					</div>
					<div class="rspd-flow-step">
						<span class="rspd-step-number">2</span>
						<div>
							<strong>Add project</strong>
							<p>Paste HTML or upload the built files.</p>
						</div>
					</div>
					<div class="rspd-flow-step">
						<span class="rspd-step-number">3</span>
						<div>
							<strong>Deploy</strong>
							<p>Click deploy and the page goes live.</p>
						</div>
					</div>
				</div>
			</div>

			<!-- ═══ DEPLOY FORM ═══ -->
			<div class="rspd-panel">
				<h2><?php echo $edit_id && $edit_page ? 'Edit: ' . esc_html( $edit_page->post_title ) : 'New Deployment'; ?></h2>

				<!-- Tab selector -->
				<div class="rspd-tabs" style="margin-bottom:20px;">
					<button type="button" class="rspd-tab active" data-tab="paste">Paste HTML</button>
					<button type="button" class="rspd-tab" data-tab="upload">Upload ZIP / File</button>
					<button type="button" class="rspd-tab" data-tab="merge">Merge Sections</button>
					<button type="button" class="rspd-tab" data-tab="layout">Headers and Footers</button>
				</div>

				<!-- ─── TAB 1: Paste HTML (single page, classic flow) ─── -->
				<div class="rspd-tab-content" id="rspd-tab-paste">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" class="rspd-form">
						<input type="hidden" name="action" value="rspd_deploy">
						<input type="hidden" name="import_method" value="paste">
						<?php wp_nonce_field( 'rspd_deploy' ); ?>

						<?php if ( $edit_id ) : ?>
							<input type="hidden" name="page_id" value="<?php echo esc_attr( $edit_id ); ?>">
							<input type="hidden" name="preserve_existing_source" value="1">
						<?php endif; ?>

						<div class="rspd-field">
							<label class="rspd-field-label">Target Page</label>
							<?php if ( $edit_id && $edit_page ) : ?>
								<div class="rspd-page-badge">
									<?php echo esc_html( $edit_page->post_title ); ?>
									<span class="rspd-page-url"><?php echo esc_url( get_permalink( $edit_page ) ); ?></span>
								</div>
							<?php else : ?>
								<div class="rspd-page-options">
									<div class="rspd-option-group">
										<label><input type="radio" name="page_mode" value="existing" checked class="rspd-radio" id="rspd-mode-existing"><span>Choose existing page</span></label>
										<select name="page_id" id="rspd-page-select" class="rspd-select">
											<option value="">— Select a page —</option>
											<?php foreach ( $pages as $p ) : ?>
												<option value="<?php echo esc_attr( $p->ID ); ?>"><?php echo esc_html( $p->post_title ); ?></option>
											<?php endforeach; ?>
										</select>
									</div>
									<div class="rspd-option-group">
										<label><input type="radio" name="page_mode" value="new" class="rspd-radio" id="rspd-mode-new"><span>Create new page</span></label>
										<input type="text" name="new_page_title" id="rspd-new-title" class="rspd-input" placeholder="e.g. About Us, Services, Landing Page..." disabled>
									</div>
								</div>
							<?php endif; ?>
						</div>

						<div class="rspd-field">
							<label class="rspd-field-label">Your Code</label>
							<textarea name="combined_code" class="rspd-code" placeholder="Paste your full HTML page here..."><?php
								if ( $edit_id && ! empty( $edit_config['deployment_rel_dir'] ) && ! empty( $edit_config['entry_file'] ) ) {
									$path = $this->storage->get_deployment_path( $edit_config['deployment_rel_dir'] ) . '/' . $edit_config['entry_file'];
									echo esc_textarea( $this->storage->read_file( $path ) );
								}
							?></textarea>
						</div>

						<div class="rspd-deploy-bar">
							<button type="submit" class="rspd-btn-deploy"><?php echo $edit_id ? 'Update Deployment' : 'Deploy Now'; ?></button>
							<?php if ( $edit_id ) : ?>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=rspd' ) ); ?>" class="rspd-btn-secondary">Cancel</a>
							<?php endif; ?>
						</div>
					</form>
				</div>

				<!-- ─── TAB 2: Upload ZIP (multi-page smart flow) ─── -->
				<div class="rspd-tab-content" id="rspd-tab-upload" style="display:none;">
					<div class="rspd-field">
						<label class="rspd-field-label">Deployment Type</label>
						<div class="rspd-page-options">
							<div class="rspd-option-group">
								<label><input type="radio" name="rspd_upload_mode" value="website_pages" checked class="rspd-radio" id="rspd-upload-mode-pages"><span>Website Pages</span></label>
								<span class="rspd-text-muted">Deploy each HTML file onto WordPress pages like the current flow.</span>
							</div>
							<div class="rspd-option-group">
								<label><input type="radio" name="rspd_upload_mode" value="software_app" class="rspd-radio" id="rspd-upload-mode-software"><span>Software App</span></label>
								<span class="rspd-text-muted">Mount the whole project under one parent folder such as <code>/invoicing-software/</code>.</span>
							</div>
						</div>
					</div>

					<div id="rspd-upload-step">
						<div class="rspd-upload-zone" id="rspd-drop-zone" tabindex="0" role="button" aria-label="Upload a ZIP, HTML file, or folder">
							<div class="rspd-upload-zone-inner">
								<div class="rspd-upload-icon" aria-hidden="true">
									<svg class="rspd-upload-icon-svg" viewBox="0 0 64 64" focusable="false" aria-hidden="true">
										<defs>
											<linearGradient id="rspd-folder-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
												<stop offset="0%" stop-color="#FFD56A" />
												<stop offset="100%" stop-color="#FF8A00" />
											</linearGradient>
										</defs>
										<path d="M11 20.5c0-3.6 2.9-6.5 6.5-6.5H27l4.6 4.8H46.5c3.6 0 6.5 2.9 6.5 6.5v1.2H11v-6z" fill="url(#rspd-folder-gradient)" opacity="0.92" />
										<path d="M11 26h42c3.6 0 6.5 2.9 6.5 6.5v14c0 3.6-2.9 6.5-6.5 6.5h-42c-3.6 0-6.5-2.9-6.5-6.5v-14C4.5 28.9 7.4 26 11 26z" fill="url(#rspd-folder-gradient)" />
										<path d="M15 31.5h34" stroke="rgba(255,255,255,0.28)" stroke-width="2.2" stroke-linecap="round" />
									</svg>
								</div>
								<p class="rspd-upload-title">Drag &amp; drop a ZIP, HTML file, or folder</p>
								<p class="rspd-upload-hint">or click to browse from your computer</p>
								<div class="rspd-upload-badges" aria-hidden="true">
									<span class="rspd-upload-badge">ZIP</span>
									<span class="rspd-upload-badge">HTML</span>
									<span class="rspd-upload-badge">Folder</span>
								</div>
								<div class="rspd-upload-actions">
									<button type="button" class="rspd-upload-action-btn rspd-upload-action-btn--primary" id="rspd-upload-browse-btn">Browse Files</button>
									<button type="button" class="rspd-upload-action-btn" id="rspd-upload-browse-folder-btn">Browse Folder</button>
								</div>
							</div>
							<input type="file" accept=".zip,.html,.htm" class="rspd-file-input" id="rspd-file-input" multiple>
							<input type="file" class="rspd-file-input" id="rspd-folder-input" webkitdirectory directory multiple>
						</div>
						<div id="rspd-scan-status" style="display:none;margin-top:16px;text-align:center;">
							<p class="rspd-text-muted">Scanning contents...</p>
						</div>
					</div>

					<!-- JS populates this after scanning -->
					<div id="rspd-multi-deploy" style="display:none;">
						<div id="rspd-software-options" style="display:none;">
							<div class="rspd-field">
								<label class="rspd-field-label" for="rspd-software-slug">Parent Folder Slug</label>
								<input type="text" id="rspd-software-slug" class="rspd-input" placeholder="e.g. invoicing-software">
								<span class="rspd-text-muted">The app will be mounted under this folder and stay separate from normal website pages.</span>
							</div>
							<div class="rspd-field">
								<label class="rspd-field-label" for="rspd-software-entry">Entry File</label>
								<select id="rspd-software-entry" class="rspd-select"></select>
								<span class="rspd-text-muted">Usually leave this as <code>index.html</code>.</span>
							</div>
							<div id="rspd-software-validation" class="rspd-file-validation" style="display:none;"></div>
						</div>
						<div id="rspd-file-list"></div>
						<div class="rspd-deploy-bar" style="margin-top:20px;">
							<button type="button" class="rspd-btn-deploy" id="rspd-deploy-all-btn">Deploy Selected</button>
							<button type="button" class="rspd-btn-secondary" id="rspd-upload-reset">Start Over</button>
						</div>
						<div id="rspd-deploy-progress" style="display:none;margin-top:16px;"></div>
					</div>
				</div>

				<!-- ─── TAB 3: Merge Sections ─── -->
				<div class="rspd-tab-content" id="rspd-tab-merge" style="display:none;">
					<div id="rspd-merge-editor">
						<div class="rspd-field">
							<label class="rspd-field-label">Target Page</label>
							<?php if ( $edit_id && $edit_page && ! empty( $edit_config['source_type'] ) && 'merge' === $edit_config['source_type'] ) : ?>
								<div class="rspd-page-badge">
									<?php echo esc_html( $edit_page->post_title ); ?>
									<span class="rspd-page-url"><?php echo esc_url( get_permalink( $edit_page ) ); ?></span>
								</div>
							<?php else : ?>
								<div class="rspd-page-options">
									<div class="rspd-option-group">
										<label><input type="radio" name="merge_page_mode" value="existing" checked class="rspd-radio" id="rspd-merge-mode-existing"><span>Choose existing page</span></label>
										<select id="rspd-merge-page-select" class="rspd-select">
											<option value="">— Select a page —</option>
											<?php foreach ( $pages as $p ) : ?>
												<option value="<?php echo esc_attr( $p->ID ); ?>"><?php echo esc_html( $p->post_title ); ?></option>
											<?php endforeach; ?>
										</select>
									</div>
									<div class="rspd-option-group">
										<label><input type="radio" name="merge_page_mode" value="new" class="rspd-radio" id="rspd-merge-mode-new"><span>Create new page</span></label>
										<input type="text" id="rspd-merge-new-title" class="rspd-input" placeholder="e.g. Landing Page, About Us..." disabled>
									</div>
								</div>
							<?php endif; ?>
						</div>

						<div class="rspd-field">
							<label class="rspd-field-label">Sections</label>
							<p class="rspd-text-muted" style="margin:0 0 12px;">Add HTML snippets section by section. Each section is CSS-isolated.</p>
							<div id="rspd-sections-list"></div>
							<button type="button" class="rspd-btn-secondary" id="rspd-add-section" style="margin-top:12px;">+ Add Section</button>
						</div>

						<div class="rspd-deploy-bar" style="margin-top:20px;">
							<button type="button" class="rspd-btn-deploy" id="rspd-merge-deploy-btn"><?php echo ( $edit_id && ! empty( $edit_config['source_type'] ) && 'merge' === $edit_config['source_type'] ) ? 'Update Merged Page' : 'Deploy Merged Page'; ?></button>
							<?php if ( $edit_id && ! empty( $edit_config['source_type'] ) && 'merge' === $edit_config['source_type'] ) : ?>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=rspd' ) ); ?>" class="rspd-btn-secondary">Cancel</a>
							<?php endif; ?>
						</div>
						<div id="rspd-merge-status" style="display:none;margin-top:16px;"></div>
					</div>
				</div>

				<!-- ─── TAB 4: Headers and Footers ─── -->
				<div class="rspd-tab-content" id="rspd-tab-layout" style="display:none;">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rspd-form">
						<input type="hidden" name="action" value="rspd_save_layout_injections">
						<?php wp_nonce_field( 'rspd_save_layout_injections' ); ?>

						<?php if ( ! empty( $layout_result ) ) : ?>
						<div class="rspd-status-note rspd-layout-result-note">
							<strong>
								<?php
								$page_count = ! empty( $layout_result['page_ids'] ) && is_array( $layout_result['page_ids'] ) ? count( $layout_result['page_ids'] ) : 0;
								echo esc_html( $page_count > 0 ? sprintf( 'Saved and applied to %d page%s.', $page_count, 1 === $page_count ? '' : 's' ) : 'Saved, but no pages are selected yet.' );
								?>
							</strong>
							<?php if ( ! empty( $layout_result['page_titles'] ) && is_array( $layout_result['page_titles'] ) ) : ?>
							<div class="rspd-layout-selection-chips">
								<?php foreach ( $layout_result['page_titles'] as $page_title ) : ?>
									<span class="rspd-layout-selection-chip"><?php echo esc_html( $page_title ); ?></span>
								<?php endforeach; ?>
							</div>
							<?php else : ?>
							<span>Select one or more deployed pages below, then save again to apply the blocks live.</span>
							<?php endif; ?>
						</div>
						<?php endif; ?>

						<div class="rspd-status-note">
							<strong>Reusable global blocks.</strong>
							<span>Add full HTML, CSS, and JS blocks here, then choose which deployed pages should receive them. Full document snippets are supported too. Unselected pages stay exactly as they are now.</span>
						</div>

						<div class="rspd-layout-snippet-grid">
							<div class="rspd-layout-snippet-card">
								<label class="rspd-field-label" for="rspd-layout-header-html">Global Header Block</label>
								<p class="rspd-text-muted">Rendered before the deployed page content. You can paste combined HTML, CSS, and JS here.</p>
								<textarea id="rspd-layout-header-html" name="layout_injections[header_html]" class="rspd-code rspd-layout-code" placeholder="<header>...</header>&#10;<style>...</style>&#10;<script>...</script>"><?php echo esc_textarea( isset( $layout_injections['header_html'] ) ? $layout_injections['header_html'] : '' ); ?></textarea>
							</div>

							<div class="rspd-layout-snippet-card">
								<label class="rspd-field-label" for="rspd-layout-body-html">Global Body Block</label>
								<p class="rspd-text-muted">Rendered after the deployed page content and before the footer block. Good for newsletter strips, CTAs, or promos.</p>
								<textarea id="rspd-layout-body-html" name="layout_injections[body_html]" class="rspd-code rspd-layout-code" placeholder="<section>...</section>&#10;<style>...</style>&#10;<script>...</script>"><?php echo esc_textarea( isset( $layout_injections['body_html'] ) ? $layout_injections['body_html'] : '' ); ?></textarea>
							</div>

							<div class="rspd-layout-snippet-card">
								<label class="rspd-field-label" for="rspd-layout-footer-html">Global Footer Block</label>
								<p class="rspd-text-muted">Rendered at the bottom of the page. You can paste combined HTML, CSS, and JS here too.</p>
								<textarea id="rspd-layout-footer-html" name="layout_injections[footer_html]" class="rspd-code rspd-layout-code" placeholder="<footer>...</footer>&#10;<style>...</style>&#10;<script>...</script>"><?php echo esc_textarea( isset( $layout_injections['footer_html'] ) ? $layout_injections['footer_html'] : '' ); ?></textarea>
							</div>
						</div>

						<div class="rspd-field" style="margin-top:22px;">
							<label class="rspd-field-label">Apply To Selected Deployed Pages</label>
							<p class="rspd-text-muted" style="margin:0 0 14px;">Only the checked managed pages will receive these blocks. Software apps stay separate and are not affected.</p>
							<?php if ( empty( $deployments ) ) : ?>
								<div class="rspd-status-note">
									<strong>No deployed pages yet.</strong>
									<span>Deploy a website page first, then come back here to assign your global header, body, and footer blocks.</span>
								</div>
							<?php else : ?>
								<div class="rspd-layout-selection-summary" data-layout-selection-summary>
									<strong data-layout-selection-count><?php echo esc_html( count( $layout_page_ids ) ); ?> page<?php echo 1 === count( $layout_page_ids ) ? '' : 's'; ?> selected</strong>
									<div class="rspd-layout-selection-chips" data-layout-selection-chips>
										<?php
										$selected_layout_pages = array();
										foreach ( $deployments as $d ) {
											if ( empty( $d['page']->ID ) || ! in_array( (int) $d['page']->ID, $layout_page_ids, true ) ) {
												continue;
											}
											$selected_layout_pages[] = $d['page']->post_title;
										}
										?>
										<?php if ( empty( $selected_layout_pages ) ) : ?>
											<span class="rspd-layout-selection-empty">No pages selected yet.</span>
										<?php else : ?>
											<?php foreach ( $selected_layout_pages as $selected_layout_page ) : ?>
												<span class="rspd-layout-selection-chip"><?php echo esc_html( $selected_layout_page ); ?></span>
											<?php endforeach; ?>
										<?php endif; ?>
									</div>
									<div class="rspd-tools-selection-actions">
										<button type="button" class="rspd-btn-sm" data-layout-select-all>Select All</button>
										<button type="button" class="rspd-btn-sm rspd-btn-secondary" data-layout-clear-all>Clear</button>
									</div>
								</div>
								<div class="rspd-layout-page-grid">
									<?php foreach ( $deployments as $d ) :
										$page      = $d['page'];
										$permalink = $d['permalink'];
										$checked   = in_array( (int) $page->ID, $layout_page_ids, true );
									?>
									<label class="rspd-layout-page-card">
										<input class="rspd-layout-page-checkbox" type="checkbox" name="layout_injections[page_ids][]" value="<?php echo esc_attr( $page->ID ); ?>" <?php checked( $checked ); ?>>
										<span class="rspd-layout-page-card-inner">
											<span class="rspd-layout-page-status"><?php echo $checked ? 'Applied' : 'Not Applied'; ?></span>
											<strong><?php echo esc_html( $page->post_title ); ?></strong>
											<span><?php echo esc_html( wp_make_link_relative( $permalink ) ); ?></span>
										</span>
									</label>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</div>

						<div class="rspd-deploy-bar" style="margin-top:20px;">
							<button type="submit" class="rspd-btn-deploy">Save Headers and Footers</button>
						</div>
					</form>
				</div>
			</div>

			<!-- ═══ DEPLOYMENTS LIST ═══ -->
			<?php if ( ! empty( $deployments ) || ! empty( $software_apps ) ) : ?>
			<div class="rspd-panel">
				<h2>Your Deployments</h2>
				<?php if ( ! empty( $deployments ) ) : ?>
				<div class="rspd-deploy-meta" style="margin-bottom:12px;"><strong>Website Pages</strong></div>
				<div class="rspd-deployments-grid">
					<?php foreach ( $deployments as $d ) :
						$page   = $d['page'];
						$config = $d['config'];
						$active = ! empty( $config['enabled'] );
						$permalink = $d['permalink'];
						$has_ab_test = ! empty( $config['ab_test']['enabled'] ) && ! empty( $config['ab_test']['variants'] );
					?>
					<div class="rspd-deploy-card <?php echo $active ? 'is-active' : 'is-disabled'; ?><?php echo $has_ab_test ? ' has-ab-test' : ''; ?>" data-page-id="<?php echo esc_attr( $page->ID ); ?>">
						<div class="rspd-deploy-card-head">
							<h3><?php echo esc_html( $page->post_title ); ?></h3>
							<span class="rspd-status-dot <?php echo $active ? 'active' : 'disabled'; ?>">
								<?php echo $active ? 'Live' : 'Off'; ?>
							</span>
						</div>
						<?php if ( $has_ab_test ) : ?>
						<div class="rspd-ab-variant-indicators">
							<span class="rspd-ab-indicator rspd-ab-indicator-running">A/B Test Running</span>
							<?php foreach ( $config['ab_test']['variants'] as $vkey => $vdata ) : ?>
								<span class="rspd-ab-variant-pill <?php echo 'control' === $vkey ? 'control' : 'variant'; ?>">
									<?php echo esc_html( $vdata['label'] ); ?> (<?php echo esc_html( $vdata['weight'] ); ?>%)
								</span>
							<?php endforeach; ?>
						</div>
						<?php endif; ?>
						<a href="<?php echo esc_url( $permalink ); ?>" class="rspd-deploy-url" target="_blank"><?php echo esc_html( $permalink ); ?></a>
						<div class="rspd-deploy-meta">
							Updated <?php echo esc_html( date( 'M j, Y g:i A', $d['updated_at'] ) ); ?>
						</div>
						<div class="rspd-deploy-actions">
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=rspd&edit=' . $page->ID ) ); ?>" class="rspd-btn-sm">Edit</a>
							<?php if ( $has_ab_test ) : ?>
							<button type="button" class="rspd-btn-sm rspd-btn-variant-settings-toggle" data-page-id="<?php echo esc_attr( $page->ID ); ?>">
								&#9881; Variant Settings
							</button>
							<?php else : ?>
							<?php
							$has_overrides  = ! empty( $config['page_overrides'] ) && is_array( $config['page_overrides'] );
							$override_count = $has_overrides ? $this->storage->count_override_keys( $config['page_overrides'] ) : 0;
							?>
							<button type="button" class="rspd-btn-sm rspd-btn-settings-toggle" data-page-id="<?php echo esc_attr( $page->ID ); ?>">
								&#9881; Settings<?php if ( $override_count ) : ?><span class="rspd-override-badge"><?php echo esc_html( $override_count ); ?></span><?php endif; ?>
							</button>
							<?php endif; ?>
							<a href="<?php echo esc_url( $permalink ); ?>" target="_blank" class="rspd-btn-sm">Open</a>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rspd-inline-form" onsubmit="return confirm('Delete this deployment? The page will revert to the normal theme.');">
								<input type="hidden" name="action" value="rspd_delete">
								<?php wp_nonce_field( 'rspd_delete' ); ?>
								<input type="hidden" name="page_id" value="<?php echo esc_attr( $page->ID ); ?>">
								<button type="submit" class="rspd-btn-sm rspd-btn-danger">Delete</button>
							</form>
						</div>
						<?php if ( $has_ab_test ) : ?>
						<div class="rspd-variant-settings-panel" data-page-id="<?php echo esc_attr( $page->ID ); ?>" style="display:none;">
							<div class="rspd-page-settings-loading">Loading variant settings...</div>
						</div>
						<?php else : ?>
						<div class="rspd-page-settings-panel" data-page-id="<?php echo esc_attr( $page->ID ); ?>" style="display:none;">
							<div class="rspd-page-settings-loading">Loading settings...</div>
						</div>
						<?php endif; ?>
					</div>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>

				<?php if ( ! empty( $software_apps ) ) : ?>
				<div class="rspd-deploy-meta" style="margin-top:<?php echo ! empty( $deployments ) ? '28px' : '0'; ?>;margin-bottom:12px;"><strong>Software Apps</strong></div>
				<div class="rspd-deployments-grid" style="margin-top:<?php echo ! empty( $deployments ) ? '24px' : '0'; ?>;">
					<?php foreach ( $software_apps as $app_slug => $app ) :
						$app_label = ! empty( $app['label'] ) ? $app['label'] : ucwords( str_replace( '-', ' ', $app_slug ) );
						$app_url   = $this->storage->get_software_mount_url( $app_slug );
						$app_routes = $this->get_software_app_routes( $app );
						$app_active = ! empty( $app['enabled'] );
					?>
					<div class="rspd-deploy-card <?php echo $app_active ? 'is-active' : 'is-disabled'; ?>">
						<div class="rspd-deploy-card-head">
							<h3><?php echo esc_html( $app_label ); ?></h3>
							<span class="rspd-status-dot <?php echo $app_active ? 'active' : 'disabled'; ?>">
								<?php echo $app_active ? 'Software Live' : 'Off'; ?>
							</span>
						</div>
						<div class="rspd-deploy-meta">Mounted at /<?php echo esc_html( $app_slug ); ?>/</div>
						<a href="<?php echo esc_url( $app_url ); ?>" class="rspd-deploy-url" target="_blank"><?php echo esc_html( $app_url ); ?></a>
						<div class="rspd-deploy-meta">
							Entry file: <?php echo esc_html( ! empty( $app['entry_file'] ) ? $app['entry_file'] : 'index.html' ); ?><br>
							Updated <?php echo esc_html( date( 'M j, Y g:i A', ! empty( $app['updated_at'] ) ? (int) $app['updated_at'] : time() ) ); ?>
						</div>
						<?php if ( ! empty( $app_routes ) ) : ?>
						<div class="rspd-deploy-meta">
							<strong>Mounted routes</strong>
						</div>
						<div class="rspd-ab-variant-indicators">
							<?php foreach ( $app_routes as $route ) : ?>
								<a href="<?php echo esc_url( $route['url'] ); ?>" target="_blank" class="rspd-ab-variant-pill <?php echo ! empty( $route['is_root'] ) ? 'control' : 'variant'; ?>">
									<?php echo esc_html( $route['file'] ); ?>
								</a>
							<?php endforeach; ?>
						</div>
						<?php endif; ?>
						<div class="rspd-deploy-actions">
							<a href="<?php echo esc_url( $app_url ); ?>" target="_blank" class="rspd-btn-sm">Open App</a>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rspd-inline-form" onsubmit="return confirm('Delete this software deployment? This will remove /<?php echo esc_js( $app_slug ); ?>/, delete its mounted files, and free the slug for reuse.');">
								<input type="hidden" name="action" value="rspd_delete_software">
								<?php wp_nonce_field( 'rspd_delete_software' ); ?>
								<input type="hidden" name="software_slug" value="<?php echo esc_attr( $app_slug ); ?>">
								<button type="submit" class="rspd-btn-sm rspd-btn-danger" title="<?php echo esc_attr( sprintf( 'Delete /%s/ and free this slug for reuse.', $app_slug ) ); ?>">Delete</button>
							</form>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}

	// ─── SETTINGS PAGE ───

	public function render_settings_page() {
		$settings = $this->storage->get_settings();
		$this->license->maybe_refresh_status( false, 'settings' );
		$license_context = $this->license->get_status_context();
		$license_locked  = $this->license->should_block_admin();
		?>
		<div class="rspd-wrap">
			<div class="rspd-header">
				<div>
					<div class="rspd-header-row">
						<img src="<?php echo esc_url( $this->logo_url ); ?>" alt="Reputifly" class="rspd-logo">
						<div class="rspd-header-text">
							<h1>Access &amp; Settings</h1>
							<p class="rspd-subtitle">Connect the site first. Everything else is optional.</p>
						</div>
					</div>
				</div>
			</div>

			<div class="rspd-panel">
				<div class="rspd-license-panel-head">
					<div>
						<h2>Connect This Site</h2>
						<p class="rspd-subtitle"><?php echo esc_html( $license_context['message'] ); ?></p>
					</div>
					<span class="rspd-license-pill rspd-license-pill--<?php echo esc_attr( $license_context['tone'] ); ?>"><?php echo esc_html( $license_context['label'] ); ?></span>
				</div>

				<?php $this->render_license_summary_cards( $license_context ); ?>

				<div class="rspd-license-actions" style="margin-top:16px;">
					<?php if ( ! empty( $license_context['can_request'] ) ) : ?>
						<?php $this->render_license_request_form( $license_context ); ?>
					<?php else : ?>
					<div class="rspd-status-note rspd-status-note--success">
						<strong>Site connected.</strong>
						<span>This plugin is live. Revoke the key from your Reputifly dashboard any time you want to shut access off.</span>
					</div>
					<?php endif; ?>
				</div>

				<?php $this->render_license_technical_details( $license_context ); ?>

				<?php if ( ! empty( $license_context['last_error'] ) ) : ?>
				<div class="rspd-license-error"><?php echo esc_html( $license_context['last_error'] ); ?></div>
				<?php endif; ?>
			</div>

			<?php if ( ! $license_locked ) : ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rspd-form">
					<input type="hidden" name="action" value="rspd_save_settings">
					<?php wp_nonce_field( 'rspd_save_settings' ); ?>

					<div class="rspd-panel">
						<h2>Performance Defaults</h2>
						<div class="rspd-settings-grid">
							<?php
							$perf = $settings['performance'];
							$checks = array(
								'enable_html_cache'    => 'Cache rendered HTML',
								'minify_html'          => 'Minify HTML output',
								'minify_inline'        => 'Minify inline CSS &amp; JS',
								'lazy_load_images'     => 'Lazy-load images',
								'disable_emoji'        => 'Disable emoji scripts',
								'disable_wp_embed'     => 'Disable wp-embed',
								'asset_fingerprinting' => 'Fingerprint assets (cache busting)',
								'defer_scripts'        => 'Defer external scripts',
							);
							foreach ( $checks as $key => $label ) :
							?>
							<label class="rspd-check-item">
								<input type="hidden" name="performance[<?php echo esc_attr( $key ); ?>]" value="0">
								<input type="checkbox" name="performance[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( ! empty( $perf[ $key ] ) ); ?>>
								<span><?php echo esc_html( $label ); ?></span>
							</label>
							<?php endforeach; ?>
						</div>
					</div>

					<div class="rspd-panel">
						<h2>Uninstall Behavior</h2>
						<label class="rspd-check-item">
							<input type="hidden" name="data[remove_on_uninstall]" value="0">
							<input type="checkbox" name="data[remove_on_uninstall]" value="1" <?php checked( ! empty( $settings['data']['remove_on_uninstall'] ) ); ?>>
							<span>Remove all deployment data when plugin is uninstalled</span>
						</label>
					</div>

					<div class="rspd-deploy-bar">
						<button type="submit" class="rspd-btn-deploy">Save Settings</button>
					</div>
				</form>
			<?php endif; ?>

			<?php
			$page_map = $this->storage->get_page_map();
			$pages_with_overrides = array();
			foreach ( $page_map as $pid => $entry ) {
				if ( ! empty( $entry['has_overrides'] ) ) {
					$pages_with_overrides[ $pid ] = $entry;
				}
			}
			if ( ! $license_locked && ! empty( $pages_with_overrides ) ) : ?>
			<div class="rspd-panel" style="margin-top:28px;">
				<h2>Pages with Custom Settings</h2>
				<p class="rspd-text-muted" style="margin-bottom:16px;">
					These pages have settings that override your global defaults. Changes to global settings will not affect overridden values.
				</p>
				<div class="rspd-overrides-table">
					<?php foreach ( $pages_with_overrides as $pid => $entry ) :
						$page_title     = get_the_title( $pid );
						$o_count        = isset( $entry['override_count'] ) ? (int) $entry['override_count'] : 0;
					?>
					<div class="rspd-overrides-row">
						<div class="rspd-overrides-page">
							<strong><?php echo esc_html( $page_title ); ?></strong>
							<span class="rspd-override-count"><?php echo esc_html( $o_count ); ?> override<?php echo 1 !== $o_count ? 's' : ''; ?></span>
						</div>
						<div class="rspd-overrides-actions">
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=rspd' ) ); ?>" class="rspd-btn-sm">View on Deploy Page</a>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}

	// ─── TOOLS PAGE ───

	public function render_tools_page() {
		$this->license->maybe_refresh_status( false, 'admin_screen' );
		if ( $this->license->should_block_admin() ) {
			$this->render_license_locked_page( 'Tools' );
			return;
		}

		$deployments  = $this->storage->get_deployments();
		$last_result  = $this->consume_tools_replace_result();
		$selected_ids = ! empty( $last_result['page_ids'] ) && is_array( $last_result['page_ids'] ) ? array_map( 'absint', $last_result['page_ids'] ) : array();
		?>
		<div class="rspd-wrap">
			<div class="rspd-header">
				<div>
					<div class="rspd-header-row">
						<img src="<?php echo esc_url( $this->logo_url ); ?>" alt="Reputifly" class="rspd-logo">
						<div class="rspd-header-text">
							<h1>Reputifly <span class="rspd-brand-accent">Tools</span></h1>
							<p class="rspd-subtitle">Maintenance utilities for deployed website pages without touching software apps.</p>
						</div>
					</div>
				</div>
			</div>

			<div class="rspd-panel">
				<h2>Replace URL</h2>
				<p class="rspd-text-muted" style="margin-bottom:16px;">Select deployed pages, enter the exact original URL, then replace it across the selected deployment files. A backup is created automatically before anything changes.</p>

				<?php if ( ! empty( $last_result ) ) : ?>
				<div class="rspd-tools-result-grid">
					<div class="rspd-access-card">
						<span class="rspd-license-meta-label">Pages Updated</span>
						<strong><?php echo esc_html( isset( $last_result['pages_updated'] ) ? (int) $last_result['pages_updated'] : 0 ); ?></strong>
					</div>
					<div class="rspd-access-card">
						<span class="rspd-license-meta-label">Files Changed</span>
						<strong><?php echo esc_html( isset( $last_result['files_changed'] ) ? (int) $last_result['files_changed'] : 0 ); ?></strong>
					</div>
					<div class="rspd-access-card">
						<span class="rspd-license-meta-label">Replacements</span>
						<strong><?php echo esc_html( isset( $last_result['replacement_count'] ) ? (int) $last_result['replacement_count'] : 0 ); ?></strong>
					</div>
					<div class="rspd-access-card">
						<span class="rspd-license-meta-label">Backup Created</span>
						<strong><?php echo ! empty( $last_result['backup_relative_dir'] ) ? esc_html( $last_result['backup_relative_dir'] ) : 'Not needed'; ?></strong>
					</div>
				</div>
				<?php endif; ?>

				<?php if ( empty( $deployments ) ) : ?>
					<div class="rspd-status-note">
						<strong>No deployed website pages yet.</strong>
						<span>Deploy a website page first, then come back here to run URL replacement safely.</span>
					</div>
				<?php else : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rspd-form">
						<input type="hidden" name="action" value="rspd_replace_urls">
						<?php wp_nonce_field( 'rspd_replace_urls' ); ?>

						<div class="rspd-status-note">
							<strong>Exact string replacement only.</strong>
							<span>This updates the selected page deployments and their active A/B variant folders when present. Software app mounts are not affected.</span>
						</div>

						<div class="rspd-tools-fields-grid">
							<div class="rspd-field">
								<label class="rspd-field-label" for="rspd-tools-original-url">Original URL</label>
								<input type="text" id="rspd-tools-original-url" name="replace_tools[original_url]" class="rspd-input" placeholder="https://old-domain.com/example">
							</div>
							<div class="rspd-field">
								<label class="rspd-field-label" for="rspd-tools-new-url">New URL</label>
								<input type="text" id="rspd-tools-new-url" name="replace_tools[new_url]" class="rspd-input" placeholder="https://new-domain.com/example">
							</div>
						</div>

						<div class="rspd-field" style="margin-top:22px;">
							<label class="rspd-field-label">Apply To Selected Deployed Pages</label>
							<p class="rspd-text-muted" style="margin:0 0 14px;">Choose the deployed website pages you want to update.</p>
							<div class="rspd-layout-selection-summary" data-tools-selection-summary>
								<strong data-tools-selection-count><?php echo esc_html( count( $selected_ids ) ); ?> page<?php echo 1 === count( $selected_ids ) ? '' : 's'; ?> selected</strong>
								<div class="rspd-layout-selection-chips" data-tools-selection-chips>
									<?php if ( empty( $selected_ids ) ) : ?>
										<span class="rspd-layout-selection-empty">No pages selected yet.</span>
									<?php else : ?>
										<?php foreach ( $deployments as $deployment ) : ?>
											<?php if ( empty( $deployment['page']->ID ) || ! in_array( (int) $deployment['page']->ID, $selected_ids, true ) ) { continue; } ?>
											<span class="rspd-layout-selection-chip"><?php echo esc_html( $deployment['page']->post_title ); ?></span>
										<?php endforeach; ?>
									<?php endif; ?>
								</div>
								<div class="rspd-tools-selection-actions">
									<button type="button" class="rspd-btn-sm" data-tools-select-all>Select All</button>
									<button type="button" class="rspd-btn-sm rspd-btn-secondary" data-tools-clear-all>Clear</button>
								</div>
							</div>

							<div class="rspd-layout-page-grid">
								<?php foreach ( $deployments as $deployment ) : ?>
									<?php
									$page      = $deployment['page'];
									$permalink = $deployment['permalink'];
									$checked   = in_array( (int) $page->ID, $selected_ids, true );
									?>
									<label class="rspd-layout-page-card">
										<input class="rspd-layout-page-checkbox" type="checkbox" name="replace_tools[page_ids][]" value="<?php echo esc_attr( $page->ID ); ?>" <?php checked( $checked ); ?>>
										<span class="rspd-layout-page-card-inner">
											<span class="rspd-layout-page-status"><?php echo $checked ? 'Selected' : 'Not Selected'; ?></span>
											<strong><?php echo esc_html( $page->post_title ); ?></strong>
											<span><?php echo esc_html( wp_make_link_relative( $permalink ) ); ?></span>
										</span>
									</label>
								<?php endforeach; ?>
							</div>
						</div>

						<div class="rspd-deploy-bar" style="margin-top:20px;">
							<button type="submit" class="rspd-btn-deploy">Replace URL</button>
						</div>
					</form>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	// ─── SEO INTELLIGENCE PAGE ───

	public function render_seo_page() {
		$this->license->maybe_refresh_status( false, 'admin_screen' );
		if ( $this->license->should_block_admin() ) {
			$this->render_license_locked_page( 'SEO Intelligence' );
			return;
		}

		$deployments = $this->storage->get_deployments();
		$total       = count( $deployments );
		$scores      = array();
		$with_schema = 0;
		$with_og     = 0;
		foreach ( $deployments as $d ) {
			$s       = $this->calculate_seo_score( $d['config'] );
			$scores[] = $s;
			if ( ! empty( $d['config']['schema']['type'] ) && 'none' !== $d['config']['schema']['type'] ) {
				$with_schema++;
			}
			if ( ! empty( $d['config']['social']['og_title'] ) || ! empty( $d['config']['social']['og_image'] ) ) {
				$with_og++;
			}
		}
		$avg_score = $total > 0 ? round( array_sum( $scores ) / $total ) : 0;
		?>
		<div class="rspd-wrap">
			<div class="rspd-header">
				<div>
					<div class="rspd-header-row">
						<img src="<?php echo esc_url( $this->logo_url ); ?>" alt="Reputifly" class="rspd-logo">
						<div class="rspd-header-text">
							<h1>Reputifly <span class="rspd-brand-accent">Archimedes</span></h1>
							<p class="rspd-subtitle">SEO Intelligence — Structured data &amp; optimization scores per page.</p>
						</div>
					</div>
				</div>
			</div>

			<!-- Stats Bar -->
			<div class="rspd-panel rspd-seo-stats-bar">
				<div class="rspd-seo-stat">
					<span class="rspd-seo-stat-num"><?php echo esc_html( $total ); ?></span>
					<span class="rspd-seo-stat-label">Pages Deployed</span>
				</div>
				<div class="rspd-seo-stat-divider"></div>
				<div class="rspd-seo-stat">
					<span class="rspd-seo-stat-num" style="color:<?php echo $avg_score >= 80 ? 'var(--rspd-green)' : ( $avg_score >= 50 ? 'var(--rspd-orange)' : 'var(--rspd-pink)' ); ?>"><?php echo esc_html( $avg_score ); ?></span>
					<span class="rspd-seo-stat-label">Avg SEO Score</span>
				</div>
				<div class="rspd-seo-stat-divider"></div>
				<div class="rspd-seo-stat">
					<span class="rspd-seo-stat-num" style="color:var(--rspd-green)"><?php echo esc_html( $with_schema ); ?></span>
					<span class="rspd-seo-stat-label">With Schema</span>
				</div>
				<div class="rspd-seo-stat-divider"></div>
				<div class="rspd-seo-stat">
					<span class="rspd-seo-stat-num" style="color:var(--rspd-text-muted)"><?php echo esc_html( $total - $with_schema ); ?></span>
					<span class="rspd-seo-stat-label">Missing Schema</span>
				</div>
				<div class="rspd-seo-stat-divider"></div>
				<div class="rspd-seo-stat">
					<span class="rspd-seo-stat-num" style="color:<?php echo $with_og > 0 ? 'var(--rspd-blue)' : 'var(--rspd-text-muted)'; ?>"><?php echo esc_html( $with_og ); ?></span>
					<span class="rspd-seo-stat-label">Social Cards</span>
				</div>
			</div>

			<!-- Pages List -->
			<div class="rspd-panel">
				<h2>Deployed Pages</h2>
				<?php if ( empty( $deployments ) ) : ?>
					<div class="rspd-seo-empty">
						<p style="font-size:15px;font-weight:600;margin-bottom:12px;">No deployed pages yet.</p>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=rspd' ) ); ?>" class="rspd-btn-deploy" style="display:inline-block;text-decoration:none;">Deploy Your First Page</a>
					</div>
				<?php else : ?>
					<div class="rspd-seo-pages" id="rspd-seo-pages">
						<?php foreach ( $deployments as $d ) :
							$page      = $d['page'];
							$config    = $d['config'];
							$permalink = $d['permalink'];
							$score     = $this->calculate_seo_score( $config );
							$breakdown = $this->get_score_breakdown( $config );
							$schema    = isset( $config['schema'] ) && is_array( $config['schema'] ) ? $config['schema'] : array();
							$schema_type = isset( $schema['type'] ) ? $schema['type'] : 'none';
							$schema_labels = array(
								'none'           => array( 'label' => 'No Schema',       'color' => 'muted' ),
								'custom_json'    => array( 'label' => 'Custom JSON-LD',  'color' => 'purple' ),
								'local_business' => array( 'label' => 'Local Business',  'color' => 'pink' ),
								'webpage'        => array( 'label' => 'Web Page',        'color' => 'blue' ),
								'article'        => array( 'label' => 'Article',         'color' => 'purple' ),
								'faq'            => array( 'label' => 'FAQ Page',        'color' => 'orange' ),
								'product'        => array( 'label' => 'Product',         'color' => 'green' ),
								'service'        => array( 'label' => 'Service',         'color' => 'green' ),
							);
							$sl = isset( $schema_labels[ $schema_type ] ) ? $schema_labels[ $schema_type ] : $schema_labels['none'];
							$test_url = 'https://search.google.com/test/rich-results?url=' . rawurlencode( $permalink );
							$social   = isset( $config['social'] ) && is_array( $config['social'] ) ? $config['social'] : array();
							$has_og   = ! empty( $social['og_title'] ) || ! empty( $social['og_image'] );
						?>
						<div class="rspd-seo-card" id="seo-card-<?php echo esc_attr( $page->ID ); ?>" data-page-id="<?php echo esc_attr( $page->ID ); ?>" data-schema="<?php echo esc_attr( wp_json_encode( $schema ) ); ?>">
							<div class="rspd-seo-card-main">
								<!-- Score Ring -->
								<?php echo $this->render_score_ring( $score ); ?>

								<!-- Info -->
								<div class="rspd-seo-card-info">
									<div class="rspd-seo-card-title"><?php echo esc_html( $page->post_title ); ?></div>
									<a href="<?php echo esc_url( $permalink ); ?>" target="_blank" class="rspd-seo-card-url"><?php echo esc_html( $permalink ); ?></a>
									<div class="rspd-breakdown">
										<?php foreach ( $breakdown as $check ) : ?>
											<span class="rspd-breakdown-dot <?php echo $check['passed'] ? 'pass' : 'fail'; ?>" title="<?php echo esc_attr( $check['label'] . ': ' . $check['points'] . ' pts' . ( $check['passed'] ? ' ✓' : ' ✗' ) ); ?>">
												<?php echo esc_html( $check['label'] ); ?>
											</span>
										<?php endforeach; ?>
									</div>
								</div>

								<!-- Actions -->
								<div class="rspd-seo-card-actions">
									<span class="rspd-schema-badge rspd-schema-badge--<?php echo esc_attr( $sl['color'] ); ?>"><?php echo esc_html( $sl['label'] ); ?></span>
									<span class="rspd-schema-badge rspd-schema-badge--<?php echo $has_og ? 'blue' : 'muted'; ?> rspd-og-badge"><?php echo $has_og ? 'OG Ready' : 'No OG'; ?></span>
									<button type="button" class="rspd-btn-sm rspd-btn-schema-edit" data-page-id="<?php echo esc_attr( $page->ID ); ?>">Edit Schema</button>
									<button type="button" class="rspd-btn-sm rspd-btn-social-edit" data-page-id="<?php echo esc_attr( $page->ID ); ?>">Edit Social</button>
									<a href="<?php echo esc_url( $test_url ); ?>" target="_blank" class="rspd-btn-sm rspd-btn-test" title="Test with Google Rich Results">Test ↗</a>
								</div>
							</div>

							<!-- Inline Schema Editor (JS populates) -->
							<div class="rspd-schema-editor" id="schema-editor-<?php echo esc_attr( $page->ID ); ?>" style="display:none;"></div>

							<!-- Inline Social Editor (JS populates) -->
							<div class="rspd-schema-editor" id="social-editor-<?php echo esc_attr( $page->ID ); ?>" style="display:none;"></div>
						</div>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	// ─── SEO Score Helpers ───

	protected function calculate_seo_score( array $config ) {
		$score = 0;
		foreach ( $this->get_score_breakdown( $config ) as $check ) {
			if ( $check['passed'] ) {
				$score += $check['points'];
			}
		}
		return min( 100, $score );
	}

	protected function get_score_breakdown( array $config ) {
		$perf   = isset( $config['performance'] ) && is_array( $config['performance'] ) ? $config['performance'] : array();
		$meta   = isset( $config['metadata'] ) && is_array( $config['metadata'] ) ? $config['metadata'] : array();
		$schema = isset( $config['schema'] ) && is_array( $config['schema'] ) ? $config['schema'] : array();
		$social = isset( $config['social'] ) && is_array( $config['social'] ) ? $config['social'] : array();

		return array(
			array( 'key' => 'canonical',    'label' => 'Canonical',     'points' => 10, 'passed' => true ),
			array( 'key' => 'description',  'label' => 'Meta Desc',     'points' => 15, 'passed' => ! empty( $meta['description'] ) ),
			array( 'key' => 'schema',       'label' => 'Schema',        'points' => 15, 'passed' => ! empty( $schema['type'] ) && 'none' !== $schema['type'] ),
			array( 'key' => 'og_tags',      'label' => 'OG Tags',       'points' => 10, 'passed' => ! empty( $social['og_title'] ) || ! empty( $social['og_image'] ) ),
			array( 'key' => 'lazy_load',    'label' => 'Lazy Load',     'points' => 10, 'passed' => ! empty( $perf['lazy_load_images'] ) ),
			array( 'key' => 'defer',        'label' => 'Defer Scripts', 'points' => 10, 'passed' => ! empty( $perf['defer_scripts'] ) ),
			array( 'key' => 'minify',       'label' => 'Minify',        'points' => 10, 'passed' => ! empty( $perf['minify_html'] ) ),
			array( 'key' => 'fingerprint',  'label' => 'Fingerprinting','points' => 10, 'passed' => ! empty( $perf['asset_fingerprinting'] ) ),
			array( 'key' => 'cache',        'label' => 'Cache',         'points' => 10, 'passed' => ! empty( $perf['enable_html_cache'] ) ),
		);
	}

	protected function render_score_ring( $score ) {
		$r     = 28;
		$cx    = $cy = 36;
		$circ  = 2 * M_PI * $r;
		$off   = $circ * ( 1 - $score / 100 );
		$color = $score >= 80 ? '#34D399' : ( $score >= 50 ? '#FF8A00' : '#E6397F' );

		return '<div class="rspd-score-ring-wrap">'
			. '<svg width="72" height="72" viewBox="0 0 72 72" style="display:block">'
			. '<circle cx="' . $cx . '" cy="' . $cy . '" r="' . $r . '" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="5"/>'
			. '<circle cx="' . $cx . '" cy="' . $cy . '" r="' . $r . '" fill="none" stroke="' . esc_attr( $color ) . '" stroke-width="5" stroke-linecap="round"'
			. ' stroke-dasharray="' . number_format( $circ, 2 ) . '" stroke-dashoffset="' . number_format( $off, 2 ) . '"'
			. ' transform="rotate(-90 ' . $cx . ' ' . $cy . ')"/>'
			. '</svg>'
			. '<div class="rspd-score-ring-label">'
			. '<span class="rspd-score-num" style="color:' . esc_attr( $color ) . '">' . esc_html( $score ) . '</span>'
			. '<span class="rspd-score-pct">/100</span>'
			. '</div>'
			. '</div>';
	}

	// ─── AJAX: Save Schema ───

	public function ajax_save_schema() {
		check_ajax_referer( 'rspd_save_schema', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
		}

		$page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
			wp_send_json_error( array( 'message' => 'Invalid page.' ) );
		}

		$raw = isset( $_POST['schema'] ) && is_array( $_POST['schema'] ) ? $_POST['schema'] : array();

		// Sanitize schema fields.
		$schema = array();
		$schema['type'] = sanitize_key( isset( $raw['type'] ) ? $raw['type'] : 'none' );

		// Pro Mode: raw JSON-LD — validate JSON and store as string.
		if ( 'custom_json' === $schema['type'] ) {
			$json_ld = isset( $raw['json_ld'] ) ? wp_unslash( $raw['json_ld'] ) : '';
			$json_ld = trim( $json_ld );
			if ( ! empty( $json_ld ) ) {
				$decoded = json_decode( $json_ld, true );
				if ( json_last_error() !== JSON_ERROR_NONE ) {
					wp_send_json_error( array( 'message' => 'Invalid JSON: ' . json_last_error_msg() ) );
				}
				// Re-encode to ensure clean storage.
				$schema['json_ld'] = wp_json_encode( $decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			}
		} else {
			$text_fields = array( 'name', 'description', 'telephone', 'email', 'street_address', 'city', 'state',
				'postal_code', 'country', 'hours', 'price_range', 'business_type', 'author_name',
				'publisher_name', 'publisher_logo', 'date_published', 'brand_name', 'price', 'currency',
				'provider_name', 'area_served' );
			foreach ( $text_fields as $f ) {
				if ( isset( $raw[ $f ] ) && '' !== $raw[ $f ] ) {
					$schema[ $f ] = sanitize_text_field( $raw[ $f ] );
				}
			}

			// FAQ rows.
			if ( isset( $raw['faqs'] ) && is_array( $raw['faqs'] ) ) {
				$faqs = array();
				foreach ( $raw['faqs'] as $faq ) {
					if ( ! empty( $faq['question'] ) && ! empty( $faq['answer'] ) ) {
						$faqs[] = array(
							'question' => sanitize_text_field( $faq['question'] ),
							'answer'   => sanitize_textarea_field( $faq['answer'] ),
						);
					}
				}
				if ( ! empty( $faqs ) ) {
					$schema['faqs'] = $faqs;
				}
			}
		}

		$config           = $this->storage->get_page_config( $page_id );
		$config['schema'] = $schema;
		$this->storage->update_page_config( $page_id, $config );

		// Clear render cache so schema appears immediately.
		delete_transient( 'rspd_render_' . $page_id );

		$new_score     = $this->calculate_seo_score( $config );
		$new_breakdown = $this->get_score_breakdown( $config );

		wp_send_json_success( array(
			'message'   => 'Schema saved.',
			'score'     => $new_score,
			'breakdown' => $new_breakdown,
			'type'      => $schema['type'],
		) );
	}

	// ─── AJAX: Save Social (OG + Twitter) ───

	public function ajax_save_social() {
		check_ajax_referer( 'rspd_save_social', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
		}

		$page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
			wp_send_json_error( array( 'message' => 'Invalid page.' ) );
		}

		$raw = isset( $_POST['social'] ) && is_array( $_POST['social'] ) ? $_POST['social'] : array();

		$allowed = array( 'og_title', 'og_description', 'og_image', 'og_type', 'og_site_name', 'twitter_card' );
		$social  = array();
		foreach ( $allowed as $key ) {
			if ( isset( $raw[ $key ] ) && '' !== $raw[ $key ] ) {
				$social[ $key ] = sanitize_text_field( $raw[ $key ] );
			}
		}

		$config            = $this->storage->get_page_config( $page_id );
		$config['social']  = $social;
		$this->storage->update_page_config( $page_id, $config );

		delete_transient( 'rspd_render_' . $page_id );

		$new_score     = $this->calculate_seo_score( $config );
		$new_breakdown = $this->get_score_breakdown( $config );
		$has_og        = ! empty( $social['og_title'] ) || ! empty( $social['og_image'] );

		wp_send_json_success( array(
			'message'   => 'Social tags saved.',
			'score'     => $new_score,
			'breakdown' => $new_breakdown,
			'has_og'    => $has_og,
		) );
	}

	// ─── A/B TESTING PAGE ───

	public function render_ab_page() {
		$this->license->maybe_refresh_status( false, 'admin_screen' );
		if ( $this->license->should_block_admin() ) {
			$this->render_license_locked_page( 'A/B Testing' );
			return;
		}

		$deployments = $this->storage->get_deployments();
		$active_tests = array();
		$eligible     = array();

		foreach ( $deployments as $d ) {
			$ab = isset( $d['config']['ab_test'] ) && is_array( $d['config']['ab_test'] ) ? $d['config']['ab_test'] : array();
			if ( ! empty( $ab['enabled'] ) && ! empty( $ab['variants'] ) ) {
				$active_tests[] = array(
					'page'      => $d['page'],
					'permalink' => $d['permalink'],
					'ab_test'   => $ab,
				);
			} else {
				$eligible[] = array(
					'page'      => $d['page'],
					'permalink' => $d['permalink'],
				);
			}
		}
		?>
		<div class="rspd-wrap" id="rspd-ab-page">
			<div class="rspd-header">
				<div>
					<div class="rspd-header-row">
						<img src="<?php echo esc_url( $this->logo_url ); ?>" alt="Reputifly" class="rspd-logo">
						<div class="rspd-header-text">
							<h1>Reputifly <span class="rspd-brand-accent">Archimedes</span></h1>
							<p class="rspd-subtitle">A/B Testing — Deploy variants and find your best-performing page.</p>
						</div>
					</div>
				</div>
			</div>

			<!-- Active Tests -->
			<div class="rspd-panel">
				<h2>Active Tests</h2>
				<?php if ( empty( $active_tests ) ) : ?>
					<p style="color:var(--rspd-text-muted);margin:20px 0;">No active tests. Create one below.</p>
				<?php else : ?>
					<div class="rspd-ab-tests-list">
					<?php foreach ( $active_tests as $t ) :
						$page    = $t['page'];
						$ab      = $t['ab_test'];
						$created = ! empty( $ab['created_at'] ) ? human_time_diff( $ab['created_at'], time() ) . ' ago' : 'Unknown';
					?>
						<div class="rspd-ab-test-card" data-page-id="<?php echo esc_attr( $page->ID ); ?>">
							<div class="rspd-ab-test-header">
								<div>
									<div class="rspd-ab-test-title"><?php echo esc_html( $page->post_title ); ?></div>
									<a href="<?php echo esc_url( $t['permalink'] ); ?>" target="_blank" class="rspd-seo-card-url"><?php echo esc_html( $t['permalink'] ); ?></a>
								</div>
								<div class="rspd-ab-status rspd-ab-status--running">Running</div>
							</div>
							<div class="rspd-ab-variants-row">
								<?php foreach ( $ab['variants'] as $key => $v ) : ?>
									<div class="rspd-ab-variant-pill rspd-ab-variant-pill--<?php echo 'control' === $key ? 'control' : 'variant'; ?>">
										<span class="rspd-ab-variant-label"><?php echo esc_html( $v['label'] ); ?></span>
										<span class="rspd-ab-variant-weight"><?php echo esc_html( $v['weight'] ); ?>%</span>
									</div>
								<?php endforeach; ?>
								<span class="rspd-ab-test-date">Started <?php echo esc_html( $created ); ?></span>
							</div>
							<div class="rspd-ab-split-row">
								<?php foreach ( $ab['variants'] as $key => $v ) : ?>
									<div class="rspd-ab-split-input-group">
										<label><?php echo esc_html( $v['label'] ); ?></label>
										<input type="number" class="rspd-input rspd-ab-weight-input" data-variant="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $v['weight'] ); ?>" min="1" max="99" style="width:64px;">
										<span>%</span>
									</div>
								<?php endforeach; ?>
								<button type="button" class="rspd-btn-sm rspd-ab-update-split-btn">Update Split</button>
							</div>
							<div class="rspd-ab-test-actions">
								<div class="rspd-ab-end-group">
									<select class="rspd-select rspd-ab-winner-select" style="width:auto;">
										<?php foreach ( $ab['variants'] as $key => $v ) : ?>
											<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $v['label'] ); ?></option>
										<?php endforeach; ?>
									</select>
									<button type="button" class="rspd-btn-sm rspd-ab-end-btn" style="background:rgba(248,113,113,0.1);border-color:rgba(248,113,113,0.2);color:#F87171;">End Test &amp; Pick Winner</button>
								</div>
								<button type="button" class="rspd-btn-sm rspd-ab-toggle-btn" data-enabled="1">Pause Test</button>
							</div>
						</div>
					<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>

			<!-- Create New Test -->
			<div class="rspd-panel">
				<h2>Create New Test</h2>
				<?php if ( empty( $eligible ) ) : ?>
					<p style="color:var(--rspd-text-muted);margin:20px 0;">All deployed pages already have active tests, or no pages are deployed yet.</p>
				<?php else : ?>
					<div class="rspd-ab-create-section">
						<div class="rspd-field">
							<label class="rspd-label">Select Page</label>
							<select class="rspd-select" id="rspd-ab-page-select">
								<option value="">— Choose a deployed page —</option>
								<?php foreach ( $eligible as $e ) : ?>
									<option value="<?php echo esc_attr( $e['page']->ID ); ?>" data-title="<?php echo esc_attr( $e['page']->post_title ); ?>" data-url="<?php echo esc_attr( $e['permalink'] ); ?>">
										<?php echo esc_html( $e['page']->post_title ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>

						<div id="rspd-ab-control-preview" style="display:none;">
							<div class="rspd-ab-control-card">
								<span class="rspd-ab-variant-pill rspd-ab-variant-pill--control">
									<span class="rspd-ab-variant-label">Control (Original)</span>
								</span>
								<span id="rspd-ab-control-title" style="color:var(--rspd-text);font-weight:600;"></span>
								<span id="rspd-ab-control-url" style="color:var(--rspd-text-muted);font-size:12px;"></span>
							</div>
						</div>

						<div class="rspd-field" id="rspd-ab-variant-section" style="display:none;">
							<label class="rspd-label">Variant B — Paste HTML</label>
							<textarea class="rspd-code" id="rspd-ab-variant-html" rows="12" placeholder="Paste your variant HTML here..."></textarea>
						</div>

						<div class="rspd-ab-split-row" id="rspd-ab-create-split" style="display:none;">
							<div class="rspd-ab-split-input-group">
								<label>Control</label>
								<input type="number" class="rspd-input" id="rspd-ab-weight-control" value="50" min="1" max="99" style="width:64px;">
								<span>%</span>
							</div>
							<div class="rspd-ab-split-input-group">
								<label>Variant B</label>
								<input type="number" class="rspd-input" id="rspd-ab-weight-variant" value="50" min="1" max="99" style="width:64px;">
								<span>%</span>
							</div>
						</div>

						<div id="rspd-ab-deploy-section" style="display:none;">
							<button type="button" class="rspd-btn-deploy" id="rspd-ab-deploy-btn">Deploy &amp; Start Test</button>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	// ─── AJAX: A/B Create ───

	/**
	 * Render the isolated Labs area for experimental export tooling.
	 *
	 * @return void
	 */
	public function render_labs_page() {
		$this->license->maybe_refresh_status( false, 'admin_screen' );
		if ( $this->license->should_block_admin() ) {
			$this->render_license_locked_page( 'Labs' );
			return;
		}

		$elementor_active = $this->is_elementor_active();
		$sources          = $elementor_active ? $this->get_elementor_source_pages() : array();
		$pages            = get_pages( array( 'sort_column' => 'post_title', 'sort_order' => 'asc' ) );
		$result           = $this->consume_labs_result();
		$restorable       = $this->get_restorable_elementor_exports();
		?>
		<div class="rspd-wrap" id="rspd-labs-page">
			<div class="rspd-header">
				<div>
					<div class="rspd-header-row">
						<img src="<?php echo esc_url( $this->logo_url ); ?>" alt="Reputifly" class="rspd-logo">
						<div class="rspd-header-text">
							<h1>Reputifly <span class="rspd-brand-accent">Labs</span></h1>
							<p class="rspd-subtitle">Experimental exports that stay isolated from your normal deployment flow.</p>
						</div>
					</div>
				</div>
			</div>

			<div class="rspd-panel">
				<div class="rspd-license-panel-head">
					<div>
						<h2>Elementor Export</h2>
						<p class="rspd-subtitle">Select Elementor-built pages, capture their live frontend output, then convert them into Archimedes deployments.</p>
					</div>
					<span class="rspd-license-pill rspd-license-pill--<?php echo $elementor_active ? 'success' : 'warning'; ?>">
						<?php echo $elementor_active ? 'Elementor Ready' : 'Elementor Inactive'; ?>
					</span>
				</div>

				<div class="rspd-status-note<?php echo $elementor_active ? '' : ' rspd-status-note--warning'; ?>">
					<strong><?php echo $elementor_active ? 'Live frontend capture enabled.' : 'Elementor is not active on this site.'; ?></strong>
					<span>
						<?php
						echo $elementor_active
							? esc_html__( 'This captures the rendered public page, localizes same-origin assets into a static package, then deploys it through the normal Archimedes page pipeline.', 'reputifly-static-page-deployer' )
							: esc_html__( 'Activate Elementor first, then come back here to convert Elementor pages into Archimedes deployments.', 'reputifly-static-page-deployer' );
						?>
					</span>
				</div>
			</div>

			<?php if ( ! empty( $result ) ) : ?>
			<div class="rspd-panel">
				<h2>Last Conversion</h2>
				<div class="rspd-tools-result-grid">
					<div class="rspd-access-card">
						<span class="rspd-license-meta-label">Converted</span>
						<strong><?php echo esc_html( isset( $result['converted_count'] ) ? (int) $result['converted_count'] : 0 ); ?></strong>
					</div>
					<div class="rspd-access-card">
						<span class="rspd-license-meta-label">Created Pages</span>
						<strong><?php echo esc_html( isset( $result['created_count'] ) ? (int) $result['created_count'] : 0 ); ?></strong>
					</div>
					<div class="rspd-access-card">
						<span class="rspd-license-meta-label">Warnings</span>
						<strong><?php echo esc_html( isset( $result['warning_count'] ) ? (int) $result['warning_count'] : 0 ); ?></strong>
					</div>
					<div class="rspd-access-card">
						<span class="rspd-license-meta-label">Failures</span>
						<strong><?php echo esc_html( isset( $result['failed_count'] ) ? (int) $result['failed_count'] : 0 ); ?></strong>
					</div>
				</div>
				<?php if ( ! empty( $result['items'] ) ) : ?>
				<div class="rspd-labs-result-list">
					<?php foreach ( $result['items'] as $item ) : ?>
					<div class="rspd-labs-result-card">
						<div>
							<strong><?php echo esc_html( $item['source_title'] ); ?></strong>
							<span class="rspd-text-muted">Source ID <?php echo esc_html( (int) $item['source_id'] ); ?></span>
						</div>
						<div class="rspd-labs-result-arrow">→</div>
						<div>
							<strong><?php echo esc_html( $item['target_title'] ); ?></strong>
							<a href="<?php echo esc_url( $item['target_url'] ); ?>" target="_blank" class="rspd-deploy-url"><?php echo esc_html( $item['target_url'] ); ?></a>
						</div>
						<div class="rspd-labs-result-meta">
							<span class="rspd-layout-selection-chip"><?php echo esc_html( ucwords( str_replace( '_', ' ', $item['target_mode'] ) ) ); ?></span>
							<?php if ( ! empty( $item['warnings'] ) ) : ?>
								<span class="rspd-layout-selection-chip rspd-labs-chip-warning"><?php echo esc_html( count( $item['warnings'] ) ); ?> warning<?php echo 1 === count( $item['warnings'] ) ? '' : 's'; ?></span>
							<?php endif; ?>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>
				<?php if ( ! empty( $result['failures'] ) ) : ?>
				<div class="rspd-labs-result-list" style="margin-top:16px;">
					<?php foreach ( $result['failures'] as $failure ) : ?>
					<div class="rspd-labs-result-card is-warning">
						<div>
							<strong><?php echo esc_html( ! empty( $failure['source_title'] ) ? $failure['source_title'] : 'Unknown Source' ); ?></strong>
							<span class="rspd-text-muted">Source ID <?php echo esc_html( ! empty( $failure['source_id'] ) ? (int) $failure['source_id'] : 0 ); ?></span>
						</div>
						<div class="rspd-labs-result-meta">
							<span class="rspd-layout-selection-chip rspd-labs-chip-warning">Failed</span>
							<span class="rspd-text-muted"><?php echo esc_html( ! empty( $failure['message'] ) ? $failure['message'] : 'Conversion failed.' ); ?></span>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>
			</div>
			<?php endif; ?>

			<?php if ( ! empty( $restorable ) ) : ?>
			<div class="rspd-panel">
				<h2>Restore Elementor Source</h2>
				<p class="rspd-text-muted" style="margin-bottom:16px;">Only pages converted in place show up here. Restoring removes the Archimedes deployment on that page URL and puts the saved Elementor source snapshot back.</p>
				<div class="rspd-deployments-grid">
					<?php foreach ( $restorable as $item ) : ?>
					<div class="rspd-deploy-card is-active">
						<div class="rspd-deploy-card-head">
							<h3><?php echo esc_html( $item['page']->post_title ); ?></h3>
							<span class="rspd-status-dot active">Restore Ready</span>
						</div>
						<a href="<?php echo esc_url( $item['permalink'] ); ?>" target="_blank" class="rspd-deploy-url"><?php echo esc_html( $item['permalink'] ); ?></a>
						<div class="rspd-deploy-meta">
							Originally captured from <?php echo esc_html( $item['backup_title'] ); ?><br>
							Backup created <?php echo esc_html( $item['backup_created_label'] ); ?>
						</div>
						<div class="rspd-deploy-actions">
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rspd-inline-form" onsubmit="return confirm('Restore the original Elementor page on this same URL?');">
								<input type="hidden" name="action" value="rspd_restore_elementor_source">
								<?php wp_nonce_field( 'rspd_restore_elementor_source' ); ?>
								<input type="hidden" name="page_id" value="<?php echo esc_attr( $item['page']->ID ); ?>">
								<button type="submit" class="rspd-btn-sm">Restore Elementor Source</button>
							</form>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
			<?php endif; ?>

			<div class="rspd-panel">
				<?php if ( ! $elementor_active ) : ?>
					<div class="rspd-seo-empty">
						<p style="font-size:15px;font-weight:600;margin-bottom:12px;">Elementor is not active yet.</p>
						<p class="rspd-text-muted">Once Elementor is active, this Labs screen will list eligible Elementor pages here for conversion.</p>
					</div>
				<?php elseif ( empty( $sources ) ) : ?>
					<div class="rspd-seo-empty">
						<p style="font-size:15px;font-weight:600;margin-bottom:12px;">No Elementor pages detected.</p>
						<p class="rspd-text-muted">This screen only lists pages that look Elementor-managed based on Elementor post metadata.</p>
					</div>
				<?php else : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rspd-form" id="rspd-labs-export-form">
						<input type="hidden" name="action" value="rspd_labs_export">
						<?php wp_nonce_field( 'rspd_labs_export' ); ?>

						<div class="rspd-layout-selection-summary" data-labs-selection-summary>
							<strong data-labs-selection-count>0 page selected</strong>
							<div class="rspd-layout-selection-chips" data-labs-selection-chips>
								<span class="rspd-layout-selection-empty">No Elementor pages selected yet.</span>
							</div>
							<div class="rspd-tools-selection-actions">
								<button type="button" class="rspd-btn-sm" data-labs-select-all>Select All</button>
								<button type="button" class="rspd-btn-sm rspd-btn-secondary" data-labs-clear-all>Clear</button>
							</div>
						</div>

						<div class="rspd-status-note" style="margin-top:18px;">
							<strong>Preflight summary.</strong>
							<span data-labs-preflight-summary>Select the Elementor pages you want to convert. Internal links between selected source pages will be rewritten to the final Archimedes targets when matches are found.</span>
						</div>

						<div class="rspd-labs-grid">
							<?php foreach ( $sources as $source ) : ?>
								<?php
								$source_id       = (int) $source['page']->ID;
								$default_title   = $source['page']->post_title;
								$default_slug    = $this->get_elementor_default_target_slug( $source['page'] );
								$existing_deploy = ! empty( $source['existing_deployment'] );
								?>
								<div class="rspd-labs-card" data-labs-card data-source-id="<?php echo esc_attr( $source_id ); ?>" data-source-title="<?php echo esc_attr( $default_title ); ?>">
									<div class="rspd-labs-card-top">
										<label class="rspd-labs-source-toggle">
											<input type="checkbox" class="rspd-labs-source-checkbox" name="labs_export[items][<?php echo esc_attr( $source_id ); ?>][selected]" value="1">
											<span>Convert This Page</span>
										</label>
										<span class="rspd-license-pill rspd-license-pill--<?php echo $existing_deploy ? 'warning' : 'muted'; ?>">
											<?php echo $existing_deploy ? 'Already Managed' : 'Elementor Source'; ?>
										</span>
									</div>

									<div class="rspd-labs-source-head">
										<h3><?php echo esc_html( $default_title ); ?></h3>
										<a href="<?php echo esc_url( $source['permalink'] ); ?>" target="_blank" class="rspd-deploy-url"><?php echo esc_html( $source['permalink'] ); ?></a>
										<div class="rspd-deploy-meta">Source Page ID <?php echo esc_html( $source_id ); ?></div>
									</div>

									<?php if ( ! empty( $source['risk_badges'] ) ) : ?>
									<div class="rspd-ab-variant-indicators">
										<?php foreach ( $source['risk_badges'] as $risk_badge ) : ?>
											<span class="rspd-ab-variant-pill variant"><?php echo esc_html( $risk_badge ); ?></span>
										<?php endforeach; ?>
									</div>
									<?php else : ?>
									<div class="rspd-ab-variant-indicators">
										<span class="rspd-ab-variant-pill control">Static-Friendly</span>
									</div>
									<?php endif; ?>

									<div class="rspd-labs-target-mode">
										<label><input type="radio" name="labs_export[items][<?php echo esc_attr( $source_id ); ?>][target_mode]" value="create_new" class="rspd-radio rspd-labs-target-radio" data-source-id="<?php echo esc_attr( $source_id ); ?>" checked><span>Create New Archimedes Page</span></label>
										<label><input type="radio" name="labs_export[items][<?php echo esc_attr( $source_id ); ?>][target_mode]" value="existing" class="rspd-radio rspd-labs-target-radio" data-source-id="<?php echo esc_attr( $source_id ); ?>"><span>Deploy To Existing Page</span></label>
										<label><input type="radio" name="labs_export[items][<?php echo esc_attr( $source_id ); ?>][target_mode]" value="in_place" class="rspd-radio rspd-labs-target-radio" data-source-id="<?php echo esc_attr( $source_id ); ?>"><span>Convert In Place</span></label>
									</div>

									<div class="rspd-labs-target-fields" data-labs-target-fields="<?php echo esc_attr( $source_id ); ?>">
										<div class="rspd-labs-target-fields-row" data-labs-target-create>
											<div class="rspd-field">
												<label class="rspd-field-label">New Page Title</label>
												<input type="text" class="rspd-input rspd-labs-target-title" name="labs_export[items][<?php echo esc_attr( $source_id ); ?>][new_title]" value="<?php echo esc_attr( $default_title ); ?>">
											</div>
											<div class="rspd-field">
												<label class="rspd-field-label">New Page Slug</label>
												<input type="text" class="rspd-input rspd-labs-target-slug" name="labs_export[items][<?php echo esc_attr( $source_id ); ?>][new_slug]" value="<?php echo esc_attr( $default_slug ); ?>">
											</div>
										</div>
										<div class="rspd-field" data-labs-target-existing style="display:none;">
											<label class="rspd-field-label">Existing Target Page</label>
											<select name="labs_export[items][<?php echo esc_attr( $source_id ); ?>][existing_page_id]" class="rspd-select rspd-labs-existing-select">
												<option value="">— Select a page —</option>
												<?php foreach ( $pages as $p ) : ?>
													<option value="<?php echo esc_attr( $p->ID ); ?>"><?php echo esc_html( $p->post_title ); ?></option>
												<?php endforeach; ?>
											</select>
										</div>
										<div class="rspd-status-note" data-labs-target-in-place style="display:none;">
											<strong>Same URL conversion.</strong>
											<span>The current Elementor page URL stays the same. A source backup is stored first so you can restore it later from Labs.</span>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						</div>

						<div class="rspd-deploy-bar" style="margin-top:24px;">
							<button type="submit" class="rspd-btn-deploy">Convert Then Deploy</button>
						</div>
					</form>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	public function ajax_ab_create() {
		check_ajax_referer( 'rspd_ab_test', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
		}

		$page_id        = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		$variant_html   = isset( $_POST['variant_html'] ) ? wp_unslash( $_POST['variant_html'] ) : '';
		$weight_control = isset( $_POST['weight_control'] ) ? absint( $_POST['weight_control'] ) : 50;
		$weight_variant = isset( $_POST['weight_variant'] ) ? absint( $_POST['weight_variant'] ) : 50;

		if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
			wp_send_json_error( array( 'message' => 'Invalid page.' ) );
		}
		if ( empty( trim( $variant_html ) ) ) {
			wp_send_json_error( array( 'message' => 'Variant HTML is required.' ) );
		}
		if ( $weight_control + $weight_variant !== 100 ) {
			wp_send_json_error( array( 'message' => 'Weights must sum to 100.' ) );
		}

		$config = $this->storage->get_page_config( $page_id );
		if ( empty( $config['deployment_rel_dir'] ) ) {
			wp_send_json_error( array( 'message' => 'Page must be deployed first.' ) );
		}
		if ( ! empty( $config['ab_test']['enabled'] ) ) {
			wp_send_json_error( array( 'message' => 'This page already has an active test.' ) );
		}

		// Deploy variant.
		$result = $this->deployer->deploy_ab_variant( $page_id, 'variant_b', $variant_html );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		// Build A/B test config.
		$ab_test = array(
			'enabled'    => true,
			'created_at' => time(),
			'variants'   => array(
				'control'   => array(
					'label'              => 'Control (Original)',
					'weight'             => $weight_control,
					'deployment_rel_dir' => $config['deployment_rel_dir'],
					'cache_version'      => isset( $config['cache_version'] ) ? $config['cache_version'] : '',
				),
				'variant_b' => array(
					'label'              => 'Variant B',
					'weight'             => $weight_variant,
					'deployment_rel_dir' => $result['deployment_rel_dir'],
					'cache_version'      => $result['cache_version'],
				),
			),
		);

		$this->storage->update_ab_test_config( $page_id, $ab_test );

		wp_send_json_success( array(
			'message' => 'A/B test created.',
			'page_id' => $page_id,
			'title'   => get_the_title( $page_id ),
		) );
	}

	// ─── AJAX: A/B Toggle ───

	public function ajax_ab_toggle() {
		check_ajax_referer( 'rspd_ab_test', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
		}

		$page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		$enabled = isset( $_POST['enabled'] ) ? (bool) $_POST['enabled'] : false;

		$ab_test = $this->storage->get_ab_test_config( $page_id );
		if ( empty( $ab_test ) ) {
			wp_send_json_error( array( 'message' => 'No test found.' ) );
		}

		$ab_test['enabled'] = $enabled;
		$this->storage->update_ab_test_config( $page_id, $ab_test );

		wp_send_json_success( array( 'message' => $enabled ? 'Test resumed.' : 'Test paused.' ) );
	}

	// ─── AJAX: A/B End Test ───

	public function ajax_ab_end() {
		check_ajax_referer( 'rspd_ab_test', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
		}

		$page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		$winner  = isset( $_POST['winner'] ) ? sanitize_key( $_POST['winner'] ) : '';

		$ab_test = $this->storage->get_ab_test_config( $page_id );
		if ( empty( $ab_test['variants'][ $winner ] ) ) {
			wp_send_json_error( array( 'message' => 'Invalid winner.' ) );
		}

		$config = $this->storage->get_page_config( $page_id );

		// If winner is not control, swap the main deployment.
		if ( 'control' !== $winner ) {
			$winner_v = $ab_test['variants'][ $winner ];
			$config['deployment_rel_dir'] = $winner_v['deployment_rel_dir'];
			$config['cache_version']      = wp_generate_password( 12, false, false );
		}

		// Delete loser variant deployment directories.
		foreach ( $ab_test['variants'] as $key => $v ) {
			if ( $key === $winner || $key === 'control' ) {
				continue; // Don't delete winner or control (control dir is the main deployment).
			}
			if ( $key !== $winner && ! empty( $v['deployment_rel_dir'] ) ) {
				$this->deployer->delete_variant_deployment( $v['deployment_rel_dir'] );
			}
		}
		// If winner IS a variant (not control), delete nothing extra — the old control dir IS the main deployment dir,
		// and the new main deployment now points to the winner's dir.

		unset( $config['ab_test'] );
		$this->storage->update_page_config( $page_id, $config );

		wp_send_json_success( array(
			'message' => 'Test ended. "' . esc_html( $ab_test['variants'][ $winner ]['label'] ) . '" is now the permanent version.',
		) );
	}

	// ─── AJAX: A/B Update Split ───

	public function ajax_ab_update_split() {
		check_ajax_referer( 'rspd_ab_test', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
		}

		$page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		$weights = isset( $_POST['weights'] ) && is_array( $_POST['weights'] ) ? $_POST['weights'] : array();

		$ab_test = $this->storage->get_ab_test_config( $page_id );
		if ( empty( $ab_test['variants'] ) ) {
			wp_send_json_error( array( 'message' => 'No test found.' ) );
		}

		$total = 0;
		foreach ( $weights as $key => $w ) {
			$w = absint( $w );
			if ( isset( $ab_test['variants'][ $key ] ) ) {
				$ab_test['variants'][ $key ]['weight'] = $w;
				$total += $w;
			}
		}

		if ( 100 !== $total ) {
			wp_send_json_error( array( 'message' => 'Weights must sum to 100.' ) );
		}

		$this->storage->update_ab_test_config( $page_id, $ab_test );

		wp_send_json_success( array( 'message' => 'Split updated.' ) );
	}

	// ─── AJAX: Scan ZIP ───

	public function ajax_scan_zip() {
		check_ajax_referer( 'rspd_scan_zip', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		if ( empty( $_FILES['zip_file'] ) ) {
			wp_send_json_error( 'No file received.' );
		}

		$file = $_FILES['zip_file'];

		if ( ! empty( $file['error'] ) && UPLOAD_ERR_OK !== (int) $file['error'] ) {
			wp_send_json_error( 'Upload error code ' . (int) $file['error'] . '. Check your server upload limits.' );
		}

		$ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );

		// Single HTML file — no scanning needed, return one entry.
		if ( in_array( $ext, array( 'html', 'htm' ), true ) ) {
			$temp_dir = get_temp_dir() . 'rspd_scan_' . wp_generate_password( 12, false );
			wp_mkdir_p( $temp_dir );
			$dest = $temp_dir . '/' . sanitize_file_name( $file['name'] );
			move_uploaded_file( $file['tmp_name'], $dest );

			$temp_key = wp_generate_password( 16, false );
			set_transient( 'rspd_temp_scan_' . $temp_key, $temp_dir, 3600 );

			wp_send_json_success( array(
				'files'            => array( sanitize_file_name( $file['name'] ) ),
				'temp_key'         => $temp_key,
				'image_count'      => 0,
				'total_image_size' => 0,
				'gd_available'     => function_exists( 'imagecreatefromjpeg' ) && function_exists( 'imagewebp' ),
			) );
		}

		if ( 'zip' !== $ext ) {
			wp_send_json_error( 'Please upload a ZIP or HTML file.' );
		}

		if ( ! class_exists( 'ZipArchive' ) ) {
			wp_send_json_error( 'ZipArchive is not available on this server.' );
		}

		// Extract to temp dir for scanning.
		$temp_dir = get_temp_dir() . 'rspd_scan_' . wp_generate_password( 12, false );
		wp_mkdir_p( $temp_dir );

		$zip = new ZipArchive();
		if ( true !== $zip->open( $file['tmp_name'] ) ) {
			wp_send_json_error( 'Could not open ZIP file.' );
		}

		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$name = $zip->getNameIndex( $i );

			if ( ! $name || '/' === substr( $name, -1 ) || 0 === strpos( $name, '__MACOSX' ) ) {
				continue;
			}

			$safe = $this->security->normalize_relative_path( $name );
			if ( ! $safe || ! $this->security->is_allowed_file( $safe ) ) {
				continue;
			}

			$dest = $this->security->safe_join( $temp_dir, $safe );
			if ( ! $dest ) {
				continue;
			}

			wp_mkdir_p( dirname( $dest ) );
			$stream = $zip->getStream( $name );
			if ( $stream ) {
				$contents = stream_get_contents( $stream );
				fclose( $stream );
				if ( false !== $contents ) {
					$this->storage->write_file( $dest, $contents );
				}
			}
		}
		$zip->close();

		// If ZIP had a single root folder (e.g. ellora-v5-WP-CDN-Code/), flatten it.
		$temp_dir = $this->flatten_single_root_folder( $temp_dir );

		// Now scan for HTML files relative to the (possibly flattened) temp dir.
		$html_files = $this->scan_html_in_dir( $temp_dir );

		if ( empty( $html_files ) ) {
			$this->recursive_delete( $temp_dir );
			wp_send_json_error( 'No HTML files found in the ZIP.' );
		}

		// Store temp dir path for the deploy step.
		$temp_key = wp_generate_password( 16, false );
		set_transient( 'rspd_temp_scan_' . $temp_key, $temp_dir, 3600 );

		// Also count images so JS can show stats and WebP toggle.
		$image_stats = $this->scan_images_in_dir( $temp_dir );

		wp_send_json_success( array(
			'files'            => $html_files,
			'temp_key'         => $temp_key,
			'image_count'      => $image_stats['count'],
			'total_image_size' => $image_stats['total_size'],
			'gd_available'     => function_exists( 'imagecreatefromjpeg' ) && function_exists( 'imagewebp' ),
		) );
	}

	// ─── AJAX: Scan Folder Upload ───

	public function ajax_scan_folder() {
		check_ajax_referer( 'rspd_scan_folder', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		if ( empty( $_FILES['files'] ) || ! is_array( $_FILES['files']['name'] ) ) {
			wp_send_json_error( 'No files received.' );
		}

		$paths = isset( $_POST['paths'] ) && is_array( $_POST['paths'] ) ? $_POST['paths'] : array();

		$temp_dir = get_temp_dir() . 'rspd_scan_' . wp_generate_password( 12, false );
		wp_mkdir_p( $temp_dir );

		$count = count( $_FILES['files']['name'] );

		for ( $i = 0; $i < $count; $i++ ) {
			if ( UPLOAD_ERR_OK !== (int) $_FILES['files']['error'][ $i ] ) {
				continue;
			}

			// Use the relative path sent from JS, falling back to the filename.
			$rel = isset( $paths[ $i ] ) ? sanitize_text_field( $paths[ $i ] ) : sanitize_file_name( $_FILES['files']['name'][ $i ] );
			$safe = $this->security->normalize_relative_path( $rel );

			if ( ! $safe || ! $this->security->is_allowed_file( $safe ) ) {
				continue;
			}

			$dest = $this->security->safe_join( $temp_dir, $safe );
			if ( ! $dest ) {
				continue;
			}

			wp_mkdir_p( dirname( $dest ) );
			move_uploaded_file( $_FILES['files']['tmp_name'][ $i ], $dest );
		}

		// Flatten single root folder if present.
		$temp_dir = $this->flatten_single_root_folder( $temp_dir );

		$html_files = $this->scan_html_in_dir( $temp_dir );

		if ( empty( $html_files ) ) {
			$this->recursive_delete( $temp_dir );
			wp_send_json_error( 'No HTML files found in the uploaded folder.' );
		}

		$temp_key = wp_generate_password( 16, false );
		set_transient( 'rspd_temp_scan_' . $temp_key, $temp_dir, 3600 );

		$image_stats = $this->scan_images_in_dir( $temp_dir );

		wp_send_json_success( array(
			'files'            => $html_files,
			'temp_key'         => $temp_key,
			'image_count'      => $image_stats['count'],
			'total_image_size' => $image_stats['total_size'],
			'gd_available'     => function_exists( 'imagecreatefromjpeg' ) && function_exists( 'imagewebp' ),
		) );
	}

	// ─── AJAX: Deploy Multiple Pages ───

	public function ajax_deploy_multi() {
		check_ajax_referer( 'rspd_deploy_multi', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$temp_key = isset( $_POST['temp_key'] ) ? sanitize_text_field( $_POST['temp_key'] ) : '';
		$temp_dir = get_transient( 'rspd_temp_scan_' . $temp_key );

		if ( ! $temp_dir || ! is_dir( $temp_dir ) ) {
			wp_send_json_error( 'Scan expired. Please re-upload the ZIP.' );
		}

		$deployment_type = isset( $_POST['deployment_type'] ) ? sanitize_key( wp_unslash( $_POST['deployment_type'] ) ) : 'website_pages';

		if ( 'software_app' === $deployment_type ) {
			$software_slug  = isset( $_POST['software_slug'] ) ? sanitize_title( wp_unslash( $_POST['software_slug'] ) ) : '';
			$software_entry = isset( $_POST['software_entry_file'] ) ? sanitize_text_field( wp_unslash( $_POST['software_entry_file'] ) ) : '';
			$reserved_slugs = array( 'wp-admin', 'wp-content', 'wp-includes', 'reputifly-static-assets' );

			if ( '' === $software_slug ) {
				$this->recursive_delete( $temp_dir );
				delete_transient( 'rspd_temp_scan_' . $temp_key );
				wp_send_json_error( 'Add a parent folder slug for the software app.' );
			}

			if ( in_array( $software_slug, $reserved_slugs, true ) ) {
				$this->recursive_delete( $temp_dir );
				delete_transient( 'rspd_temp_scan_' . $temp_key );
				wp_send_json_error( 'That parent folder slug is reserved. Choose a different one.' );
			}

			$existing_resource_id = url_to_postid( home_url( '/' . $software_slug . '/' ) );
			$existing_page        = $existing_resource_id ? get_post( $existing_resource_id ) : get_page_by_path( $software_slug, OBJECT, 'page' );
			if ( $existing_page instanceof WP_Post ) {
				$this->recursive_delete( $temp_dir );
				delete_transient( 'rspd_temp_scan_' . $temp_key );
				wp_send_json_error(
					sprintf(
						'The folder /%1$s/ conflicts with the existing WordPress URL "%2$s". Choose a different parent folder slug.',
						$software_slug,
						$existing_page->post_title
					)
				);
			}

			$result = $this->deployer->deploy_software_app_from_directory( $temp_dir, $software_slug, $software_entry );

			$this->recursive_delete( $temp_dir );
			delete_transient( 'rspd_temp_scan_' . $temp_key );

			if ( is_wp_error( $result ) ) {
				wp_send_json_error( $result->get_error_message() );
			}

			wp_send_json_success(
				array(
					'type'   => 'software_app',
					'result' => $result,
				)
			);
		}

		$items = isset( $_POST['items'] ) && is_array( $_POST['items'] ) ? $_POST['items'] : array();

		if ( empty( $items ) ) {
			wp_send_json_error( 'No files selected for deployment.' );
		}

		$convert_webp = ! empty( $_POST['convert_webp'] ) && '1' === $_POST['convert_webp'];
		$settings     = $this->storage->get_settings();
		$results      = array();
		$pending_builds = array();
		$webp_totals  = array( 'converted' => 0, 'saved_bytes' => 0 );
		$package_key  = $this->storage->generate_package_key_from_directory( $temp_dir );

		foreach ( $items as $item ) {
			$html_file = isset( $item['file'] ) ? sanitize_text_field( $item['file'] ) : '';
			$mode      = isset( $item['mode'] ) ? sanitize_key( $item['mode'] ) : '';
			$page_id   = isset( $item['page_id'] ) ? absint( $item['page_id'] ) : 0;
			$new_title = isset( $item['new_title'] ) ? sanitize_text_field( wp_unslash( $item['new_title'] ) ) : '';

			if ( ! $html_file ) {
				continue;
			}

			// Create new page if needed. Use a file-derived slug so `about.html`
			// becomes `/about/` even when the page title is more descriptive.
			if ( 'new' === $mode && $new_title ) {
				$post_name = $this->derive_slug_from_html_file( $html_file, $new_title );
				$existing_page = get_page_by_path( $post_name, OBJECT, 'page' );

				if ( $existing_page instanceof WP_Post ) {
					$results[] = array(
						'file'    => $html_file,
						'ok'      => false,
						'message' => sprintf(
							'Cannot create a new page for %1$s because the slug /%2$s/ already exists on "%3$s". Choose "Assign to existing page" or change the title.',
							$html_file,
							$post_name,
							$existing_page->post_title
						),
					);
					continue;
				}

				$page_id = wp_insert_post( array(
					'post_title'  => $new_title,
					'post_name'   => $post_name,
					'post_status' => 'publish',
					'post_type'   => 'page',
				) );
				if ( is_wp_error( $page_id ) ) {
					$results[] = array( 'file' => $html_file, 'ok' => false, 'message' => $page_id->get_error_message() );
					continue;
				}
			}

			if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
				$results[] = array( 'file' => $html_file, 'ok' => false, 'message' => 'Invalid page.' );
				continue;
			}

			// Delete old deployment for this page if exists.
			$existing = $this->storage->get_page_config( $page_id );
			if ( ! empty( $existing['deployment_rel_dir'] ) ) {
				$this->storage->remove_deployment_directory( $existing['deployment_rel_dir'] );
				$this->storage->delete_page_config( $page_id );
			}

			// Create deployment directory and copy ALL files from temp dir (CSS, JS, images, everything).
			$deployment = $this->storage->create_deployment_directory( $page_id );
			$this->copy_directory( $temp_dir, $deployment['absolute_dir'] );

			// WebP conversion (runs per-deployment so each page gets its own converted images).
			$webp_result = null;
			if ( $convert_webp && function_exists( 'imagecreatefromjpeg' ) && function_exists( 'imagewebp' ) ) {
				$webp_result = $this->convert_images_to_webp( $deployment['absolute_dir'] );
				if ( ! empty( $webp_result['map'] ) ) {
					$this->rewrite_assets_for_webp( $deployment['absolute_dir'], $webp_result['map'] );
					$webp_totals['converted']  += $webp_result['converted'];
					$webp_totals['saved_bytes'] += $webp_result['saved_bytes'];
				}
			}

			// Verify the HTML file exists in the deployment.
			$html_path = $deployment['absolute_dir'] . '/' . $html_file;
			if ( ! file_exists( $html_path ) ) {
				$results[] = array( 'file' => $html_file, 'ok' => false, 'message' => 'HTML file not found after copy.' );
				continue;
			}

			// Scan all HTML files in the deployment.
			$all_html = $this->scan_html_in_dir( $deployment['absolute_dir'] );

			// Save a stable static-package config so rebuild_page_deployment can
			// host the uploaded bundle like a normal static site.
			$initial_config = array(
				'enabled'                => 1,
				'raw_html'               => 1,
				'deployment_id'          => basename( $deployment['relative_dir'] ),
				'deployment_rel_dir'     => $deployment['relative_dir'],
				'entry_file'             => $html_file,
				'package_key'            => $package_key,
				'source_type'            => 'upload',
				'html_files'             => $all_html,
				'render_mode'            => 'isolated',
				'preserve_imported_head' => 1,
				'prefer_plugin_metadata' => 0,
				'compatibility'          => array( 'wp_head' => 0, 'wp_footer' => 0 ),
				'metadata'               => array(),
				'performance'            => isset( $settings['performance'] ) ? $settings['performance'] : array(),
				'updated_at'             => time(),
				'cache_version'          => wp_generate_password( 12, false, false ),
			);
			$this->storage->update_page_config( $page_id, $initial_config );

			$pending_builds[] = array(
				'file'        => $html_file,
				'page_id'     => $page_id,
				'webp_result' => $webp_result,
			);
		}

		foreach ( $pending_builds as $build_item ) {
			$rebuilt = $this->deployer->rebuild_page_deployment( (int) $build_item['page_id'] );

			if ( is_wp_error( $rebuilt ) ) {
				$results[] = array(
					'file'    => $build_item['file'],
					'ok'      => false,
					'message' => $rebuilt->get_error_message(),
				);
				continue;
			}

			$result_item = array(
				'file'      => $build_item['file'],
				'ok'        => true,
				'page_id'   => (int) $build_item['page_id'],
				'title'     => get_the_title( (int) $build_item['page_id'] ),
				'permalink' => get_permalink( (int) $build_item['page_id'] ),
			);

			if ( ! empty( $build_item['webp_result']['converted'] ) ) {
				$result_item['webp_converted'] = $build_item['webp_result']['converted'];
				$result_item['webp_saved']     = $build_item['webp_result']['saved_bytes'];
			}

			$results[] = $result_item;
		}

		// Cleanup temp directory.
		$this->recursive_delete( $temp_dir );
		delete_transient( 'rspd_temp_scan_' . $temp_key );

		$response = array( 'results' => $results );
		if ( $convert_webp && $webp_totals['converted'] > 0 ) {
			$response['webp_summary'] = $webp_totals;
		}
		wp_send_json_success( $response );
	}

	// ─── HANDLERS (classic single-page flow) ───

	public function handle_deploy() {
		$this->security->guard_manage_capability();
		$this->security->verify_nonce( 'rspd_deploy' );
		$this->guard_license_action();

		$data = $_POST;

		if ( ! empty( $data['page_mode'] ) && 'new' === $data['page_mode'] && ! empty( $data['new_page_title'] ) ) {
			$title      = sanitize_text_field( wp_unslash( $data['new_page_title'] ) );
			$entry_file = ! empty( $data['entry_file'] ) ? sanitize_text_field( wp_unslash( $data['entry_file'] ) ) : '';
			$post_name  = $this->derive_slug_from_html_file( $entry_file, $title );
			$existing_page = get_page_by_path( $post_name, OBJECT, 'page' );

			if ( $existing_page instanceof WP_Post ) {
				$this->storage->set_admin_notice(
					sprintf(
						'Cannot create a new page because the slug /%1$s/ already exists on "%2$s". Choose an existing page or change the title.',
						$post_name,
						$existing_page->post_title
					),
					'error'
				);
				wp_safe_redirect( admin_url( 'admin.php?page=rspd' ) );
				exit;
			}

			$page_id = wp_insert_post( array(
				'post_title'  => $title,
				'post_name'   => $post_name,
				'post_status' => 'publish',
				'post_type'   => 'page',
			) );
			if ( is_wp_error( $page_id ) ) {
				$this->storage->set_admin_notice( 'Failed to create page: ' . $page_id->get_error_message(), 'error' );
				wp_safe_redirect( admin_url( 'admin.php?page=rspd' ) );
				exit;
			}
			$data['page_id'] = $page_id;
		}

		$data['enabled'] = 1;

		$result  = $this->deployer->save_deployment( $data, $_FILES );
		$page_id = isset( $data['page_id'] ) ? absint( $data['page_id'] ) : 0;

		if ( is_wp_error( $result ) ) {
			$this->storage->set_admin_notice( $result->get_error_message(), 'error' );
		} else {
			$this->storage->set_admin_notice( 'Deployed successfully! Your page is now live.' );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=rspd' ) );
		exit;
	}

	public function handle_delete() {
		$this->security->guard_manage_capability();
		$this->security->verify_nonce( 'rspd_delete' );
		$this->guard_license_action();

		$page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		if ( $page_id ) {
			$this->deployer->delete_deployment( $page_id );
			$this->storage->set_admin_notice( 'Deployment removed. Page reverted to normal theme.' );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=rspd' ) );
		exit;
	}

	/**
	 * Delete a mounted software app deployment.
	 *
	 * @return void
	 */
	public function handle_delete_software() {
		$this->security->guard_manage_capability();
		$this->security->verify_nonce( 'rspd_delete_software' );
		$this->guard_license_action();

		$software_slug = isset( $_POST['software_slug'] ) ? sanitize_title( wp_unslash( $_POST['software_slug'] ) ) : '';

		if ( '' !== $software_slug ) {
			$this->deployer->delete_software_app( $software_slug );
			$this->storage->set_admin_notice( sprintf( 'Software deployment /%s/ removed. That folder slug is available again.', $software_slug ) );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=rspd' ) );
		exit;
	}

	/**
	 * Run a Labs Elementor export batch.
	 *
	 * @return void
	 */
	public function handle_labs_export() {
		$this->security->guard_manage_capability();
		$this->security->verify_nonce( 'rspd_labs_export' );
		$this->guard_license_action();

		if ( ! $this->is_elementor_active() ) {
			$this->storage->set_admin_notice( 'Elementor is not active on this site yet.', 'error' );
			wp_safe_redirect( $this->get_admin_page_url( self::LABS_SLUG ) );
			exit;
		}

		$raw_items = isset( $_POST['labs_export']['items'] ) && is_array( $_POST['labs_export']['items'] ) ? wp_unslash( $_POST['labs_export']['items'] ) : array();
		$jobs      = array();
		$failures  = array();

		foreach ( $raw_items as $source_id => $item ) {
			if ( empty( $item['selected'] ) ) {
				continue;
			}

			$source_id  = absint( $source_id );
			$source_page = $source_id ? get_post( $source_id ) : null;
			if ( ! $source_page instanceof WP_Post || 'page' !== $source_page->post_type ) {
				$failures[] = array(
					'source_id'    => $source_id,
					'source_title' => 'Unknown Source',
					'message'      => 'The selected Elementor source page could not be found.',
				);
				continue;
			}

			$target_mode = sanitize_key( isset( $item['target_mode'] ) ? $item['target_mode'] : 'create_new' );
			$jobs[ $source_id ] = array(
				'source_id'    => $source_id,
				'source_page'  => $source_page,
				'source_title' => $source_page->post_title,
				'item'         => is_array( $item ) ? $item : array(),
				'target_mode'  => in_array( $target_mode, array( 'create_new', 'existing', 'in_place' ), true ) ? $target_mode : 'create_new',
			);
		}

		if ( empty( $jobs ) ) {
			$this->storage->set_admin_notice( 'Select at least one Elementor page before converting.', 'warning' );
			wp_safe_redirect( $this->get_admin_page_url( self::LABS_SLUG ) );
			exit;
		}

		foreach ( $jobs as $source_id => $job ) {
			$target = $this->resolve_labs_target_page( $job['source_page'], $job['target_mode'], $job['item'] );

			if ( is_wp_error( $target ) ) {
				$failures[] = array(
					'source_id'    => $source_id,
					'source_title' => $job['source_title'],
					'message'      => $target->get_error_message(),
				);
				unset( $jobs[ $source_id ] );
				continue;
			}

			$jobs[ $source_id ]['target_page_id'] = (int) $target['page']->ID;
			$jobs[ $source_id ]['target_page']    = $target['page'];
			$jobs[ $source_id ]['target_url']     = get_permalink( $target['page'] );
			$jobs[ $source_id ]['created_new']    = ! empty( $target['created_new'] );
		}

		if ( empty( $jobs ) ) {
			$this->persist_labs_result(
				array(
					'converted_count' => 0,
					'created_count'   => 0,
					'warning_count'   => 0,
					'failed_count'    => count( $failures ),
					'items'           => array(),
					'failures'        => $failures,
				)
			);
			$this->storage->set_admin_notice( 'No Elementor pages could be converted. Review the Labs errors and try again.', 'error' );
			wp_safe_redirect( $this->get_admin_page_url( self::LABS_SLUG ) );
			exit;
		}

		$link_map = $this->build_labs_internal_link_map( $jobs );
		$results  = array();
		$warnings = 0;
		$created  = 0;

		foreach ( $jobs as $job ) {
			if ( 'in_place' === $job['target_mode'] ) {
				$this->backup_elementor_source_page( $job['source_page'] );
			}

			$conversion = $this->deployer->export_elementor_page_to_page(
				$job['source_page'],
				$job['target_page_id'],
				array(
					'target_mode' => $job['target_mode'],
					'link_map'    => $link_map,
				)
			);

			if ( is_wp_error( $conversion ) ) {
				if ( ! empty( $job['created_new'] ) && ! empty( $job['target_page_id'] ) ) {
					wp_delete_post( (int) $job['target_page_id'], true );
				}
				$failures[] = array(
					'source_id'    => (int) $job['source_id'],
					'source_title' => $job['source_title'],
					'message'      => $conversion->get_error_message(),
				);
				continue;
			}

			if ( ! empty( $job['created_new'] ) ) {
				$created++;
			}

			$item_warnings = ! empty( $conversion['warnings'] ) && is_array( $conversion['warnings'] ) ? $conversion['warnings'] : array();
			$warnings += count( $item_warnings );
			$this->purge_frontend_cache_for_page( $job['target_page_id'] );

			$results[] = array(
				'source_id'    => (int) $job['source_id'],
				'source_title' => $job['source_title'],
				'target_id'    => (int) $job['target_page_id'],
				'target_title' => get_the_title( $job['target_page_id'] ),
				'target_url'   => get_permalink( $job['target_page_id'] ),
				'target_mode'  => $job['target_mode'],
				'warnings'     => $item_warnings,
			);
		}

		$summary = array(
			'converted_count' => count( $results ),
			'created_count'   => $created,
			'warning_count'   => $warnings,
			'failed_count'    => count( $failures ),
			'items'           => $results,
			'failures'        => $failures,
		);

		$this->persist_labs_result( $summary );

		if ( empty( $results ) ) {
			$this->storage->set_admin_notice( 'No Elementor pages were converted successfully. Review Labs and try again.', 'error' );
		} else {
			$message = sprintf(
				'Elementor export completed. %1$d page%s converted.',
				count( $results ),
				1 === count( $results ) ? '' : 's'
			);
			if ( $created > 0 ) {
				$message .= sprintf( ' %1$d new Archimedes page%s created.', $created, 1 === $created ? '' : 's' );
			}
			if ( ! empty( $failures ) ) {
				$message .= sprintf( ' %1$d page%s failed.', count( $failures ), 1 === count( $failures ) ? '' : 's' );
				$this->storage->set_admin_notice( $message, 'warning' );
			} else {
				$this->storage->set_admin_notice( $message );
			}
		}

		wp_safe_redirect( $this->get_admin_page_url( self::LABS_SLUG ) );
		exit;
	}

	/**
	 * Restore the saved Elementor source snapshot for an in-place Labs conversion.
	 *
	 * @return void
	 */
	public function handle_restore_elementor_source() {
		$this->security->guard_manage_capability();
		$this->security->verify_nonce( 'rspd_restore_elementor_source' );
		$this->guard_license_action();

		$page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		$backup  = $page_id ? $this->storage->get_elementor_backup( $page_id ) : array();

		if ( ! $page_id || empty( $backup ) ) {
			$this->storage->set_admin_notice( 'No saved Elementor source backup was found for that page.', 'error' );
			wp_safe_redirect( $this->get_admin_page_url( self::LABS_SLUG ) );
			exit;
		}

		$post_data = isset( $backup['post'] ) && is_array( $backup['post'] ) ? $backup['post'] : array();
		$post_data['ID'] = $page_id;
		$updated = wp_update_post( wp_slash( $post_data ), true );

		if ( is_wp_error( $updated ) ) {
			$this->storage->set_admin_notice( 'The Elementor source could not be restored: ' . $updated->get_error_message(), 'error' );
			wp_safe_redirect( $this->get_admin_page_url( self::LABS_SLUG ) );
			exit;
		}

		$managed_meta_keys = array(
			'_wp_page_template',
			'_thumbnail_id',
		);

		foreach ( get_post_meta( $page_id ) as $meta_key => $values ) {
			if ( 0 === strpos( $meta_key, '_elementor' ) || in_array( $meta_key, $managed_meta_keys, true ) ) {
				delete_post_meta( $page_id, $meta_key );
			}
		}

		if ( ! empty( $backup['meta'] ) && is_array( $backup['meta'] ) ) {
			foreach ( $backup['meta'] as $meta_key => $values ) {
				delete_post_meta( $page_id, $meta_key );
				foreach ( is_array( $values ) ? $values : array( $values ) as $value ) {
					add_post_meta( $page_id, $meta_key, maybe_unserialize( $value ) );
				}
			}
		}

		$this->deployer->delete_deployment( $page_id );
		$this->storage->delete_elementor_backup( $page_id );
		$this->purge_frontend_cache_for_page( $page_id );
		$this->storage->set_admin_notice( 'Elementor source restored successfully on the original page URL.' );

		wp_safe_redirect( $this->get_admin_page_url( self::LABS_SLUG ) );
		exit;
	}

	/**
	 * Save reusable global header/body/footer injections.
	 *
	 * @return void
	 */
	public function handle_save_layout_injections() {
		$this->security->guard_manage_capability();
		$this->security->verify_nonce( 'rspd_save_layout_injections' );
		$this->guard_license_action();

		$settings = $this->storage->get_settings();
		$raw      = isset( $_POST['layout_injections'] ) && is_array( $_POST['layout_injections'] ) ? wp_unslash( $_POST['layout_injections'] ) : array();
		$page_ids = isset( $raw['page_ids'] ) && is_array( $raw['page_ids'] ) ? array_values( array_unique( array_map( 'absint', $raw['page_ids'] ) ) ) : array();
		$allowed_page_ids = array();

		foreach ( $this->storage->get_deployments() as $deployment ) {
			if ( ! empty( $deployment['page']->ID ) ) {
				$allowed_page_ids[] = (int) $deployment['page']->ID;
			}
		}

		$settings['layout_injections'] = array(
			'header_html' => $this->sanitize_layout_markup( isset( $raw['header_html'] ) ? $raw['header_html'] : '' ),
			'body_html'   => $this->sanitize_layout_markup( isset( $raw['body_html'] ) ? $raw['body_html'] : '' ),
			'footer_html' => $this->sanitize_layout_markup( isset( $raw['footer_html'] ) ? $raw['footer_html'] : '' ),
			'page_ids'    => array_values( array_intersect( $page_ids, $allowed_page_ids ) ),
		);

		$this->storage->update_settings( $settings );
		$selected_titles  = array();
		$refreshed_pages  = array();
		$all_deployments  = $this->storage->get_deployments();

		foreach ( $all_deployments as $deployment ) {
			if ( empty( $deployment['page']->ID ) || ! in_array( (int) $deployment['page']->ID, $settings['layout_injections']['page_ids'], true ) ) {
				continue;
			}

			$selected_titles[] = $deployment['page']->post_title;
		}

		foreach ( $settings['layout_injections']['page_ids'] as $selected_page_id ) {
			$config = $this->storage->get_page_config( $selected_page_id );

			if ( empty( $config['deployment_rel_dir'] ) ) {
				continue;
			}

			$this->refresh_layout_target_page( $selected_page_id, $config );
			$refreshed_pages[] = (int) $selected_page_id;
		}

		$this->persist_layout_result(
			array(
				'page_ids'        => $settings['layout_injections']['page_ids'],
				'page_titles'     => $selected_titles,
				'refreshed_pages' => $refreshed_pages,
			)
		);

		if ( empty( $settings['layout_injections']['page_ids'] ) ) {
			$this->storage->set_admin_notice( 'Global header, body, and footer blocks saved, but no pages are selected yet, so nothing is being applied.', 'warning' );
		} else {
			$summary = 'Global header, body, and footer blocks saved.';
			if ( ! empty( $selected_titles ) ) {
				$summary .= ' Applied to: ' . implode( ', ', $selected_titles ) . '.';
			}
			if ( ! empty( $refreshed_pages ) ) {
				$summary .= ' Live output refreshed immediately.';
			}
			$this->storage->set_admin_notice( $summary );
		}

		wp_safe_redirect( $this->get_admin_page_url( self::MENU_SLUG, array( 'tab' => 'layout' ) ) );
		exit;
	}

	/**
	 * Replace one exact URL across selected deployed website pages.
	 *
	 * @return void
	 */
	public function handle_replace_urls() {
		$this->security->guard_manage_capability();
		$this->security->verify_nonce( 'rspd_replace_urls' );
		$this->guard_license_action();

		$raw         = isset( $_POST['replace_tools'] ) && is_array( $_POST['replace_tools'] ) ? wp_unslash( $_POST['replace_tools'] ) : array();
		$original    = trim( isset( $raw['original_url'] ) ? (string) $raw['original_url'] : '' );
		$new         = trim( isset( $raw['new_url'] ) ? (string) $raw['new_url'] : '' );
		$selected_ids = isset( $raw['page_ids'] ) && is_array( $raw['page_ids'] ) ? array_values( array_unique( array_map( 'absint', $raw['page_ids'] ) ) ) : array();
		$deployments = $this->storage->get_deployments();
		$allowed_ids = array();

		foreach ( $deployments as $deployment ) {
			if ( ! empty( $deployment['page']->ID ) ) {
				$allowed_ids[] = (int) $deployment['page']->ID;
			}
		}

		$selected_ids = array_values( array_intersect( $selected_ids, $allowed_ids ) );

		if ( empty( $selected_ids ) ) {
			$this->storage->set_admin_notice( 'Select at least one deployed page before running URL replacement.', 'warning' );
			wp_safe_redirect( $this->get_admin_page_url( self::TOOLS_SLUG ) );
			exit;
		}

		if ( '' === $original || '' === $new ) {
			$this->storage->set_admin_notice( 'Both Original URL and New URL are required.', 'error' );
			wp_safe_redirect( $this->get_admin_page_url( self::TOOLS_SLUG ) );
			exit;
		}

		if ( $original === $new ) {
			$this->storage->set_admin_notice( 'Original URL and New URL are identical. Nothing to replace.', 'warning' );
			wp_safe_redirect( $this->get_admin_page_url( self::TOOLS_SLUG ) );
			exit;
		}

		$backup   = $this->storage->create_backup_directory( 'url-replace' );
		$summary  = array(
			'page_ids'           => $selected_ids,
			'pages_updated'      => 0,
			'files_changed'      => 0,
			'replacement_count'  => 0,
			'backed_up_files'    => 0,
			'backup_relative_dir'=> $backup['relative_dir'],
			'changed_pages'      => array(),
		);
		$errors = array();

		foreach ( $selected_ids as $page_id ) {
			$config = $this->storage->get_page_config( $page_id );

			if ( empty( $config['deployment_rel_dir'] ) ) {
				continue;
			}

			$targets = $this->get_replace_targets_for_page( $config );
			$page_changed = false;
			$variant_keys_changed = array();

			foreach ( $targets as $target_key => $relative_dir ) {
				$result = $this->storage->replace_string_in_deployment( $relative_dir, $original, $new, $backup['absolute_dir'] );

				$summary['files_changed'] += (int) $result['files_changed'];
				$summary['replacement_count'] += (int) $result['replacement_count'];
				$summary['backed_up_files'] += (int) $result['backed_up_files'];

				if ( ! empty( $result['errors'] ) ) {
					$errors = array_merge( $errors, $result['errors'] );
				}

				if ( ! empty( $result['files_changed'] ) ) {
					$page_changed = true;

					if ( 'main' === $target_key ) {
						$new_cache_version = wp_generate_password( 12, false, false );
						$config['cache_version'] = $new_cache_version;
						if ( ! empty( $config['ab_test']['variants'] ) && is_array( $config['ab_test']['variants'] ) ) {
							foreach ( $config['ab_test']['variants'] as $variant_key => $variant ) {
								if ( empty( $variant['deployment_rel_dir'] ) || (string) $variant['deployment_rel_dir'] !== (string) $config['deployment_rel_dir'] ) {
									continue;
								}
								$config['ab_test']['variants'][ $variant_key ]['cache_version'] = $new_cache_version;
								$variant_keys_changed[] = $variant_key;
							}
						}
					} elseif ( 0 === strpos( $target_key, 'variant:' ) ) {
						$variant_key = substr( $target_key, 8 );
						if ( ! empty( $config['ab_test']['variants'][ $variant_key ] ) ) {
							$config['ab_test']['variants'][ $variant_key ]['cache_version'] = wp_generate_password( 12, false, false );
							$variant_keys_changed[] = $variant_key;
						}
					}
				}
			}

			if ( ! $page_changed ) {
				continue;
			}

			$config['updated_at'] = time();
			$this->storage->update_page_config( $page_id, $config );

			foreach ( array_unique( $variant_keys_changed ) as $variant_key ) {
				delete_transient( 'rspd_render_' . absint( $page_id ) . '_' . sanitize_key( $variant_key ) );
			}

			$summary['pages_updated']++;
			$summary['changed_pages'][] = get_the_title( $page_id );
		}

		$this->persist_tools_replace_result( $summary );

		if ( $summary['files_changed'] < 1 ) {
			$this->storage->set_admin_notice( 'No matching URLs were found in the selected deployed pages.', 'warning' );
			wp_safe_redirect( $this->get_admin_page_url( self::TOOLS_SLUG ) );
			exit;
		}

		$message = sprintf(
			'URL replacement completed. %1$d page%s updated, %2$d file%s changed, %3$d replacement%s made.',
			$summary['pages_updated'],
			1 === (int) $summary['pages_updated'] ? '' : 's',
			$summary['files_changed'],
			1 === (int) $summary['files_changed'] ? '' : 's',
			$summary['replacement_count'],
			1 === (int) $summary['replacement_count'] ? '' : 's'
		);

		if ( ! empty( $summary['changed_pages'] ) ) {
			$message .= ' Pages: ' . implode( ', ', $summary['changed_pages'] ) . '.';
		}

		if ( ! empty( $errors ) ) {
			$message .= ' Some files could not be rewritten: ' . implode( ', ', array_slice( array_unique( $errors ), 0, 5 ) ) . '.';
			$this->storage->set_admin_notice( $message, 'warning' );
		} else {
			$this->storage->set_admin_notice( $message );
		}

		wp_safe_redirect( $this->get_admin_page_url( self::TOOLS_SLUG ) );
		exit;
	}

	/**
	 * Preserve combined HTML/CSS/JS blocks for admin-defined layout injections.
	 *
	 * @param string $markup Raw markup.
	 * @return string
	 */
	protected function sanitize_layout_markup( $markup ) {
		$markup = trim( (string) $markup );

		if ( '' === $markup ) {
			return '';
		}

		if ( current_user_can( 'manage_options' ) || current_user_can( 'unfiltered_html' ) ) {
			return $markup;
		}

		return wp_kses_post( $markup );
	}

	/**
	 * Refresh cache state for one layout target page so new shell blocks appear immediately.
	 *
	 * @param int   $page_id Managed page id.
	 * @param array $config  Existing page config.
	 * @return void
	 */
	protected function refresh_layout_target_page( $page_id, array $config ) {
		$page_id = absint( $page_id );

		if ( ! $page_id ) {
			return;
		}

		$config['cache_version'] = wp_generate_password( 12, false, false );
		$config['updated_at']    = time();

		$variant_keys = array();
		if ( ! empty( $config['ab_test']['variants'] ) && is_array( $config['ab_test']['variants'] ) ) {
			foreach ( $config['ab_test']['variants'] as $variant_key => $variant ) {
				$config['ab_test']['variants'][ $variant_key ]['cache_version'] = wp_generate_password( 12, false, false );
				$variant_keys[] = sanitize_key( $variant_key );
			}
		}

		$this->storage->update_page_config( $page_id, $config );

		foreach ( array_unique( array_filter( $variant_keys ) ) as $variant_key ) {
			delete_transient( 'rspd_render_' . $page_id . '_' . $variant_key );
		}

		$this->purge_frontend_cache_for_page( $page_id );
	}

	/**
	 * Ask common cache layers to purge one managed page after layout shell changes.
	 *
	 * @param int $page_id Managed page id.
	 * @return void
	 */
	protected function purge_frontend_cache_for_page( $page_id ) {
		$page_id   = absint( $page_id );
		$permalink = $page_id ? get_permalink( $page_id ) : '';

		if ( $page_id && function_exists( 'clean_post_cache' ) ) {
			clean_post_cache( $page_id );
		}

		if ( $page_id && has_action( 'rocket_clean_post' ) ) {
			do_action( 'rocket_clean_post', $page_id );
		}

		if ( $page_id && has_action( 'litespeed_purge_post' ) ) {
			do_action( 'litespeed_purge_post', $page_id );
		}

		if ( $page_id && has_action( 'wpfc_clear_post_cache_by_id' ) ) {
			do_action( 'wpfc_clear_post_cache_by_id', $page_id );
		}

		if ( $permalink && has_action( 'sg_cachepress_purge_url' ) ) {
			do_action( 'sg_cachepress_purge_url', $permalink );
		} elseif ( has_action( 'sg_cachepress_purge_cache' ) ) {
			do_action( 'sg_cachepress_purge_cache' );
		}
	}

	/**
	 * Build the deployment directories that should be updated for one page.
	 *
	 * @param array $config Page deployment config.
	 * @return array
	 */
	protected function get_replace_targets_for_page( array $config ) {
		$targets = array();

		if ( ! empty( $config['deployment_rel_dir'] ) ) {
			$targets['main'] = (string) $config['deployment_rel_dir'];
		}

		if ( ! empty( $config['ab_test']['variants'] ) && is_array( $config['ab_test']['variants'] ) ) {
			foreach ( $config['ab_test']['variants'] as $variant_key => $variant ) {
				if ( empty( $variant['deployment_rel_dir'] ) ) {
					continue;
				}
				$targets[ 'variant:' . sanitize_key( $variant_key ) ] = (string) $variant['deployment_rel_dir'];
			}
		}

		return array_unique( $targets );
	}

	/**
	 * Get the transient key used for the last tools replace summary.
	 *
	 * @return string
	 */
	protected function get_tools_replace_result_key() {
		return 'rspd_tools_replace_result_' . get_current_user_id();
	}

	/**
	 * Get the transient key used for the last layout apply summary.
	 *
	 * @return string
	 */
	protected function get_layout_result_key() {
		return 'rspd_layout_result_' . get_current_user_id();
	}

	/**
	 * Persist the last tools replace summary for display on the tools page.
	 *
	 * @param array $summary Result summary.
	 * @return void
	 */
	protected function persist_tools_replace_result( array $summary ) {
		set_transient( $this->get_tools_replace_result_key(), $summary, HOUR_IN_SECONDS );
	}

	/**
	 * Persist the last layout apply summary for display on the layout tab.
	 *
	 * @param array $summary Result summary.
	 * @return void
	 */
	protected function persist_layout_result( array $summary ) {
		set_transient( $this->get_layout_result_key(), $summary, HOUR_IN_SECONDS );
	}

	/**
	 * Load and clear the last tools replace summary.
	 *
	 * @return array
	 */
	protected function consume_tools_replace_result() {
		$key    = $this->get_tools_replace_result_key();
		$result = get_transient( $key );
		delete_transient( $key );

		return is_array( $result ) ? $result : array();
	}

	/**
	 * Load and clear the last layout apply summary.
	 *
	 * @return array
	 */
	protected function consume_layout_result() {
		$key    = $this->get_layout_result_key();
		$result = get_transient( $key );
		delete_transient( $key );

		return is_array( $result ) ? $result : array();
	}

	/**
	 * Determine whether Elementor is active enough for live frontend export.
	 *
	 * @return bool
	 */
	protected function is_elementor_active() {
		return defined( 'ELEMENTOR_VERSION' ) || did_action( 'elementor/loaded' ) || class_exists( '\Elementor\Plugin' );
	}

	/**
	 * Discover Elementor-managed source pages that can be exported from Labs.
	 *
	 * @return array
	 */
	protected function get_elementor_source_pages() {
		$query = new WP_Query(
			array(
				'post_type'           => 'page',
				'post_status'         => 'publish',
				'posts_per_page'      => -1,
				'orderby'             => 'title',
				'order'               => 'ASC',
				'ignore_sticky_posts' => true,
				'meta_query'          => array(
					'relation' => 'OR',
					array(
						'key'     => '_elementor_edit_mode',
						'compare' => 'EXISTS',
					),
					array(
						'key'     => '_elementor_data',
						'compare' => 'EXISTS',
					),
					array(
						'key'     => '_elementor_version',
						'compare' => 'EXISTS',
					),
				),
			)
		);

		if ( empty( $query->posts ) ) {
			return array();
		}

		$items = array();
		foreach ( $query->posts as $page ) {
			if ( ! $page instanceof WP_Post ) {
				continue;
			}

			$permalink = get_permalink( $page );
			if ( empty( $permalink ) ) {
				continue;
			}

			$config = $this->storage->get_page_config( $page->ID );
			$items[] = array(
				'page'                => $page,
				'permalink'           => $permalink,
				'existing_deployment' => ! empty( $config['deployment_rel_dir'] ) ? $config : array(),
				'risk_badges'         => $this->detect_elementor_risk_badges( $page ),
			);
		}

		return $items;
	}

	/**
	 * Build the default target slug for a new Archimedes page created from Elementor.
	 *
	 * @param WP_Post $page Source Elementor page.
	 * @return string
	 */
	protected function get_elementor_default_target_slug( WP_Post $page ) {
		$base = sanitize_title( $page->post_name ? $page->post_name : $page->post_title );
		if ( '' === $base ) {
			$base = 'elementor-page';
		}

		return sanitize_title( $base . '-archimedes' );
	}

	/**
	 * List pages that have an in-place Elementor backup available for restore.
	 *
	 * @return array
	 */
	protected function get_restorable_elementor_exports() {
		$query = new WP_Query(
			array(
				'post_type'           => 'page',
				'post_status'         => 'any',
				'posts_per_page'      => -1,
				'orderby'             => 'title',
				'order'               => 'ASC',
				'ignore_sticky_posts' => true,
				'meta_query'          => array(
					array(
						'key'     => RSPD_Storage::ELEMENTOR_BACKUP_META_KEY,
						'compare' => 'EXISTS',
					),
				),
			)
		);

		if ( empty( $query->posts ) ) {
			return array();
		}

		$items = array();
		foreach ( $query->posts as $page ) {
			if ( ! $page instanceof WP_Post ) {
				continue;
			}

			$backup = $this->storage->get_elementor_backup( $page->ID );
			$config = $this->storage->get_page_config( $page->ID );
			if ( empty( $backup ) || empty( $config['elementor_export']['target_mode'] ) || 'in_place' !== $config['elementor_export']['target_mode'] ) {
				continue;
			}

			$created_at = ! empty( $backup['created_at'] ) ? (int) $backup['created_at'] : 0;
			$items[] = array(
				'page'               => $page,
				'permalink'          => get_permalink( $page ),
				'backup_title'       => ! empty( $backup['source_title'] ) ? (string) $backup['source_title'] : $page->post_title,
				'backup_created_at'  => $created_at,
				'backup_created_label' => $created_at ? wp_date( 'M j, Y g:i A', $created_at ) : 'Unknown',
			);
		}

		return $items;
	}

	/**
	 * Resolve the final target page for one Labs export item.
	 *
	 * @param WP_Post $source_page Source Elementor page.
	 * @param string  $target_mode Requested target mode.
	 * @param array   $item Raw Labs form item.
	 * @return array|WP_Error
	 */
	protected function resolve_labs_target_page( WP_Post $source_page, $target_mode, array $item ) {
		$target_mode = sanitize_key( (string) $target_mode );

		if ( 'in_place' === $target_mode ) {
			return array(
				'page'        => $source_page,
				'created_new' => false,
			);
		}

		if ( 'existing' === $target_mode ) {
			$page_id = ! empty( $item['existing_page_id'] ) ? absint( $item['existing_page_id'] ) : 0;
			$page    = $page_id ? get_post( $page_id ) : null;

			if ( ! $page instanceof WP_Post || 'page' !== $page->post_type ) {
				return new WP_Error( 'rspd_labs_existing_target_missing', __( 'Choose an existing WordPress page for that Labs export item.', 'reputifly-static-page-deployer' ) );
			}
			if ( (int) $page->ID === (int) $source_page->ID ) {
				return new WP_Error( 'rspd_labs_existing_target_same_source', __( 'Use "Convert In Place" if you want to overwrite the current Elementor page URL and keep a restore backup.', 'reputifly-static-page-deployer' ) );
			}

			return array(
				'page'        => $page,
				'created_new' => false,
			);
		}

		$title = ! empty( $item['new_title'] ) ? sanitize_text_field( (string) $item['new_title'] ) : $source_page->post_title;
		$slug  = ! empty( $item['new_slug'] ) ? sanitize_title( (string) $item['new_slug'] ) : $this->get_elementor_default_target_slug( $source_page );
		$title = '' !== trim( $title ) ? $title : $source_page->post_title;
		$slug  = '' !== trim( $slug ) ? $slug : $this->get_elementor_default_target_slug( $source_page );

		$post_status = in_array( $source_page->post_status, array( 'publish', 'draft', 'pending', 'private' ), true ) ? $source_page->post_status : 'publish';
		$unique_slug = wp_unique_post_slug( $slug, 0, $post_status, 'page', 0 );

		$page_id = wp_insert_post(
			array(
				'post_type'      => 'page',
				'post_status'    => $post_status,
				'post_title'     => $title,
				'post_name'      => $unique_slug,
				'post_author'    => get_current_user_id(),
				'post_parent'    => 0,
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
			),
			true
		);

		if ( is_wp_error( $page_id ) ) {
			return new WP_Error( 'rspd_labs_target_create_failed', sprintf( __( 'Could not create the new Archimedes target page: %s', 'reputifly-static-page-deployer' ), $page_id->get_error_message() ) );
		}

		$page = get_post( $page_id );
		if ( ! $page instanceof WP_Post ) {
			return new WP_Error( 'rspd_labs_target_create_missing', __( 'The new Archimedes target page was created but could not be loaded.', 'reputifly-static-page-deployer' ) );
		}

		return array(
			'page'        => $page,
			'created_new' => true,
		);
	}

	/**
	 * Build the internal link rewrite map for a selected Labs batch.
	 *
	 * @param array $jobs Selected Labs export jobs.
	 * @return array
	 */
	protected function build_labs_internal_link_map( array $jobs ) {
		$map = array();

		foreach ( $jobs as $job ) {
			if ( empty( $job['source_page'] ) || empty( $job['target_url'] ) ) {
				continue;
			}

			$source_permalink = get_permalink( $job['source_page'] );
			foreach ( $this->build_labs_url_aliases( $source_permalink ) as $alias ) {
				$map[ $alias ] = $job['target_url'];
			}
		}

		return $map;
	}

	/**
	 * Save the current Elementor source snapshot for in-place restoration later.
	 *
	 * @param WP_Post $page Source page being converted in place.
	 * @return void
	 */
	protected function backup_elementor_source_page( WP_Post $page ) {
		$post_snapshot = array(
			'post_title'      => $page->post_title,
			'post_name'       => $page->post_name,
			'post_content'    => $page->post_content,
			'post_excerpt'    => $page->post_excerpt,
			'post_status'     => $page->post_status,
			'post_type'       => $page->post_type,
			'post_author'     => (int) $page->post_author,
			'post_parent'     => (int) $page->post_parent,
			'menu_order'      => (int) $page->menu_order,
			'post_password'   => $page->post_password,
			'comment_status'  => $page->comment_status,
			'ping_status'     => $page->ping_status,
			'post_date'       => $page->post_date,
			'post_date_gmt'   => $page->post_date_gmt,
		);

		$meta_snapshot = array();
		foreach ( get_post_meta( $page->ID ) as $meta_key => $values ) {
			if ( 0 === strpos( $meta_key, '_elementor' ) || in_array( $meta_key, array( '_wp_page_template', '_thumbnail_id' ), true ) ) {
				$meta_snapshot[ $meta_key ] = $values;
			}
		}

		$this->storage->save_elementor_backup(
			$page->ID,
			array(
				'created_at'       => time(),
				'source_title'     => $page->post_title,
				'source_permalink' => get_permalink( $page ),
				'post'             => $post_snapshot,
				'meta'             => $meta_snapshot,
			)
		);
	}

	/**
	 * Persist the last Labs conversion summary.
	 *
	 * @param array $summary Conversion result summary.
	 * @return void
	 */
	protected function persist_labs_result( array $summary ) {
		set_transient( $this->get_labs_result_key(), $summary, HOUR_IN_SECONDS );
	}

	/**
	 * Load and clear the last Labs conversion summary.
	 *
	 * @return array
	 */
	protected function consume_labs_result() {
		$key    = $this->get_labs_result_key();
		$result = get_transient( $key );
		delete_transient( $key );

		return is_array( $result ) ? $result : array();
	}

	/**
	 * Get the transient key used for the last Labs result.
	 *
	 * @return string
	 */
	protected function get_labs_result_key() {
		return 'rspd_labs_result_' . get_current_user_id();
	}

	/**
	 * Build the useful source URL aliases for one Elementor permalink.
	 *
	 * @param string $url Source permalink.
	 * @return array
	 */
	protected function build_labs_url_aliases( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return array();
		}

		$aliases = array(
			$url,
			untrailingslashit( $url ),
			trailingslashit( untrailingslashit( $url ) ),
		);

		$parts = wp_parse_url( $url );
		$path  = ! empty( $parts['path'] ) ? '/' . ltrim( (string) $parts['path'], '/' ) : '';
		if ( '' !== $path ) {
			$aliases[] = $path;
			$aliases[] = untrailingslashit( $path );
			$aliases[] = trailingslashit( untrailingslashit( $path ) );
			$trimmed   = trim( $path, '/' );
			if ( '' !== $trimmed ) {
				$aliases[] = $trimmed;
			}
		}

		return array_values(
			array_unique(
				array_filter(
					$aliases,
					static function ( $alias ) {
						return '' !== trim( (string) $alias );
					}
				)
			)
		);
	}

	/**
	 * Detect dynamic/runtime-heavy Elementor features and surface warning badges.
	 *
	 * @param WP_Post $page Source page.
	 * @return array
	 */
	protected function detect_elementor_risk_badges( WP_Post $page ) {
		$data    = (string) get_post_meta( $page->ID, '_elementor_data', true );
		$badges  = array();
		$matches = array(
			'Forms'         => array( '"widgetType":"form"', '"widgetType":"wpforms"' ),
			'WooCommerce'   => array( '"widgetType":"woocommerce-', '"widgetType":"wc-' ),
			'Query Widgets' => array( '"widgetType":"posts"', '"widgetType":"loop-grid"', '"widgetType":"archive"', '"widgetType":"portfolio"' ),
			'Popups'        => array( '"popup"', '"widgetType":"popup"' ),
			'Shortcodes'    => array( '"widgetType":"shortcode"' ),
			'Search / Login'=> array( '"widgetType":"search-form"', '"widgetType":"login"' ),
		);

		foreach ( $matches as $label => $needles ) {
			foreach ( $needles as $needle ) {
				if ( false !== stripos( $data, $needle ) ) {
					$badges[] = $label;
					break;
				}
			}
		}

		return array_values( array_unique( $badges ) );
	}

	public function handle_save_settings() {
		$this->security->guard_manage_capability();
		$this->security->verify_nonce( 'rspd_save_settings' );

		$settings = $this->storage->get_settings();

		if ( isset( $_POST['performance'] ) && is_array( $_POST['performance'] ) ) {
			foreach ( $_POST['performance'] as $key => $val ) {
				$settings['performance'][ sanitize_key( $key ) ] = absint( $val );
			}
		}
		if ( isset( $_POST['data']['remove_on_uninstall'] ) ) {
			$settings['data']['remove_on_uninstall'] = absint( $_POST['data']['remove_on_uninstall'] );
		}
		if ( isset( $_POST['license'] ) && is_array( $_POST['license'] ) ) {
			$license = wp_unslash( $_POST['license'] );
			$settings['license']['api_base_url']     = isset( $license['api_base_url'] ) ? esc_url_raw( trim( $license['api_base_url'] ) ) : $settings['license']['api_base_url'];
			$settings['license']['request_endpoint'] = isset( $license['request_endpoint'] ) ? sanitize_text_field( trim( $license['request_endpoint'] ) ) : $settings['license']['request_endpoint'];
			$settings['license']['check_endpoint']   = isset( $license['check_endpoint'] ) ? sanitize_text_field( trim( $license['check_endpoint'] ) ) : $settings['license']['check_endpoint'];
		}

		$this->storage->update_settings( $settings );
		$this->license->maybe_refresh_status( true, 'settings_save' );
		if ( ! $this->license->should_block_admin() ) {
			$this->deployer->rebuild_all_deployments();
		}
		$this->storage->set_admin_notice( 'Settings saved.' );

		wp_safe_redirect( admin_url( 'admin.php?page=rspd-settings' ) );
		exit;
	}

	public function handle_license_recheck() {
		$this->security->guard_manage_capability();
		$this->security->verify_nonce( 'rspd_recheck_license' );

		$license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		if ( '' !== trim( $license_key ) ) {
			$this->license->set_license_key( $license_key );
		}

		$state   = $this->license->maybe_refresh_status( true, 'manual' );
		$context = $this->license->get_status_context();
		$message = 'License re-check completed. Status: ' . $context['label'] . '.';

		if ( ! empty( $state['last_error'] ) ) {
			$message .= ' ' . $state['last_error'];
		}

		$this->storage->set_admin_notice( $message, $context['locked'] ? 'error' : 'success' );
		wp_safe_redirect( $this->get_admin_page_url( self::SETTINGS_SLUG ) );
		exit;
	}

	/**
	 * Derive a stable WordPress slug from a deployed HTML file path.
	 *
	 * Examples:
	 * - `about.html` -> `about`
	 * - `services.html` -> `services`
	 * - `team/index.html` -> `team`
	 * - `index.html` -> slug from title if available, otherwise `index`
	 *
	 * @param string $html_file HTML file path from the uploaded package.
	 * @param string $fallback_title Human-readable page title.
	 * @return string
	 */
	protected function derive_slug_from_html_file( $html_file, $fallback_title = '' ) {
		$html_file = wp_normalize_path( (string) $html_file );
		$html_file = preg_replace( '/\.(html?|htm)$/i', '', $html_file );
		$html_file = trim( (string) $html_file, '/' );

		if ( '' === $html_file ) {
			return sanitize_title( $fallback_title ? $fallback_title : 'index' );
		}

		$segments = array_values(
			array_filter(
				explode( '/', $html_file ),
				static function ( $segment ) {
					return '' !== trim( (string) $segment );
				}
			)
		);

		if ( empty( $segments ) ) {
			return sanitize_title( $fallback_title ? $fallback_title : 'index' );
		}

		$last_segment = end( $segments );

		if ( 'index' === strtolower( (string) $last_segment ) ) {
			array_pop( $segments );
		}

		if ( empty( $segments ) ) {
			return sanitize_title( $fallback_title ? $fallback_title : 'index' );
		}

		return sanitize_title( implode( '-', $segments ) );
	}

	// ─── AJAX: Per-Page Overrides ───

	public function ajax_get_page_overrides() {
		check_ajax_referer( 'rspd_page_overrides', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		if ( ! $page_id ) {
			wp_send_json_error( 'Invalid page ID.' );
		}

		$config   = $this->storage->get_page_config( $page_id );
		$settings = $this->storage->get_settings();

		if ( empty( $config ) ) {
			wp_send_json_error( 'No deployment found for this page.' );
		}

		$overrides = isset( $config['page_overrides'] ) && is_array( $config['page_overrides'] )
			? $config['page_overrides'] : array();

		wp_send_json_success( array(
			'page_id'   => $page_id,
			'overrides' => $overrides,
			'globals'   => array(
				'defaults'    => isset( $settings['defaults'] ) ? $settings['defaults'] : array(),
				'performance' => isset( $settings['performance'] ) ? $settings['performance'] : array(),
				'metadata'    => isset( $settings['metadata'] ) ? $settings['metadata'] : array(),
			),
		) );
	}

	public function ajax_save_page_overrides() {
		check_ajax_referer( 'rspd_page_overrides', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		if ( ! $page_id ) {
			wp_send_json_error( 'Invalid page ID.' );
		}

		$config = $this->storage->get_page_config( $page_id );
		if ( empty( $config ) ) {
			wp_send_json_error( 'No deployment found for this page.' );
		}

		$submitted     = isset( $_POST['overrides'] ) && is_array( $_POST['overrides'] ) ? $_POST['overrides'] : array();
		$new_overrides = $this->normalize_submitted_overrides( $submitted );

		$config['page_overrides'] = $new_overrides;
		$this->storage->update_page_config( $page_id, $config );

		// Rebuild this single page with the new overrides applied.
		$result = $this->deployer->rebuild_page_deployment( $page_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( array(
			'page_id'   => $page_id,
			'overrides' => $new_overrides,
			'message'   => 'Page settings saved and deployment rebuilt.',
		) );
	}

	protected function normalize_submitted_overrides( array $submitted ) {
		$overrides = array();

		// Flat render-behavior keys.
		$flat_keys = array(
			'render_mode'            => 'sanitize_key',
			'preserve_imported_head' => 'absint',
			'prefer_plugin_metadata' => 'absint',
			'raw_html'               => 'absint',
		);
		foreach ( $flat_keys as $key => $sanitizer ) {
			if ( ! empty( $submitted[ $key ]['enabled'] ) ) {
				$overrides[ $key ] = call_user_func( $sanitizer, isset( $submitted[ $key ]['value'] ) ? $submitted[ $key ]['value'] : '' );
			}
		}

		// Compatibility.
		$compat_keys = array( 'wp_head', 'wp_footer' );
		foreach ( $compat_keys as $key ) {
			if ( ! empty( $submitted[ 'compatibility_' . $key ]['enabled'] ) ) {
				if ( ! isset( $overrides['compatibility'] ) ) {
					$overrides['compatibility'] = array();
				}
				$overrides['compatibility'][ $key ] = absint( isset( $submitted[ 'compatibility_' . $key ]['value'] ) ? $submitted[ 'compatibility_' . $key ]['value'] : 0 );
			}
		}

		// Performance booleans.
		$perf_booleans = array(
			'enable_html_cache', 'minify_html', 'minify_inline', 'defer_scripts',
			'lazy_load_images', 'disable_emoji', 'disable_wp_embed', 'asset_fingerprinting',
		);
		foreach ( $perf_booleans as $key ) {
			if ( ! empty( $submitted[ 'performance_' . $key ]['enabled'] ) ) {
				if ( ! isset( $overrides['performance'] ) ) {
					$overrides['performance'] = array();
				}
				$overrides['performance'][ $key ] = absint( isset( $submitted[ 'performance_' . $key ]['value'] ) ? $submitted[ 'performance_' . $key ]['value'] : 0 );
			}
		}

		// Performance text fields.
		$perf_text = array( 'hero_image', 'preload_styles', 'preconnect_urls', 'dns_prefetch_urls', 'critical_css' );
		foreach ( $perf_text as $key ) {
			if ( ! empty( $submitted[ 'performance_' . $key ]['enabled'] ) ) {
				if ( ! isset( $overrides['performance'] ) ) {
					$overrides['performance'] = array();
				}
				$value = isset( $submitted[ 'performance_' . $key ]['value'] ) ? wp_unslash( $submitted[ 'performance_' . $key ]['value'] ) : '';
				$overrides['performance'][ $key ] = 'critical_css' === $key ? trim( $value ) : sanitize_textarea_field( trim( $value ) );
			}
		}

		return $overrides;
	}

	// ─── AJAX: Per-Variant Overrides ───

	public function ajax_get_variant_overrides() {
		check_ajax_referer( 'rspd_page_overrides', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		if ( ! $page_id ) {
			wp_send_json_error( 'Invalid page ID.' );
		}

		$config   = $this->storage->get_page_config( $page_id );
		$settings = $this->storage->get_settings();

		if ( empty( $config ) ) {
			wp_send_json_error( 'No deployment found for this page.' );
		}

		if ( empty( $config['ab_test']['enabled'] ) || empty( $config['ab_test']['variants'] ) ) {
			wp_send_json_error( 'No active A/B test for this page.' );
		}

		// Build per-variant overrides data.
		$variants_data = array();
		foreach ( $config['ab_test']['variants'] as $vkey => $vdata ) {
			$variants_data[ $vkey ] = array(
				'label'     => isset( $vdata['label'] ) ? $vdata['label'] : $vkey,
				'weight'    => isset( $vdata['weight'] ) ? $vdata['weight'] : 0,
				'overrides' => isset( $vdata['page_overrides'] ) && is_array( $vdata['page_overrides'] )
					? $vdata['page_overrides'] : array(),
			);
		}

		// Also include base page_overrides as fallback reference.
		$base_overrides = isset( $config['page_overrides'] ) && is_array( $config['page_overrides'] )
			? $config['page_overrides'] : array();

		wp_send_json_success( array(
			'page_id'        => $page_id,
			'variants'       => $variants_data,
			'base_overrides' => $base_overrides,
			'globals'        => array(
				'defaults'    => isset( $settings['defaults'] ) ? $settings['defaults'] : array(),
				'performance' => isset( $settings['performance'] ) ? $settings['performance'] : array(),
				'metadata'    => isset( $settings['metadata'] ) ? $settings['metadata'] : array(),
			),
		) );
	}

	public function ajax_save_variant_overrides() {
		check_ajax_referer( 'rspd_page_overrides', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$page_id     = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		$variant_key = isset( $_POST['variant_key'] ) ? sanitize_key( $_POST['variant_key'] ) : '';

		if ( ! $page_id || empty( $variant_key ) ) {
			wp_send_json_error( 'Invalid page ID or variant key.' );
		}

		$config = $this->storage->get_page_config( $page_id );
		if ( empty( $config ) ) {
			wp_send_json_error( 'No deployment found for this page.' );
		}

		if ( empty( $config['ab_test']['variants'][ $variant_key ] ) ) {
			wp_send_json_error( 'Variant not found.' );
		}

		$submitted     = isset( $_POST['overrides'] ) && is_array( $_POST['overrides'] ) ? $_POST['overrides'] : array();
		$new_overrides = $this->normalize_submitted_overrides( $submitted );

		$config['ab_test']['variants'][ $variant_key ]['page_overrides'] = $new_overrides;
		$this->storage->update_page_config( $page_id, $config );

		// Clear variant transients.
		delete_transient( 'rspd_render_' . $page_id );
		delete_transient( 'rspd_render_' . $page_id . '_' . $variant_key );

		// Rebuild the variant deployment with new overrides.
		$variant = $config['ab_test']['variants'][ $variant_key ];
		if ( ! empty( $variant['deployment_rel_dir'] ) ) {
			$this->deployer->rebuild_variant_deployment( $page_id, $variant_key );
		}

		wp_send_json_success( array(
			'page_id'     => $page_id,
			'variant_key' => $variant_key,
			'overrides'   => $new_overrides,
			'message'     => ucfirst( str_replace( '_', ' ', $variant_key ) ) . ' settings saved.',
		) );
	}

	// ─── Merge Sections AJAX ───

	public function ajax_deploy_merge() {
		check_ajax_referer( 'rspd_deploy_merge', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$page_mode = sanitize_key( isset( $_POST['page_mode'] ) ? $_POST['page_mode'] : 'existing' );
		$page_id   = absint( isset( $_POST['page_id'] ) ? $_POST['page_id'] : 0 );
		$new_title = sanitize_text_field( wp_unslash( isset( $_POST['new_title'] ) ? $_POST['new_title'] : '' ) );
		$sections  = isset( $_POST['sections'] ) && is_array( $_POST['sections'] ) ? $_POST['sections'] : array();

		if ( empty( $sections ) ) {
			wp_send_json_error( 'Add at least one section.' );
		}

		if ( 'new' === $page_mode ) {
			if ( '' === $new_title ) {
				wp_send_json_error( 'Enter a title for the new page.' );
			}
			$page_id = wp_insert_post( array(
				'post_title'  => $new_title,
				'post_status' => 'publish',
				'post_type'   => 'page',
			) );
			if ( is_wp_error( $page_id ) ) {
				wp_send_json_error( $page_id->get_error_message() );
			}
		}

		if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
			wp_send_json_error( 'Select a valid page.' );
		}

		$clean = array();
		foreach ( $sections as $i => $sec ) {
			$title = sanitize_text_field( wp_unslash( isset( $sec['title'] ) ? $sec['title'] : '' ) );
			$code  = wp_unslash( isset( $sec['code'] ) ? $sec['code'] : '' );
			if ( '' === trim( $code ) ) {
				continue;
			}
			$clean[] = array(
				'title' => '' !== $title ? $title : 'Section ' . ( $i + 1 ),
				'code'  => $code,
			);
		}

		if ( empty( $clean ) ) {
			wp_send_json_error( 'All sections are empty.' );
		}

		$result = $this->deployer->import_merged_sections( $clean, $page_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( array(
			'page_id'   => $page_id,
			'title'     => get_the_title( $page_id ),
			'permalink' => get_permalink( $page_id ),
		) );
	}

	// ─── Helpers ───

	/**
	 * If the extracted dir has a single subfolder and no root files, treat that
	 * subfolder as the real root. Common pattern: ZIP contains one wrapper folder.
	 */
	protected function flatten_single_root_folder( $dir ) {
		$entries = array_diff( scandir( $dir ), array( '.', '..' ) );

		if ( 1 !== count( $entries ) ) {
			return $dir;
		}

		$single = $dir . '/' . reset( $entries );

		if ( is_dir( $single ) ) {
			return $single;
		}

		return $dir;
	}

	protected function scan_html_in_dir( $dir ) {
		$files = array();
		if ( ! is_dir( $dir ) ) {
			return $files;
		}
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ) );
		foreach ( $it as $f ) {
			if ( $f->isFile() && preg_match( '/\.html?$/i', $f->getFilename() ) ) {
				$files[] = ltrim( str_replace( wp_normalize_path( $dir ), '', wp_normalize_path( $f->getPathname() ) ), '/' );
			}
		}
		sort( $files );
		return $files;
	}

	protected function copy_directory( $src, $dst ) {
		if ( ! is_dir( $src ) ) {
			return;
		}
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $src, RecursiveDirectoryIterator::SKIP_DOTS ), RecursiveIteratorIterator::SELF_FIRST );
		foreach ( $it as $item ) {
			$target = $dst . '/' . ltrim( str_replace( wp_normalize_path( $src ), '', wp_normalize_path( $item->getPathname() ) ), '/' );
			if ( $item->isDir() ) {
				wp_mkdir_p( $target );
			} else {
				wp_mkdir_p( dirname( $target ) );
				copy( $item->getPathname(), $target );
			}
		}
	}

	protected function recursive_delete( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
		foreach ( $it as $item ) {
			if ( $item->isDir() ) {
				@rmdir( $item->getPathname() );
			} else {
				@unlink( $item->getPathname() );
			}
		}
		@rmdir( $dir );
	}

	// ─── Image helpers ───

	/**
	 * Count convertible images in a directory.
	 */
	protected function scan_images_in_dir( $dir ) {
		$result = array( 'count' => 0, 'total_size' => 0 );
		if ( ! is_dir( $dir ) ) {
			return $result;
		}
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ) );
		foreach ( $it as $f ) {
			if ( ! $f->isFile() ) {
				continue;
			}
			$ext = strtolower( pathinfo( $f->getFilename(), PATHINFO_EXTENSION ) );
			if ( in_array( $ext, array( 'jpg', 'jpeg', 'png', 'gif', 'bmp' ), true ) ) {
				$result['count']++;
				$result['total_size'] += $f->getSize();
			}
		}
		return $result;
	}

	/**
	 * Convert images to WebP format using GD.
	 *
	 * Returns a map of original relative paths to new WebP relative paths,
	 * plus stats on how many were converted and bytes saved.
	 */
	protected function convert_images_to_webp( $dir, $quality = 80 ) {
		$result = array( 'map' => array(), 'converted' => 0, 'saved_bytes' => 0, 'errors' => array() );
		if ( ! is_dir( $dir ) ) {
			return $result;
		}

		$norm_dir = wp_normalize_path( $dir );
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ) );

		foreach ( $it as $f ) {
			if ( ! $f->isFile() ) {
				continue;
			}

			$ext = strtolower( pathinfo( $f->getFilename(), PATHINFO_EXTENSION ) );
			if ( ! in_array( $ext, array( 'jpg', 'jpeg', 'png', 'gif', 'bmp' ), true ) ) {
				continue;
			}

			$source_path = $f->getPathname();
			$webp_path   = preg_replace( '/\.(jpe?g|png|gif|bmp)$/i', '.webp', $source_path );

			$image = null;
			switch ( $ext ) {
				case 'jpg':
				case 'jpeg':
					$image = @imagecreatefromjpeg( $source_path );
					break;
				case 'png':
					$image = @imagecreatefrompng( $source_path );
					if ( $image ) {
						imagepalettetotruecolor( $image );
						imagealphablending( $image, true );
						imagesavealpha( $image, true );
					}
					break;
				case 'gif':
					$image = @imagecreatefromgif( $source_path );
					break;
				case 'bmp':
					if ( function_exists( 'imagecreatefrombmp' ) ) {
						$image = @imagecreatefrombmp( $source_path );
					}
					break;
			}

			if ( ! $image ) {
				$result['errors'][] = basename( $source_path ) . ': could not load';
				continue;
			}

			$ok = @imagewebp( $image, $webp_path, $quality );
			imagedestroy( $image );

			if ( ! $ok || ! file_exists( $webp_path ) ) {
				$result['errors'][] = basename( $source_path ) . ': conversion failed';
				continue;
			}

			$original_size = filesize( $source_path );
			$webp_size     = filesize( $webp_path );

			if ( $webp_size < $original_size ) {
				// WebP is smaller — use it and remove original.
				$rel_original = ltrim( str_replace( $norm_dir, '', wp_normalize_path( $source_path ) ), '/' );
				$rel_webp     = ltrim( str_replace( $norm_dir, '', wp_normalize_path( $webp_path ) ), '/' );

				$result['map'][ $rel_original ] = $rel_webp;
				$result['converted']++;
				$result['saved_bytes'] += ( $original_size - $webp_size );

				@unlink( $source_path );
			} else {
				// WebP is not smaller — discard it and keep original.
				@unlink( $webp_path );
			}
		}

		return $result;
	}

	/**
	 * Rewrite image references in HTML and CSS files after WebP conversion.
	 */
	protected function rewrite_assets_for_webp( $dir, array $webp_map ) {
		if ( empty( $webp_map ) ) {
			return;
		}

		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ) );
		foreach ( $it as $f ) {
			if ( ! $f->isFile() ) {
				continue;
			}
			$ext = strtolower( pathinfo( $f->getFilename(), PATHINFO_EXTENSION ) );
			if ( ! in_array( $ext, array( 'html', 'htm', 'css', 'js' ), true ) ) {
				continue;
			}

			$path    = $f->getPathname();
			$content = file_get_contents( $path );
			if ( ! $content ) {
				continue;
			}

			$changed = false;
			foreach ( $webp_map as $original => $webp ) {
				// Replace full relative path references.
				if ( false !== strpos( $content, $original ) ) {
					$content = str_replace( $original, $webp, $content );
					$changed = true;
				}
				// Also replace basename-only references (e.g. in CSS with ../images/photo.jpg).
				$orig_base = basename( $original );
				$webp_base = basename( $webp );
				if ( $orig_base !== $original && false !== strpos( $content, $orig_base ) ) {
					$content = str_replace( $orig_base, $webp_base, $content );
					$changed = true;
				}
			}

			if ( $changed ) {
				file_put_contents( $path, $content );
			}
		}
	}
}
