<?php
/**
 * Licensing and remote approval flow.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Remote licensing helper.
 */
class RSPD_License {

	/**
	 * Cron hook for periodic license refreshes.
	 *
	 * @var string
	 */
	const CRON_HOOK = 'rspd_license_check';

	/**
	 * Custom cron schedule key.
	 *
	 * @var string
	 */
	const CRON_SCHEDULE = 'rspd_every_15_minutes';

	/**
	 * Storage helper.
	 *
	 * @var RSPD_Storage
	 */
	protected $storage;

	/**
	 * Security helper.
	 *
	 * @var RSPD_Security
	 */
	protected $security;

	/**
	 * Constructor.
	 *
	 * @param RSPD_Storage  $storage  Storage helper.
	 * @param RSPD_Security $security Security helper.
	 */
	public function __construct( RSPD_Storage $storage, RSPD_Security $security ) {
		$this->storage  = $storage;
		$this->security = $security;

		add_filter( 'cron_schedules', array( $this, 'register_cron_schedule' ) );
		add_action( 'init', array( $this, 'maybe_schedule_check' ) );
		add_action( 'admin_init', array( $this, 'maybe_refresh_during_admin_boot' ) );
		add_action( self::CRON_HOOK, array( $this, 'scheduled_check' ) );
	}

	/**
	 * Activation callback.
	 *
	 * @return void
	 */
	public function activate() {
		$this->ensure_install_id();
		$this->maybe_schedule_check();
		$this->maybe_refresh_status( true, 'activation' );
	}

	/**
	 * Deactivation callback.
	 *
	 * @return void
	 */
	public function deactivate() {
		$timestamp = wp_next_scheduled( self::CRON_HOOK );

		while ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::CRON_HOOK );
			$timestamp = wp_next_scheduled( self::CRON_HOOK );
		}
	}

	/**
	 * Register the 15-minute cron schedule.
	 *
	 * @param array $schedules Existing schedules.
	 * @return array
	 */
	public function register_cron_schedule( $schedules ) {
		if ( ! isset( $schedules[ self::CRON_SCHEDULE ] ) ) {
			$schedules[ self::CRON_SCHEDULE ] = array(
				'interval' => 15 * MINUTE_IN_SECONDS,
				'display'  => __( 'Every 15 Minutes', 'reputifly-static-page-deployer' ),
			);
		}

		return $schedules;
	}

	/**
	 * Schedule periodic checks if not already scheduled.
	 *
	 * @return void
	 */
	public function maybe_schedule_check() {
		if ( wp_next_scheduled( self::CRON_HOOK ) ) {
			return;
		}

		wp_schedule_event( time() + MINUTE_IN_SECONDS, self::CRON_SCHEDULE, self::CRON_HOOK );
	}

	/**
	 * Cron callback.
	 *
	 * @return void
	 */
	public function scheduled_check() {
		$this->maybe_refresh_status( false, 'cron' );
	}

	/**
	 * Refresh licensing opportunistically during normal admin page loads.
	 *
	 * This helps new installs appear in the superadmin dashboard even before the
	 * user opens a dedicated plugin screen.
	 *
	 * @return void
	 */
	public function maybe_refresh_during_admin_boot() {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$this->maybe_refresh_status( false, 'admin_boot' );
	}

	/**
	 * Get current licensing settings.
	 *
	 * @return array
	 */
	public function get_settings() {
		$defaults = array(
			'api_base_url'     => 'https://asia-southeast1-reputifly-plugin.cloudfunctions.net',
			'request_endpoint' => 'licenseCheck',
			'check_endpoint'   => 'licenseCheck',
			'check_interval'   => 15 * MINUTE_IN_SECONDS,
			'grace_period'     => DAY_IN_SECONDS,
		);
		$settings = $this->storage->get_settings();

		if ( empty( $settings['license'] ) || ! is_array( $settings['license'] ) ) {
			return $defaults;
		}

		return wp_parse_args( $settings['license'], $defaults );
	}

	/**
	 * Get the current persisted license state.
	 *
	 * @return array
	 */
	public function get_state() {
		return $this->storage->get_license_state();
	}

	/**
	 * Persist license state.
	 *
	 * @param array $state State payload.
	 * @return array
	 */
	public function update_state( array $state ) {
		$this->storage->update_license_state( $state );

		return $this->storage->get_license_state();
	}

	/**
	 * Ensure this installation has a stable ID.
	 *
	 * @return array
	 */
	public function ensure_install_id() {
		$state = $this->get_state();

		if ( ! empty( $state['install_id'] ) ) {
			return $state;
		}

		$state['install_id'] = 'rspd_' . strtolower( wp_generate_password( 24, false, false ) );

		return $this->update_state( $state );
	}

	/**
	 * Normalize a submitted license key into a stable uppercase format.
	 *
	 * @param string $license_key Raw key.
	 * @return string
	 */
	public function normalize_license_key( $license_key ) {
		$license_key = strtoupper( sanitize_text_field( wp_unslash( (string) $license_key ) ) );
		$license_key = preg_replace( '/[^A-Z0-9]+/', '-', $license_key );
		$license_key = trim( (string) $license_key, '-' );
		$license_key = preg_replace( '/-{2,}/', '-', $license_key );

		return (string) $license_key;
	}

	/**
	 * Mask a license key for display after it has been saved.
	 *
	 * @param string $license_key Normalized key.
	 * @return string
	 */
	public function mask_license_key( $license_key ) {
		$license_key = $this->normalize_license_key( $license_key );

		if ( '' === $license_key ) {
			return '';
		}

		$visible_prefix = substr( $license_key, 0, min( 9, strlen( $license_key ) ) );
		$visible_suffix = strlen( $license_key ) > 4 ? substr( $license_key, -4 ) : $license_key;

		if ( strlen( $license_key ) <= 14 ) {
			return $visible_prefix . str_repeat( '*', max( 0, strlen( $license_key ) - strlen( $visible_prefix ) ) );
		}

		return $visible_prefix . '-****-' . $visible_suffix;
	}

	/**
	 * Save a license key locally without changing deployment logic.
	 *
	 * @param string $license_key Raw key entered by the user.
	 * @return array
	 */
	public function set_license_key( $license_key ) {
		$state        = $this->ensure_install_id();
		$normalized   = $this->normalize_license_key( $license_key );
		$current_key  = isset( $state['license_key'] ) ? $this->normalize_license_key( $state['license_key'] ) : '';

		if ( '' === $normalized || $normalized === $current_key ) {
			return $state;
		}

		$state['license_key']        = $normalized;
		$state['license_key_masked'] = $this->mask_license_key( $normalized );
		$state['license_source']     = 'key';
		$state['key_status']         = '';
		$state['license_status']     = 'unregistered';
		$state['status_message']     = 'License key saved. Request access to validate it.';
		$state['validated_once']     = 0;
		$state['next_check_after']   = 0;
		$state['lease_token']        = '';
		$state['lease_expires_at']   = 0;
		$state['last_success_at']    = 0;
		$state['last_error']         = '';

		return $this->update_state( $state );
	}

	/**
	 * Refresh state if it is stale or force requested.
	 *
	 * @param bool   $force   Whether to force a check.
	 * @param string $context Context label for diagnostics.
	 * @return array
	 */
	public function maybe_refresh_status( $force = false, $context = 'runtime' ) {
		$state = $this->ensure_install_id();

		if ( ! $this->is_backend_configured() ) {
			return $state;
		}

		if ( ! $force && ! $this->needs_remote_check( $state ) ) {
			return $state;
		}

		$endpoint_type = $this->should_use_request_endpoint( $state ) ? 'request' : 'check';
		$endpoint_url  = $this->get_endpoint_url( $endpoint_type );

		if ( '' === $endpoint_url ) {
			return $state;
		}

		$request = wp_remote_post(
			$endpoint_url,
			array(
				'timeout' => 12,
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
				),
				'body'    => wp_json_encode( $this->build_request_payload( $state, $context ) ),
			)
		);

		$state['last_check_at'] = time();

		if ( is_wp_error( $request ) ) {
			$state['last_error'] = $request->get_error_message();
			return $this->update_state( $state );
		}

		$code = (int) wp_remote_retrieve_response_code( $request );
		$body = wp_remote_retrieve_body( $request );
		$data = json_decode( $body, true );

		if ( $code < 200 || $code >= 300 || ! is_array( $data ) ) {
			$state['last_error'] = 'Licensing server returned an invalid response.';
			return $this->update_state( $state );
		}

		$status = isset( $data['status'] ) ? sanitize_key( $data['status'] ) : '';

		if ( ! in_array( $status, array( 'pending', 'approved', 'denied', 'revoked' ), true ) ) {
			$state['last_error'] = 'Licensing server did not return a valid status.';
			return $this->update_state( $state );
		}

		$state['license_status']    = $status;
		$state['status_message']    = isset( $data['message'] ) ? sanitize_text_field( $data['message'] ) : '';
		$state['lease_token']       = isset( $data['lease_token'] ) ? sanitize_text_field( $data['lease_token'] ) : '';
		$state['lease_expires_at']  = isset( $data['lease_expires_at'] ) ? absint( $data['lease_expires_at'] ) : 0;
		$state['next_check_after']  = isset( $data['next_check_after'] ) ? absint( $data['next_check_after'] ) : 0;
		$state['normalized_domain'] = isset( $data['normalized_domain'] ) ? sanitize_text_field( $data['normalized_domain'] ) : $this->get_normalized_domain();
		$state['license_source']    = isset( $data['license_source'] ) ? sanitize_key( $data['license_source'] ) : ( ! empty( $state['license_key'] ) ? 'key' : 'legacy' );
		$state['key_status']        = isset( $data['key_status'] ) ? sanitize_key( $data['key_status'] ) : ( ! empty( $state['license_key'] ) ? $status : '' );
		$state['license_key_masked']= isset( $data['license_key_masked'] ) ? sanitize_text_field( $data['license_key_masked'] ) : ( ! empty( $state['license_key'] ) ? $this->mask_license_key( $state['license_key'] ) : '' );
		$state['last_response_at']  = time();
		$state['validated_once']    = 1;
		$state['last_error']        = '';

		if ( 'approved' === $status ) {
			$state['last_success_at'] = time();
		}

		return $this->update_state( $state );
	}

	/**
	 * Determine whether the plugin should use the initial request endpoint.
	 *
	 * @param array $state Current state.
	 * @return bool
	 */
	protected function should_use_request_endpoint( array $state ) {
		if ( empty( $state['validated_once'] ) ) {
			return true;
		}

		return in_array( $state['license_status'], array( 'pending', 'denied', 'unregistered' ), true );
	}

	/**
	 * Determine whether the backend should be queried now.
	 *
	 * @param array $state Current state.
	 * @return bool
	 */
	public function needs_remote_check( array $state = array() ) {
		if ( empty( $state ) ) {
			$state = $this->get_state();
		}

		$next = ! empty( $state['next_check_after'] ) ? absint( $state['next_check_after'] ) : 0;

		if ( $next > 0 ) {
			return time() >= $next;
		}

		$last_check = ! empty( $state['last_check_at'] ) ? absint( $state['last_check_at'] ) : 0;
		$interval   = $this->get_check_interval();

		return $last_check < 1 || ( time() - $last_check ) >= $interval;
	}

	/**
	 * Whether the backend is configured.
	 *
	 * @return bool
	 */
	public function is_backend_configured() {
		return '' !== $this->get_api_base_url();
	}

	/**
	 * Whether the plugin should block admin features.
	 *
	 * @return bool
	 */
	public function should_block_admin() {
		return $this->should_block_runtime();
	}

	/**
	 * Whether managed frontend rendering should be blocked.
	 *
	 * @return bool
	 */
	public function should_block_frontend() {
		return $this->should_block_runtime();
	}

	/**
	 * Shared runtime enforcement rules.
	 *
	 * @return bool
	 */
	protected function should_block_runtime() {
		$state = $this->get_state();

		if ( 'approved' !== $state['license_status'] ) {
			return true;
		}

		if ( ! empty( $state['lease_expires_at'] ) && absint( $state['lease_expires_at'] ) >= time() ) {
			return false;
		}

		$last_success = ! empty( $state['last_success_at'] ) ? absint( $state['last_success_at'] ) : 0;

		if ( $last_success < 1 ) {
			return true;
		}

		return ( time() - $last_success ) > $this->get_grace_period();
	}

	/**
	 * Return a view-friendly status payload.
	 *
	 * @return array
	 */
	public function get_status_context() {
		$state          = $this->get_state();
		$domain         = ! empty( $state['normalized_domain'] ) ? $state['normalized_domain'] : $this->get_normalized_domain();
		$license_status = isset( $state['license_status'] ) ? (string) $state['license_status'] : 'unregistered';
		$locked         = $this->should_block_runtime();

		$labels = array(
			'unregistered' => 'Not Active',
			'pending'      => 'Pending Approval',
			'approved'     => 'Active',
			'denied'       => 'Not Active',
			'revoked'      => 'Not Active',
		);

		$tones = array(
			'unregistered' => 'muted',
			'pending'      => 'warning',
			'approved'     => 'success',
			'denied'       => 'danger',
			'revoked'      => 'danger',
		);

		$message = ! empty( $state['status_message'] ) ? $state['status_message'] : '';
		if ( '' === $message ) {
			switch ( $license_status ) {
				case 'pending':
					$message = ! empty( $state['license_key'] ) ? 'This key is waiting for approval.' : 'Access has been requested and is waiting for approval.';
					break;
				case 'denied':
					$message = ! empty( $state['license_key'] ) ? 'This key is not active for this site.' : 'This site does not currently have access.';
					break;
				case 'revoked':
					$message = ! empty( $state['license_key'] ) ? 'This license key has been revoked for this site.' : 'Access for this site has been revoked.';
					break;
				case 'approved':
					$message = ! empty( $state['license_key'] ) ? 'This site is approved and unlocked with its license key.' : 'This site is approved and can use the plugin.';
					break;
				default:
					$message = ! empty( $state['license_key'] ) ? 'Enter the saved key and request access to validate it.' : 'Enter your license key and request access, or ask Reputifly to approve this site.';
					break;
			}
		}

		return array(
			'status'          => $license_status,
			'label'           => isset( $labels[ $license_status ] ) ? $labels[ $license_status ] : ucfirst( $license_status ),
			'tone'            => isset( $tones[ $license_status ] ) ? $tones[ $license_status ] : 'muted',
			'locked'          => $locked,
			'message'         => $message,
			'domain'          => $domain,
			'install_id'      => isset( $state['install_id'] ) ? (string) $state['install_id'] : '',
			'license_key'     => isset( $state['license_key'] ) ? (string) $state['license_key'] : '',
			'license_key_masked' => isset( $state['license_key_masked'] ) ? (string) $state['license_key_masked'] : '',
			'license_source'  => isset( $state['license_source'] ) ? (string) $state['license_source'] : 'legacy',
			'key_status'      => isset( $state['key_status'] ) ? (string) $state['key_status'] : '',
			'last_check_at'   => ! empty( $state['last_check_at'] ) ? absint( $state['last_check_at'] ) : 0,
			'last_success_at' => ! empty( $state['last_success_at'] ) ? absint( $state['last_success_at'] ) : 0,
			'last_error'      => ! empty( $state['last_error'] ) ? (string) $state['last_error'] : '',
			'validated_once'  => ! empty( $state['validated_once'] ),
			'api_base_url'    => $this->get_api_base_url(),
			'is_active'       => 'approved' === $license_status,
			'can_request'     => 'approved' !== $license_status,
		);
	}

	/**
	 * Build the JSON payload for the remote licensing server.
	 *
	 * @param array  $state   Current state.
	 * @param string $context Context label.
	 * @return array
	 */
	protected function build_request_payload( array $state, $context ) {
		return array(
			'install_id'      => isset( $state['install_id'] ) ? (string) $state['install_id'] : '',
			'license_key'     => isset( $state['license_key'] ) ? (string) $state['license_key'] : '',
			'home_url'        => home_url(),
			'site_url'        => site_url(),
			'normalized_domain' => $this->get_normalized_domain(),
			'plugin_version'  => RSPD_VERSION,
			'wp_version'      => get_bloginfo( 'version' ),
			'php_version'     => PHP_VERSION,
			'status'          => isset( $state['license_status'] ) ? (string) $state['license_status'] : 'unregistered',
			'lease_token'     => isset( $state['lease_token'] ) ? (string) $state['lease_token'] : '',
			'context'         => sanitize_key( $context ),
			'requested_at'    => time(),
		);
	}

	/**
	 * Get the normalized current domain.
	 *
	 * @return string
	 */
	public function get_normalized_domain() {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$host = is_string( $host ) ? strtolower( trim( $host ) ) : '';

		if ( 0 === strpos( $host, 'www.' ) ) {
			$host = substr( $host, 4 );
		}

		return $host;
	}

	/**
	 * Get the base API URL.
	 *
	 * @return string
	 */
	public function get_api_base_url() {
		$settings = $this->get_settings();

		return isset( $settings['api_base_url'] ) ? untrailingslashit( esc_url_raw( $settings['api_base_url'] ) ) : '';
	}

	/**
	 * Get the request/check endpoint URL.
	 *
	 * @param string $type Endpoint type.
	 * @return string
	 */
	public function get_endpoint_url( $type ) {
		$settings  = $this->get_settings();
		$base_url  = $this->get_api_base_url();
		$field_key = 'request' === $type ? 'request_endpoint' : 'check_endpoint';
		$endpoint  = isset( $settings[ $field_key ] ) ? trim( (string) $settings[ $field_key ] ) : '';

		if ( '' === $base_url || '' === $endpoint ) {
			return '';
		}

		return trailingslashit( $base_url ) . ltrim( $endpoint, '/' );
	}

	/**
	 * Get the check interval in seconds.
	 *
	 * @return int
	 */
	public function get_check_interval() {
		$settings = $this->get_settings();
		$interval = isset( $settings['check_interval'] ) ? absint( $settings['check_interval'] ) : 15 * MINUTE_IN_SECONDS;

		return max( 60, $interval );
	}

	/**
	 * Get the approved-site outage grace period in seconds.
	 *
	 * @return int
	 */
	public function get_grace_period() {
		$settings = $this->get_settings();
		$period   = isset( $settings['grace_period'] ) ? absint( $settings['grace_period'] ) : DAY_IN_SECONDS;

		return max( HOUR_IN_SECONDS, $period );
	}
}
