=== Reputifly Static Page Deployer ===
Contributors: reputifly
Tags: static html, deployment, landing pages, seo, performance
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.10.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Deploy trusted static HTML/CSS/JS pages onto real WordPress page URLs with plugin-owned blank templates that bypass theme wrappers.

== Description ==

Reputifly Static Page Deployer is a private internal-use agency plugin built for one narrow job: take already-coded static pages and render them on real WordPress page permalinks as close to 1:1 as possible, without letting the active theme inject headers, footers, wrappers, spacing, or unrelated frontend junk.

It is not a page builder.
It is not Elementor.
It is not a shortcode wrapper.
It does not use iframes for production rendering.

Production rendering works by:

1. Assigning a deployment to a real WordPress page.
2. Preprocessing the imported HTML into a stored render bundle.
3. Rewriting local asset references into the plugin upload area.
4. Intercepting that page on the frontend.
5. Serving a plugin-owned isolated template instead of the theme layout.

== Installation ==

1. Upload the plugin ZIP in WordPress at Plugins > Add New > Upload Plugin.
2. Activate Reputifly Static Page Deployer.
3. Open Reputifly Deploy in the WordPress admin menu.
4. Go to Deploy.
5. Select an existing WordPress page.
6. Paste a full HTML document / fragment or upload a ZIP / HTML package.
7. Save the deployment.
8. Open the page permalink and verify the plugin-owned output.

== Activation ==

Activation creates a plugin-specific uploads folder at:

`wp-content/uploads/reputifly-static-page-deployer/`

Inside that folder the plugin stores:

- deployment packages
- rewritten local asset references
- render bundles
- upload-area hardening files such as `.htaccess`, `web.config`, and `index.html`

No theme files are modified. Deactivation safely restores normal WordPress theme rendering because the page interception only runs while the plugin is active.

== How To Deploy A Page ==

1. Create or choose an existing WordPress page.
2. Open Reputifly Deploy > Deploy.
3. Select the WordPress page.
4. Enable static override mode.
5. Choose one import method:

Paste Combined Code:
- Paste a full HTML document with `doctype`, `html`, `head`, and `body`, or a fragment.
- Fragments are wrapped in a valid document shell.

Upload ZIP / HTML:
- Upload a ZIP containing `index.html` and local assets, or a standalone `.html` file.
- Choose the entry HTML file if the ZIP contains more than one.
- Relative local assets are rewritten to the deployment folder URL.

6. Choose Full Isolation or Compatibility mode.
7. Save.
8. Visit the page permalink.

== Isolation Mode ==

Full Isolation Mode is the default and the recommended production mode.

It does not call the theme header or footer.
It does not render inside the theme content area.
It does not rely on the WordPress content editor output.
It does not inherit theme wrapper markup.

This is the primary mechanism that keeps imported pages close to their original static rendering.

Compatibility Mode still uses the plugin-owned template, but can optionally run `wp_head()` and `wp_footer()` if you need a specific integration.

== Metadata Overrides ==

The plugin parses imported head metadata when available, including:

- title
- meta description
- canonical
- robots
- Open Graph tags
- Twitter card tags
- viewport
- charset
- JSON-LD blocks

Per-page metadata fields in the plugin can override imported values.
If fields are left blank, imported values can be preserved or replaced by plugin defaults depending on your settings.

== Asset Rewriting ==

Uploaded package assets are stored in the WordPress uploads directory under a deployment-specific folder.

Relative references such as:

- `style.css`
- `./images/hero.webp`
- `../fonts/site.woff2`

are rewritten to deployment URLs so they still resolve correctly when the final page is rendered on the WordPress permalink.

The system also:

- fingerprints local asset URLs when enabled
- detects missing local asset references
- keeps assets local for better cacheability and performance

Links to other `.html` files inside the uploaded package are intentionally not auto-remapped to WordPress pages in V1 unless they target the same entry file. Use real WordPress permalinks or map those pages manually.

== Performance Recommendations ==

For best results:

1. Use Full Isolation mode unless you specifically need compatibility hooks.
2. Keep imported pages server-rendered and crawlable without client-side bootstrapping critical content.
3. Upload self-hosted fonts rather than pulling remote font CDNs.
4. Use WebP or AVIF images where practical.
5. Set the hero image preload field for obvious LCP images.
6. Turn on asset fingerprinting for long-lived browser caching.
7. Keep third-party scripts minimal.
8. Use server-side Brotli or Gzip compression.
9. Put WordPress behind a page cache or reverse proxy where appropriate.

== Server Recommendations ==

For maximum speed:

- enable Brotli or Gzip compression
- enable HTTP/2 or HTTP/3
- serve the uploads directory with far-future cache headers for versioned assets
- use OPcache
- keep PHP current
- use a real page cache / reverse proxy if your stack supports it

The plugin itself keeps frontend PHP overhead low by preprocessing deployments into stored render bundles and using a very small runtime path on managed pages.

== Diagnostics ==

The Diagnostics screen reports:

- HTML size
- local asset count
- whether title / description / canonical exist
- missing local asset references
- whether lazy loading, hero preload, deferred scripts, and cache are enabled

If debug iframe preview mode is enabled in settings, the Diagnostics screen can show the raw uploaded entry file in an admin-only iframe. This mode is never used for production rendering.

== Uninstall Behavior ==

By default the plugin keeps deployment data on uninstall.

If you enable "Delete deployment data on uninstall" in Settings, uninstall will remove:

- plugin settings
- page deployment mappings
- stored render bundles
- uploaded deployment folders

== Caveats And Limitations ==

- V1 is optimized for high-quality single-page deployment.
- Links to other HTML files inside uploaded packages are not bulk-mapped into WordPress pages automatically.
- Inline JavaScript minification is intentionally conservative.
- Compatibility mode can reintroduce third-party or SEO plugin output because it allows WordPress hooks by design.

== Changelog ==

= 1.10.7 =
- Restore the premium admin UI on the new Reputifly menu screens by loading the plugin CSS/JS for the new menu slug and matching the updated WordPress screen classes.

= 1.10.6 =
- Fix a PHP parse error in the admin settings screen that was causing activation to fatal before the sidebar menu could register.

= 1.10.5 =
- Fix the bootstrap safety guard so the admin sidebar and plugin menu still register normally on sites without an active duplicate Reputifly copy.

= 1.10.4 =
- Use a safer unique WordPress admin menu slug so the Reputifly sidebar appears reliably.
- Auto-refresh licensing during normal admin requests so new installs show up in the superadmin dashboard.

= 1.10.3 =
- Prevent activation fatals when an older duplicate Reputifly plugin folder is still active.
- Keep the licensing flow locked until approval with the simplified request-access UI.

= 1.10.2 =
- Simplify licensing UI to an active/not active access gate with request access flow.
- Hide backend endpoint controls from WordPress and lock plugin features until approved.
- Refresh the hosted Firebase dashboard to a simpler login-first access console.

= 1.10.1 =
- Default the initial request flow to the live `licenseCheck` endpoint so pending approval works out of the box.

= 1.10.0 =
- Add Firebase-backed licensing hooks with manual approval, hard revoke, and managed-page lockout support.
- Add a companion Firebase backend scaffold and approval dashboard.

= 1.9.12 =
- Restore a stable plugin ZIP root for WordPress-friendly install and update behavior.
- Keep nested duplicate plugin folders out of the release package.

= 1.0.0 =
- Initial release.
