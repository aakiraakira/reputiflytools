<?php
/**
 * Plugin Name: Reputifly Static Page Deployer
 * Plugin URI:  https://reputifly.com
 * Description: Deploy trusted static HTML/CSS/JS pages onto real WordPress page URLs with theme-bypassing isolated templates.
 * Version:     1.18.3
 * Author:      Reputifly
 * Author URI:  https://reputifly.com
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: reputifly-static-page-deployer
 * Update URI:  https://reputifly.com/plugins/reputifly-static-page-deployer
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Deactivate conflicting active copies of the plugin that use a different folder slug.
 *
 * This prevents class redeclaration fatals during the one-time transition away from
 * older versioned plugin folders such as `reputifly-static-page-deployer-199/...`.
 *
 * @return array
 */
function rspd_deactivate_conflicting_copies() {
	$current_basename = plugin_basename( __FILE__ );
	$active_plugins   = function_exists( 'get_option' ) ? (array) get_option( 'active_plugins', array() ) : array();
	$conflicts        = array();

	foreach ( $active_plugins as $plugin_file ) {
		$plugin_file = (string) $plugin_file;

		if ( $plugin_file === $current_basename ) {
			continue;
		}

		if ( preg_match( '#(^|/)reputifly-static-page-deployer[^/]*/reputifly-static-page-deployer\.php$#i', $plugin_file ) ) {
			$conflicts[] = $plugin_file;
		}
	}

	if ( ! empty( $conflicts ) && function_exists( 'deactivate_plugins' ) ) {
		deactivate_plugins( $conflicts, true );

		add_action(
			'admin_notices',
			static function () {
				echo '<div class="notice notice-warning"><p><strong>Reputifly Static Page Deployer</strong> deactivated an older duplicate plugin copy to prevent an activation crash. You can now remove the old versioned copy from Plugins.</p></div>';
			}
		);
	}

	return $conflicts;
}

$rspd_conflicting_copies = rspd_deactivate_conflicting_copies();

if ( ! empty( $rspd_conflicting_copies ) ) {
	return;
}

// Bail early if PHP version is too old.
if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-error"><p><strong>Reputifly Static Page Deployer</strong> requires PHP 7.4 or newer. Your server is running PHP ' . esc_html( PHP_VERSION ) . '.</p></div>';
	} );
	return;
}

define( 'RSPD_VERSION', '1.18.3' );
define( 'RSPD_PLUGIN_FILE', __FILE__ );
define( 'RSPD_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'RSPD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'RSPD_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

require_once RSPD_PLUGIN_PATH . 'includes/class-rspd-security.php';
require_once RSPD_PLUGIN_PATH . 'includes/class-rspd-storage.php';
require_once RSPD_PLUGIN_PATH . 'includes/class-rspd-performance.php';
require_once RSPD_PLUGIN_PATH . 'includes/class-rspd-license.php';
require_once RSPD_PLUGIN_PATH . 'includes/class-rspd-metadata.php';
require_once RSPD_PLUGIN_PATH . 'includes/class-rspd-deployer.php';
require_once RSPD_PLUGIN_PATH . 'includes/class-rspd-renderer.php';
require_once RSPD_PLUGIN_PATH . 'includes/class-rspd-admin.php';
require_once RSPD_PLUGIN_PATH . 'includes/class-rspd-agent-auth.php';
require_once RSPD_PLUGIN_PATH . 'includes/class-rspd-agentic-ai.php';

/**
 * Main plugin singleton container.
 */
final class RSPD_Plugin {

	/** @var RSPD_Plugin|null */
	private static $instance = null;

	/** @var RSPD_Security */
	private $security;

	/** @var RSPD_Storage */
	private $storage;

	/** @var RSPD_Performance */
	private $performance;

	/** @var RSPD_Metadata */
	private $metadata;

	/** @var RSPD_License */
	private $license;

	/** @var RSPD_Deployer */
	private $deployer;

	/** @var RSPD_Renderer */
	private $renderer;

	/** @var RSPD_Admin|null */
	private $admin = null;

	/** @var RSPD_Agent_Auth */
	private $agent_auth;

	/** @var RSPD_Agentic_AI */
	private $agentic_ai;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->security    = new RSPD_Security();
		$this->storage     = new RSPD_Storage( $this->security );
		$this->performance = new RSPD_Performance( $this->security, $this->storage );
		$this->license     = new RSPD_License( $this->storage, $this->security );
		$this->metadata    = new RSPD_Metadata( $this->security, $this->performance );
		$this->deployer    = new RSPD_Deployer( $this->storage, $this->security, $this->metadata, $this->performance );
		$this->renderer    = new RSPD_Renderer( $this->storage, $this->performance, $this->license );
		$this->agent_auth  = new RSPD_Agent_Auth( $this->storage, $this->security );
		$this->agentic_ai  = new RSPD_Agentic_AI( $this->storage, $this->security, $this->deployer, $this->license, $this->agent_auth );

		if ( is_admin() ) {
			$this->admin = new RSPD_Admin( $this->storage, $this->security, $this->deployer, $this->license );
		}

		// Rebuild deployments when a deployed page's slug changes so link maps stay current.
		add_action( 'post_updated', array( $this, 'maybe_rebuild_on_slug_change' ), 10, 3 );
	}

	/**
	 * If a deployed page's slug (post_name) changed, rebuild all deployments.
	 *
	 * @param int     $post_id     Post ID.
	 * @param WP_Post $post_after  Post object after update.
	 * @param WP_Post $post_before Post object before update.
	 */
	public function maybe_rebuild_on_slug_change( $post_id, $post_after, $post_before ) {
		if ( 'page' !== $post_after->post_type ) {
			return;
		}

		// Only act if slug actually changed.
		if ( $post_after->post_name === $post_before->post_name ) {
			return;
		}

		// Only if this page has a deployment.
		$config = $this->storage->get_page_config( $post_id );
		if ( empty( $config ) || empty( $config['enabled'] ) ) {
			return;
		}

		$this->deployer->rebuild_all_deployments();
	}

	/**
	 * Plugin activation callback.
	 */
	public static function activate() {
		$security = new RSPD_Security();
		$storage  = new RSPD_Storage( $security );
		$license  = new RSPD_License( $storage, $security );
		$storage->ensure_base_structure();

		if ( false === get_option( RSPD_Storage::SETTINGS_OPTION ) ) {
			$storage->update_settings( $storage->get_default_settings() );
		}

		$license->activate();
		add_rewrite_rule(
			'^reputifly-static-assets/([0-9]+)/?(.*)$',
			'index.php?rspd_asset_page=$matches[1]&rspd_asset_path=$matches[2]',
			'top'
		);
		flush_rewrite_rules( false );
		update_option( 'rspd_asset_route_version', RSPD_VERSION, false );
	}

	/**
	 * Plugin deactivation callback. Clears render caches but preserves data.
	 */
	public static function deactivate() {
		$security = new RSPD_Security();
		$storage  = new RSPD_Storage( $security );
		$license  = new RSPD_License( $storage, $security );

		$license->deactivate();

		$page_map = get_option( RSPD_Storage::PAGE_MAP_OPTION, array() );
		if ( ! is_array( $page_map ) || empty( $page_map ) ) {
			return;
		}
		foreach ( array_keys( $page_map ) as $page_id ) {
			delete_transient( 'rspd_render_' . absint( $page_id ) );
		}

		flush_rewrite_rules( false );
	}

	public function security()    { return $this->security; }
	public function storage()     { return $this->storage; }
	public function performance() { return $this->performance; }
	public function license()     { return $this->license; }
	public function metadata()    { return $this->metadata; }
	public function deployer()    { return $this->deployer; }
	public function renderer()    { return $this->renderer; }
}

/**
 * Return the plugin singleton.
 *
 * @return RSPD_Plugin
 */
function rspd() {
	return RSPD_Plugin::instance();
}

register_activation_hook( __FILE__, array( 'RSPD_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'RSPD_Plugin', 'deactivate' ) );

rspd();
