<?php
/**
 * Frontend template shown when licensing disables managed pages.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$license = rspd()->license()->get_status_context();

status_header( 403 );
nocache_headers();
?>
<!doctype html>
<html lang="<?php echo esc_attr( str_replace( '_', '-', get_locale() ) ); ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php esc_html_e( 'Reputifly License Inactive', 'reputifly-static-page-deployer' ); ?></title>
	<style>
		body {
			margin: 0;
			font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
			background: radial-gradient(circle at top, #1f1530 0%, #09070f 55%, #050409 100%);
			color: #f4f2fb;
			min-height: 100vh;
			display: flex;
			align-items: center;
			justify-content: center;
			padding: 24px;
		}
		.rspd-license-block {
			max-width: 720px;
			width: 100%;
			background: rgba(19, 16, 31, 0.86);
			border: 1px solid rgba(255, 255, 255, 0.08);
			border-radius: 24px;
			padding: 32px;
			box-shadow: 0 30px 80px rgba(0, 0, 0, 0.4);
			backdrop-filter: blur(24px);
		}
		.rspd-license-kicker {
			display: inline-flex;
			align-items: center;
			gap: 8px;
			padding: 8px 12px;
			border-radius: 999px;
			background: rgba(248, 113, 113, 0.14);
			color: #fca5a5;
			font-size: 12px;
			font-weight: 700;
			letter-spacing: 0.08em;
			text-transform: uppercase;
		}
		h1 {
			font-size: clamp(30px, 5vw, 48px);
			line-height: 1.02;
			margin: 20px 0 14px;
		}
		p {
			color: rgba(255, 255, 255, 0.7);
			line-height: 1.7;
			font-size: 16px;
			margin: 0 0 22px;
		}
		.rspd-license-meta {
			display: grid;
			grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
			gap: 12px;
			margin-top: 24px;
		}
		.rspd-license-meta-item {
			padding: 16px 18px;
			border-radius: 18px;
			background: rgba(255, 255, 255, 0.03);
			border: 1px solid rgba(255, 255, 255, 0.06);
		}
		.rspd-license-label {
			display: block;
			font-size: 11px;
			text-transform: uppercase;
			letter-spacing: 0.08em;
			color: rgba(255, 255, 255, 0.45);
			margin-bottom: 8px;
		}
		.rspd-license-value {
			font-size: 14px;
			font-weight: 600;
			word-break: break-word;
		}
	</style>
</head>
<body>
	<div class="rspd-license-block">
		<div class="rspd-license-kicker"><?php echo esc_html( $license['label'] ); ?></div>
		<h1><?php esc_html_e( 'This Reputifly page is currently disabled.', 'reputifly-static-page-deployer' ); ?></h1>
		<p><?php echo esc_html( $license['message'] ); ?></p>
		<div class="rspd-license-meta">
			<div class="rspd-license-meta-item">
				<span class="rspd-license-label"><?php esc_html_e( 'Domain', 'reputifly-static-page-deployer' ); ?></span>
				<span class="rspd-license-value"><?php echo esc_html( $license['domain'] ); ?></span>
			</div>
			<div class="rspd-license-meta-item">
				<span class="rspd-license-label"><?php esc_html_e( 'Install ID', 'reputifly-static-page-deployer' ); ?></span>
				<span class="rspd-license-value"><?php echo esc_html( $license['install_id'] ); ?></span>
			</div>
		</div>
	</div>
</body>
</html>
