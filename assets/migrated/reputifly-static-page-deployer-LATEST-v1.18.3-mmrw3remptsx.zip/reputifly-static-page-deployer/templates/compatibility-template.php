<?php
/**
 * Compatibility frontend template.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$context = rspd()->renderer()->get_compatibility_context();

if ( empty( $context ) ) {
	return;
}
echo $context['doctype']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
?>
<html <?php echo $context['html_attrs']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
<head>
<?php echo $context['head_html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
<?php if ( ! empty( $context['allow_wp_head'] ) ) : ?>
<?php wp_head(); ?>
<?php endif; ?>
</head>
<body <?php echo $context['body_attrs']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
<?php echo $context['body_html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
<?php if ( ! empty( $context['allow_wp_footer'] ) ) : ?>
<?php wp_footer(); ?>
<?php endif; ?>
</body>
</html>
