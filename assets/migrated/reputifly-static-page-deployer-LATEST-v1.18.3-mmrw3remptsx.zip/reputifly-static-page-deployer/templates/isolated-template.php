<?php
/**
 * Fully isolated frontend template.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

echo rspd()->renderer()->render_isolated_page();
