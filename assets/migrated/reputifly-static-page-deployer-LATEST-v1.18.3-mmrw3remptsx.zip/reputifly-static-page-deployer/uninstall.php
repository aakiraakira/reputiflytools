<?php
/**
 * Plugin uninstall routine.
 *
 * @package Reputifly_Static_Page_Deployer
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$settings = get_option( 'rspd_settings', array() );

if ( empty( $settings['data']['remove_on_uninstall'] ) ) {
	return;
}

$pages = get_posts(
	array(
		'post_type'      => 'page',
		'post_status'    => 'any',
		'posts_per_page' => -1,
		'meta_key'       => '_rspd_config',
		'fields'         => 'ids',
	)
);

if ( is_array( $pages ) ) {
	foreach ( $pages as $page_id ) {
		delete_post_meta( $page_id, '_rspd_config' );
		delete_transient( 'rspd_render_' . absint( $page_id ) );
	}
}

delete_option( 'rspd_page_map' );
delete_option( 'rspd_settings' );
delete_option( 'rspd_license_state' );

$upload_dir = wp_upload_dir();
$base_dir   = wp_normalize_path( trailingslashit( $upload_dir['basedir'] ) . 'reputifly-static-page-deployer' );

if ( is_dir( $base_dir ) ) {
	$iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $base_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);

	foreach ( $iterator as $file_info ) {
		if ( $file_info->isDir() ) {
			rmdir( $file_info->getPathname() );
		} else {
			unlink( $file_info->getPathname() );
		}
	}

	rmdir( $base_dir );
}
